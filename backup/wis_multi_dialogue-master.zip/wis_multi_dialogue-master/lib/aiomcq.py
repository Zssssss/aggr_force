import asyncio
import random
import time

import aiodns
import aiomcache


class dns:
    __DNSResolver = None

    def __init__(self):
        if self.__DNSResolver is None:
            self.__DNSResolver = aiodns.DNSResolver()

    async def resolve(self, domain):
        ips = []
        try:
            result = await self.__DNSResolver.query(domain, "A")
            for record in result:
                ips.append(record.host)

        except aiodns.error.DNSError as e:
            print(f"DNS 查询出错: {e}")
        return ips


class mcq_cli:

    def __init__(self, domain: str = None, port: int = 11233):
        self.__domain = domain
        self.__port = port
        self.__conns = {}
        self.__ips = []
        self.__checktime = 0
        self.__check_gap = 30
        self.__get_cursor = None
        self.__set_cursor = None

    async def __resolve(self):
        now = time.time()
        if now - self.__checktime > self.__check_gap:
            self.__checktime = now
            ips = await dns().resolve(self.__domain)
            conn_ips = self.__conns.keys()
            ips = sorted(ips)
            self.__ips = ips
            new_ips = set(ips) - set(conn_ips)
            invalid_ips = set(conn_ips) - set(ips)
            len(new_ips) > 0 and self.__connect(new_ips)
            len(invalid_ips) > 0 and await self.__disconnect(invalid_ips)
            self.__get_cursor = (
                self.__get_cursor
                if self.__get_cursor is not None
                else random.randint(0, len(self.__ips) - 1)
            )
            self.__set_cursor = (
                self.__set_cursor
                if self.__set_cursor is not None
                else random.randint(0, len(self.__ips) - 1)
            )

    def __connect(self, ips):
        for ip in ips:
            self.__conns[ip] = aiomcache.Client(
                ip, self.__port, pool_minsize=1, pool_size=2
            )

    async def __disconnect(self, ips):
        for ip in ips:
            await self.__conns[ip].close()
            del self.__conns[ip]

    async def get(self, key):
        trytimes = 0
        await self.__resolve()
        while trytimes < len(self.__ips):
            self.__get_cursor = (self.__get_cursor + 1) % len(self.__ips)
            trytimes += 1
            target_ip = self.__ips[self.__get_cursor]
            if target_ip in self.__conns:
                try:
                    value = await self.__conns[target_ip].get(key.encode())
                    if value is not None:
                        return value
                except ValueError as e:
                    print(e)
        return None

    async def set(self, key: str = None, value: str = None, hash_key: str = None):
        await self.__resolve()
        if hash_key is None:
            self.__set_cursor = (self.__set_cursor + 1) % len(self.__ips)
            if self.__ips[self.__set_cursor] in self.__conns:
                return await self.__conns[self.__ips[self.__set_cursor]].set(
                    key.encode(), value.encode()
                )
        return False


async def test():
    mcq_obj = mcq_cli(domain="fe.queue.search.weibo.com", port=11233)
    for i in range(10):
        print(await mcq_obj.get("zs_zhijie_reply"))

