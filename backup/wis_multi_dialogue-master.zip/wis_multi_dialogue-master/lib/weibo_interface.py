# -*- coding: utf-8 -*-
import json
import os
import time

import aiohttp
import requests
from fontTools import unicodedata


def token_loader(token_file):
    token_update_time_sec = int(os.path.getmtime(token_file))
    token = open(token_file).readline().strip()

    def wrapper():
        nonlocal token
        nonlocal token_update_time_sec
        now_sec = int(time.time())
        if now_sec - token_update_time_sec > 3600:
            token = open(token_file).readline().strip()
            token_update_time_sec = now_sec
        return token
    return wrapper


load_c_token = token_loader(r'/data1/minisearch/upload/token/c_token_file')


def get_c_token():
    token_str = load_c_token()
    piece = token_str.split(':')
    return {piece[0].strip(): piece[1].strip()}


def http_get_json_with_c_token(url):
    MAX_RETRY = 3
    retry = 0
    json_res = None
    while True:
        try:
            headers = get_c_token()
            json_res = requests.get(url=url, headers=headers, timeout=5).json()
        except Exception as e:
            retry = retry + 1
            time.sleep(0.1)
            if retry < MAX_RETRY:
                continue
        break
    return json_res


async def async_http_get_json_with_c_token(url):
    MAX_RETRY = 2
    retry = 0
    json_res = None
    while True:
        try:
            headers = get_c_token()
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(1)) as session:
                async with session.get(url=url, headers=headers) as r:
                    json_res = await r.json()
        except Exception as e:
            retry = retry + 1
            time.sleep(0.1)
            if retry < MAX_RETRY:
                continue
        break
    return json_res


def checkQualifiedOcrText(text):
    """
    检查字符串中文字符占比是否超过70%且中文字符数量是否超过150
    使用更完整的中文Unicode范围检测

    参数:
    text (str): 需要检查的字符串

    返回:
    chinese_count (int): 中文字符数量
    chinese_ratio (float): 中文字符占比
    qualified (bool): 是否满足条件
    """
    if not text:
        return False
    # 计算中文字符数量
    chinese_count = 0
    total_chars = 0

    for char in text:
        # 忽略空白字符
        if char.isspace():
            continue
        total_chars += 1
        try:
            name = unicodedata.name(char)
            # print name
        except ValueError:
            continue
        # 检查是否是中文字符 (更完整的Unicode范围)
        if 'CJK' in name or 'HAN' in name:
            chinese_count += 1

        # 防止除以零
    if total_chars == 0:
        return False
    # 计算中文字符比例
    chinese_ratio = chinese_count / float(total_chars)
    # 判断是否满足条件
    # return chinese_ratio >= 0.7 and chinese_count > 150

    # 中文占比>=60% & 中文长度>150 或 中文占比>=70% & 中文长度>100，满足其一即可入库。
    return (chinese_ratio >= 0.6 and chinese_count > 150) or (chinese_ratio >= 0.7 and chinese_count > 100)


async def get_user_info(mid):
    name = ""
    uid = ""
    pub_time = ""
    try:
        bowen_url = "http://i2.api.weibo.com/2/render/statuses/show_batch.json?source=2936099636&ids={}".format(mid)
        bowen_res = await async_http_get_json_with_c_token(bowen_url)
        uid = bowen_res["statuses"][0].get("user", {}).get("idstr", "")
        name = bowen_res["statuses"][0].get("user", {}).get("name", "")

        tmp_time = time.localtime((int(mid) >> 22) + 515483463)
        pub_time = time.strftime("%Y-%m-%d %H:%M:%S", tmp_time)
    except:
        pass
    return name, uid, pub_time


async def get_voice(mid):
    query = ""
    voices = ""
    uid = ""
    try:
        bowen_url = "http://i2.api.weibo.com/2/render/statuses/show_batch.json?source=2936099636&ids={}".format(mid)
        bowen_res = await async_http_get_json_with_c_token(bowen_url)
        media_id = bowen_res["statuses"][0].get("page_info",{}).get("media_info",{}).get("media_id","")
        uid = bowen_res["statuses"][0].get("user", {}).get("idstr","")
        text = bowen_res["statuses"][0].get('text', "")
        long_text = bowen_res["statuses"][0].get('longText', {}).get("longTextContent", "")
        query = long_text if long_text else text
        if media_id:
            video_url = "http://i.media.api.weibo.com/2/media/asr.json?source=2936099636&media_id={}".format(media_id)
            video_res = await async_http_get_json_with_c_token(video_url)
            voices = "\t".join([o.get('text', '') for o in video_res['result']['sentences']])
            return query, voices, uid
    except:
        pass
    return query, voices, uid

def fetch_mblog_features(mids, fids=['10421','10484']):
    step = 100
    ans = {}
    for smids in [mids[i:i + step] for i in range(0, len(mids), step)]:
        fids_str = ",".join(map(str, fids))
        smids_str = ",".join(map(str, smids))
        url = f"http://i.ai.weibo.com/feature/mblog/query.json?source=2936099636&fids={fids_str}&mids={smids_str}"
        json_res = http_get_json_with_c_token(url)
        if json_res is None:
            continue
        ans.update(json_res.get('data', {})
                   if json_res.get('code', 1) == 0 else {})
    return ans


def get_article_content(obj_id):
    res = http_get_json_with_c_token('http://i2.api.weibo.com/2/entity/show.json?source=2936099636&object_id=1022:{}'.format(obj_id))
    if isinstance(res, dict):
        content = res.get('entity',{}).get('content')
    else:
        content = ''
    return content


def fetch_user_showbatch(uids):
    step = 20
    ans = {}
    for suids in [uids[i:i + step] for i in range(0, len(uids), step)]:
        suids_str = ",".join(map(str, suids))
        url = f'http://i2.api.weibo.com/users/show_batch.json?source=2936099636&uids={suids_str}'
        json_res = http_get_json_with_c_token(url)
        if json_res is None:
            print(f'Fail to request {url}')
            continue
        for user in json_res.get('users', []):
            ans[user['idstr']] = user
    return ans

