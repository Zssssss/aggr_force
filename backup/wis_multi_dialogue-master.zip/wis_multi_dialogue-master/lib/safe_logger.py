# -*- coding:utf-8 -*-
import logging
from collections import OrderedDict
from concurrent_log_handler import ConcurrentTimedRotatingFileHandler
import os
import threading

# 日志配置相关
logger_lock = threading.Lock()
logger_pool = OrderedDict()
log_dir = "log"
os.makedirs(log_dir, exist_ok=True)
error_log_path = os.path.join(log_dir, "error.log")


def create_handler(log_path: str, level: int):
    handler = ConcurrentTimedRotatingFileHandler(
        filename=log_path,
        when='midnight',
        backupCount=3,
        encoding='utf-8'
    )
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)8s | %(module)s:%(lineno)d | %(module_name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    handler.setLevel(level)
    return handler


def get_logger(logger_filename, module_name):
    with logger_lock:
        key = f"{logger_filename}###{module_name}"
        if key in logger_pool:
            logger = logger_pool[key]
            return logger

        logger_instance = logging.getLogger(key)
        logger_instance.setLevel(logging.INFO)
        logger_instance.propagate = False

        main_handler = create_handler(logger_filename, logging.INFO)
        error_handler = create_handler(error_log_path, logging.ERROR)
        logger_instance.addHandler(main_handler)
        logger_instance.addHandler(error_handler)

        class ModuleNameFilter(logging.Filter):
            def filter(self, record):
                record.module_name = module_name
                return True

        logger_instance.addFilter(ModuleNameFilter())
        logger_pool[key] = logger_instance
        return logger_instance