
import os
import hashlib
from ctypes import cdll, c_ulonglong

from redis import asyncio as aioredis

TIME_OUT = 3
HEALTH_CHECK_INTERVAL = 1

curdir = os.path.dirname(os.path.realpath(__file__))
lib_handle = cdll.LoadLibrary(curdir + '/libcrc.so')
RunCRC64 = lib_handle.RunCRC64
RunCRC64.restype = c_ulonglong


class AsyncRedisConnect:

    def __init__(self):
        self.servers = []
        self.hosts =  [
            'pkm26754.eos.grid.sina.com.cn',
            'pkm26755.eos.grid.sina.com.cn',
            'pkm26756.eos.grid.sina.com.cn',
            'pkm26757.eos.grid.sina.com.cn',
            'pkm26758.eos.grid.sina.com.cn',
            'pkm26759.eos.grid.sina.com.cn',
            'pkm26760.eos.grid.sina.com.cn',
            'pkm26761.eos.grid.sina.com.cn'
        ]
        self.ports = [26754, 26755, 26756, 26757, 26758, 26759, 26760, 26761]
        self.load_conn_pools()

    def load_conn_pools(self):
        for i in range(len(self.hosts)):
            redis_client = aioredis.Redis(host=self.hosts[i], port=self.ports[i], socket_timeout=TIME_OUT, decode_responses=True, 
                                          health_check_interval=HEALTH_CHECK_INTERVAL, 
                                          retry_on_timeout=True)
            self.servers.append(redis_client)

    def get_hash_index(self, query):
        md5 = hashlib.md5()
        md5.update(query.encode(encoding='utf-8'))
        m = md5.hexdigest()
        map_key = str(m)[-2:]
        return int(map_key, 16) % 8


    def get_redis_server(self, query):
        index = self.get_hash_index(query)
        return self.servers[index]

    async def close(self):
        for client in self.servers:
            try:
               await client.aclose(True)
            except Exception:
                pass


async_redis_client = AsyncRedisConnect()

if __name__ == "__main__":
    pass
