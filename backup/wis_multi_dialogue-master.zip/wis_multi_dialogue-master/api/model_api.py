"""大模型相关api接口"""
import asyncio
import base64
import hashlib
import hmac
import os
import random
import time
import re
import urllib.parse
from hashlib import sha1
from datetime import datetime
import json

import aiohttp

from api.base_api import BaseApi
from api.config import DEEPSEEK_DEFAULT_APPKEY, DEEPSEEK_APPKEYS, DEEPSEEK_AIGC_URL, DEEPSEEK_DEFAULT_MODELID

def md5_hash(query):
    return hashlib.md5(query.encode()).hexdigest()


def get_bucket_id(md5_str, bucket_num=100):
    # 方法1：将MD5字符串转换为整数后取模
    hash_int = int(md5_str, 16)
    return hash_int % bucket_num

def token_loader(token_file):
    def read_token():
        try:
            with open(token_file, "r") as f:
                return f.readline().strip()
        except FileNotFoundError:
            print(f"token 文件不存在")
            return ""  # 处理文件不存在的情况
        except Exception as e:
            print(f"读取 token 文件出错: {e}")
            return ""

    token_update_time_sec = int(os.path.getmtime(token_file))
    token = read_token()

    def wrapper():
        nonlocal token
        nonlocal token_update_time_sec
        now_sec = int(time.time())
        if now_sec - token_update_time_sec > 3600:
            new_token = read_token()
            if new_token:
                token = new_token
                token_update_time_sec = now_sec
        return token

    return wrapper


load_tauth_token = token_loader(
    r'/data1/minisearch/upload/token/tauth_token_file')


def get_tauth_token(uid):
    token_str = load_tauth_token()
    token_obj = json.loads(token_str)
    tauth_token = token_obj['tauth_token']
    tauth_token_secret = token_obj['tauth_token_secret']
    param = f"uid={uid}"
    sign_hmac = hmac.new(tauth_token_secret.encode(),
                         param.encode(), hashlib.sha1).digest()
    sign_base64 = base64.b64encode(sign_hmac).decode()
    sign = urllib.parse.urlencode({"sign": sign_base64})[5:]
    return {
        r'Authorization': f'TAuth2 token="{urllib.parse.quote(tauth_token)}", param="{urllib.parse.quote(param)}", sign="{sign}"',
        "Content-Type": "application/json"
    }


class WeiboDeepseekWrapper(BaseApi):
    def __init__(self, pid, pre_log_msg, llm_call_stage="", chat_check_info={}):
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage
        self.chat_check_info = chat_check_info

    async def async_stream_post2(self, url, api_name, params, data, headers=None, timeout=None, retry=2):
        """协程发送post请求，并记录日志"""
        prompt = data
        start = time.time()
        if headers is None:
            headers = self.default_headers

        content_str = ""
        reasoning_content_str = ""
        merge_result = ""
        error_info = ""
        error_code = ""
        result = {}
        first_result = None
        final_result = None
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url, headers=headers, params=params, data=prompt) as res:
                        first_result = res
                        error_code = res.status
                        if res.status == 200:
                            data = bytearray()
                            async for chunk in res.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        final_result = dict_text

                                        result = final_result.get('response_data', {})
                                        choices = result.get('choices', [])
                                        if not choices:
                                            final_result = {'prompt': prompt, 'text': merge_result,
                                                            'completion_tokens': result['usage']["completion_tokens"],
                                                            'prompt_tokens': result['usage']["prompt_tokens"]
                                                            }
                                            yield final_result
                                            break

                                        content_str += result['choices'][0].get('delta', {}).get('content', "") or ""
                                        reasoning_content_str += result['choices'][0].get('delta', {}).get('reasoning_content', "") or ""
                                        finish_reason = result['choices'][0].get('finish_reason', "")
                                        if finish_reason == 'content_filter':
                                            self.logger.error(self.pre_log_msg + f"response error:{result}")
                                            yield None
                                            break

                                        elif content_str:
                                            merge_result = f"<think>\n{reasoning_content_str}\n</think>\n{content_str}"
                                        else:
                                            merge_result = f"<think>\n{reasoning_content_str}"

                                        if result:
                                            usage = result.get('usage', {}) or {}
                                            final_result = {'prompt': prompt, 'text': merge_result,
                                                            'completion_tokens': usage.get("completion_tokens", 0),
                                                            'prompt_tokens': usage.get("prompt_tokens", 0)
                                                            }
                                            yield final_result

                            if data:
                                try:
                                    last_event = data.decode("utf-8")
                                    last_dict = json.loads(last_event)
                                    last_dict.pop('request_params', None)
                                    self.logger.info(self.pre_log_msg + f"处理最终事件: {last_dict}")
                                except json.JSONDecodeError:
                                    self.logger.info(f"无法解析最终数据: {data.decode('utf-8', errors='replace')}")
                                except Exception as e:
                                    self.logger.info(f"处理最终事件失败: {e}")

            except Exception as e:
                error_info = str(e)

            if not result:
                self.logger.error(self.pre_log_msg + f"llm error, result is empty : {first_result}")
                continue
            break
        self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                                  f"cost_time:{time.time() - start}\tjson:{prompt}\theaders:{headers}\t"
                                                  f"timeout:{timeout}\terror_info:{error_info}\terror_code:{error_code}\t"
                                                  f"res:{result}\tfinal:{json.dumps(merge_result,ensure_ascii=False)}\tfirst:{first_result}")

    def make_params_dialogue(self, prompt, history_list, stream=False, no_think=False):
        appkey = DEEPSEEK_DEFAULT_APPKEY
        # model_id = DEEPSEEK_DEFAULT_MODELID
        # model_type = "weibo"
        # model_type = 'volcengine'
        # model_id = 'DeepSeek-V3.1-terminus'
        model_type = 'weibo'
        model_id = 'deepseek-v3.1-terminus'
        model = self.chat_check_info.get("model", "")
        is_complex_query = self.chat_check_info.get("is_complex_query", 0)
        basemodel = self.chat_check_info.get("basemodel", "")

        is_exp = False
        if basemodel in ['实验组1', '实验组2', '实验组3', '实验组4', '实验组5']:
            is_exp = True

        if model == "非思考版" and (is_complex_query == 0 or is_exp):
            no_think = True

        self.logger.info(self.pre_log_msg + f"no_think: {no_think} is_complex_query:{is_complex_query} 实验组：{basemodel}")

        params = {
            "appkey": appkey,
            "type": model_type,
            "model_id": model_id,
            "smart_schedule": 1,
            "message": '你好',
            "use_ext_first": 1,
            "sub_source": 'zschat_app'
        }
        if stream:
            params.update({"stream": "true"})

        model_ext = {
            "messages": history_list + [{"role": "user", "content": prompt}]
        }
        if 'terminus' in model_id:
            if no_think:
                model_ext['thinking'] = {'type' : 'disabled'}
            else:
                model_ext['thinking'] = {'type': 'enabled'}

        if no_think and 'terminus' not in model_id:
            model_ext["messages"].append({"role": "assistant", "content": "<think></think>"})
        data = json.dumps({
            "model_ext": model_ext
        }, ensure_ascii=False)

        return params, data

    async def async_stream_call_dialogue(self, prompt, history_list, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1):
        async def async_stream_call_inner():
            api_name = "WEIBO_DEEPSEEK_R1"
            self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
            result = None
            first_time = None
            params, data = self.make_params_dialogue(prompt, history_list, stream=True)
            headers = get_tauth_token(7867080892)
            stream_response = self.async_stream_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers)
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                yield result

            self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")

        return async_stream_call_inner()


class QWEN3_30B_Wrapper(BaseApi):
    def __init__(self, pid, pre_log_msg, llm_call_stage=""):
        self.model_name = "virtuoso-small-v2"
        self.url = "http://10.85.96.165:8080/v1"
        self.stream_url = "http://10.85.96.165:8080/v1"
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage

    async def async_stream_call_dialogue(self, prompt, history_list, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        """stream_qwen_72b_api"""
        async def async_stream_call_inner():
            flattened_history_list = [item for msg in history_list for item in (msg['role'], msg['content'])]
            url = "http://qwen3-30b-a3b-0512.preview.search.weibo.com/v2/models/llm/generate_stream"
            data = {
                "temperature": temperature,
                "stream": True,
                "max_tokens": 2000,
                "id": "123",
                "messages":  flattened_history_list + ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt + "/no_think"]
            }
            headers = {
                'Content-Type': 'application/json'
            }
            api_name = "STREAM_QWEN3_30B"
            result = None
            content_text = ""
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.post(url, json=data, headers=headers) as response:
                        if response.status == 200:
                            # 逐块处理流式响应
                            data = bytearray()
                            async for chunk in response.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        result = dict_text
                                        content_text += dict_text['text']
                                        dict_text['text'] = content_text
                                        yield dict_text
                            if result:
                                data = {'text': content_text, 'prompt': prompt, 'content': content_text, 'completion_tokens': result.get("completion_tokens"),
                                        'prompt_tokens': result.get("prompt_tokens")}
                                self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                        else:
                            self.logger.info(f"Request failed with status code: {response.status}")
                except aiohttp.ClientError as e:
                    self.logger.info(f"An error occurred during the request: {e}")
        return async_stream_call_inner()

    async def async_call_dialogue(self, messages, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        api_name = "QWEN3_30B"
        async def async_call_inner(messages, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
            url = "http://qwen3-30b-a3b-0512.preview.search.weibo.com/v2/models/llm/generate"
            datas = {
                "temperature": temperature,
                "stream": False,
                "max_tokens": 2000,
                "id": "123",
                "messages": messages
            }
            if schema_index is not None:
                datas.update({"schema_idx": schema_index})

            return await self.async_post(url, api_name, datas, timeout=timeout, retry=retry)

        result = await async_call_inner(messages, schema_index, max_tokens, temperature, timeout, retry)
        if result:
            content_text = result.get("text", "")
            data = {'prompt': messages[-1], 'content': content_text, 'completion_tokens': result.get("completion_tokens"),
                    'prompt_tokens': result.get("prompt_tokens"), 'text': content_text}
            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
        return result

    async def async_self_call_dialogue(self, messages, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        api_name = "QWEN3_30B"

        MODEL_SERVICE_URL = "http://10.94.208.8:8000/v1/chat/completions"

        headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer EMPTY"  # vllm默认也接受这个
        }

        payload = {
            "model": "Qwen3-30B-A3B-Instruct-2507",
            "messages": messages,
            "temperature": 0.6,
            "stream": False,
            "max_tokens": 2000
        }

        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(200)) as session:
                async with session.post(url=MODEL_SERVICE_URL, json=payload, headers=headers) as r:
                    if r.status == 200:
                        res = await r.json()
                        content = res['choices'][0]['message']['content']
                        if content:
                            data = {'prompt': messages, 'content': content, 'completion_tokens': res.get("usage", {}).get("completion_tokens"),
                                    'prompt_tokens':  res.get("usage", {}).get("prompt_tokens"), 'text': content}
                            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                            return data
        except Exception as e:
            pass

        return {}

class QWEN3_235B_ModelFirstPageWrapper(BaseApi):
    def __init__(self, pid, pre_log_msg, llm_call_stage="", chat_check_info={}):
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage
        self.chat_check_info = chat_check_info

    def make_params(self, prompt, history_list=[], stream=False):
        params = {
            "appkey": "2165752702",
            "type": "dashscope",
            "model_id": 'qwen-plus-2025-07-14',
            "smart_schedule": 1,
            "message": '你好',
            "use_ext_first": 1,
            "sub_source": 'zschat-app'
        }
        if stream:
            params.update({"stream": "true"})

        model_ext = {
            "input": {
                "messages": history_list + [{"role": "user", "content": prompt}],
            },
            "parameters": {
                # 'enable_thinking': True,
                "result_format": "message",
                "incremental_output": True
            }
        }
        api_ext = {
            "X-DashScope-DataInspection": {
                "input": "disable",
                "output": "disable"
            }
        }
        data = json.dumps({
            "model_ext": model_ext,
            "api_ext": api_ext
        }, ensure_ascii=False)

        return params, data

    async def async_stream_post2(self, url, api_name, params, data, headers=None, timeout=None, retry=2) :
        start = time.time()
        prompt = data
        content_str = ""
        reasoning_content_str = ""
        final_result = None
        error_info = ""
        result = ""
        merge_result = ""
        first_result = None
        error_code = 0
        for i in range(int(retry)) :
            try :
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session :
                    async with session.post(url, headers=headers, params=params, data=prompt) as res :
                        first_result = res
                        error_code = res.status
                        if res.status == 200 :
                            data = bytearray()
                            async for chunk in res.content.iter_any() :
                                if chunk :
                                    data.extend(chunk)
                                    split_symbol = b'\n\n'
                                    while split_symbol in data :
                                        index = data.find(split_symbol)
                                        split = data[0 :index + 1]
                                        data = data[index + 1 :]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        final_result = dict_text

                                        result = final_result.get('response_data', {})
                                        choices = result.get('output').get("choices", [])
                                        content_str += choices[0].get('message', {}).get('content', "") or ""
                                        reasoning_content_str += choices[0].get('message', {}).get('reasoning_content',
                                                                                                   "") or ""
                                        if content_str :
                                            merge_result = f"<think>\n{reasoning_content_str}\n</think>\n{content_str}"
                                        else :
                                            merge_result = f"<think>\n{reasoning_content_str}"
                                        if result :
                                            usage = result.get('usage', {}) or {}
                                            yield {
                                                'prompt' : prompt, 'text' : merge_result,
                                                'completion_tokens' : usage.get("output_tokens", 0),
                                                'prompt_tokens' : usage.get("input_tokens", 0)
                                            }
                            if data :
                                try :
                                    last_event = data.decode("utf-8")
                                    last_dict = json.loads(last_event)
                                    self.logger.info(self.pre_log_msg + f"处理最终事件: {last_dict}")
                                    real_type = last_dict.get('real_type', "")
                                except json.JSONDecodeError :
                                    self.logger.info(f"无法解析最终数据: {data.decode('utf-8', errors='replace')}")
                                except Exception as e :
                                    self.logger.info(f"处理最终事件失败: {e}")


            except Exception as e :
                error_info = str(e)
            if not result :
                self.logger.error(self.pre_log_msg + f"llm error, result is empty : {first_result}")
                continue
            break
        self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                                f"cost_time:{time.time() - start}\tjson:{prompt}\theaders:{headers}\t"
                                                f"timeout:{timeout}\terror_info:{error_info}\terror_code:{error_code}\t"
                                                f"res:{result}\tfinal:{json.dumps(merge_result, ensure_ascii=False)}\tfirst:{first_result}")

    async def async_stream_call_dialogue(self, prompt, history_list=[], schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1):
        async def async_stream_call_inner():
            # flattened_history_list = [item for msg in history_list for item in (msg['role'], msg['content'])]
            flattened_history_list = history_list
            begin = time.time()
            api_name = "qwen3-235b-a22b"
            self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
            result = None
            first_time = None
            params, data = self.make_params(prompt, flattened_history_list, stream=True)
            headers = get_tauth_token(7867080892)
            stream_response = self.async_stream_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers)
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                yield result

            if result:
                # json_data = count_tokens(self.weibo, result, "qwen3-235b-a22b_stream", begin, self.llm_call_stage, first_time)
                # self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                pass
            self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")

        return async_stream_call_inner()
