#!/bin/bash


SIGNAL_TYPE=-15  # 默认 SIGTERM
PROCESS_NAME="dialogue-"
PIDS=$(pgrep -f $PROCESS_NAME)

if [ -n "$PIDS" ]; then
    echo "Found existing processes with $PROCESS_NAME:"
    echo "$PIDS"

    # 如果传入了 -f 参数，强杀
    if [ "$1" = "-f" ]; then
        SIGNAL_TYPE=-9
        echo "Force kill enabled."
    fi

    for PID in $PIDS; do
        kill $SIGNAL_TYPE "$PID"
        echo "kill $SIGNAL_TYPE $PID"
    done

    # 等待进程退出
    for PID in $PIDS; do
        while kill -0 "$PID" 2>/dev/null; do
            echo "Waiting for process $PID to exit..."
            sleep 1
        done
    done
fi

#### start cron
#service cron start
#cp -f cron /var/spool/cron/root && chmod -R 0644 /var/spool/cron/root
#crontab /var/spool/cron/root
#
#### start discovery
#chmod +x ./tools/discovery/discovery-agent
#./tools/discovery/discovery-agent -c ./tools/discovery/agent.yaml &

### start summary
source .venv/bin/activate
uv sync --upgrade-package zsmaterial
LOG_PATH=online.log
echo "== Restarting at $(date '+%Y-%m-%d %H:%M:%S') ==" >> "$LOG_PATH"
exec >> "$LOG_PATH" 2>&1
export WIS_MATERIAL_DEBUG_LOG=log
exec python -m app.dialogue