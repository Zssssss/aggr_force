def main():
    print("Hello from wis-multi-dialogue!")


if __name__ == "__main__":
    main()
