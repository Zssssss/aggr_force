
from pydantic import BaseModel, Field
from typing import Optional, List, Any, Dict


class Message(BaseModel):
    role: str
    content: Any


class ChatCompletionRequest(BaseModel):
    user: Optional[str] = ""
    model: Optional[str] = "qwen"
    conversationId: Optional[str] = ""
    sessionID:Optional[str] = ""
    messages: List[Message]
    max_tokens: Optional[int] = 4096
    temperature: Optional[float] = 0.1
    stream: Optional[bool] = False
    source_type: Optional[str] = ""

class FirstRoundBack(BaseModel):
    """起始轮返回数据"""
    think: str = ""
    content: str = ""
    search_querys: List[str] = []
    is_qa: bool = False


class ContextModel(BaseModel):
    """
    Context字典的Pydantic模型
    用于智能搜索服务中的上下文数据结构
    """
    
    # 基础查询信息
    query: str = Field(default="", description="用户查询内容")
    trace_id: str = Field(default="", description="追踪ID")
    is_complex_query_list: List[int] = Field(default=[], description="是否复杂查询列表")
    
    # 多媒体相关
    picture_urls: List[str] = Field(default_factory=list, description="图片URL列表")
    vector_dict: Dict[str, Any] = Field(default_factory=dict, description="向量字典")
    ready_pid_dict: Dict[str, Any] = Field(default_factory=dict, description="准备好的PID字典")
    pid_dup_dic: Dict[str, Any] = Field(default_factory=dict, description="PID去重字典")
    pic_info_dict_all: Dict[str, Any] = Field(default_factory=dict, description="所有图片信息字典")
    
    # 链接和视频相关
    link_list: List[str] = Field(default_factory=list, description="链接列表")
    video_mid_list: List[str] = Field(default_factory=list, description="视频MID列表")
    video_mid_dict: Dict[str, Any] = Field(default_factory=dict, description="视频MID字典")
    mid_feature_dict: Dict[str, Any] = Field(default_factory=dict, description="MID特征字典")
    
    # 状态和配置
    ready: bool = Field(default=False, description="是否准备就绪")
    is_stream: bool = Field(default=True, description="是否流式输出")
    
    # 查询分类和标识
    ban_object: int = Field(default=0, description="禁用对象标识")
    query_category: str = Field(default="", description="查询分类")
    exact_account_query: int = Field(default=0, description="精确账号查询标识")
    is_hot_query: bool = Field(default=False, description="是否热门查询")
    is_zhanghao_attention: bool = Field(default=False, description="是否账号关注")
    
    # 搜索结果
    user_search_res: List[Any] = Field(default_factory=list, description="用户搜索结果")
    blog_analysis_flag: bool = Field(default=False, description="是否进行微博分析")
    query_field_list: List[int] = Field(default_factory=list, description="领域列表")

    # 搜人意图和对应的热点物料
    da_intention: str = Field(default="", description="活动意图")
    da_intention_exact_match: str = Field(default="", description="活动意图完全匹配标记")
    famous_person_intention: Dict[str, Any] = Field(default_factory=dict, description="搜人意图")
    his_hot_s_list: List[Any] = Field(default_factory=list, description="搜人热点物料")

class MaterialModel(BaseModel):

    # 保存物料
    mid_list: List[str] = Field(default_factory=list, description="链接列表")
    sina_article_data: List[Any] = Field(default_factory=list, description="链接列表")
    baike_knowledge: List[Any] = Field(default_factory=list, description="链接列表")
    history_hot_res: List[Any] = Field(default_factory=list, description="链接列表")
    zs_knowledge: List[Any] = Field(default_factory=list, description="链接列表")
    user_search_res: List[Any] = Field(default_factory=list, description="用户搜索结果")
