# -*- coding:utf-8 -*-
import random
import re
import time
import traceback

import aiohttp
import json
import datetime

from api.model_api import md5_hash, get_bucket_id

from app.apis.wis_search.material.history import DialogueHistory
from app.apis.wis_search.utils.session_pool import SessionPool


class Input(SessionPool):

    async def input(self, model: str) -> dict | None:
        start = time.time()
        params = {'model': model}
        timeout = aiohttp.ClientTimeout(total=2)

        try:
            headers = {'Content-Type': 'application/json'}
            session = await self.start()
            async with session.get("http://admin.ai.s.weibo.com/api/chat/get_task.json", params=params, timeout=timeout, headers=headers) as response:
                response.raise_for_status()
                data = await response.json()
                if not data:
                    self.logger.warning(f"{self.pid} Queue is empty")
                    return None

                data_str = data.get("data", "")
                if not data_str:
                    self.logger.warning(f"{self.pid} Queue is empty")
                    return None

                self.logger.info(f"queue ori {data_str}")
                json_dict = json.loads(data_str)

                trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
                trace_id = json_dict.get('version', trace_id)
                json_dict['trace_id'] = trace_id
                json_dict['query_in_time'] = time.time()
                q_attr = json_dict.get("q_attr", "")
                try:
                    if q_attr:
                        risk_info = self._parse_q_attr(q_attr)
                        json_dict['risk_info'] = risk_info

                except Exception as e:
                    self.logger.error("{} de-serialize q_attr error:{}".format(q_attr, e))

                # 思考版还是非思考版
                use_deep_think = 1
                try:
                    completion_option = json.loads(json_dict.get("completion_option") or "{}")
                    use_deep_think = int(completion_option.get("use_deep_think", 1))
                except Exception as e:
                    self.logger.warning(f"input message error: {e}")
                json_dict["model"] = "思考版" if use_deep_think else "非思考版"

                # 客户端版本
                p_msg_smart_search_enable = 0
                try:
                    q_attr = json.loads(json_dict.get("q_attr") or "{}")
                    p_msg_smart_search_enable = int(q_attr.get("p_msg_smart_search_enable") or '0')
                except Exception as e:
                    self.logger.warning(f"input message error: {e}")
                json_dict['p_msg_smart_search_enable'] = p_msg_smart_search_enable

                # 测试case
                json_dict['source_type'] = "client"
                question = json_dict.get("question", "")
                json_dict["ori_question"] = question
                if question.endswith("_chattest"):
                    question = question.split("_chattest")[0]
                    json_dict['source_type'] = "client"
                json_dict["question"] = question

                # 获取历史
                user_id = json_dict.get('user_id', "")
                session_id = json_dict.get('session_id', "")

                self.logger.info(f"get_history: {user_id} {session_id}")
                if json_dict.get("send_from", "") == "comment":
                    messages = []
                else:
                    messages = await DialogueHistory(self.pid).get_history(trace_id, user_id, session_id)
                messages.append({"role": "user", "content": question})
                json_dict["messages"] = messages
                json_dict['get_history_time'] = time.time()
                json_dict['ori_conversation_id'] = json_dict.get('conversation_id', "")
                json_dict['conversation_id'] = ""
                self.update(json_dict)
                self.logger.info(f"queue in {json_dict}, cost: {time.time() - start}")
                return json_dict
        except Exception as e:
            self.logger.error(f"input error cost: {time.time() - start}, msg: {traceback.format_exc()}")

        return None

    def update(self,weibo):
        self.abtest(weibo)

    def abtest(self, weibo):
        session_id = weibo.get('user_id', "")
        hash_str = md5_hash(session_id)
        bucket_id = get_bucket_id(hash_str, bucket_num=10)
        weibo['basemodel'] = "实验组{}".format(bucket_id + 1)

    def _parse_q_attr(self, q_attr: str) -> dict:
        """解析q_attr JSON字符串并提取风控相关字段
        
        Args:
            q_attr: 原始JSON字符串
            
        Returns:
            dict: 包含解析后的风控字段，格式为:
                {
                    'limit_degree': str,  # 风控限制等级
                    'user_v_type': list[dict]  # 风控C、D等级指定物料类型数组，默认为空数组，格式:
                        # {
                        #     "verified_type": int,
                        #     "verified_type_ext": Optional[int]
                        # }
                }
        """
        risk_info = {}
        try:
            if not q_attr:
                return risk_info
                
            q_attr_data = json.loads(q_attr)
            limit_degree = q_attr_data.get("limit_degree", "")
            
            # 仅当limit_degree为B、C、D时才处理user_v_type
            user_v_type = []
            use_material = []
            if limit_degree in ["B", "C", "D"]:
                user_v_type = q_attr_data.get("extra", {}).get("user_v_type", [])
                use_material = q_attr_data.get("extra", {}).get("material", [])
                risk_info = {
                    'limit_degree': limit_degree,
                    'user_v_type': user_v_type,
                    'use_material' : use_material
                }
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse q_attr JSON: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error parsing q_attr: {e}")
        return risk_info

class OnlineInput(Input):
    async def input(self, model: str) -> dict | None:
        start = time.time()
        params = {'model': model}
        timeout = aiohttp.ClientTimeout(total=2)

        try:
            headers = {'Content-Type': 'application/json'}
            session = await self.start()
            async with session.get("http://admin.ai.s.weibo.com/api/wis/get_task.json", params=params, timeout=timeout, headers=headers) as response:
                response.raise_for_status()
                data = await response.json()
                if not data:
                    self.logger.warning(f"{self.pid} Queue is empty")
                    return None

                data_str = data.get("data", "")
                if not data_str:
                    self.logger.warning(f"{self.pid} Queue is empty")
                    return None

                self.logger.info(f"queue ori {data_str}")
                json_dict = json.loads(data_str)

                trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
                trace_id = json_dict.get('version', trace_id)
                json_dict['trace_id'] = trace_id
                json_dict['query_in_time'] = time.time()
                q_attr = json_dict.get("q_attr", "")
                try:
                    if q_attr:
                        risk_info = self._parse_q_attr(q_attr)
                        json_dict['risk_info'] = risk_info

                except Exception as e:
                    self.logger.error("{} de-serialize q_attr error:{}".format(q_attr, e))

                # 思考版还是非思考版
                use_deep_think = 1
                try:
                    completion_option = json.loads(json_dict.get("completion_option") or "{}")
                    use_deep_think = int(completion_option.get("use_deep_think", 1))
                except Exception as e:
                    self.logger.warning(f"input message error: {e}")
                json_dict["model"] = "非思考版"

                # 客户端版本
                p_msg_smart_search_enable = 0
                try:
                    q_attr = json.loads(json_dict.get("q_attr") or "{}")
                    p_msg_smart_search_enable = int(q_attr.get("p_msg_smart_search_enable") or '0')
                except Exception as e:
                    self.logger.warning(f"input message error: {e}")
                json_dict['p_msg_smart_search_enable'] = p_msg_smart_search_enable

                # 测试case
                json_dict['source_type'] = "client"
                question = json_dict.get("query", "")
                json_dict["ori_question"] = question
                if question.endswith("_chattest"):
                    question = question.split("_chattest")[0]
                    json_dict['source_type'] = "client"
                json_dict["question"] = question

                # 获取历史
                user_id = json_dict.get('user_id', "")
                session_id = json_dict.get('session_id', "")

                self.logger.info(f"get_history: {user_id} {session_id}")
                one_query = json.loads(json_dict.get("q_attr","{}")).get("one_query", "")
                if one_query:
                    messages = await self.get_history_list(one_query)
                else:
                    messages = []

                if not messages:
                    self.logger.info(f"not messages queue in {json_dict}, cost: {time.time() - start}")
                    return None

                messages.append({"role": "user", "content": question})
                json_dict["messages"] = messages
                json_dict['get_history_time'] = time.time()
                json_dict['ori_conversation_id'] = json_dict.get('conversation_id', "")
                json_dict['conversation_id'] = ""
                self.update(json_dict)
                self.logger.info(f"queue in {json_dict}, cost: {time.time() - start}")
                return json_dict
        except Exception as e:
            self.logger.error(f"input error cost: {time.time() - start}, msg: {traceback.format_exc()}")

        return None

    async def get_history_list(self, one_query: str) -> list[dict[str, str]]:
        headers = {'Content-Type': 'application/json'}
        session = await self.start()
        params = {
            "query": one_query,
            "content_type": "loop",
            "cot": 12
        }
        timeout = aiohttp.ClientTimeout(total=2)
        try:
            async with session.get("http://admin.ai.s.weibo.com/api/wis/show.json", params=params, timeout=timeout,
                                   headers=headers) as response:
                response.raise_for_status()
                data = await response.json()
                content = data.get("msg", "")
                return [{"role": "assistant", "content": content}]
        except  Exception as e:
            self.logger.error(f"online get_history error: {e}")
            return []

class Output(SessionPool):

    def fill_reference_mid4deepseek(self, link_list: list[str], content: str) -> list[dict[str, str]]:
        """
        填充deepseek的reference_mid和对应的引用数量、引用排序
        [{"mid": "5137664437388978", "citation_num": "1","rank":"1"}, {"mid": "5137648970895030", "citation_num": "1","rank":"2"}]
        """
        def _get_reference_number(text):
            # 使用正则表达式匹配<think>标签及其内容</think>
            pattern = r'<think>.*?</think>'
            # 替换匹配到的内容为空字符串
            try:
                cleaned_text = re.sub(pattern, '', text, flags=re.DOTALL)
                # a_number = re.findall(r'<a>\[\d+\]</a>', cleaned_text, flags=re.DOTALL)
                # numbers = [int(re.search(r'\d+', item).group(0)) for item in a_number]
                # numbers_str = re.findall(r'\[\^(\d+)\]', cleaned_text, flags=re.DOTALL)
                # numbers = [int(item) for item in numbers_str]
                tq_pattern = r'```wbCustomBlock(\{.*?})```'
                matches = re.findall(tq_pattern, cleaned_text, re.DOTALL)
                numbers = []
                for match in matches:
                    try:
                        dict1 = eval(match)
                        if dict1["type"] != "quoted":
                            continue
                        for num in dict1["data"]["num"]:
                            numbers.append(num)
                    except:
                        continue
            except:
                self.logger.warning("get_reference_number error, text:{}".format(text))
                numbers = []

            return numbers

        # mid_list = [item.split("mblogid=")[1] for item in link_list if "detail?mblogid=" in item]
        reference_nums = _get_reference_number(content)
        res = [{
            "mid": "",
            "citation_num": "0",
            "rank": "-1"
        } for _ in range(len(link_list))]
        rank_id = 0
        try:
            for idx, reference_num in enumerate(reference_nums):
                if reference_num > len(res):
                    self.logger.warning("reference_num:{} out of range, mid_list_len:{}".format(reference_num, len(res)))
                    continue
                mid_obj = res[reference_num - 1]
                link_item = link_list[reference_num - 1]
                if "detail?mblogid=" in link_item:
                    if not mid_obj["mid"]:
                        mid_obj["mid"] = link_item.split("mblogid=")[1]
                    mid_obj['citation_num'] = str(int(mid_obj['citation_num']) + 1)
                    rank_id += 1
                    if mid_obj["rank"] == "-1":
                        mid_obj['rank'] = str(rank_id)
        except Exception as e:
            self.logger.warning("get_reference_mid error in for, e:{}".format(traceback.format_exc()))


        return [item for item in res if item['mid']]

    def sort_all_list(self, sorted_data, sorted_material_list):
        order_dict = {item['mid']: int(item['rank']) for item in sorted_data}

        # 分割列表二为需要排序和保持原顺序的部分
        sorted_part = []
        unsorted_part = []
        for item in sorted_material_list:
            if item['mid'] in order_dict:
                sorted_part.append(item)
            else:
                unsorted_part.append(item)

    #     print(sorted_part)
        # 对需要排序的部分按照列表一的rank顺序排序
        sorted_part.sort(key=lambda x: order_dict[x['mid']])
    #     print(sorted_part)

        # 合并两部分，未提到的元素保持原顺序
        sorted_list2 = sorted_part + unsorted_part
        return sorted_list2

    def get_sorted_material_list(self, link_list):
        """获取输入博文的排序列表，返回排序后的博文以及序号
        """
        mid_rank_dict = []
        mid_set = set()
        for num,mid in enumerate(link_list):
            if "detail?mblogid=" in mid:
                mid = mid.split("mblogid=")[1]
                if mid in mid_set:
                    continue
                mid_set.add(mid)
                mid_rank_dict.append({"mid":mid,"rank":num+1,"type":"weibo"})
        return mid_rank_dict

    def gen_sorted_material_list(self, link_list, content):
        sorted_material_list = self.get_sorted_material_list(link_list)
        query_citation_mid = self.fill_reference_mid4deepseek(link_list, content)
        sorted_data = sorted(query_citation_mid, key=lambda x : int(x["rank"]), reverse=False)
        sorted_material_list = self.sort_all_list(sorted_data, sorted_material_list)
        return sorted_material_list

    async def output(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        content = kwargs.get('content', "").lstrip()
        ready = kwargs.get('ready', "")

        if ready == 'yes' and not content:
            ready = 'error'

        trace_id = weibo.get('trace_id', "")
        question = weibo.get('ori_question', "")
        model = weibo.get('model', "deepseek")
        version = weibo.get('version', "")
        session_id = weibo.get('session_id', "")
        conversation_id = weibo.get('ori_conversation_id', "")
        uid = weibo.get('user_id', "")
        q_attr = weibo.get('q_attr', "")
        prompt_scene = weibo.get('prompt_scene', "")
        status_stage = weibo.get('update_output', {}).get("status_stage", 1)
        chat_type = weibo.get('update_output', {}).get("chat_type", -1)
        link_list = weibo.get('update_output',{}).get("link_list",[])
        share_card_multimodal = weibo.get('update_output',{}).get("share_card_multimodal", {})
        sorted_material_list = self.gen_sorted_material_list(link_list, content)
        query_field =  weibo.get('update_output',{}).get('query_field', -1)
        first_chat_tag = weibo.get('first_chat_tag', 0)
        completion_option = weibo.get("completion_option", "")
        model_filter = weibo.get('model_filter', "")
        query_filter_reason = weibo.get("query_filter_reason", "")

        data = {'content': content, 'ready': ready, "question": question,
                "model": model, "version": version, "session_id": session_id,
                "conversation_id": conversation_id, "user_id": uid, "q_attr": q_attr, "prompt_scene": prompt_scene,
                "status_stage": status_stage, "chat_type": chat_type if chat_type != -1 else 0,
                "sorted_material_list": json.dumps(sorted_material_list),
                "share_card_multimodal": json.dumps(share_card_multimodal, ensure_ascii=False),
                "query_field": query_field, 'completion_option': completion_option,
                "model_filter": model_filter, "query_filter_reason": query_filter_reason}
        if chat_type != -1 and first_chat_tag == 0:
            data["first_chat_tag"] = 1
            weibo["first_chat_tag"] = 1

        if ready == 'special_tips':
            data['special_tips'] = weibo.get('special_tips', "")

        try:
            timeout = aiohttp.ClientTimeout(total=3)
            headers = {'Content-Type': 'application/json'}
            session = await self.start()
            async with session.post(url="http://admin.ai.s.weibo.com/api/chat/update_answer.json", json=data, headers=headers, timeout=timeout) as response:
                response.raise_for_status()
                response_json = await response.json()

                self.logger.info("traceid:{}\tquery:{}\tresponse:{}\tdata:{}\tcost:{}".format(
                    trace_id, question, response_json, json.dumps(data, ensure_ascii=False), time.time() - start))
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} write to fronted error data:{}, cost:{}".format(
                    question, str(e), trace_id, json.dumps(data, ensure_ascii=False), time.time() - start))

class OnlineOutput(Output):

    def deepseek_sort_mid(self, link_list):
        res_mid = []
        mid_set = set()
        for mid in link_list:
            if "detail?mblogid=" in mid:
                mid = mid.split("mblogid=")[1]
                if mid in mid_set:
                    continue
                res_mid.append(mid)
                mid_set.add(mid)

        return res_mid

    async def output(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        content = kwargs.get('content', "").lstrip()
        ready = kwargs.get('ready', "")

        if ready == 'yes' and not content:
            ready = 'error'

        trace_id = weibo.get('trace_id', "")
        question = weibo.get('ori_question', "")
        model = weibo.get('model', "deepseek")
        version = weibo.get('version', "")
        session_id = weibo.get('session_id', "")
        conversation_id = weibo.get('ori_conversation_id', "")
        uid = weibo.get('user_id', "")
        q_attr = weibo.get('q_attr', "")
        prompt_scene = weibo.get('prompt_scene', "")
        status_stage = weibo.get('update_output', {}).get("status_stage", 1)
        chat_type = weibo.get('update_output', {}).get("chat_type", -1)
        link_list = weibo.get('update_output',{}).get("link_list",[])
        share_card_multimodal = weibo.get('update_output',{}).get("share_card_multimodal", {})
        sorted_material_list = self.gen_sorted_material_list(link_list, content)
        query_field =  weibo.get('update_output',{}).get('query_field', -1)
        first_chat_tag = weibo.get('first_chat_tag', 0)
        completion_option = weibo.get("completion_option", "")
        model_filter = weibo.get('model_filter', "")
        query_filter_reason = weibo.get("query_filter_reason", "")
        query_category = weibo.get('query_category', "")
        post_data = {}
        reference_mid_list = self.deepseek_sort_mid(link_list)
        high_level = weibo.get('high_level', 0)
        stream_output = 1
        level2_uid = weibo.get('level2_uid', "")
        self_account = weibo.get('self_account', 0)
        raw_time_grade = weibo.get('raw_time_grade', "")
        label = weibo.get('label', "")
        modify_query = weibo.get('modify_query', "")
        debug_info = weibo.get('debug_info', {})
        data = {"query": question, "model": prompt_scene, "ready": ready, "content": content, "version": version,
                "first_version": version, "content_json": {}, "query_category": query_category,
                "post_data": json.dumps(post_data), "content_mid_list": json.dumps(reference_mid_list),
                "source": 1,
                "q_attr": q_attr, "high_level": high_level, "stream_output": stream_output, "level2_uid": level2_uid,
                "self_account": self_account, "time_grade": raw_time_grade, "label": label,
                'modify_query': modify_query,
                'debug': json.dumps(debug_info, ensure_ascii=False), 'link_list': json.dumps(link_list),
                'prompt_scene': prompt_scene,}
        # print(f"data: {data}")
        if chat_type != -1 and first_chat_tag == 0:
            data["first_chat_tag"] = 1
            weibo["first_chat_tag"] = 1

        if ready == 'special_tips':
            data['special_tips'] = weibo.get('special_tips', "")

        try:
            timeout = aiohttp.ClientTimeout(total=3)
            headers = {'Content-Type': 'application/json'}
            session = await self.start()
            async with session.post(url="http://admin.ai.s.weibo.com/api/wis/update_summary.json", json=data, headers=headers, timeout=timeout) as response:
                response.raise_for_status()
                response_json = await response.json()
                # print(f"response_json: {response_json}")
                self.logger.info("traceid:{}\tquery:{}\tresponse:{}\tdata:{}\tcost:{}".format(
                    trace_id, question, response_json, json.dumps(data, ensure_ascii=False), time.time() - start))
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} write to fronted error data:{}, cost:{}".format(
                    question, str(e), trace_id, json.dumps(data, ensure_ascii=False), time.time() - start))

class TestOutput(Output):
    async def output(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        content = kwargs.get('content', "")
        ready = kwargs.get('ready', "")

        trace_id = weibo.get('trace_id', "")
        question = weibo.get('ori_question', "")
        model = weibo.get('model', "deepseek")
        version = weibo.get('version', "")
        session_id = weibo.get('session_id', "")
        conversation_id = weibo.get('ori_conversation_id', "")
        uid = weibo.get('user_id', "")
        q_attr = weibo.get('q_attr', "")
        prompt_scene = weibo.get('prompt_scene', "")
        status_stage = weibo.get('update_output', {}).get("status_stage", 1)
        chat_type = weibo.get('update_output', {}).get("chat_type", 0)
        link_list = weibo.get('update_output', {}).get("link_list", [])
        sorted_material_list = self.gen_sorted_material_list(link_list, content)
        data = {'content' : content, 'ready' : ready, "question" : question,
                "model" : model, "version" : version, "session_id" : session_id,
                "conversation_id" : conversation_id, "user_id" : uid, "q_attr" : q_attr, "prompt_scene" : prompt_scene,
                "status_stage" : status_stage, "chat_type" : chat_type,
                "sorted_material_list" : json.dumps(sorted_material_list)}
        self.logger.info(f"data: {data}")
        print(ready, content)


async def mock_input(model: str):

    data = {"model":"chat","log_type":"zs_summary","stream_output":1,"self_account":0,"high_level":10,"diff_ype":"add","session_id":"0f741907-46dd-4d68-a4f4-035ae5a156d0","conversation_id":"con_4c5fce98-fb07-4039-aed8-aab51ce42701","user_id":"123456789","version":"2025-07-11 14:45:05.938999-7084","ab_test":"","prompt_scene":"chat","user_request_time_ms":0,"server_request_time_ms":0,"sens_words":"","data_type":"zs_analysis_task_chat","tid":"0c1325e02355486f253ba4268f5fd9be","sid":"","source":0,"question":"今天有什么热点","in_time":1752216302,"q_attr":"{\"risk_map\":{\"share\":true,\"show_standard_tips\":false,\"zh_djzzw\":true,\"tab_cot\":true,\"tab_ask\":true,\"tab_ref_blog\":true,\"tab_v_share\":true,\"tab_scene_rel\":true,\"tab_emo\":true,\"show_zs\":true,\"zh_show_ds\":true,\"zh_show_preview\":true,\"quote_list\":true,\"interactive\":true},\"new_high_level\":10}","messages":"\"[{\\\"content\\\":\\\"今天有什么热点\\\",\\\"id\\\":\\\"msg_b7b0f0bc-16cb-48cb-ad2c-f755c444a018\\\",\\\"role\\\":\\\"user\\\",\\\"conversation_id\\\":\\\"con_5b71d482-79ff-40d5-8889-05faec61a4c7\\\"},{\\\"content\\\":\\\"<think>\\\\n我们首先判断是否需要使用搜索工具。\\\\n 用户查询是“今天有什么热点”，这是一个需要实时信息的问题。因为热点事件每天都在变化，且今天是2025年07月11日，我的知识虽然不断更新，但为了确保提供的信息是最新且准确的，特别是微博热点，我应该使用搜索工具来获取最新的热点信息。\\\\n 因此，我决定使用搜索工具。\\\\n 输出：需要检索\\\\n\\\\n\\\\n让我看看搜索结果有什么热点内容。\\\\n看了一下，搜索结果里信息挺多的。最热门的是肖战主演的《藏海传》，这个剧不仅在微博上热度很高，还刷新了播放记录，在海外也很受欢迎，韩国、新加坡都在播[^8]。主演肖战连续两个月登顶演员热度榜第一，挺厉害的。\\\\n国内政策方面有些重要消息。国务院刚发了个文件说要推动\\\\\\\"高效办成一件事\\\\\\\"[^2][^4]，还有住建部要求各地摸排保交楼情况。金融方面也有新规，证监会发布了新《公司法》的配套规则[^1]，央行说要实施适度宽松的货币政策。另外看到北京开始试点新生儿落户全程网办了。\\\\n国际新闻也挺多的。乌克兰那边说第二次和平峰会筹备完成了[^1]，德国总统解散议会准备提前选举[^1]，伊朗外交部否认了和美国会谈的消息[^2]。还有个事件是甘肃天水幼儿园血铅异常事件调查结果出来了，是幼儿园用含铅颜料做食品，8个人被拘留了[^2]。\\\\n财经方面，2025年电影票房已经突破300亿元了[^2]，挺快的。另外深交所、上交所宣布降费措施[^1]，能降14.65亿元左右。还有个值得关注的是上海发布人工智能发展方案，说要到2025年智能算力规模突破100EFLOPS[^1]。\\\\n社会新闻方面，有个演员田栩宁被曝光在女友怀孕期间疑似出轨的新闻[^9]，引起不少讨论。另外南京警方通报了个案件，说是有个38岁男子男扮女装还涉嫌传播淫秽物品[^2]。\\\\n考虑把这些热点整理成几个大类：国内要闻、国际动态、财经热点、文娱事件和社会关注。每个大类里挑最重要的几件事，简单说明一下。这样用户看起来会比较清晰，也能快速了解今天的重要新闻。\\\\n<\\\\\\\/think>\\\\n\\\\n以下是2025年7月11日的热点事件综合整理：\\\\n\\\\n---\\\\n\\\\n### 📌 **国内要闻**\\\\n1. **政策动态**  \\\\n   - **国务院推进“高效办成一件事”常态化**，明确重点事项清单管理，推动跨部门协同服务<a>[2]<\\\\\\\/a><a>[4]<\\\\\\\/a>。  \\\\n   - **住建部部署保交楼工作**，要求各地摸排项目风险，银行需配合资金硬缺口解决方案<a>[6]<\\\\\\\/a>。  \\\\n   - **北京试点新生儿落户全程网办**，户籍改革再进一步。  \\\\n\\\\n2. **金融与经济**  \\\\n   - **沪深交易所降费让利**，预计年内降费总额达14.65亿元，支持实体经济发展<a>[1]<\\\\\\\/a>。  \\\\n   - **央行发布金融稳定报告**，强调实施适度宽松货币政策，匹配经济增长目标<a>[1]<\\\\\\\/a>。  \\\\n   - **证监会公布新《公司法》配套规则过渡期安排**，规范企业治理<a>[1]<\\\\\\\/a>。  \\\\n\\\\n3. **社会事件**  \\\\n   - **甘肃天水幼儿园血铅异常事件**调查结果公布：后厨使用含铅彩绘颜料制作食品，8人被刑拘<a>[2]<\\\\\\\/a>。  \\\\n   - **南京警方通报“男扮女装传播淫秽物品”案**，38岁嫌疑人焦某某被刑拘<a>[2]<\\\\\\\/a>。  \\\\n\\\\n---\\\\n\\\\n### 🌏 **国际动态**  \\\\n1. **冲突与外交**  \\\\n   - **乌克兰宣布完成第二次和平峰会筹备**，俄乌局势持续受关注<a>[1]<\\\\\\\/a>。  \\\\n   - **伊朗否认与美国会谈**，回应特朗普“已安排谈判”言论<a>[2]<\\\\\\\/a>。  \\\\n   - **也门胡塞武装袭击以色列机场**，使用高超音速导弹加剧中东紧张<a>[1]<\\\\\\\/a>。  \\\\n\\\\n2. **政治变革**  \\\\n   - **德国总统解散议会**，为2026年2月提前选举铺路<a>[1]<\\\\\\\/a>。  \\\\n   - **保加利亚通过引入欧元法案**，2026年将成欧元区第21个成员国<a>[2]<\\\\\\\/a>。  \\\\n\\\\n3. **科技与产业**  \\\\n   - **OpenAI计划重组为公益企业**，探索非营利模式运营<a>[1]<\\\\\\\/a>。  \\\\n\\\\n---\\\\n\\\\n### 💹 **财经热点**  \\\\n1. **资本市场**  \\\\n   - **上海人工智能算力目标公布**：2025年智能算力规模突破100EFLOPS（百亿亿次浮点运算）<a>[1]<\\\\\\\/a>。  \\\\n   - **财政部在澳门发行60亿元人民币国债**，深化跨境金融合作<a>[2]<\\\\\\\/a>。  \\\\n\\\\n2. **行业突破**  \\\\n   - **全球首罐绿氨商业化项目投产**（内蒙古赤峰），推动氢能产业落地<a>[2]<\\\\\\\/a>。  \\\\n   - **湖南发现超大型锂矿床**，探明氧化锂资源量131万吨<a>[2]<\\\\\\\/a>。  \\\\n\\\\n3. **文娱消费**  \\\\n   - **2025年电影总票房突破300亿元**，暑期档多部影片拉动市场<a>[2]<\\\\\\\/a>。  \\\\n\\\\n---\\\\n\\\\n### 🎭 **文娱与社会**  \\\\n1. **文化事件**  \\\\n   - **肖战连续两月登顶演员热度榜**，主演剧《藏海传》创优酷热度纪录，非遗元素海外引关注<a>[8]<\\\\\\\/a>。  \\\\n   - **演员田栩宁被曝孕期出轨争议**，聊天记录真实性遭质疑，合作方紧急回应<a>[9]<\\\\\\\/a>。  \\\\n\\\\n2. **民生服务**  \\\\n   - **七部门联合推进普惠托育**：社区提供免费\\\\\\\/低价场地，支持全日托、半日托服务<a>[2]<\\\\\\\/a><a>[4]<\\\\\\\/a>。  \\\\n\\\\n---\\\\n\\\\n### ⚠ 注意事项  \\\\n- 部分国际事件（如特朗普关税威胁、德国出口下滑）需关注后续政策落地影响<a>[2]<\\\\\\\/a>。  \\\\n- 网传“田栩宁事件”存伪造质疑，建议以官方通报为准<a>[9]<\\\\\\\/a>。\\\",\\\"id\\\":\\\"342768d1-ebb8-4ddd-8e2a-b6200e38228d\\\",\\\"role\\\":\\\"assistant\\\",\\\"conversation_id\\\":\\\"con_5b71d482-79ff-40d5-8889-05faec61a4c7\\\"},{\\\"content\\\":\\\"今天有什么热点\\\\n\\\",\\\"id\\\":\\\"msg_ed76369e-6706-46ca-92a8-fe68b84825d6\\\",\\\"role\\\":\\\"user\\\",\\\"conversation_id\\\":\\\"con_4c5fce98-fb07-4039-aed8-aab51ce42701\\\"}]\"","in_time_ms":1752216302.312}

    #return {'messages': [{"role": "user", "content": "你好"}], 'question': '你好', 'model': 'deepseek', 'version': '124', 'session_id': '124', 'conversation_id': '124', 'user_id': '124'}
    return None

async def mock_output(**kwargs):
    trace_id = kwargs.get('trace_id', "")
    ready = kwargs.get('ready', "")
    query = kwargs.get('query', "")
    content = kwargs.get('content', "")
    print(content)