# -*- coding:utf-8 -*-
import datetime
import json
import time
import logging
import traceback

from lib.base import Base
from aiokafka import AIOKafkaProducer

# 关闭kafka的日志输出
kafka_logger = logging.getLogger("aiokafka.conn")
kafka_logger.setLevel(logging.CRITICAL)


# 输出到kafka
class KafkaStorage(Base):
    def __init__(self, pid):
        super().__init__(pid)
        self.producer = None

    async def get_producer(self):
        producer = AIOKafkaProducer(
            bootstrap_servers=["kafka-center-endpoint.sina.com.cn:9110"],
            sasl_plain_username="weiboSearch",
            sasl_plain_password="0d57008f1a611f866fd6e7c04ebb51a2",
            security_protocol="SASL_PLAINTEXT",
            sasl_mechanism="PLAIN",
            compression_type='snappy',
            value_serializer=lambda m: json.dumps(m).encode('ascii')
        )
        await producer.start()
        return producer

    async def kafka_send_one(self, data: dict):
        kafka_producer = await self.get_producer()
        try:
            await kafka_producer.send_and_wait("search_zs_model_detail", value=data)
        except Exception as e:
            self.logger.error(f"kafka send failed: {traceback.format_exc()}")
        finally:
            await kafka_producer.stop()

    async def run(self, weibo):
        trace_id = weibo.get('trace_id', "")
        query = weibo.get('query', "")
        content = weibo.get('content', "")
        question = weibo.get('ori_question', "")
        model = weibo.get('model', "deepseek")
        version = weibo.get('version', "")
        session_id = weibo.get('session_id', "")
        conversation_id = weibo.get('ori_conversation_id', "")
        uid = weibo.get('user_id', "")
        q_attr = weibo.get('q_attr', "")
        prompt_scene = weibo.get('prompt_scene', "")
        status_stage = weibo.get('update_output', {}).get("status_stage", 1)
        chat_type = weibo.get('update_output', {}).get("chat_type", 0)
        link_list = weibo.get('update_output', {}).get("link_list", [])
        llm_trace_info = weibo.get("llm_trace_info", [])
        # 改写词和搜索结果
        modify_queries = weibo.get('modify_query',[])
        chat_prompt = weibo.get('chat_prompt', "")
        # 合一下历史对话
        message_conv = weibo.get('message_conv',[])
        task_output = weibo.get('task_output',"")
        model_filter = weibo.get('model_filter', "")
        query_filter_reason = weibo.get("query_filter_reason", "")
        basemodel = weibo.get("basemodel", "")
        json_data = {
            "log_type": "wis_dialogue",
            "data_type": "zs_generate",
            "data_from": "wis_dialogue",
            'content': content,
            "question": question,
            "model": model,
            "version": version,
            "session_id": session_id,
            "conversation_id": conversation_id,
            "user_id": uid,
            "q_attr": q_attr,
            "prompt_scene": prompt_scene,
            "status_stage": status_stage,
            "chat_type": chat_type,
            "link_list": link_list,
            "llm_trace_info": llm_trace_info,
            "modify_queries": modify_queries,
            "chat_prompt":chat_prompt,
            "message_conv":message_conv,
            "task_output":task_output,
            "model_filter": model_filter,
            "query_filter_reason": query_filter_reason,
            "basemodel": basemodel
        }

        kafka_begin = time.time()
        try:
            await self.kafka_send_one(json_data)
        except Exception as e:
            kafka_end = time.time()
            self.logger.error(
                f"write to kafka failed: query:{query}\ttraaceid:{trace_id}\t{traceback.format_exc()}")
            self.logger.error("write to kafka,query:{}\ttraaceid:{}\tpost_data:{}\ttime_cost:{}".format(
                query, trace_id, json.dumps(json_data, ensure_ascii=False), kafka_end - kafka_begin))
        self.logger.info(
            "write to kafka,query:{}\ttraceid:{}\ttime_cost:{}".format(query, trace_id, time.time() - kafka_begin))

    async def close(self):
        if self.producer:
            await self.producer.stop()
