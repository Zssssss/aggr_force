# -*- coding:utf-8 -*-
import asyncio
import json
import time

from lib.base import Base
from lib.redis_utils import async_redis_client


class RedisStorage(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.redis_client = async_redis_client
        self.days = 7  # 过期时间为7天

    async def run(self, weibo):
        trace_id = weibo.get('trace_id', "")
        content = weibo.get('content', "")
        question = weibo.get('ori_question', "")
        model = weibo.get('model', "deepseek")
        version = weibo.get('version', "")
        session_id = weibo.get('session_id', "")
        conversation_id = weibo.get('ori_conversation_id', "")
        uid = weibo.get('user_id', "")
        q_attr = weibo.get('q_attr', "")
        prompt_scene = weibo.get('prompt_scene', "")
        status_stage = weibo.get('update_output', {}).get("status_stage", 1)
        chat_type = weibo.get('update_output', {}).get("chat_type", 0)
        link_list = weibo.get('update_output', {}).get("link_list", [])
        llm_trace_info = weibo.get("llm_trace_info", [])
        # 改写词和搜索结果
        modify_queries = weibo.get('modify_query', [])
        chat_prompt = weibo.get('chat_prompt', "")
        # 合一下历史对话
        message_conv = weibo.get('message_conv', [])
        task_output = weibo.get('task_output', "")
        all_material = weibo.get('all_material', "")
        json_data = {
            'content': content,
            "question": question,
            "model": model,
            "version": version,
            "session_id": session_id,
            "conversation_id": conversation_id,
            "user_id": uid,
            "q_attr": q_attr,
            "prompt_scene": prompt_scene,
            "chat_prompt": chat_prompt,
            "all_material": all_material,
            "link_list": json.dumps(link_list, ensure_ascii=False),
        }

        start = time.time()
        key = f'wis_dialogue_{conversation_id}'
        redis_client = self.redis_client.get_redis_server(key)
        try:
            for k, v in json_data.items():
                await redis_client.hset(key, k, v)
            await redis_client.expire(key, self.days * 24 * 60 * 60)
            self.logger.info(f"trace_id:{trace_id}\tquery:{question}\t redis write success cost: {time.time() - start}")
        except Exception as e:
            self.logger.error(f"trace_id:{trace_id}\tquery:{question}\t error:{e}")

    async def close(self):
        pass
        #await self.redis_client.close()