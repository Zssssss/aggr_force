import json
import time
import datetime
import random
import traceback
import asyncio
from fastapi import APIRouter,Request

from app.apis.wis_search.services_v2 import DialogueService, WhiteboardDialogueService
from lib.safe_logger import get_logger
from starlette.responses import StreamingResponse
from app.apis.wis_search.models import ChatCompletionRequest
from app.apis.wis_search.utils.streaming import Streamer

router = APIRouter()
logger = get_logger("log/wis_search_view.log", "VIEW")


class WhiteboardOutput:
    def __init__(self, streamer):
        self.streamer = streamer

    async def output(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        content = kwargs.get('content', "")
        ready = kwargs.get('ready', "")
        await self.streamer.put(content)


async def run(service, streamer):
    try:
        await service.chat_stream()
    except Exception as e:
        print(f"run error: {e}")
    finally:
        await streamer.close()


@router.post("/v1/chat/completions")
async def handler(request: ChatCompletionRequest):
    trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
    params = request.dict()
    params['user_id'] = params.get('user').split('@')[0]
    params["conversation_id"] =params.get('conversationId')
    params["session_id"] = ""
    params["trace_id"] =params.get('trace_id', trace_id)
    params["model"] =params.get('model')
    params["source_type"] = "white_board"
    logger.info("queue in {}".format(params))
    pid = "wb"

    try:
        streamer = Streamer(pid, trace_id, 100)
        output = WhiteboardOutput(streamer)
        chat_service = WhiteboardDialogueService(pid, params, output)
        task = asyncio.create_task(run(chat_service, streamer))
        async def generate():
            l = 0
            try:
                async for resp in streamer.stream():
                    resp = resp[l:]
                    l += len(resp)
                    if not resp:
                        continue

                    yield "data: " + json.dumps({
                        "created": time.time(),
                        "model": params.get('model'),
                        "choices": [{"delta": {"role": "assistant", "content": resp}}],
                    }) + "\n\n"
                yield "data: [DONE]\n\n"
            except Exception:
                logger.error(f"{trace_id} error:{traceback.format_exc()}")
            await task
        return StreamingResponse(
            generate(), media_type="text/event-stream"
        )
    except:
        logger.error(f"{trace_id} error:{traceback.format_exc()}")



@router.post("/chat/completions")
async def handler_new(request: ChatCompletionRequest):
    trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
    params = request.dict()
    params['user_id'] = params.get('user').split('@')[0]
    params["conversation_id"] =params.get('conversationId')
    params["session_id"] =params.get('sessionID')
    params["trace_id"] =params.get('trace_id', trace_id)
    params["source_type"] = "client"
    logger.info("queue in {}".format(params))
    pid = "wb"

    try:
        streamer = Streamer(pid, trace_id, 100)
        output = WhiteboardOutput(streamer)
        chat_service = DialogueService(pid, params, output)
        task = asyncio.create_task(run(chat_service, streamer))
        async def generate():
            try:
                async for resp in streamer.stream():

                    logger.info(f"{trace_id}, output:{json.dumps(resp, ensure_ascii=False)}")
                    yield "data: " + json.dumps({
                        "created": time.time(),
                        "model": params.get('model'),
                        "choices": [{"delta": {"role": "assistant", "content": resp}}],
                    }) + "\n\n"

                logger.info(f"{trace_id}, done")
                yield "data: [DONE]\n\n"
            except Exception:
                logger.error(f"{trace_id} error:{traceback.format_exc()}")
            await task
        return StreamingResponse(
            generate(), media_type="text/event-stream"
        )
    except:
        logger.error(f"{trace_id} error:{traceback.format_exc()}")