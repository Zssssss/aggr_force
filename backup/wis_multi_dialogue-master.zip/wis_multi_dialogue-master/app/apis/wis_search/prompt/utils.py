"""prompt相关的公共方法"""
# -*- coding:utf-8 -*-
from datetime import datetime
from copy import deepcopy
from conf.config import USE_SIMILAR_HISTORY

# ============= 获取当前时间字符串 =============
def get_today_str():
    """获取当天日期字符串"""
    # 星期对应中文
    weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']

    now = datetime.now()
    weekday_cn = weekdays[now.weekday()]  # weekday() 返回 0~6，对应周一到周日

    formatted_time = now.strftime("%Y年%m月%d日 ") + weekday_cn
    return formatted_time

# ============= 使用上下文 =============
def use_context(source_type: str, cur_type: str, messages_conv: dict):
    """使用上下文"""
    use_dict = USE_SIMILAR_HISTORY.get(cur_type, {})
    if source_type in use_dict:
        is_use = use_dict[source_type]
    else:
        is_use = use_dict.get("default", True)
    new_messages_conv = deepcopy(messages_conv)
    if not is_use:
        new_messages_conv["history_conv"] = []
        new_messages_conv["retrieval_conv"] = []
    return new_messages_conv
