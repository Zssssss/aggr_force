# -*- coding:utf-8 -*-
from lib.safe_logger import get_logger


class BasePrompt:

    def __init__(self, weibo):
        self.weibo = weibo
        self.pid = weibo.get("pid", '888')
        log_filename = "log/prompt-" + str(self.pid) + ".log"
        self.logger = get_logger(log_filename, self.__class__.__name__)

    def prompt(self):
        raise NotImplementedError

    def schema_index(self):
        return None

    def post_process(self, result):
        return result
