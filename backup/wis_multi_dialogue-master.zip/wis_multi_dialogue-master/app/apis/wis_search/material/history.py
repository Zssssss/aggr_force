# -*- coding:utf-8 -*-
import asyncio
import time
import aiohttp
import json
import re

from lib.base import Base
from app.apis.wis_search.post_process.utils import delete_wbcustomblock
from app.apis.wis_search.material.mid_info import MidMaterial

class DialogueHistory(Base):

    def get_mid_url(self, trace_id, mid, chat):
        uid = ""
        try:
            mblog_info = chat.get("mblog_info")
            if not mblog_info:
                return ""
            if isinstance(mblog_info, list):
                uid = mblog_info[0].get("data", {}).get("user", {}).get("id", "")
            elif isinstance(mblog_info, dict):
                uid = mblog_info.get("data", {}).get("user", {}).get("id", "")
        except Exception as e:
            self.logger.error(f"{trace_id} parse mblog_info error: {e}")

        if uid and mid:
            return f"博文链接：https://weibo.com/{uid}/{mid}"
        return ""


    async def get_history(self, trace_id, user_id, session_id, num=6):
        retry = 2
        for i in range(retry):
            try:
                messages = []
                params = {'user_id': user_id, 'session_id': session_id, 'num': num, "filter_tag": 36}
                timeout = aiohttp.ClientTimeout(total=2)
                headers = {'Content-Type': 'application/json'}
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get("http://admin.ai.s.weibo.com/api/chat/history.json",
                                           params=params, timeout=timeout, headers=headers) as response:
                        # response.raise_for_status()
                        text = await response.text(errors='ignore')  # 忽略解码错误
                        try:
                            data = json.loads(text)
                        except json.JSONDecodeError:
                            # 尝试不同的编码
                            try:
                                binary = await response.read()
                                text = binary.decode('utf-8', errors='ignore')
                                data = json.loads(text)
                            except Exception:
                                data = None
                        history = data.get('data', [])
                        if history:
                            for chat in reversed(history):
                                blacked = str((chat.get('risk_control') or {}).get("blacked") or 0)
                                question = chat.get('question', "")
                                content = chat.get('content', "")
                                prompt_scene = chat.get('prompt_scene', "")
                                model = chat.get('model', "")
                                answer_from = chat.get('answer_from', "")
                                mblog_info = chat.get('mblog_info', {})
                                # 私信博文 or 对话博文
                                if prompt_scene == 'chat_verification' or model == 'deepseek_verification' or mblog_info:
                                    url = self.get_mid_url(trace_id, question, chat)
                                    cur_mid = question
                                    if url:
                                        question = url
                                    mid_content = await MidMaterial(self.pid).get_mid_content(trace_id, cur_mid)
                                    if mid_content:
                                        mid_content += "\n请对这篇原博进行求证和解读。"
                                        question = mid_content
                                if answer_from == "comment":
                                    comment = chat.get("comment_info", {}).get("text", "")
                                    cur_mid = chat.get("mid", "")
                                    mid_content = await MidMaterial(self.pid).get_mid_content(trace_id, cur_mid)
                                    mid_content += f"用户对原博的评论是：{comment}\n请回复用户评论。"
                                    question = mid_content
                                if question and content and blacked != '1':
                                    messages.append({'role': 'user', 'content': question})
                                    messages.append({'role': 'assistant', 'content': content})
                self.logger.info(f"{trace_id} history len: {len(messages)}")
                return messages
            except Exception as e:
                self.logger.error(f"{trace_id} get history error: {e}")
        return []


    async def get_conversation(self, trace_id, user_id, session_id, conversation_id):
        retry = 2
        for i in range(retry):
            try:
                params = {'user_id': user_id, 'session_id': session_id, "conversation_id": conversation_id,
                          "filter_tag": 36}
                timeout = aiohttp.ClientTimeout(total=3)
                headers = {'Content-Type': 'application/json'}
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get("http://admin.ai.s.weibo.com/api/chat/history.json",
                                           params=params, timeout=timeout, headers=headers) as response:
                        # response.raise_for_status()
                        text = await response.text(errors='ignore')  # 忽略解码错误
                        try:
                            data = json.loads(text)
                        except json.JSONDecodeError:
                            # 尝试不同的编码
                            try:
                                binary = await response.read()
                                text = binary.decode('utf-8', errors='ignore')
                                data = json.loads(text)
                            except Exception:
                                data = None
                        history = data.get('data', [])
                        if history:
                            chat = history[0]
                            blacked = str((chat.get('risk_control') or {}).get("blacked") or 0)
                            content = chat.get('content', "")
                            if content and blacked != '1':
                                result = content
                                if "</think>" in result:
                                    result = result.split("</think>")[1]
                                return delete_wbcustomblock(result)
                return ""
            except Exception as e:
                self.logger.error(f"{trace_id} get history error: {e}")
        return ""


async def main():
    # history = await DialogueHistory("test").get_history("test", "2820854703", "75c8054018f1f4340a01d0f983d46ad6")
    history = await DialogueHistory("test").get_history("test", "7717229954", "1448932661151580872")
    print(history)


if __name__ == '__main__':
    asyncio.run(main())