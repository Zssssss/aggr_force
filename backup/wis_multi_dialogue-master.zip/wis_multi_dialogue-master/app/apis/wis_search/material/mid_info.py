# -*- coding:utf-8 -*-
import time
import json
import re
import aiohttp

from lib.base import Base
from lib.weibo_interface import checkQualifiedOcrText, get_voice, get_user_info


class MidMaterial(Base):

    async def get_art_content(self, trace_id, id):
        cleaned_text = ""
        url = "http://i2.api.weibo.com/2/entity/show.json?source=2842762591&object_id=1022:{}&with_object=1".format(id)

        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        content = res.get("entity", {}).get("content", "")
                        follow_to_read = int(res.get("entity", {}).get("follow_to_read", 1) or 1)
                        if follow_to_read == 1 or not content:
                            return ""
                        cleaned_text = re.sub(r'<[^>]+>', '', content)
        except Exception as e:
            self.logger.error(
                "{} get art content error:{}".format(trace_id, e))
        return cleaned_text

    async def get_weibo_article(self, trace_id, weibo):
        art_text = ""
        filter = int(weibo.get("FILTER", "0") or "0")
        if filter & 128 == 0:
            return art_text
        lurls = weibo.get("LURLS", "")
        art_id = ""
        for url in lurls.split(" "):
            if "ttarticle" in url:
                art_id = url.split("id=")[-1]
                break
        if art_id:
            art_text = await self.get_art_content(trace_id, art_id)
        return art_text

    def parse_all_tag_new(self, trace_id, all_tag_new):
        try:
            if not all_tag_new:
                return False

            all_tag_new_dict = json.loads(all_tag_new)
            m1 = all_tag_new_dict.get("m1", "")
            r1 = all_tag_new_dict.get("r1", "")
            if "医疗" in m1 or "医疗" in r1:
                return True
        except:
            self.logger.error(
                "{} all_tag_new parse error:{}".format(trace_id, all_tag_new))
        return False


    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        start = time.time()
        # 博文分析-求证
        mid_content = ""
        mid_voice = ""
        ocr_text = ""
        article_text = ""
        mid_uid = ""
        nick_name = ""
        pub_time = ""
        root_name = ""
        root_txt = ""
        filter = False
        is_star = False
        is_ad = False
        try:
            url = f"http://hbaseapi.search.weibo.com/getdata/querydata2.php?condition={query}&mode=weibo&format=json&hbase=1"
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as session:
                try:
                    async with session.get(url) as resp:
                        text = await resp.text()
                        res = json.loads(text)

                        if not isinstance(res, dict):
                            self.logger.error(
                                "{} hase get error:{}".format(trace_id, json.dumps(res, ensure_ascii=False)))

                        mid_content = res.get("LONGTEXT", "") if res.get("ISLONG", "") == "1" else res.get("CONTENT", "")
                        filter = int(res.get("FILTER", 0) or "0") & 4
                        nick_name = res.get('NICK', "")
                        pub_time = res.get('TIME')
                        if filter:
                            root_long_text = res.get("ROOT_LONGTEXT", "")
                            root_mid = res.get("ROOTMID", "")
                            root_name, root_uid, root_pub = await get_user_info(root_mid)
                            root_txt = root_long_text if root_long_text else res.get("TEXT", "")
                        mid_voice = res.get("VIDEO_VOICE", "").strip()
                        mid_uid = res.get('UID', "")
                        is_ad = int(res.get('QI') or '0') % 2

                        pic_feature = json.loads(res.get("PICS_FEATURE", "{}"))
                        if pic_feature:
                            txt = "".join([item['ocr'] for item in pic_feature['res'] if 'ocr' in item])
                            is_ocr = checkQualifiedOcrText(txt)
                            self.logger.info(
                                "{} ocr {} is_ocr:{}".format(trace_id, json.dumps(txt, ensure_ascii=False), is_ocr))
                            if is_ocr:
                                ocr_text = txt
                        article_text = await self.get_weibo_article(trace_id, res)
                        INNER_USER_INFO = json.loads(res.get("INNER_USER_INFO","{}"))
                        users = INNER_USER_INFO.get("users", [])
                        if users:
                            attr1 = users[0].get("flevel", {}).get("attr1", "")
                            if attr1 == "明星":
                                weibo['is_star'] = True
                                is_star = True
                            if attr1 == "组织号":
                                weibo['is_organization'] = True
                        category_v2 = res.get("CATEGORY_V2")
                        if category_v2:
                            weibo["mid_category_v2"] = int(category_v2) - 1

                        all_tag_new = res.get("ALL_TAG_NEW", "")
                        if self.parse_all_tag_new(trace_id, all_tag_new):
                            weibo["mid_is_medical"] = True
                except Exception as e:
                    self.logger.error(
                        "{} HBASE ERROR {} error:{}".format(trace_id, query, e))

            if not mid_content:
                mid_content, mid_voice, mid_uid = await get_voice(query)

            try:
                mid_content = re.sub(u'(?i)http[s]?://(?:[a-zA-Z]|[0-9]|[#$%*-;=?&@~.&+]|[!*,])+$', '', mid_content.strip())
                mid_content = re.sub(r'<sina.*?>$', '', mid_content)

                root_txt = re.sub(u'(?i)http[s]?://(?:[a-zA-Z]|[0-9]|[#$%*-;=?&@~.&+]|[!*,])+$', '', root_txt.strip())
                root_txt = re.sub(r'<sina.*?>$', '', root_txt)
            except:
                pass

            parts = []
            if mid_content or filter:
                mid_content_part = f"- 博文正文：{mid_content}"
                if filter:
                    mid_content_part += f"- 转自@{ root_name }：\n{ root_txt }"
                parts.append(mid_content_part)
            if article_text:
                parts.append(f"- 博文中的文章内容为：{article_text}")
            if mid_voice:
                parts.append(f"- 博文中视频的声音识别结果为：{mid_voice}")
            if ocr_text:
                parts.append(f"- 博文中图片的识别结果为：{ocr_text}")

            mid_content = '\n'.join(parts) if parts else ''
        except Exception as e:
            self.logger.error(
                "{} mid material {} error:{}".format(trace_id, query,e))

        weibo['mid_content'] = mid_content
        weibo['mid_uid'] = mid_uid
        weibo['nick_name'] = nick_name
        weibo['pub_time'] = pub_time
        weibo['is_forward'] = filter
        weibo['is_ad'] = is_ad
        self.logger.info("{} mid_content: {}, cost: {}".format(trace_id, mid_content, time.time() - start))

    async def get_mid_content(self, trace_id, mid):
        weibo = {
            "query": mid,
            "trace_id": trace_id,
        }
        await self.run(weibo=weibo)
        nick_name = weibo.get("nick_name", "")
        pub_time = weibo.get("pub_time", "")
        mid_content = weibo.get("mid_content", "")
        return f"现在有一篇由{ nick_name }在{ pub_time }发布的原博，内容如下：\n{ mid_content }"
