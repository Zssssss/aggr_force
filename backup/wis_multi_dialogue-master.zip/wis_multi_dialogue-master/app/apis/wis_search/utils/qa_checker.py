import re
import json
import time
import traceback

from api.model_api import QWEN3_235B_ModelFirstPageWrapper, QWEN3_30B_Wrapper
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think
from app.apis.wis_search.prompt.utils import get_today_str
from app.apis.wis_search.utils.count_token import count_tokens
from lib.safe_logger import get_logger
from app.apis.wis_search.models import FirstRoundBack
import asyncio
import json
from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
qa_check_prompt_template = env.get_template('app/apis/wis_search/prompt/qa_check.j2')


class QaChecker:

    def __init__(self, trace_id, model) :
        log_filename = "log/" + self.__class__.__name__.lower() + ".log"
        self.logger = get_logger(log_filename, self.__class__.__name__)
        self.trace_id = trace_id
        self.model = model

    def check_content(self, content: str, is_end=False):
        """检查内容是否直接输出"""
        re_reason = re.compile(r"理由[:：]")
        max_length = 10
        if len(content) < max_length and not is_end:
            return "待定", ""
        if "直接回答" in content[:max_length]:
            return "直接回答", ""
        if "联网检索" in content[:max_length]:
            search = re_reason.search(content)
            if not search:
                content = ""
            else:
                content = content[search.end(0):].strip()
            return "联网检索", content
        return "直接回答", ""


    async def run(self, query: str, messages_conv: dict, fr_back: FirstRoundBack, llm_trace_info: list, chat_check_info: dict):
        """起始轮对话"""
        start = time.time()
        self.logger.info(
            f"trace_id: {self.trace_id}, first_round start, query: {query}, messages_conv: {json.dumps(messages_conv, ensure_ascii=False)}")
        cur_date = get_today_str()
        history_conv = messages_conv.get("history_conv", [])
        is_deepthink = self.model == "思考版"
        qa_check_prompt = qa_check_prompt_template.render(question=query,
                                                          cur_date=cur_date,
                                                          is_deepthink=is_deepthink).strip()
        llm = QWEN3_235B_ModelFirstPageWrapper("", f"trace_id: {self.trace_id}\t", chat_check_info)
        try :
            stream_response = await llm.async_stream_call_dialogue(qa_check_prompt, history_conv)
            chat_check_info["qa_check_prompt"] = history_conv + [{"role": "user", "content": qa_check_prompt}]
            is_qa = True
            result = ""
            think = ""
            content = ""
            check = "待定"
            ori_content = ""

            response = None
            first_token = None
            # 使用 async for 来迭代异步生成器
            async for response in stream_response :
                # if response is None :  # 处理可能的 None 响应
                #     continue
                result = response.get("text", "")
                if not result :  # 如果没有文本内容，跳过
                    continue

                if first_token is None:
                    first_token = time.time()

                think, content = split_think_and_content_with_no_think(result)
                content = content.strip()
                if not content :
                    continue

                ori_content = content
                check, content = self.check_content(content)
                if check == "直接回答":
                    is_qa = False
                    self.logger.info(f"trace_id: {self.trace_id}, first_round end, prompt: {json.dumps(qa_check_prompt, ensure_ascii=False)}, content: {ori_content}")
                    break
                if check == "联网检索" and content:
                    yield f"<think>\n{content}"
            if check == "待定":
                check, content = self.check_content(ori_content, is_end=True)
                if check == "直接回答":
                    is_qa = False
                    self.logger.info(f"trace_id: {self.trace_id}, first_round end, prompt: {json.dumps(qa_check_prompt, ensure_ascii=False)}, content: {ori_content}")
                elif check == "联网检索" and content:
                    yield f"<think>\n{content}"
            fr_back.think = content
            fr_back.content = ""
            fr_back.is_qa = is_qa
            chat_check_info["qa_check_result"] = ori_content

            count_tokens(start, response, "qwen-plus", llm_trace_info, "query_check", first_token)
            self.logger.info(
                f"trace_id: {self.trace_id}, query: {query}, is_qa: {is_qa} first_round end, cost: {time.time() - start}, ori_content：{ori_content}")
        except Exception as e :  # 使用更通用的异常类型
            self.logger.error(
                f"trace_id: {self.trace_id}, query: {query}, first_round error: {e}, {traceback.format_exc()}")


async def main():

    print('hello')
    fr = FirstRoundBack()
    checker = QaChecker("test", '')
    async for txt in  checker.run("今天天气怎么样", {}, fr):
        print(txt)


if __name__ == "__main__":

    asyncio.run(main())