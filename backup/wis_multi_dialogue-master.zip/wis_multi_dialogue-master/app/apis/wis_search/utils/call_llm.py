import time
import traceback
from datetime import datetime

import aiohttp
from jinja2 import Environment, FileSystemLoader
from zsmaterial.pipeline import MultiTurnPipeline
from app.apis.wis_search.utils.count_token import count_tokens
from api.model_api import WeiboDeepseekWrapper
from lib.safe_logger import get_logger
from app.apis.wis_search.models import FirstRoundBack, MaterialModel
from app.apis.wis_search.post_process.quote_process import process_text
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think
from app.apis.wis_search.prompt.utils import get_today_str
from app.apis.wis_search.models import ContextModel

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('app/apis/wis_search/prompt/chat_user.j2')
prompt_template_system = env.get_template('app/apis/wis_search/prompt/chat_system.j2')
sixin_tool_prompt_template = env.get_template('app/apis/wis_search/prompt/sixin_tool.j2')
log_filename = "log/" + "call_llm.log"


class MultiStreamChat(object):

    def __init__(self, query, trace_id, modified_queries, messages_conv, model, is_private_message, basemodel, risk_info = {}):
        self.query = query
        self.messages_conv = messages_conv
        self.trace_id = trace_id
        self.modified_queries = modified_queries
        self.logger = get_logger(log_filename, "multi_stream_chat")
        self.model = model
        self.is_private_message = is_private_message
        self.basemodel = basemodel
        self.risk_info = risk_info
        if not self.modified_queries and self.query:
            self.modified_queries = [self.query]

    async def get_materials(self,model):
        start_time = time.time()
        datas = {
            "search_querys" : self.modified_queries,
            "trace_id" : self.trace_id
        }
        headers = {'Content-Type' : 'application/json'}

        base_length = 50000
        if model == "非思考版":
            base_length = 50000
        materials = ""
        context_data = ContextModel()
        material_data = MaterialModel()
        try:
            if self.risk_info:
                cur_data = await MultiTurnPipeline(base_length).run(self.modified_queries, risk_info=self.risk_info, query=self.query)
            else:
                cur_data = await MultiTurnPipeline(base_length).run(self.modified_queries, query=self.query)
            materials = cur_data.get("content", "")
            context_data = ContextModel(**cur_data)
            material_data = MaterialModel(**cur_data)

            self.logger.info(
                f"get_materials trace_id: {self.trace_id}, query: {self.query},is_complex_query: {context_data.is_complex_query_list}， materials_len: {len(materials)},cost: {time.time() - start_time}"
            )
            return materials, context_data, material_data
        except Exception as e:
            self.logger.error(
                f"get_materials error trace_id: {self.trace_id}, exception: {e}, query: {self.query}, post_data: {datas}, err: {traceback.format_exc()}"
            )
            return materials, context_data, material_data

    async def get_prompt(self):
        materials = ""
        context_data = ContextModel()
        material_data = MaterialModel()
        if self.modified_queries:
            materials, context_data, material_data = await self.get_materials(self.model)
        parametric_knowledge = True
        # query命中B级、C级或D级风控不使用参数化知识
        if self.risk_info.get("limit_degree", "") in ["B", "C", "D"]:
            parametric_knowledge = False
        cur_date = get_today_str()
        blog_analysis = context_data.blog_analysis_flag
        cur_round = self.messages_conv.get("cur_round", 1)
        num_history_conv = len(self.messages_conv.get("history_conv", [])) // 2
        retrieval_conv = "\n".join(map(str, self.messages_conv.get("retrieval_conv", [])))
        history_conv = "\n".join(map(str, self.messages_conv.get("history_conv", [])))
        first_conv = not self.messages_conv.get("history_conv", [])
        is_deepthink = self.model == '思考版'
        is_exp = self.basemodel in ['实验组3']
        shiyan3 = is_exp and not is_deepthink

        # grice_optim = self.basemodel in ['实验组1', '实验组2', '实验组3']
        # no_guide_optim = self.basemodel in ['实验组4', '实验组5', '实验组6']
        prompt = prompt_template.render(question=self.query,
                                    is_dialogue=False,
                                    search_result=materials,
                                    cur_round=cur_round,
                                    first_conv=first_conv,
                                    parametric_knowledge=parametric_knowledge,
                                    cur_date=cur_date,
                                    blog_analysis=blog_analysis,
                                    retrieval_conv=retrieval_conv,
                                    is_private_message=self.is_private_message,
                                    is_deepthink=is_deepthink,
                                    shiyan3=shiyan3
                               ).strip()
        return prompt, context_data, material_data

    async def run(self, sc_back: FirstRoundBack, llm_trace_info, chat_check_info, prompt=None):
        self.logger.info(f"call_llm start trace_id: {self.trace_id}, query: {self.query}")
        start_time = time.time()
        pre_log_msg = f"trace_id:{self.trace_id}\t"
        llm = WeiboDeepseekWrapper(pid="", pre_log_msg=pre_log_msg, chat_check_info=chat_check_info)
        # if not prompt:
        #     prompt, context_data = await self.get_prompt()
        result = ""
        response = None
        first_token = None
        history_conv = self.messages_conv.get("history_conv", [])
        stream_response = await llm.async_stream_call_dialogue(prompt, history_conv)
        chat_check_info["qa_prompt"] = history_conv + [{"role": "user", "content": prompt}]
        ori_content = ""
        async for response in stream_response:
            # if response is None :  # 处理可能的 None 响应
            #     continue

            if first_token is None:
                first_token = time.time()
            result = response.get("text", "")
            ori_content = result
            result = process_text(result)
            yield result

        chat_check_info["qa_result"] = ori_content
        count_tokens(start_time, response, "deepseek_v3.1", llm_trace_info, "second_round", first_token)
        think, content = split_think_and_content_with_no_think(result)
        sc_back.think = think
        sc_back.content = content
        self.logger.info(f"call_llm finished trace_id: {self.trace_id}, query: {self.query}, cost: {time.time() - start_time}")

class SiXinToolStreamChat(object):
    def __init__(self, query, trace_id, model):
        self.query = query
        self.trace_id = trace_id
        self.model = model
        self.logger = get_logger(log_filename, "sixintool_stream_chat")

    def get_prompt(self):
        cur_date = get_today_str()
        retrieval_conv = ""
        is_private_message = True
        prompt = sixin_tool_prompt_template.render(retrieval_conv=retrieval_conv,
                                                   question=self.query,
                                                   cur_date=cur_date,
                                                   is_private_message=is_private_message).strip()
        return prompt

    async def run(self, prompt):
        start_time = time.time()
        pre_log_msg = f"trace_id:{self.trace_id}\t"
        chat_check_info = {}
        llm = WeiboDeepseekWrapper(pid="", pre_log_msg=pre_log_msg, chat_check_info=chat_check_info)
        history_conv = []
        first_token = None
        prompt_system = prompt_template_system.render().strip()
        stream_response = await llm.async_stream_call_dialogue(prompt,[{"role": "system", "content": prompt_system}] + history_conv)
        async for response in stream_response :
            # if response is None :  # 处理可能的 None 响应
            #     continue

            if first_token is None :
                first_token = time.time()
            result = response.get("text", "")
            result = process_text(result)
            yield result
        self.logger.info(f"call_llm finished trace_id: {self.trace_id}, query: {self.query}, cost: {time.time() - start_time}, first token cost: {time.time() - first_token}")

