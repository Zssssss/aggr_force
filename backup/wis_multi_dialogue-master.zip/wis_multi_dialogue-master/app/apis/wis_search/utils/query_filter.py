# -*- coding:utf-8 -*-
import json
import re
import time
from datetime import datetime

from jinja2 import Environment, FileSystemLoader

from api.model_api import QWEN3_30B_Wrapper
from app.apis.wis_search.prompt.base import BasePrompt
from app.apis.wis_search.utils.count_token import count_tokens
from lib.base import Base

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('app/apis/wis_search/prompt/query_filter.j2')


class QueryFilterPrompt(BasePrompt):
    @staticmethod
    def remove_urls(text):
        # 匹配更全面的URL模式，包括www开头的网址
        url_pattern = r'https?://[^\s\u4e00-\u9fa5]+|www\.[^\s\u4e00-\u9fa5]+'
        return re.sub(url_pattern, '', text)

    def prompt(self):
        query = self.weibo.get("question", "")
        clean_query = self.remove_urls(query)
        prompt = prompt_template.render(user_input=clean_query)
        return prompt

    def post_process(self, result):
        try:
            decision_match = re.search(r'decision:\s*([^\r\n]*)', result)
            category_match = re.search(r'category:\s*([^\r\n]*)', result)
            disguise_match = re.search(r'disguise[：:]\s*([^\r\n]*)', result)

            decision = ""
            category = ""
            disguise = ""
            if decision_match:
                decision = decision_match.group(1).strip()
            if category_match:
                category = category_match.group(1).strip()
            if disguise_match:
                disguise = disguise_match.group(1).strip()

            if decision == '有风险' and (category == '政治风险' or category == '违法犯罪' or category == '系统安全') and disguise == '有诱导':
                return True
        except Exception as e:
            pass
        return False


def log(weibo, llm_result, is_filter, logger):
    query = weibo.get("question", "")
    version = weibo.get("version", "")
    q_attr = weibo.get("q_attr", "")
    uid = weibo.get('user_id', "")
    logger.info(f"chat filter log: {version}\t{json.dumps(query,ensure_ascii=False)}\t{json.dumps(llm_result, ensure_ascii=False)}\t{is_filter}\t{q_attr}\t{uid}")

async def query_filter(weibo, logger):
    start = time.time()
    trace_id = weibo.get("trace_id", "")
    query = weibo.get("question", "")
    llm_trace_info = weibo.get("llm_trace_info", [])
    debug_info = weibo.get("debug_info", {})
    debug_info["query_filter_start"] = start
    stage = '诱导Query判断'
    is_filter = False
    if len(query) >= 30:
        pre_log_msg = f"trace_id:{trace_id}\tquery:{query}\t"
        llm_model = QWEN3_30B_Wrapper(pid="", pre_log_msg=pre_log_msg, llm_call_stage=stage)
        prompt = QueryFilterPrompt(weibo)
        for _ in range(2):
            try:
                prompt_content = prompt.prompt()
                messages = ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt_content]
                response = await llm_model.async_call_dialogue(messages, timeout=1, temperature=0)
                count_tokens(start, response, 'qwen3-30b', llm_trace_info, stage)
                llm_result = response.get("text", "")
                weibo['query_filter_reason'] = json.dumps(llm_result, ensure_ascii=False)
                is_filter = prompt.post_process(llm_result)
                log(weibo, llm_result, is_filter, logger)
                logger.info(
                    pre_log_msg + f"response: {json.dumps(llm_result, ensure_ascii=False)}, result: {is_filter}")
                break
            except Exception as e:
                logger.error(f"query filter retry call qwen30b llm: {e}")
        end = time.time()
        debug_info["query_filter_end"] = end
        logger.info("{}, cost: {}".format(trace_id, end - start))
    return is_filter
