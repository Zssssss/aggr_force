# -*- coding:utf-8 -*-
import asyncio
from typing import AsyncGenerator, Any
from lib.base import Base

class NoStreamer:
    async def put(self, data: Any) -> None:
        pass

    async def close(self) -> None:
        pass


class Streamer(Base):
    _END = object()

    def __init__(self, pid, trace_id: str, timeout: int = None):
        super().__init__(pid)
        self.trace_id = trace_id
        self.queue = asyncio.Queue()
        self.timeout = timeout

        self._closed = False
        self._close_lock = asyncio.Lock()

    async def put(self, data: Any) -> None:
        async with self._close_lock:
            if self._closed:
                self.logger.error(f"{self.trace_id} put 被拒绝，队列已关闭")
                return

            await self.queue.put(data)

    async def close(self) -> None:
        async with self._close_lock:
            if not self._closed:
                self._closed = True
                await self.queue.put(self._END)  # 结束标志

    async def stream(self) -> AsyncGenerator[Any, None]:
        try:
            while True:
                data = await asyncio.wait_for(self.queue.get(), self.timeout)
                if data is self._END:
                    break
                yield data
        except asyncio.TimeoutError:
            self.logger.error(f"{self.trace_id} 获取超时，自动关闭")
            await self.close()
            raise
        except asyncio.CancelledError:
            self.logger.error(f"{self.trace_id} 流被取消，自动关闭")
            await self.close()
            raise
        except Exception as e:
            self.logger.error(f"{self.trace_id} 流处理错误: {e}")
            await self.close()
            raise
        finally:
            remain = self.queue.qsize()
            if remain:
                self.logger.error(f"{self.trace_id} 队列剩余长度: {remain}")

    def is_closed(self) -> bool:
        return self._closed

    def size(self) -> int:
        return self.queue.qsize()