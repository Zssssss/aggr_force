import json
import re
import time
import traceback
from datetime import datetime
from jinja2 import Environment, FileSystemLoader

from app.apis.wis_search.utils.count_token import count_tokens
from lib.safe_logger import get_logger
from api.model_api import QWEN3_30B_Wrapper
from app.apis.wis_search.prompt.utils import get_today_str

log_filename = "log/" + "modify_query.log"
logger = get_logger(log_filename, "modify_query")

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('app/apis/wis_search/prompt/modify.j2')
rewrite_prompt_template = env.get_template('app/apis/wis_search/prompt/rewrite.j2')

def parse_rewrites(output_text):
    """解析模型返回的多版本输出"""
    rewrites = []
    pattern = r"查询词\d+:\s*(.*)"

    # 使用 re.finditer() 替代 findall() 更高效（惰性匹配）
    for match in re.finditer(pattern, output_text):
        rewrites.append(match.group(1))  # group(1) 获取第一个捕获组

    return rewrites


def parse_modify(output_text):
    pattern = r'<search>(.*?)</search>'
    rewrites = []

    # 使用 re.finditer() 替代 findall() 更高效（惰性匹配）
    for match in re.finditer(pattern, output_text):
        rewrites.append(match.group(1))  # group(1) 获取第一个捕获组

    return rewrites


async def modified_function(weibo,query, messages_conv, trace_id, llm_trace_info, chat_check_info):

    cur_round = messages_conv.get("cur_round", 1)
    num_history_conv = len(messages_conv.get("history_conv", [])) // 2
    last_content = messages_conv.get("history_conv", [])
    user_content = "\n".join(map(str, last_content))

    user_prompt = prompt_template.render(
        cur_date=get_today_str(),
        cur_round=cur_round,
        num_history_conv=num_history_conv,
        question=query,
        history_conv=user_content, # 最多3条历史信息
        num_versions=3, # 最多输出3个改写的query
    ).strip()
    
    try:
        start = time.time()
        messages = ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", user_prompt]
        self_messages = [
            {"role": "system", "content": datetime.now().strftime('当前时间 %Y-%m-%d.')},
            {"role": "user", "content": user_prompt + "/no_think"}
        ]
        chat_check_info["modify_prompt"] = messages
        pre_log_msg = f"trace_id:{trace_id}\t"
        response = await QWEN3_30B_Wrapper(pid="",pre_log_msg=pre_log_msg).async_call_dialogue(messages)
        # response = await QWEN3_30B_Wrapper(pid="", pre_log_msg=pre_log_msg).async_self_call_dialogue(self_messages)
        ret = response.get("text", query)
        chat_check_info["modify_result"] = ret
        count_tokens(start, response, 'qwen3-30b', llm_trace_info, "query_modify")
        content = ret.split("</think>")[1] if "<think>" in ret else ret
        # modified_queries = parse_rewrites(content.strip())
        weibo['task_output'] = content.strip()
        modified_queries = parse_modify(content.strip())
        logger.info(f"trace_id: {trace_id}, modify prompt: {json.dumps(messages, ensure_ascii=False)}, result: {json.dumps(ret, ensure_ascii=False)}, cost:{time.time() - start}")
        logger.info(f"trace_id: {trace_id}, modify input_info: query: {query}, history: {json.dumps(user_content, ensure_ascii=False)}, modified_queries: {json.dumps(modified_queries, ensure_ascii=False)}")
    except Exception as e:
        modified_queries = []
        logger.error(f"trace_id: {trace_id}, modify input_info: query: {query}, history: {json.dumps(user_content, ensure_ascii=False)}, modified_queries: {json.dumps(modified_queries, ensure_ascii=False)}, error:{traceback.format_exc()}")

    return modified_queries


async def rewrite_function(weibo,query, messages_conv, trace_id, llm_trace_info, chat_check_info):
    cur_round = messages_conv.get("cur_round", 1)
    num_history_conv = len(messages_conv.get("history_conv", [])) // 2
    last_content = messages_conv.get("history_conv", [])
    user_content = "\n".join(map(str, last_content))

    user_prompt = rewrite_prompt_template.render(
        cur_date=get_today_str(),
        cur_round=cur_round,
        num_history_conv=num_history_conv,
        question=query,
        history_conv=user_content,  # 最多3条历史信息
        num_versions=3,  # 最多输出3个改写的query
    ).strip()

    try:
        start = time.time()
        messages = ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", user_prompt + "/no_think"]
        self_messages = [
            {"role": "system", "content": datetime.now().strftime('当前时间 %Y-%m-%d.')},
            {"role": "user", "content": user_prompt + "/no_think"}
        ]
        chat_check_info["rewrite_prompt"] = messages
        pre_log_msg = f"trace_id:{trace_id}\t"
        response = await QWEN3_30B_Wrapper(pid="",pre_log_msg=pre_log_msg).async_call_dialogue(messages)
        # response = await QWEN3_30B_Wrapper(pid="", pre_log_msg=pre_log_msg).async_self_call_dialogue(self_messages)
        ret = response.get("text", query)
        chat_check_info["rewrite_result"] = ret
        count_tokens(start, response, 'qwen3-30b', llm_trace_info, "query_modify")
        content = ret.split("</think>")[1] if "<think>" in ret else ret
        modified_queries = parse_rewrites(content.strip())
        logger.info(
            f"trace_id: {trace_id}, rewrite prompt: {json.dumps(messages, ensure_ascii=False)}, result: {json.dumps(ret, ensure_ascii=False)}, cost:{time.time() - start}")
        logger.info(
            f"trace_id: {trace_id}, rewrite input_info: query: {query}, history: {json.dumps(user_content, ensure_ascii=False)}, modified_queries: {json.dumps(modified_queries, ensure_ascii=False)}")
    except Exception as e:
        modified_queries = []
        logger.error(
            f"trace_id: {trace_id}, rewrite input_info: query: {query}, history: {json.dumps(user_content, ensure_ascii=False)}, modified_queries: {json.dumps(modified_queries, ensure_ascii=False)}, error:{traceback.format_exc()}")

    if not modified_queries:
        modified_queries = [query] + modified_queries
    return modified_queries