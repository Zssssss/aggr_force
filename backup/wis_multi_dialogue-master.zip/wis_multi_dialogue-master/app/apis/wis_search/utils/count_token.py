# -*- coding:utf-8 -*-
import time


def count_tokens(begin, response, model, llm_trace_info, llm_stage="", first_stream=None):
    try:
        if not response or llm_trace_info is None:
            return

        input_token = response.get("prompt_tokens", 0)
        output_token = response.get("completion_tokens", 0)
        json_data = {
            "data_type": "zs_chat_call",
            "llm_stage": llm_stage,
            "prompt_tokens": input_token,
            "completion_tokens": output_token,
            "model_type": model,
            "in_time_ms": begin,
            "end_process": time.time(),
        }
        if first_stream:
            json_data["first_answer"] = first_stream
        llm_trace_info.append(json_data)
    except Exception as e:
        print("count_tokens error")
