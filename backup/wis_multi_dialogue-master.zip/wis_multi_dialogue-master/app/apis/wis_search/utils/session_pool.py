# -*- coding:utf-8 -*-
import asyncio

import aiohttp

from api.config import TASK_CONCURRENCY
from lib.base import Base


class SessionPool(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self._session = None
        self._lock = asyncio.Lock()

    async def start(self):
        async with self._lock:
            if self._session is None or self._session.closed:
                timeout = aiohttp.ClientTimeout(total=5)
                connector = aiohttp.TCPConnector(limit=TASK_CONCURRENCY)
                self._session = aiohttp.ClientSession(timeout=timeout, connector=connector)
        return self._session

    async def close(self):
        async with self._lock:
            if self._session and not self._session.closed:
                await self._session.close()

