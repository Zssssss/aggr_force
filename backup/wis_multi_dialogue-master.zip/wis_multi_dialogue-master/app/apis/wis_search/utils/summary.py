import json
import time

from api.model_api import QWEN3_30B_Wrapper
from app.apis.wis_search.utils.count_token import count_tokens
from lib.safe_logger import get_logger

SUMMARY_THRESHOLD = 150
log_filename = "log/" + "summary.log"
logger = get_logger(log_filename, "summary")

async def get_summary_answer(trace_id: str, query: str, message: str, llm_trace_info: list):
    """压缩回答"""
    system_prompt = "现在你是一个文字概要的助手,帮我概述下下面的信息,请直接给出概要后的信息不要给出其他语句,严格按照要求来。"
    user_prompt = f"请将下面的内容概要成150字以内的summary: \n{message}"
    messages = ["system", system_prompt, "user", user_prompt + "/no_think"]
    pre_log_msg = f"trace_id:{trace_id}\t"

    logger.info(f"{pre_log_msg}, 请求总结模块: {json.dumps(message, ensure_ascii=False)}")
    # 默认是模型回复，如果超过阈值进行总结
    summary_text = message
    if len(message) > SUMMARY_THRESHOLD:
        try:
            start = time.time()
            response = await QWEN3_30B_Wrapper(pid="", pre_log_msg=pre_log_msg).async_call_dialogue(messages)
            summary_text = response.get("text", "")
            count_tokens(start, response, 'qwen3-30b', llm_trace_info, "query_summary")
        except Exception as e:
            logger.debug("Summary error: %s", e)
            return ""
    return summary_text
