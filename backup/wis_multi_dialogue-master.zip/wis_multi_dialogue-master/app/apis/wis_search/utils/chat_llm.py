"""聊天类对话"""
# -*- coding:utf-8 -*-
import json
import time
import traceback
from jinja2 import Environment, FileSystemLoader
from app.apis.wis_search.utils.count_token import count_tokens
from api.model_api import WeiboDeepseekWrapper
from lib.safe_logger import get_logger
from app.apis.wis_search.models import FirstRoundBack
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think
from app.apis.wis_search.post_process.think_process import think_process
from app.apis.wis_search.prompt.utils import get_today_str

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template_user = env.get_template('app/apis/wis_search/prompt/chat_user.j2')
prompt_template_system = env.get_template('app/apis/wis_search/prompt/chat_system.j2')

class ChatLLM:
    def __init__(self, trace_id, model) :
        log_filename = "log/" + self.__class__.__name__.lower() + ".log"
        self.logger = get_logger(log_filename, self.__class__.__name__)
        self.trace_id = trace_id
        self.model = model

    async def run(self, query: str, messages_conv: dict, chat_back: FirstRoundBack, llm_trace_info: list, chat_check_info:dict, is_private_message: bool, basemodel: str):
        """聊天类入口"""
        start = time.time()
        self.logger.info(f"trace_id: {self.trace_id}, chat-llm start, query: {query}, messages_conv: {json.dumps(messages_conv, ensure_ascii=False)}")
        cur_date = get_today_str()
        retrieval_conv_str = "\n".join(map(str, messages_conv.get("retrieval_conv", [])))
        history_conv = messages_conv.get("history_conv", [])
        first_conv = not history_conv
        is_deepthink = self.model == '思考版'
        is_think_model = basemodel in ['实验组1', '实验组2', '实验组3', '实验组4', '实验组5']
        # grice_optim = basemodel in ['实验组1', '实验组2', '实验组3']
        # no_guide_optim = basemodel in ['实验组4', '实验组5', '实验组6']
        prompt_user = prompt_template_user.render(question=query,
                                                  cur_date=cur_date,
                                                  is_dialogue=True,
                                                  first_conv=first_conv,
                                                  retrieval_conv=retrieval_conv_str,
                                                  is_private_message=is_private_message,
                                                  is_deepthink=is_deepthink
                                                  ).strip()
        prompt_system = prompt_template_system.render().strip()
        llm = WeiboDeepseekWrapper("", f"trace_id: {self.trace_id}\t", chat_check_info=chat_check_info)
        try:
            stream_response = await llm.async_stream_call_dialogue(prompt_user, [{"role": "system", "content": prompt_system}] + history_conv)
            chat_check_info["chat_prompt"] = [{"role": "system", "content": prompt_system}] + history_conv + [{"role": "user", "content": prompt_user}]
            result = ""
            think = ""
            content = ""
            response = None
            first_token = None
            ori_content = ""
            # 使用 async for 来迭代异步生成器
            async for response in stream_response:
                # if response is None:  # 处理可能的 None 响应
                #     continue
                result = response.get("text", "")
                ori_content = result
                if not result:  # 如果没有文本内容，跳过
                    continue

                if first_token is None:
                    first_token = time.time()
                think, content = split_think_and_content_with_no_think(result)
                think = think_process(think)
                if not content:
                    # 思考态直接输出
                    yield f"<think>{think}"
                else:
                    yield f"<think>{think}</think>{content}"

            chat_check_info["chat_result"] = ori_content
            count_tokens(start, response, "deepseek_v3.1", llm_trace_info, "first_round", first_token)
            chat_back.think = think
            chat_back.content = content
            yield f"<think>{think}</think>{content}"
            self.logger.info(f"trace_id: {self.trace_id}, query: {query}, chat-llm end, cost: {time.time() - start}")
        except Exception as e:  # 使用更通用的异常类型
            self.logger.error(f"trace_id: {self.trace_id}, query: {query}, chat-llm error: {e}, {traceback.format_exc()}")
