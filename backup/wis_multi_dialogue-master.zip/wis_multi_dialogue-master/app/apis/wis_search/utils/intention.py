"""意图分类"""
import re
import json
import time
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
from api.model_api import QWEN3_30B_Wrapper
from lib.safe_logger import get_logger
from lib.base import Base
from lib.aiomcq import mcq_cli
from app.apis.wis_search.utils.count_token import count_tokens

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('app/apis/wis_search/prompt/intention.j2')


class Intention:

    def __init__(self, trace_id):
        log_filename = "log/" + self.__class__.__name__.lower() + ".log"
        self.logger = get_logger(log_filename, self.__class__.__name__)
        self.trace_id = trace_id

    def get_intention(self, intention):
        """提取意图"""
        intention_pattern = re.compile(r"<label>(.*?)</label>")
        intention_match = intention_pattern.search(intention)
        if intention_match:
            return intention_match.group(1)
        else:
            return "其他"

    async def run(self, question, messages_conv, llm_trace_info, chat_check_info):
        start = time.time()
        self.logger.info(
            f"trace_id: {self.trace_id}, intention start, query: {question}, messages_conv: {json.dumps(messages_conv, ensure_ascii=False)}")
        pre_log_msg = f"trace_id:{self.trace_id}\t"
        llm = QWEN3_30B_Wrapper(pid="", pre_log_msg=pre_log_msg)
        history_conv = messages_conv.get("history_conv", [])
        history_conv = "\n".join(map(str, history_conv))
        prompt = prompt_template.render(question=question, history_conv=history_conv)
        messages = ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt]
        chat_check_info["intention_prompt"] = messages
        query_intention = "其他"
        result = ""
        response = None
        try:
            response = await llm.async_call_dialogue(messages)
            result = response.get("text", "")
            query_intention = self.get_intention(result)
        except Exception as e:
            self.logger.error(f"trace_id: {self.trace_id}, intention error: {e}")
        self.logger.info(
            f"trace_id: {self.trace_id}, intention end, query: {question}, query_intention: {query_intention}, result: {result}, cost: {time.time() - start}")
        chat_check_info["intention_result"] = result
        count_tokens(start, response, 'qwen3-30b', llm_trace_info, "intention")
        return query_intention
        

class MaybeAskIntention(Base):
    persona_queue = mcq_cli(domain="queue.search.weibo.com", port=11233)

    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo

    async def run(self, data):
        await self.persona_queue.set("wis_dialogue_ask_intention", json.dumps(data, ensure_ascii=False))