# -*- coding:utf-8 -*-
import json
import re
import time
from jinja2 import Environment, FileSystemLoader
from api.model_api import QWEN3_30B_Wrapper
from app.apis.wis_search.utils.count_token import count_tokens
from lib.aiomcq import mcq_cli
from lib.base import Base

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template_route = env.get_template('app/apis/wis_search/prompt/route.j2')

def is_url(query: str):
    """
    判断字符串是否是完整的URL
    """
    # 预编译正则表达式（重要！）
    url_patterns = [
        # 标准http/https URL
        re.compile(r'^https?://[^\s/$.?#].[^\s]*$', re.IGNORECASE),
        # 简化版域名检测（避免回溯）
        re.compile(r'^(?:https?://)?(?:[\w-]+\.)+[a-z]{2,}(?:/[^\s]*)?$', re.IGNORECASE),
        # 常见文件路径模式
        re.compile(r'^(?:www\.|ftp\.)[^\s/$.?#].[^\s]*$', re.IGNORECASE),
    ]

    query = query.strip()
    if len(query) < 4:  # 最小"a.b"
        return False

    # 快速排除明显不是URL的情况
    if ' ' in query and not ('://' in query or query.startswith('www.')):
        return False

    # 顺序匹配
    for pattern in url_patterns:
        if pattern.match(query):
            return True

    return False


def extract_urls(text: str):
    """
    从字符串中提取所有URL
    """
    url_pattern = r'(https?://[^\s<>"]+|www\.[^\s<>"]+)(?=[\s<>"]|$)'
    return re.findall(url_pattern, text)


class IntentRecognition(Base):
    intent_queue = mcq_cli(domain="queue.search.weibo.com", port=11233)

    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo
        self.trace_id = weibo.get("trace_id", "")
        self.model = self.weibo.get("model", "")

    async def get_material(self, url):
        try:
            web_content = []
            start = time.time()
            from zsmaterial.retriever import URLContentRetriever
            materials = await URLContentRetriever().query(url)
            self.logger.info(
                f"trace_id: {self.trace_id}, url: {url} material: {json.dumps(materials, ensure_ascii=False)}, cost:{time.time() - start}")

            title = materials.get("title", "")
            content = materials.get("content", "")
            if title or content:
                web_content.append(f"● url：{url}")
            if title:
                web_content.append(f"● 网页标题：{title}")
            if content:
                web_content.append(f"● 网页正文：{content}")

            return "\n".join(web_content)
        except Exception as e:
            self.logger.error(f"trace_id: {self.trace_id} get url content error: {url}")

        return ""



    async def run(self):
        query = self.weibo.get("question", "")
        llm_trace_info = self.weibo.get("llm_trace_info", [])
        chat_check_info = self.weibo.get("chat_check_info", {})
        debug_info = self.weibo.get("debug_info", {})

        debug_info["intent_recognition_start"] = time.time()
        data = self.weibo
        try:
            # url直接求证
            if is_url(query):
                await self.intent_queue.set("wis_dialogue_intent_recognition", json.dumps(data))
                self.logger.info(f"{self.trace_id} enqueue data:{json.dumps(data, ensure_ascii=False)}")
                debug_info["intent_recognition_end"] = time.time()
                return True

            # 有url判断是否求证
            urls = extract_urls(query)
            if len(urls):
                url = urls[0]
                web_content = await self.get_material(url)
                if web_content:
                    share_content = f"现在有网页内容如下：\n{web_content}"
                    prompt = prompt_template_route.render(question=query,
                                                    first_conv=True,
                                                    share_content=share_content
                                                    ).strip()

                    messages = ['user', prompt]
                    start = time.time()
                    response = await QWEN3_30B_Wrapper(pid=self.pid, pre_log_msg=self.pre_log_msg).async_call_dialogue(messages)
                    ret = response.get("text", query)
                    count_tokens(start, response, 'qwen3-30b', llm_trace_info, "intent_recognition")
                    chat_check_info["intent_result"] = ret
                    self.logger.info(
                        f"trace_id: {self.trace_id}, intent prompt: {json.dumps(messages, ensure_ascii=False)}, result: {json.dumps(ret, ensure_ascii=False)}, cost:{time.time() - start}")

                    content = ret.split("</think>")[1] if "<think>" in ret else ret

                    match = re.search(r"<label>(.*?)</label>", content)
                    if match:
                        result = match.group(1)
                        if '求证' in result or '解读' in result:
                            data['question'] = url
                            await self.intent_queue.set("wis_dialogue_intent_recognition", json.dumps(data))
                            self.logger.info(f"{self.trace_id} enqueue data:{json.dumps(data, ensure_ascii=False)}")

                            debug_info["intent_recognition_end"] = time.time()
                            return True

                    history = self.weibo.get("messages", [])
                    history[-1:-1] = [
                        {"role": "user", "content": share_content},
                        {"role": "assistant", "content": "你希望我针对这篇网页做什么？"}
                    ]

        except Exception as e:
            self.logger.error(f"trace_id: {self.trace_id} intent recognition error: {e}")

        debug_info["intent_recognition_end"] = time.time()
        return False