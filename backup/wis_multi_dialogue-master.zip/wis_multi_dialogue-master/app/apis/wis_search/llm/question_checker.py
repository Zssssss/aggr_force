# -*- coding:utf-8 -*-
import time

from app.apis.wis_search.post_process.think_process import merge_think_process
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think, update_status_stage
from app.apis.wis_search.utils.qa_checker import QaChecker
from app.apis.wis_search.prompt.utils import use_context
from lib.base import Base
import traceback

class QuestionChecker(Base):
    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo
        self.trace_id = weibo.get("trace_id", "")
        self.model = self.weibo.get("model", "")

    async def run(self, messages_conv, fr_back, output):
        start_time = time.time()
        query = self.weibo.get("question", "")
        source_type = self.weibo.get("source_type", "")
        llm_trace_info = self.weibo.get("llm_trace_info", [])
        chat_check_info = self.weibo.get("chat_check_info", {})
        debug_info = self.weibo.get("debug_info", {})

        first = True
        cur_txt = ""
        last_txt = ""
        debug_info["question_check_start"] = time.time()
        messages_conv = use_context(source_type, "qa_check", messages_conv)
        try:
            async for text in QaChecker(self.trace_id, self.model).run(query, messages_conv, fr_back, llm_trace_info,
                                                                  chat_check_info):
                if not text:
                    continue
                self.weibo["update_output"]["chat_type"] = 1
                think, content = split_think_and_content_with_no_think(text)
                is_think_end = False
                if content:
                    is_think_end = True
                    # 状态：完成思考
                    update_status_stage(self.weibo, "ANSWERING")
                text = merge_think_process(source_type, self.model, think, is_think_end, True) + content
                cur_txt = text
                if first:
                    # 状态：思考中
                    update_status_stage(self.weibo, "THINKING")
                    end_time = time.time()
                    debug_info["question_check_first_answer"] = time.time()
                    self.logger.info(
                        f"{self.trace_id} 首字符生成所花的时间 " + str(
                            format(end_time - start_time, ".2f")) + " query: " + str(query))
                    first = False
                    last_txt = cur_txt
                    # await streamer.put(cur_txt)
                    await  output.output(ready="no", content=cur_txt, weibo=self.weibo)
                    # yield cur_txt
                if len(cur_txt) - len(last_txt) > 10:
                    last_txt = cur_txt
                    # await streamer.put(cur_txt)
                    await  output.output(ready="no", content=cur_txt, weibo=self.weibo)
                    # yield cur_txt
            if cur_txt:
                await  output.output(ready="no", content=cur_txt, weibo=self.weibo)
                # await streamer.put(cur_txt)
                # yield cur_txt
        except:
            self.logger.error(f"{self.trace_id} Fisrt LLM error: {traceback.format_exc()}")
        debug_info["question_check_end"] = time.time()
        return cur_txt


class SixinQuestionCheckerV2(QuestionChecker):
    def __init__(self, pid, weibo):
        super().__init__(pid, weibo)
        self.model = '思考版'