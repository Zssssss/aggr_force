# -*- coding:utf-8 -*-
import asyncio
import time
from copy import deepcopy
import json
import traceback
import re

from app.apis.wis_search.post_process.think_process import merge_think_process
from lib.base import Base
from app.apis.wis_search.models import ContextModel
from app.apis.wis_search.post_process.multimodal_process import add_media_process, process_wbcustomblock_format, back_wbcustomblock_format
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think, update_status_stage, split_think_and_content, \
    get_paragraph_list_by_h1_or_above
from app.apis.wis_search.utils.call_llm import MultiStreamChat
from app.apis.wis_search.utils.modified_query import modified_function, rewrite_function
from app.apis.wis_search.post_process.post_process_handler import PostProcessor, ReplaceInvalidStrHandler, \
    ReplaceMultimodalHandler, CodeBlockFixHandler, DeleteQuote, CardOutputHandler
from app.apis.wis_search.prompt.utils import use_context
from app.apis.wis_search.utils.intention import Intention
from app.apis.wis_search.post_process.md_special_format_process import process_special_format, back_special_format



class QuestionAnswer(Base):
    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo
        self.trace_id = weibo.get("trace_id", "")
        self.task = None
        self.context = {}
        self.qa_prompt = ""
        self.context_data = ContextModel()
        self.modified_queries = []
        self.pre_think = ""
        self.model = self.weibo.get("model", "")

    async def get_material_task(self, messages_conv):
        """query改写、获取物料、拼接问答prompt"""

        start = time.time()
        query = self.weibo.get("question", "")
        debug_info = self.weibo.get("debug_info", {})
        llm_trace_info = self.weibo.get("llm_trace_info", [])
        chat_check_info = self.weibo.get("chat_check_info", [])
        is_private_message = self.weibo.get("is_private_message", False)
        risk_info = self.weibo.get("risk_info", {})
        source_type = self.weibo.get("source_type", "")
        basemodel = self.weibo.get("basemodel", "")

        debug_info["modify_query_start"] = time.time()
        modified_messages_conv = use_context(source_type, "modified", messages_conv)
        rewrite_messages_conv = use_context(source_type, "rewrite", messages_conv)

        modified_queries, rewrite_queries, _ = await asyncio.gather(
            modified_function(self.weibo,query, modified_messages_conv, self.trace_id, llm_trace_info, chat_check_info),
            rewrite_function(self.weibo,query, rewrite_messages_conv, self.trace_id, llm_trace_info, chat_check_info),
            Intention(self.trace_id).run(query, messages_conv, llm_trace_info, chat_check_info)
        )

        if not modified_queries or len(modified_queries) >= 10:
            modified_queries = rewrite_queries

        debug_info["modify_query_end"] = time.time()
        debug_info["get_qa_prompt_start"] = time.time()
        qa_chat_messages_conv = use_context(source_type, "qa_chat", messages_conv)
        prompt, context_data, material_data = await MultiStreamChat(query, self.trace_id, modified_queries, qa_chat_messages_conv,
                                                     self.model, is_private_message, basemodel, risk_info).get_prompt()
        debug_info["get_qa_prompt_end"] = time.time()
        # 增加俩列，改写词和搜索结果
        self.weibo["modify_query"] = modified_queries
        self.weibo["chat_prompt"] = prompt

        try:
            self.weibo["all_material"] = json.dumps(material_data.model_dump(), ensure_ascii=False)
        except:
            pass
        self.logger.info(
            f"{self.trace_id}, query {query}, get-qa-prompt end, prompt_len: {len(prompt)}, modified_queries: {modified_queries} cost:{time.time() - start}")
        return prompt, context_data, modified_queries

    async def await_material_task(self, fr_back, output):

        # 问答类，需要获取物料，使用 search 工具, 并输出 正在搜索中...，保存当前字符
        query = self.weibo.get("question", "")
        source_type = self.weibo.get("source_type", "")
        debug_info = self.weibo.get("debug_info", [])
        # 状态：检索中
        update_status_stage(self.weibo, "SEARCHING")
        self.weibo["update_output"]["chat_type"] = 1
        modified_queries = fr_back.search_querys
        self.pre_think = merge_think_process(source_type, self.model, fr_back.think, False, True)
        # await streamer.put(pre_think)
        await output.output(ready="no", content=self.pre_think, weibo=self.weibo)
        # yield pre_think
        if self.model == "思考版":
            await self.output_searching_materials(self.pre_think, output)

        debug_info["wait_prompt_start"] = time.time()
        if self.task:
            self.qa_prompt, self.context_data, self.modified_queries = await self.task

        self.weibo["update_output"]['query_field'] = -1 if not len(self.context_data.query_field_list) else \
        self.context_data.query_field_list[0]
        debug_info["wait_prompt_end"] = time.time()
        self.logger.info(
            f"{self.trace_id} wait prompt cost:{debug_info['wait_prompt_end'] - debug_info['wait_prompt_start']}")
        self.update_context(query, self.context_data)
        if 1 in self.context_data.is_complex_query_list:
            self.weibo["is_complex_query"] = 1
        else:
            self.weibo["is_complex_query"] = 0
        self.weibo["update_output"]["link_list"] = self.context.get("link_list", [])
        self.weibo["person_search_info"] = {
            "his_hot_s_list" : json.dumps(self.context.get("his_hot_s_list", []), ensure_ascii=False),
            "da_intention" : self.context.get("da_intention", ""),
            "da_intention_exact_match": self.context.get("da_intention_exact_match", ""),
            "famous_person_intention": self.context.get("famous_person_intention", {})
        }

    async def cancel_material_task(self):

        start = time.time()
        try:
            if self.task:
                self.task.cancel()
                await self.task
        except asyncio.CancelledError as e:
            self.logger.info(
                f"{self.trace_id} cancel_material_task error: {e}")

        self.logger.info(
            f"{self.trace_id} cancel_material_task cost: {time.time() - start}")

    async def output_searching_materials(self, pre_think, output):
        await output.output(ready="no", content=f"{pre_think}{self.get_searching_materials()}", weibo=self.weibo)

    def update_context(self,query,context_data):
        context = context_data.model_dump()
        context["query"] = query
        context["trace_id"] = self.trace_id
        context["weibo_update_dict"] = {}

        # 更新self.context
        self.context = deepcopy(context)

    async def run(self, messages_conv, fr_back, sec_round_back, output):

        query = self.weibo.get("question", "")
        source_type = self.weibo.get("source_type", "")
        debug_info = self.weibo.get("debug_info", {})
        llm_trace_info = self.weibo.get("llm_trace_info", [])
        chat_check_info = self.weibo.get("chat_check_info", {})
        basemodel = self.weibo.get("basemodel", "")

        # chat_check_info["model"] = self.model
        chat_check_info["is_complex_query"] = self.weibo.get("is_complex_query", 0)
        first = True
        cur_txt = ""
        last_txt = ""
        second_start_time = time.time()
        debug_info["question_answer_start"] = time.time()
        pre_think = self.pre_think
        messages_conv = use_context(source_type, "qa_chat", messages_conv)
        if fr_back.is_qa and self.qa_prompt:
            try:
                # 状态：检索完成
                # self.update_status_stage(kwargs, "ANSWERING")
                query_count = len(self.modified_queries)
                link_list = self.context.get("link_list", [])
                blog_count = len(link_list)
                is_private_message = self.weibo.get("is_private_message", False)
                first_content = False
                self.logger.info(
                    f"modified_queries: {self.modified_queries}, link_list_len:{blog_count}, link_list:{json.dumps(link_list, ensure_ascii=False)}")
                if self.model == '思考版':
                    pre_think = self.update_pre_think(pre_think, query_count, blog_count)
                async for text in MultiStreamChat(query, self.trace_id, self.modified_queries, messages_conv, self.model, is_private_message, basemodel).run(
                        sec_round_back, llm_trace_info, chat_check_info, prompt=self.qa_prompt):
                    if not text:
                        continue
                    # 后处理
                    self.weibo["update_output"]["first_chat_tag"] = 0
                    think, content = split_think_and_content_with_no_think(text)
                    if content.strip():
                        update_status_stage(self.weibo, "ANSWERING")
                        text = merge_think_process(source_type, self.model, think, True, False, pre_think=False) + content
                        if not first_content:
                            debug_info["question_answer_first_content"] = time.time()
                            first_content = True
                    else:
                        update_status_stage(self.weibo, "THINKING")
                        text = merge_think_process(source_type, self.model, think, False, False, pre_think=False)
                    cur_txt = text
                    if pre_think:
                        cur_txt = f"{pre_think}\n{text}"
                    if first:
                        self.weibo["update_output"]["first_chat_tag"] = 1
                        end_time = time.time()
                        debug_info["question_answer_first_answer"] = time.time()
                        self.logger.info(
                            f"{self.trace_id} 第二轮生成首字符所花的时间 " + str(
                                format(end_time - second_start_time, ".2f")) + " query: " + str(query))
                        first = False
                        last_txt = cur_txt
                        final_text = self.post_process(cur_txt, self.context)
                        await output.output(ready="no", content=final_text, weibo=self.weibo)
                    if len(cur_txt) - len(last_txt) > 10:
                        last_txt = cur_txt
                        final_text = self.post_process(cur_txt, self.context)
                        await output.output(ready="no", content=final_text, weibo=self.weibo)
                update_status_stage(self.weibo, "FINISHED")
                self.weibo["update_output"].update(self.context["weibo_update_dict"])
                # cur_txt = self.add_media_content(cur_txt,
                #                                  self.context.get("ready_pid_dict", {}).get("all_ready_list", []))
                self.context["output_all_ready"] = True
                final_text = self.post_process(cur_txt, self.context)
                await output.output(ready="yes", content=final_text, weibo=self.weibo)
            except:
                await output.output(ready="error", content="", weibo=self.weibo)
                self.logger.error(f"{self.trace_id} Second LLM error: {traceback.format_exc()}")
                cur_txt= ""

        debug_info["question_answer_end"] = time.time()
        return cur_txt


    def get_searching_materials(self):
        data = {
            "type": "search_res",
            "data": {
                "text": "正在搜索内容"
            }
        }
        r = f'```wbCustomBlock{json.dumps(data, ensure_ascii=False)}```'
        return r


    def update_pre_think(self,pre_think, query_count, blog_count):
        data = {
            "type": "search_res",
            "data": {
                "text": f"检索{query_count}个关键词，找到{blog_count}篇博文"
            }
        }
        r = pre_think + f'```wbCustomBlock{json.dumps(data, ensure_ascii=False)}```'
        return r

    def merge_multi_result(self, result, context):
        """合并多模态"""
        think, content = split_think_and_content(result)
        content = content.strip()
        if not content:
            return result

        ready = context.get("output_all_ready", False)
        ready_pid_dict = context.get("ready_pid_dict", {})
        # 先去除多模态信息和特殊格式的markdown格式
        content, block_dict = process_wbcustomblock_format(content, ready, self.logger)
        multi_data = deepcopy(ready_pid_dict.get("mediablock", []))
        content, spe_md_dict = process_special_format(content)
        # 通过标题分段
        paragraph_list = get_paragraph_list_by_h1_or_above(content)
        re_multi = re.compile(r"\[\^多模态_mediablock_(\d+)\]")
        if ready:
            end_content = ""
        else:
            end_content = "\n" + re_multi.sub("", paragraph_list[-1])
            paragraph_list = paragraph_list[:-1]
        
        for pid, paragraph in enumerate(paragraph_list):
            all_multi = re_multi.findall(paragraph)
            paragraph = re_multi.sub("", paragraph)
            paragraph_list[pid] = paragraph.rstrip("\n -")
            cur_data_list = []
            for multi in all_multi:
                multi = int(multi)
                if multi >= len(multi_data):
                    continue
                current_data = multi_data[multi]["data"].get("data", [])
                cur_data_list.extend(current_data)
            for cur_i, cur_data in enumerate(cur_data_list):
                cur_data["scheme"] += f"&multi_paragraph={pid}&multi_count={cur_i}"
            paragraph_list[pid] = add_media_process(paragraph_list[pid], cur_data_list)
        content = "\n".join(paragraph_list) + end_content
        content = back_special_format(content, spe_md_dict)
        content = back_wbcustomblock_format(content, block_dict)
        return think + "\n" + content


    def post_process(self, result, context) :

        pid = ""
        processor = PostProcessor([
            ReplaceInvalidStrHandler(pid),
            ReplaceMultimodalHandler(pid),
            CodeBlockFixHandler(pid),
            CardOutputHandler(pid),
            DeleteQuote(pid)
        ])
        result = processor.run(result, context)
        result = self.merge_multi_result(result, context)
        return result

    def add_media_content(self, cur_txt, param) :
        cur_txt = add_media_process(cur_txt, self.context.get("ready_pid_dict", {}).get("all_ready_list", []))
        return cur_txt

    async def get_material_task_async(self, messages_conv):
        self.task = asyncio.create_task(self.get_material_task(messages_conv))
        return self.task



class WhiteboardQuestionAnswer(QuestionAnswer):

    async def output_searching_materials(self, pre_think, weibo):
        pass

    def update_pre_think(self, pre_think, query_count, blog_count):
        return pre_think

    def post_process(self, result, context):
        return result

    def add_media_content(self, text, all_ready_list):
        return text



class SixinQuestionAnswerV2(QuestionAnswer):
    def __init__(self, pid, weibo):
        super().__init__(pid, weibo)
        self.model = '思考版'
