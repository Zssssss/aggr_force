# -*- coding:utf-8 -*-
import time

from app.apis.wis_search.post_process.think_process import merge_think_process
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think, update_status_stage
from app.apis.wis_search.utils.chat_llm import ChatLLM
from app.apis.wis_search.prompt.utils import use_context
from lib.base import Base
import traceback

class SimpleDialogue(Base):
    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo
        self.trace_id = weibo.get("trace_id", "")
        self.model = self.weibo.get("model", "")

    async def run(self, messages_conv, sec_round_back, output):
        # 聊天类，不需要物料
        start_time = time.time()
        query = self.weibo.get("question", "")
        source_type = self.weibo.get("source_type", "")
        llm_trace_info = self.weibo.get("llm_trace_info", [])
        chat_check_info = self.weibo.get("chat_check_info", {})
        debug_info = self.weibo.get("debug_info", {})
        is_private_message = self.weibo.get("is_private_message", False)
        basemodel = self.weibo.get("basemodel", "")
        first = True
        cur_txt = ""
        last_txt = ""
        debug_info["simple_dialogue_start"] = time.time()
        messages_conv = use_context(source_type, "simple_chat", messages_conv)
        chat_check_info["source_type"] = source_type
        first_content = False
        try:
            async for text in ChatLLM(self.trace_id, self.model).run(query, messages_conv, sec_round_back, llm_trace_info,
                                                                chat_check_info, is_private_message, basemodel):
                if not text:
                    continue
                self.weibo["update_output"]["first_chat_tag"] = 0
                think, content = split_think_and_content_with_no_think(text)
                is_think_end = False
                if content.strip():
                    is_think_end = True
                    # 状态：完成思考
                    update_status_stage(self.weibo, "ANSWERING")
                    if not first_content:
                        debug_info["simple_dialogue_first_content"] = time.time()
                        first_content = True
                else:
                    # 状态：思考中
                    update_status_stage(self.weibo, "THINKING")

                text = merge_think_process(source_type, self.model, think, is_think_end, True) + content
                model_resp = content
                cur_txt = text
                if first:
                    end_time = time.time()
                    debug_info["simple_dialogue_first_answer"] = time.time()
                    self.logger.info(
                        f"{self.trace_id} 首字符生成所花的时间 " + str(
                            format(end_time - start_time, ".2f")) + " query: " + str(query))
                    first = False
                    last_txt = cur_txt
                    self.weibo["update_output"]["first_chat_tag"] = 1
                    await output.output(ready="no", content=cur_txt, weibo=self.weibo)

                if len(cur_txt) - len(last_txt) > 10:
                    last_txt = cur_txt
                    await output.output(ready="no", content=cur_txt, weibo=self.weibo)
                    # await streamer.put(cur_txt)
                    # yield cur_txt
            update_status_stage(self.weibo, "FINISHED")
            await output.output(ready="yes", content=cur_txt, weibo=self.weibo)
            # await streamer.put(cur_txt)
            # yield cur_txt
        except:
            await output.output(ready="error", content="", weibo=self.weibo)
            self.logger.error(f"{self.trace_id} chat-llm error: {traceback.format_exc()}")
            cur_txt = ""
        debug_info["simple_dialogue_end"] = time.time()
        return cur_txt


class SixinSimpleDialogue(SimpleDialogue):

    def __init__(self, pid, weibo):
        super().__init__(pid, weibo)
        self.model = '非思考版'

