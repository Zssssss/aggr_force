# -*- coding:utf-8 -*-
import time

from app.apis.wis_search.post_process.think_process import merge_think_process
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think
from app.apis.wis_search.utils.call_llm import SiXinToolStreamChat
from lib.base import Base
import traceback

class SixinTool(Base):
    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo
        self.trace_id = weibo.get("trace_id", "")
        # 一期强制非思考
        # self.model = self.weibo.get("model", "")
        self.model = "非思考版"

    async def run(self, output):
        first = True
        last_txt = ""
        cur_txt = ""
        query = self.weibo.get("question", "")
        source_type = self.weibo.get("source_type", "")
        debug_info = self.weibo.get("debug_info", {})
        debug_info["sinxin_tool_start"] = time.time()
        try:
            chatter = SiXinToolStreamChat(query, self.trace_id, self.model)
            prompt = chatter.get_prompt()
            async for text in chatter.run(prompt=prompt):
                if not text:
                    continue
                # 后处理
                # text = self.post_process(text, self.context)
                think, content = split_think_and_content_with_no_think(text)
                is_think_end = False
                if content.strip():
                    is_think_end = True
                    text = merge_think_process(source_type, self.model, think, is_think_end, False, pre_think=True) + content
                else:
                    text = merge_think_process(source_type, self.model, think, is_think_end, False, pre_think=True)
                cur_txt = text
                if first:
                    first = False
                    last_txt = cur_txt
                    await output.output(ready="no", content=cur_txt, weibo=self.weibo)
                if len(cur_txt) - len(last_txt) > 10:
                    last_txt = cur_txt
                    await output.output(ready="no", content=cur_txt, weibo=self.weibo)
            await output.output(ready="yes", content=cur_txt, weibo=self.weibo)
            self.logger.info(f"{self.trace_id} sixin tool: query: {query} chat_stream: {cur_txt}")
        except:
            await output.output(ready="error", content="", weibo=self.weibo)
            self.logger.error(f"{self.trace_id} sixin tool LLM error: {traceback.format_exc()}")
            cur_txt= ""

        debug_info["sinxin_tool_end"] = time.time()
        return cur_txt


class SixinToolV2(SixinTool):
    def __init__(self, pid, weibo):
        super().__init__(pid, weibo)
        self.model = self.weibo.get("model", "")