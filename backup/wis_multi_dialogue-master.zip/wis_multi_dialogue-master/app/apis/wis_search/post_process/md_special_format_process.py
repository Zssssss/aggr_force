"""markdown特殊格式后处理"""
# -*- coding:utf-8 -*-

import re
from typing import List
from collections import defaultdict

# ============= 整体入口，回写特殊格式 =============
def back_special_format(text: str, result) -> str:
    """回写特殊格式"""
    for lang, blocks in result.items():
        for index, block in enumerate(blocks):
            text = text.replace(format_spe(lang, index), block["new_text"])
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text


# ============= 整体入口，解析特殊格式 =============
def process_special_format(text: str) -> (str, dict):
    """处理特殊格式"""
    result = parse_markdown_code_blocks(text)
    for lang, blocks in result.items():
        for index, block in enumerate(blocks):
            ori_text = block['ori_text']
            new_text, quote_list = remove_and_extract_refs(ori_text)
            if lang == "mermaid":
                new_text = convert_chinese_punctuation_to_english(new_text)
            if lang == "md_table":
                new_text = re.sub("<br>", " " * 4, new_text)
                new_text += "\n\n"
            block['new_text'] = new_text
            text = text.replace(block['ori_text'], format_spe(lang, index) + ''.join(quote_list))


    return text, result

def format_spe(lang: str, index: int):
    """构造特殊格式"""
    return f'[^特殊_{lang}_{index}]'

def extract_md_tables(text: str) -> List[str]:
    """
    提取 Markdown 表格：
    - 每行都必须含有 '|' 才算表格行
    - 中间不能有空行（空行立即中断表格）
    - 非表格行、空行之后，表格重新开始
    """
    lines = text.strip().splitlines()
    tables = []
    current_table = []

    for line in lines:
        stripped = line.strip()

        if stripped and '|' in stripped:
            current_table.append(line)
        else:
            if current_table:
                tables.append('\n'.join(current_table).strip())
                current_table = []

    # 补上最后一个未收尾的表格
    if current_table:
        tables.append('\n'.join(current_table).strip())

    return tables

def parse_markdown_code_blocks(md: str):
    """
    解析 Markdown 中用 ``` 包裹的代码块，支持未闭合代码块提取。
    输出为按语言分类的 dict。
    """
    result = defaultdict(list)
    code_block_pattern = re.compile(r'```([a-zA-Z0-9]*)\n([\s\S]*?)(```|$)', re.DOTALL)

    for match in code_block_pattern.finditer(md):
        lang = match.group(1)
        content = match.group(2).rstrip()
        end_marker = match.group(3)

        ori_text = f"```{lang}\n{content}"
        lang = lang or "other"
        if end_marker == '```':
            ori_text += "\n```"

        # 特殊处理 mermaid 的 type 提取
        if lang == "mermaid":
            first_line = content.strip().splitlines()[0] if content.strip() else "mermaid"
            type_val = first_line
        else:
            type_val = lang

        result[lang].append({
            "ori_text": ori_text.strip(),
            "type": type_val
        })

    for table in extract_md_tables(md):
        result["md_table"].append({
            "ori_text": table,
            "type": "md_table"
        })

    return dict(result)

def remove_and_extract_refs(text):
    # 匹配形如 [^1]、[^23] 的格式
    pattern = re.compile(r"\[\^\d+\]")
    
    # 找到所有匹配项并去重
    matches = pattern.findall(text)
    unique_matches = list(set(matches))
    
    # 去除原文本中的所有匹配项
    cleaned_text = pattern.sub('', text)
    
    return cleaned_text, unique_matches

def convert_chinese_punctuation_to_english(text):
    cn_punc = '，。！？【】（）％＃＠＆１２３４５６７８９０：“”‘’《》、；'
    en_punc = ',.!?[]()%#@&1234567890:""\'\'<>/;'
    
    translation_table = str.maketrans(cn_punc, en_punc)
    return text.translate(translation_table)

def remove_markdown_links(md_text: str) -> str:
    """
    将形如 [显示文字](链接地址) 的 Markdown 链接替换为仅显示文字。
    """
    pattern = re.compile(r'\[([^\]\n]+)\]\([^\)\n]+\)')
    return pattern.sub(r'`\1`', md_text)
