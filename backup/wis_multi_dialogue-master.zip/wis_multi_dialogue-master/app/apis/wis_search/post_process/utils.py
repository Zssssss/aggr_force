"""后处理公共方法"""
# -*- coding:utf-8 -*-
import re
from collections import defaultdict
import emoji

# ============= 基础的正则表达式 =============
# 匹配中文字符
ZH_PATTERN = r'[\u4e00-\u9fa5]'
# 匹配数字
NUM_PATTERN = r'\d'
# 匹配英文字符
EN_PATTERN = r'[A-Za-z]'
# 匹配特殊字符
SPECIAL_CHAR_PATTERN = r'[^\w\s]'
# 匹配链接
LINK_PATTERN = r'https?://\S+'

# ============= 分割段落（通过markdown #开头的标题分割） =============
def split_paragraphs_with_markdown_title(text: str):
    """按段落拆分文本，段落以markdown #开头的标题分割"""
    split_result = re.split(r"\n#+", text)
    return split_result

# ============= 分割思考态和正文 =============
def split_think_and_content_with_no_think(result):
    """分割思考态和正文"""
    if "<think>" in result and "</think>" in result:
        think = result.split("</think>")[0].split("<think>")[1]
        content = result.split("</think>")[1]
    elif "<think>" in result:
        think = result.split("<think>")[1]
        content = ""
    else:
        think = ""
        content = result
    return think, content

# ============= 获取微博链接索引列表 =============
def get_weibo_link_index_list(link_list: list):
    """获取微博链接索引列表"""
    index_list = []
    for index, link_item in enumerate(link_list):
        if link_item.startswith("sinaweibo:"):
            index_list.append(index + 1)
    return index_list

# ============= 分割思考态和正文 =============
def split_think_and_content(result):
    """分割思考态和正文"""
    if "</think>" in result:
        think = result.split("</think>")[0] + "</think>"
        content = result.split("</think>")[1]
    elif "<think>" in result:
        think = result
        content = ""
    else:
        think = ""
        content = result
    return think, content

# ============= 分割正文段落（细致分割） =============
# ============= 入口函数 split_markdown_paragraphs =============
def check_is_next_paragraph(text: str):
    """判断是否是下一个段落"""
    is_header = re.match(r'^#{1,6}\s', text)   # 标题
    is_list = re.match(r'^ *[-*+] |^ *\d+\. ', text)  # 列表项
    is_blockquote = re.match(r'^ *> ', text)  # 引用

    if is_header or is_list or is_blockquote:
        return True
    return False

def single_split_markdown_paragraphs(text: str):
    """单\n区分"""
    split_list = []
    line_list = text.split("\n")
    cur_text = ""
    for i in range(len(line_list) - 1):
        cur_text += line_list[i] + "\n"
        if check_is_next_paragraph(line_list[i + 1]):
            split_list.append(cur_text)
            cur_text = ""
    cur_text += line_list[-1]
    split_list.append(cur_text)
    return split_list

def split_markdown_paragraphs(text: str):
    """按段落拆分markdown格式文本"""
    split_list = []
    line_list = text.split("\n\n")
    for single_text in line_list[:-1]:
        single_text += "\n\n"
        split_list.extend(single_split_markdown_paragraphs(single_text))
    split_list.extend(single_split_markdown_paragraphs(line_list[-1]))
    return split_list

# ============= 分割段落（粗略分割, 多个换行符） =============
def split_paragraphs_with_multiple_linefeed(text: str):
    """按段落拆分文本，段落以两个或多个换行符分割"""
    split_result = re.split(r"\n{2,}", text)
    return split_result

# ============= 删除空括号 =============
def delete_empty_brackets(text: str):
    """删除空括号"""
    return re.sub(r"[\(（\[【][\)）\]】]", "", text)

# ============ 找到markdown标题 =============
def find_markdown_title(result) -> list[str]:
    # 去除特殊字符块
    result = re.sub(r'```.*?```', "", result, flags=re.DOTALL)
    result = re.sub(r'<media-block>.*?</media-block>', "", result, flags=re.DOTALL)
    lines = result.split('\n')
    categorized = defaultdict(list)

    for line in lines:

        if not line.startswith('#'):
            continue

        level = len(line) - len(line.lstrip('#'))

        # 清除 <a>...</a> 标签并去除尾部空白
        clean_line = re.sub(r"<a>.*?</a>", "", line).strip()

        categorized[level].append(clean_line)

    # 返回按标题等级升序排序的列表
    return [categorized[level] for level in sorted(categorized)]

# ============ 清洗markdown标题 =============
def clean_markdown_title(title: str) -> str:
    # 1. 去除井号（如 # 标记）
    text = title.replace("#", "")
    # 2. 去除编号前缀：如 1.、一、等
    text = re.sub(r"^[\s\W]*(\d+\.\s*|[一二三四五六七八九]、)", "", text)
    # 3. 去除 emoji
    text = emoji.replace_emoji(text, replace="")
    # 4. 去除星号
    text = text.replace("*", "")
    # 5. 去除副标题（以中英文冒号分隔）
    for sep in ("：", ":"):
        if sep in text:
            text = text.split(sep, 1)[0]
            break
    # 6. 去除全角括号及其中内容（如：标题（推荐） → 标题）
    text = re.sub(r"（.*?）", "", text)
    # 7. 去除首尾空格
    return text.strip()

# ============= 去除并保存段落末尾的空格和换行符 =============
def remove_and_save_trailing(s):
    """去除并保存段落末尾的空格和换行符"""
    # 移除末尾所有空格和换行符
    stripped_str = s.rstrip()
    # 计算被移除的长度
    removed_length = len(s) - len(stripped_str)
    removed_part = s[-removed_length:] if removed_length > 0 else ""
    return stripped_str, removed_part

# ============= 去除多模态内容 =============
def delete_wbcustomblock(result: str):
    """```wbCustomBlock``` 为自定义的块"""
    re_quote = re.compile(r"<a>\[\d+\]</a>")
    result = re_quote.sub("", result)
    result = re.sub(r"```wbCustomBlock(.*?)```", "", result, flags=re.DOTALL)
    result = re.sub(r"<media-block>(.*?)</media-block>", "", result, flags=re.DOTALL)
    result = re.sub(r"<br>", "\n", result)
    return result

# ============= 解析query和历史对话 =============
re_think = re.compile(r"<span style=\"font-size:\d+px; color:grey;\">.*?</span>", re.DOTALL)
re_think_end = re.compile(r"\n{2,}")
re_think_new = re.compile(r"<think>.*?</think>", re.DOTALL)

def delete_think(text):
    """删除think"""
    if "<think>" not in text:
        return text
    if "</think>" not in text:
        return ""
    text = re_think_new.sub("", text)
    return text

def get_query_and_history(messages: list):
    """获取当前对话的query和历史数据"""
    # 获取query并截取历史对话
    query = ""
    history = []
    index = len(messages)
    for message in messages[: :-1]:
        index -= 1
        if message.get("role", "") == "user":
            query = message.get("content", "")
            query = query.strip()
            query = query.strip("/")
            break
    messages = messages[:index]
    # 不限制条数
    for message in messages:
        role = message.get("role", "")
        if role == "user" :
            history.append({'role' : role, 'content' : message.get("content", "")})
        if role == "assistant" :
            content = message.get("content", "")
            content_arr = content.split("[//]: <>")
            cur_content = content
            if len(content_arr) > 1 :
                cur_content = re_think.sub("", content_arr[1].replace("({\"role\": \"assistant\"})\n", ""))
            cur_content = delete_think(cur_content)
            cur_content = re_think_end.sub("\n\n", cur_content)
            cur_content = delete_wbcustomblock(cur_content)
            history.append({'role' : role, 'content' : cur_content})
    return query, history



def update_status_stage(weibo, status):
    dic = {
        "BEGIN": 0,
        "THINKING": 1,
        "SEARCHING": 2,
        "ANSWERING": 3,
        "FINISHED": 4
    }
    weibo["update_output"]["status_stage"] = dic[status]


# ============= 通过>= 首次标题级别 的标题获取段落列表 =============
def get_paragraph_list_by_h1_or_above(content: str):
    """按所有 >= 首次标题级别 的标题分段，常用于 Markdown 文本处理"""
    lines = content.split("\n")
    paragraph_list = []
    cur_paragraph = []
    cur_level = -1
    title_re = re.compile(r"^(#{1,6})\s")  # 捕获标题等级

    for line in lines:
        match = title_re.match(line)
        if match:
            level = len(match.group(1))
            # 记录首次标题级别
            if cur_level == -1:
                cur_level = level
            # 如果标题级别 >= 首次标题级别，就分段
            if level >= cur_level:
                if cur_paragraph:
                    paragraph_list.append("\n".join(cur_paragraph))
                    cur_paragraph = []
        cur_paragraph.append(line)

    if cur_paragraph:
        paragraph_list.append("\n".join(cur_paragraph))
    return paragraph_list
