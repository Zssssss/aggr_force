"""后处理think过程"""
# -*- coding:utf-8 -*-
import json
import re

# ============= think引文过滤 =============
re_quote = re.compile(r"\[\^\d+\]")
re_in_quote = re.compile(r"\[(\^\d*)?$")

def think_quote_process(text: str):
    """引文处理，[^1]删掉"""
    # 先替换已经生成好的引文
    text = re_quote.sub("", text)
    # 再处理生成中的引文
    text = re_in_quote.sub(r"", text)
    return text

# ============= 思考态处理 =============
re_think_br = re.compile(r"\n+")
def think_process(think: str):
    """思考过程后处理"""
    think = think_quote_process(think)
    think = re_think_br.sub("\n", think)
    return think

# ============= 思考态临时处理，传给前端的数据 =============
def merge_think_whiteboard(think: str, is_think_end: bool, is_frist_round: bool, font_size: int):
    """思考过程临时处理，传给前端的数据"""
    if is_frist_round:
        meta = {'role': "assistant"}
        resp = f'\n\n[//]: <> ({json.dumps(meta, ensure_ascii=False)})\n'
    else:
        resp = ""
    if not think:
        return resp
    think = think.replace("<think>", "").replace("</think>", "").strip()
    think_list = think.split("\n")
    pre_line = f'<span style="font-size:{font_size}px; color:grey;">'
    end_line = '</span>'
    end_think = ""
    if not is_think_end:
        end_think = pre_line + think_list[-1]
        think_list = think_list[:-1]
    think_list = [pre_line + item + end_line for item in think_list]
    think = "\n".join(think_list)
    if think and end_think:
        think += "\n" + end_think
    elif end_think:
        think = end_think
    return resp + think


def merge_think_client(model: str, think: str, is_think_end: bool, is_frist_round: bool, font_size=12, pre_think=True):
    if model == '非思考版':
        return ""

    if pre_think:
        think = "<think>" + think
    if is_think_end:
        think = think + "</think>"
    return think

def merge_think_process(source_type: str, model: str, think: str, is_think_end: bool, is_frist_round: bool, font_size=12, pre_think=True):
    if source_type == 'white_board':
        return merge_think_whiteboard(think, is_think_end, is_frist_round, font_size)
    return merge_think_client(model, think, is_think_end, is_frist_round, font_size, pre_think)