"""图片后处理"""
# -*- coding:utf-8 -*-
import json
import re
import binascii


# ============= 图片处理基础函数,由普搜提供 =============
def get_size_from_pid(pid):
    """通过pid获取图片的长宽"""
    try:
        if len(pid) < 32 or pid[22] < "1":
            return 1, 1
        width = int(pid[23:26], 36)
        height = int(pid[26:29], 36)
    except:
        return 1, 1
    return height, width

letter32dict={"0":0,"1":1,"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"a":10,"b":11,"c":12,"d":13,"e":14,"f":15,"g":16,"h":17,"i":18,"j":19,"k":20,"l":21,"m":22,"n":23,"o":24,"p":25,"q":26,"r":27,"s":28,"t":29,"u":30,"v":31}
def finger2bit_raw(finger, type_num):
    """指纹处理"""
    finger_bits = ""
    prefix = finger[0:type_num]
    finger_bits += prefix
    for i in range(type_num, len(finger)):
        b = '{0:05b}'.format(letter32dict[finger[i]])
        finger_bits += b
    return finger_bits

def pic_hamming_distance(fingerpress1, fingerpress2):
    """
    计算两个指纹的汉明距离
    """
    fg1Len = len(fingerpress1)
    fg2Len = len(fingerpress2)
    if fg1Len < 5 or fg2Len < 5 or fg1Len != fg2Len:
        return 80

    # 如果指纹的前3位，即类别不致，则认为图片不同，反回距离最大值。
    if fingerpress1[:2] != fingerpress2[:2]:
        return 80
    # 下面为正常指纹第6位以后距离计算
    fp1 = finger2bit_raw(fingerpress1, 2)
    fp2 = finger2bit_raw(fingerpress2, 2)
    # print(fp1,fp2)
    # 转为二进制后，指纹更不准，故用原来的情况
    dist = max(len(fp1), len(fp2))
    if "null" not in fp1 and "null" not in fp2:
        dist = sum(el1 != el2 for el1, el2 in zip(fp1, fp2))
    return dist

def get_pic_url(pid, typ='middle', https=False):
    """ 获取图片 URL
    Args:
      pid: A picture id provided by Imgbed.
      typ: picture typ.
      https: A Boolean flag, return https url or http url.
    Returns:
      A string of picture URL.
    """
    if pid[9] == 'y' and len(pid) >= 32:
        zone = (binascii.crc32(pid.encode('utf8')) & 0xffffffff & 0x03) + 1
        ext = 'jpg' if pid[21] == 'j' else 'gif'
        fmt = "https://wx{}.sinaimg.cn/{}/{}.{}" if https else \
            "http://wx{}.sinaimg.cn/{}/{}.{}"
        return fmt.format(zone, typ, pid, ext)

    elif pid[9] == 'w':
        zone = (binascii.crc32(pid.encode('utf8')) & 0xffffffff & 0x03) + 1
        ext = 'jpg' if pid[21] == 'j' else 'gif'
        fmt = "https://ww{}.sinaimg.cn/{}/{}.{}" if https else \
            "http://ww{}.sinaimg.cn/{}/{}.{}"
        return fmt.format(zone, typ, pid, ext)

# ============= 图片后处理 =============
def get_all_img_data_from_quote(quote_id: int, quote_dict: dict, is_credible: bool, is_hot_query, mid_feature_dict, log_func=None):
    """从引文中提取所有图片url"""
    img_list = []
    count = 1
    item = quote_dict.get(quote_id, {})
    new_k = ""
    use_image = False
    mix_media_ids = mid_feature_dict.get("mix_media_ids", [])
    pic_ids = mid_feature_dict.get("pic_ids", [])
    pic_ids = pic_ids if pic_ids else []  # 防止接口传其他的空值，导致循环出错
    final_media_ids = mix_media_ids if mix_media_ids else pic_ids   # 博文里面视频图片混合顺序为mix_media_ids，图片单独为pic_ids
    for media_id in final_media_ids:
        if media_id.startswith("http:"):
            break
        use_image = True
        if media_id not in item:
            break
        k = media_id
        v = item.get(k, {})
        h = v.get('h', 0)
        w = v.get('w', 0)
        ocr_len = v.get('ocr_len', -2)
        ocr = v.get('ocr', "") if v.get('ocr', "") else ""
        type_p = v.get('type', '').upper() 
        pic_tags = v.get('pic_tags', "0")
        dup_group = v.get('dup_group', -1)
        pic_finger = v.get('pic_finger', "")
        photo_sub_type = v.get('photo_sub_type', '')
        fea_1174 = v.get('fea_1174',-1)
        doc_valid_num = int(v.get('doc_valid_num', 0))
        pic_index = v.get('mix_media_id', 0)
        is_media = v.get('is_media_user', False)
        h_limit = 1000 if ocr_len == 0 else 400
        ratio_credit = 0.5 < h / w <= 2
        # ratio_not_credit = (0.5 < h / w <= 2) if ocr_len == 0 else (0.5 < h / w < 0.9 or 1.1 < h / w < 2)
        # valid_type = (photo_sub_type not in {'1', '3', '4', '5', '6'}) and (type != "GIF")
        is_jpg = k[21] == 'j' if len(k) > 21 else True
        verify_type = int(v.get('verified_type', -1))
        is_top = v.get('is_top_up', False)
        if is_hot_query:
            special_check = (int(doc_valid_num) > 20 or is_top) and is_jpg
        else:
            special_check = True
        ocr_ratio = (ocr_len * 400)/(h * w)
        ocr_limit = 100 if is_hot_query else 30
        size_ratio = (ocr_len * 400)/(h * w) 
        dazibao_keyword = ['最新消息', '最新,消息', '今日焦点', '今日关注', '今日辟谣', '权威发布', '最新资讯', '权威,发布', '军报快讯', '最新,俏息', '关注', '快讯', '快评', '社评', '消息', '声音', '聚焦', '最新', '重磅', '两会', '情况通报']
        def is_valid_string(input_str: str) -> bool:
            return any(keyword in input_str for keyword in dazibao_keyword)
        has_keyword=is_valid_string(ocr)
        # if MULTIMODAL_DEBUG:
        #     if ocr_len == -2 or ocr_len == -1 or dup_group == -1 or doc_valid_num == 0 or not pic_finger:
        #         if log_func:
        #             log_func(f"<物料信息不全>图片{k}，宽高:{w}x{h}，ocr_len:{ocr_len}，标签:{pic_tags}，dup_group:{dup_group}，指纹:{pic_finger}，doc_valid_num:{doc_valid_num}，不符合要求")
        def is_valid_pic(h, w, pic_tags, fea_1174, doc_valid_num, ocr_len, is_hot_query, special_check, has_keyword, verify_type):
            if h == 0 or w == 0:
                return False
            if pic_tags != "0":
                return False
            if ocr_len<=25 and has_keyword:
                return False
            if not special_check and is_hot_query:
                return False
            ocr_limit = 100 if is_hot_query else 30
            size_limit = 400 if ocr_len >=0 else 1000
            ocr_ratio = True if (ocr_len * 400)/(h * w) <= 0.03 else False
            ratio_limit = 0.5 < h / w < 0.9 or 1.1 < h / w < 2
            bad_pic = (fea_1174 ==2 and (ocr_len>=15 or 0.9 < h/w < 1)) or fea_1174==3
            if not is_hot_query and verify_type==-1 and doc_valid_num <10:
                return False
            if ocr_len > ocr_limit:
                return False
            if h <=size_limit or w <= size_limit:
                return False
            if bad_pic:
                return False
            if not ocr_ratio:
                return False
            if not ratio_limit:
                return False
            return True       
        ocr_content=ocr.replace(",", "")
        # 添加其他信息
        new_k = f"<首图特征：img_url: http://bj.service.t.sinaimg.cn/middle/{k} ocr_len:{ocr_len}, ocr:{ocr_content}, has_keyword:{has_keyword}, verify_type:{verify_type}, is_media:{is_media}, photo_sub_type:{photo_sub_type}, type:{type_p}, fea_1174:{fea_1174}, size_ratio:{size_ratio}, h:{h}, w:{w}, h/w:{h / w}, dup_group:{dup_group}, pic_tags:{pic_tags}, 是否可信:{is_credible}, is_hot_query:{is_hot_query}, doc_valid_num:{doc_valid_num}, is_jpg:{is_jpg}, pic_index:{pic_index}, is_hot_query:{is_hot_query}, pic_finger:{pic_finger}>"
        if pic_index != 0:
            if log_func:
                log_func(f"图片{k}非首图，{new_k}，不符合要求")
            continue
        # if (fea_1174 ==2 and (ocr_len>=15 or 0.9 < h/w < 1)) or fea_1174==3:
        #     if log_func:
        #         log_func(f"fea_1174={fea_1174}")
        #     continue
        if is_valid_pic(h, w, pic_tags, fea_1174, doc_valid_num, ocr_len, is_hot_query, special_check, has_keyword, verify_type):
            img_list.append({'img_pid': k, "pic_finger": pic_finger, "h": h, "w": w,
                                'img_idx': f"img_{quote_id}_{count}",
                                'dup_group': dup_group})
        else:
            if log_func:
                log_func(f"可信账号的图片{k}，{new_k}，不符合要求")
        count += 1
        break
    return img_list, new_k, use_image

def check_img_is_similar(img_item: dict, vector_dict, ready_pid_dict, log_func=None) -> bool:
    """检查图片是否重复"""
    img_pid = img_item["img_pid"]
    img_idx = img_item["img_idx"]  ## img_4_2
    dup_group = img_item["dup_group"]
    pic_finger = img_item["pic_finger"]
    # 通过dup_group判断是否重复
    for cur_idx, cur_pid_dict in ready_pid_dict.items():
        cur_pid = cur_pid_dict["pid"]
        if cur_pid == img_pid:
            if log_func:
                log_func(f"图片索引{img_idx}的图片id:{img_pid},与索引{cur_idx}的图片id:{cur_pid},重复")
            return True
        if not cur_pid_dict["flag"]:
            continue
        cur_dup_group = cur_pid_dict["dup_group"]
        if dup_group != -1 and cur_dup_group != -1 and cur_dup_group == dup_group:
            if log_func:
                log_func(f"图片索引{img_idx}的图片id:{img_pid},图片dup_group:{dup_group},与索引{cur_idx}的图片id:{cur_pid},图片dup_group:{cur_dup_group},重复")
            return True
    # 通过指纹判断是否重复
    for cur_idx, cur_pid_dict in ready_pid_dict.items():
        cur_pid = cur_pid_dict["pid"]
        cur_pic_finger = cur_pid_dict["pic_finger"]
        hamming_distance = pic_hamming_distance(pic_finger, cur_pic_finger)
        if hamming_distance < 10:
            if log_func:
                log_func(f"图片索引{img_idx}的图片id:{img_pid},图片指纹:{pic_finger},与索引{cur_idx}的图片id:{cur_pid},图片指纹:{cur_pic_finger},汉明距离:{hamming_distance},指纹相似度过高,重复")
            return True
    # # 通过相似度判断是否重复
    # img_vec = vector_dict.get(img_pid, None)
    # if not img_vec:
    #     return False
    # for cur_idx, cur_pid_dict in ready_pid_dict.items():
    #     cur_pid = cur_pid_dict["pid"]
    #     cur_vec = vector_dict.get(cur_pid, None)
    #     if not cur_vec:
    #         continue
    #     is_similar, similarity = check_img_similarity(img_vec, cur_vec)
    #     if is_similar:
    #         if log_func:
    #             log_func(f"图片索引{img_idx}的图片id:{img_pid},与索引{cur_idx}的图片id:{cur_pid},相似度{similarity},重复")
    #         return True
    return False