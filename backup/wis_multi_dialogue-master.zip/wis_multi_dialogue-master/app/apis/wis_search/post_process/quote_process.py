"""对于流式增量输出的文本进行后处理"""
# -*- coding:utf-8 -*-
import re
import json
from app.apis.wis_search.post_process.filter_process import filter_jieguo_str
from app.apis.wis_search.post_process.utils import split_think_and_content_with_no_think, delete_empty_brackets
from app.apis.wis_search.post_process.think_process import think_process

# ============= 基础正则 =============
re_quote = re.compile(r"\[\^\d+\]")
re_num = re.compile(r"\d+")
re_in_quote = re.compile(r"\[(\^\d*)?$")
re_quote_num = re.compile(r'<a>\[(\d+)\]</a>')

# ============= 过滤入口 =============
def process_text(text: str):
    """整体入口"""
    think, content = split_think_and_content_with_no_think(text)
    think = think_process(think)
    think = remove_first_sentence(think)
    content = quote_process(content)
    text = f"<think>{think}</think>{content}"
    return text

# ============= 引文过滤 =============
def quote_process(text: str):
    """引文处理，[^1]处理成为<a>[1]</a>"""
    # 先替换已经生成好的引文
    quote_list = re_quote.findall(text)
    quote_list = list(set(quote_list))
    for quote in quote_list:
        match = re_num.search(quote)
        if match:
            text = text.replace(quote, f"<a>[{match.group()}]</a>")
    # 再处理生成中的引文
    text = re_in_quote.sub(r"", text)
    return text

# ============= 第二轮删除思考态第一句话 =============
def remove_first_sentence(text: str):
    """删除思考态第一句话"""
    first_sentence_end = text.find('。')
    if first_sentence_end != -1:
        text = text[first_sentence_end + 1:]
    else:
        text = ""
    if not text.startswith("\n"):
        text = "\n" + text
    return text


# ============= 引文标准化 =============
def standardize_quote(content: str, weibo_link_index_list: list):
    """标准化引文, 格式替换[^6]\[【6】]替换成<a>[6]</a>,,并删除非微博索引"""

    # 删除 类似[^1]\[【1】]: YN_菲菲菲的微博提到了“刘宇宁10部作品入围微博视界大会”以及“6个赛道，33项入围”的行
    extra_pattern = r"^[-*+ ]*((\[(?:\^|【)\d+(?:\]|】\]))+|\**引用说明\**)[:：].*$"
    content = re.sub(extra_pattern, "", content, flags=re.MULTILINE)

    pattern = r"\[(?:\^|【)\d+(?:\]|】\])"
    all_replaced_matches = []
    replace_matches = re.findall(pattern, content)
    replace_matches = list(set(replace_matches))
    re_num = re.compile(r"\d+")
    for ori_str in replace_matches:
        search = re_num.search(ori_str)
        if search:
            num_str = search.group()
            if int(num_str) in weibo_link_index_list:
                replace_str = f"<a>[{num_str}]</a>"
            else:
                replace_str = ""
            content = content.replace(ori_str, replace_str)
            all_replaced_matches.append(ori_str)
    # 转义特殊字符
    pattern = r"\d+~\d+"
    replace_matches = re.findall(pattern, content)
    replace_matches = list(set(replace_matches))
    for ori_str in replace_matches:
        num_str = ori_str.replace("~", "-")
        content = content.replace(ori_str, num_str)
    return content, all_replaced_matches

# ============= 最后删除之前标准化的引文 =============
def code_block_process(text: str):
    """代码块处理,避免多模态内容与代码块同行导致的显示问题"""
    pattern = r"([^\}])```[ ]*```"
    text = re.sub(pattern, r'\1```\n```', text)
    return text

def table_end(text: str):
    """表格结尾"""
    text_list = text.split("\n")
    re_table = re.compile(r"\|.*\|")
    for i in range(len(text_list) - 1):
        if re_table.search(text_list[i]) and text_list[i + 1].strip() and not re_table.search(text_list[i + 1]):
            text_list[i] = text_list[i] + "\n"
    return "\n".join(text_list)

def delete_quote(text: str):
    """删除之前的引文"""
    # 引用放最后，故这里去掉之前的<a>[1]</a>引用
    num = 0
    pattern = r"((?:<a>\[\d+\]</a>){" + str(num) + r"})(?:<a>\[\d+\]</a>)+"
    search = re.search(pattern, text)
    while search:
        text = text.replace(search.group(), search.group(1))
        search = re.search(pattern, text)
    text = filter_jieguo_str(text)
    text = delete_empty_brackets(text)
    text = code_block_process(text)
    text = table_end(text)
    return text

# ============= 获取段落引文 =============
def get_media_block_info(text: str, index, link_list, mid_feature_dict, ready_text_dict, single_ready_quote):
    """获取可信媒体引文信息"""
    a_number = re_quote_num.findall(text)
    numbers = [int(index) for index in a_number]
    numbers = sorted(list(dict.fromkeys(numbers)))
    result = {
        "type": "quoted",
        "index": index,
        "data": {"num": [], "version": 2, "quote_list": []},
    }
    media_user_dict = ready_text_dict["media_ready"]
    media_limit_num = 20
    media_user_num = 0
    already_mid_list = set()
    media_user_list = []
    other_credible_media_list = []
    for reference_num in numbers:
        if reference_num > len(link_list):
            continue

        link_item = link_list[reference_num - 1]
        if "detail?mblogid=" in link_item:
            mid = link_item.split("mblogid=")[1]
            if mid in already_mid_list:
                continue
            already_mid_list.add(mid)
            result["data"]["num"].append(reference_num)
            if len(media_user_dict) >= media_limit_num:
                continue

            v = mid_feature_dict.get(mid, {})
            user_name = v.get('user_name', '')
            user_avatar = v.get('user_avatar', '')
            verify_type = int(v.get('verified_type', -1))
            scheme = f'sinaweibo://detail?mblogid={mid}'
            is_media_user = v.get('is_media_user', False)
            doc_valid_num = v.get('doc_valid_num', 0)
            is_credible_media_user = v.get('is_credible_media_user', False)
            key = f"{user_name}"
            # 可信媒体
            if is_media_user and key not in media_user_dict and key not in single_ready_quote:
                media_user_num += 1
                if is_media_user:  # 权威媒体
                    media_user_list.append({"index": len(result["data"]["quote_list"]), "doc_valid_num": doc_valid_num,
                        "data": {"name": user_name, "img": user_avatar, "scheme": scheme, "vType": verify_type}})
                else:
                    other_credible_media_list.append({"index": len(result["data"]["quote_list"]), "doc_valid_num": doc_valid_num,
                        "data": {"name": user_name, "img": user_avatar, "scheme": scheme, "vType": verify_type}})
            result["data"]["quote_list"].append({"name": user_name, "scheme": scheme, "index": reference_num, "label": ""})
    if media_user_list:
        media_user_list.sort(key=lambda x: (-x["doc_valid_num"], x["index"]))
        result["data"].update(media_user_list[0]["data"])
        media_user = result["data"]["quote_list"].pop(media_user_list[0]["index"])
        media_user["label"] = "大v"
        result["data"]["quote_list"] = [media_user] + result["data"]["quote_list"]
        media_user_dict[media_user["name"]] = True
    elif other_credible_media_list:
        other_credible_media_list.sort(key=lambda x: (-x["doc_valid_num"], x["index"]))
        result["data"].update(other_credible_media_list[0]["data"])
        media_user = result["data"]["quote_list"].pop(other_credible_media_list[0]["index"])
        media_user["label"] = "大v"
        result["data"]["quote_list"] = [media_user] + result["data"]["quote_list"]
        media_user_dict[media_user["name"]] = True
    return media_user_num, result

def single_quote_process(text: str, index, link_list, mid_feature_dict, ready_text_dict, single_ready_quote, log_func=None):
    """单个段落引文处理"""
    # test_dict = {"type":"reliability","data":{"tag_name":"有争议","tag_normal_color":"11","tag_dark_color":"22","tips":"该信息可能有争议，主要来源于普通认证用户，请谨慎参考。"}}
    # text += f'```wbCustomBlock{json.dumps(test_dict, ensure_ascii=False)}```'
    media_user_num, result = get_media_block_info(text, index, link_list, mid_feature_dict, ready_text_dict, single_ready_quote)
    # if media_user_num > 2:
    #     text = re.sub(r"```wbCustomBlock.*```", "", text)
    if not result["data"]["num"]:
        # 没有引文，则删除可信标志
        text = re.sub(r"```wbCustomBlock.*?```", "", text)
        return text
    result_text = f"```wbCustomBlock{json.dumps(result, ensure_ascii=False)}```"
    # if text.endswith("```"):
    #     result_text = " " + result_text
    return text.rstrip() + result_text
