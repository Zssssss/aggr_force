"""多模态整体后处理"""
# -*- coding:utf-8 -*-
import json
import re
from collections import defaultdict
from conf.config import MULTIMODAL_DEBUG
from lib.safe_convert import convert_to_int, convert_to_float
from app.apis.wis_search.post_process.utils import split_markdown_paragraphs, remove_and_save_trailing
from app.apis.wis_search.post_process.quote_process import single_quote_process
from app.apis.wis_search.post_process.picture_process import get_pic_url, get_all_img_data_from_quote, check_img_is_similar
from app.apis.wis_search.post_process.video_process import get_all_video_data_from_quote, check_video_is_similar

re_quote_num = re.compile(r'<a>\[(\d+)\]</a>')
re_wb_custom_block = re.compile("```wbCustomBlock(.*?)```", flags=re.DOTALL)

# ============= 整体入口 pic_process_ds =============
def get_all_quote_list(text: str, pic_info_dict_all, link_list, video_mid_dict, mid_feature_dict):
    """获取所有引文列表"""
    numbers_pic_dict = {}
    numbers_video_dict = {}
    numbers_mid_dict = {}
    a_number = re_quote_num.findall(text)
    numbers = [int(index) for index in a_number]
    numbers = list(dict.fromkeys(numbers))

    is_top_up_list = []
    is_media_user_list = []
    is_gold_orange_list = []
    is_verify_list = []
    other_list = []
    other_quote_list = []
    for reference_num in numbers:
        if reference_num > len(link_list):
            continue

        link_item = link_list[reference_num - 1]
        if "detail?mblogid=" in link_item:
            mid = link_item.split("mblogid=")[1]

            v = mid_feature_dict.get(mid, {})
            filter_tag = v.get('filter_tag', False)
            if filter_tag == True:
                continue
            doc_valid_nums = int(v.get('doc_valid_num', -1))
            verify_type = int(v.get('verified_type', -1))
            if v.get('is_top_up', False):
                is_top_up_list.append({"quote": reference_num, "is_credible": True})
            elif v.get('is_media_user', False):
                is_media_user_list.append({"quote": reference_num, "is_credible": True})
            elif v.get('is_gold_orange', False):
                is_gold_orange_list.append({"quote": reference_num, "is_credible": False})
            elif 0 <= verify_type <= 7:
                is_verify_list.append({"quote": reference_num, "is_credible": False})
            else:
                other_list.append({"quote": reference_num, "is_credible": False})
                other_quote_list.append(reference_num)

            numbers_pic_dict[reference_num] = pic_info_dict_all.get(mid, {})
            numbers_video_dict[reference_num] = video_mid_dict.get(mid, [])
            numbers_mid_dict[reference_num] = mid

    res_quote_list = is_top_up_list + is_media_user_list + is_gold_orange_list + is_verify_list + other_list

    return res_quote_list, numbers_pic_dict, numbers_video_dict, numbers_mid_dict, other_quote_list

def selcet_img_video(use_list: list, query_info_dict: dict, log_func=None):
    """
    选择图片和视频
    1. 若q_attr.ban_object = 3 不出图片和视频
    2. 若单段落采编数量小于等于3，则按照顺序直接输出
    3. 若单段落采编数量大于3，则按照顺序：权威媒体》蓝V》其他 输出前3条符合条件的多模态内容
    """
    if query_info_dict["ban_object"] == 3:
        return []
    limit_num = 3
    if len(use_list) <= limit_num:
        return use_list
    # 调整排序key以符合需求
    if log_func:
        log_func(f"单段落多模态内容排序前:{json.dumps(use_list, ensure_ascii=False)}")
    use_list.sort(key=lambda x: (x["is_top_up"], x["is_media_user"], x["is_blue"]), reverse=True)
    return use_list[:limit_num]

def single_text_process(text:str, pic_info_dict_all: dict, link_list: list, vector_dict: dict, ready_pid_dict: dict, video_mid_dict, mid_feature_dict, query_info_dict, log_func=None):
    """单段落文本处理"""
    quote_list, quote_pic_dict, quote_video_dict, quote_mid_dict, other_list = get_all_quote_list(text, pic_info_dict_all, link_list, video_mid_dict, mid_feature_dict)
    use_list = []
    first_no_finger_img = {}
    img_num = 0
    special_md_key = "mediablock"
    ready_pid_dict.setdefault(special_md_key, [])
    for quote_item in quote_list:
        quote = quote_item["quote"]
        is_credible = quote_item["is_credible"]
        cur_mid = quote_mid_dict.get(quote, "")
        user_name = mid_feature_dict.get(cur_mid, {}).get('user_name', '')
        user_avatar = mid_feature_dict.get(cur_mid, {}).get('user_avatar', '')
        verify_type = convert_to_int(mid_feature_dict.get(cur_mid, {}).get('verified_type', -1), -1)
        hit_score_new = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("hit_score_new", "0"))
        hit_score_final = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("hit_score_final", "0"))
        doc_score = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("doc_score", "0"))
        is_top_up = mid_feature_dict.get(cur_mid, {}).get("is_top_up", False)
        is_media_user = mid_feature_dict.get(cur_mid, {}).get("is_media_user", False)
        mix_media_ids = mid_feature_dict.get(cur_mid, {}).get("mix_media_ids", [])
        is_blue = 1 <= verify_type <= 7
        user_info = f'<span class="vator" style="display: none;background: url({user_avatar}) no-repeat;background-size: contain;"></span><span class="nick" style="display: none">{user_name}</span>'
        img_list, new_k, use_image = get_all_img_data_from_quote(quote, quote_pic_dict, is_credible, query_info_dict["is_hot_query"], mid_feature_dict.get(cur_mid, {}),
                                                      log_func=log_func)
        new_k = re.sub(r">$", f", hit_score_new:{hit_score_new}, hit_score_final:{hit_score_final}, doc_score:{doc_score}>", new_k)
        if MULTIMODAL_DEBUG:
            text = text.replace(f"<a>[{quote}]</a>", f"<a>[{quote}]</a>{new_k}")
        else:
            if log_func:
                log_func(f'当前引文{quote},mid:{cur_mid},{new_k}')
        for img_item in img_list:
            img_pid = img_item["img_pid"]
            img_url = get_pic_url(img_pid)
            img_idx = img_item["img_idx"]  ## img_4_2
            dup_group = img_item["dup_group"]
            pic_finger = img_item["pic_finger"]
            h = img_item["h"]
            w = img_item["w"]
            if img_idx in ready_pid_dict["img_ready"]:
                continue
            if check_img_is_similar(img_item, vector_dict, ready_pid_dict["img_ready"], log_func=log_func):
                ready_pid_dict["img_ready"][img_idx] = {"pid": img_pid, "dup_group": dup_group,
                                                        "pic_finger": pic_finger, "flag": False}
                continue
            cur_scheme = f"sinaweibo://multimedia?mix_mid={cur_mid}&from=search&content_show=1&limit_pid={img_pid}&hide_index=1"
            cur_img_dict = {"type": "p", "scheme": cur_scheme, "img": img_url,
                            "user_name": user_name, "user_avatar": user_avatar, "h": h, "w": w, "vtype": verify_type,
                            "hit_score_new": hit_score_new, "hit_score_final": hit_score_final, "doc_score": doc_score}
            if MULTIMODAL_DEBUG:
                cur_img_str = f'<img src="http://bj.service.t.sinaimg.cn/middle/{img_pid}">'
            else:
                cur_img_str = f'<div data-type="p" data-scheme="{cur_scheme}">{user_info}<img src="{img_url}" data-width={h} data-height={w}></div>'
            cur_img_all_info = {"img_video_str": cur_img_str, "img_video_idx": img_idx, "img_video_dict": cur_img_dict,
                                "is_media_user": is_media_user, "is_blue": is_blue, "is_top_up": is_top_up}
            if not first_no_finger_img and not pic_finger:
                first_no_finger_img = cur_img_all_info
            if not pic_finger:
                ready_pid_dict["img_ready"][img_idx] = {"pid": img_pid, "dup_group": dup_group,
                                                        "pic_finger": pic_finger, "flag": False}
                continue
            use_list.append(cur_img_all_info)
            ready_pid_dict["img_ready"][img_idx] = {"pid": img_pid, "dup_group": dup_group, "pic_finger": pic_finger,
                                                    "flag": True}
            img_num += 1
            use_image = True
        if use_image:
            continue
        video_list, new_video_url = get_all_video_data_from_quote(quote, quote_video_dict, mid_feature_dict.get(cur_mid, {}), other_list, log_func=log_func)
        new_video_url = re.sub(r">$", f", hit_score_new:{hit_score_new}, hit_score_final:{hit_score_final}, doc_score:{doc_score}>", new_video_url)
        if MULTIMODAL_DEBUG:
            text = text.replace(f"<a>[{quote}]</a>", f"<a>[{quote}]</a>{new_video_url}")
        else:
            if log_func:
                log_func(f'当前引文{quote},mid:{cur_mid},{new_video_url}')
        for video_item in video_list:
            video_url = video_item.get('video_url', '')
            video_idx = video_item.get('wideo_idx', '')
            v_phash = video_item.get('v_phash', [])
            waic_video_dup_finger = video_item.get('waic_video_dup_finger', "")
            video_voice_pinying = video_item.get('video_voice_pinying', [])
            img_url = video_item.get('img_url', '')
            h = video_item.get('img_h', 0)
            w = video_item.get('img_w', 0)
            if video_idx in ready_pid_dict["video_ready"]:
                continue
            if check_video_is_similar(video_idx, video_url, v_phash, waic_video_dup_finger, video_voice_pinying, ready_pid_dict["video_ready"], log_func=log_func):
                ready_pid_dict["video_ready"][video_idx] = {"url": video_url, "v_phash": v_phash, "waic_video_dup_finger": waic_video_dup_finger, "video_voice_pinying": video_voice_pinying, "flag": False}
                continue
            if mix_media_ids:
                cur_scheme = f"sinaweibo://multimedia?mix_mid={cur_mid}&mix_index=0"
            else:
                cur_scheme = f"sinaweibo://video/vvs?mid={cur_mid}"
            cur_video_dict = {"type": "v", "scheme": cur_scheme, "img": img_url,
                            "user_name": user_name, "user_avatar": user_avatar, "h": h, "w": w, "vtype": verify_type,
                            "hit_score_new": hit_score_new, "hit_score_final": hit_score_final, "doc_score": doc_score}
            if MULTIMODAL_DEBUG:
                cur_video_str = f'<video src="{video_url}">'
            else:
                cur_video_str = f'<div data-type="v" data-scheme="{cur_scheme}"><span class="arrow"></span>{user_info}<img src="{img_url}" data-width={h} data-height={w}></div>'
            cur_video_all_info = {"img_video_str": cur_video_str, "img_video_idx": video_idx, "img_video_dict": cur_video_dict,
                                "is_media_user": is_media_user, "is_blue": is_blue, "is_top_up": is_top_up}
            use_list.append(cur_video_all_info)
            ready_pid_dict["video_ready"][video_idx] = {"url": video_url, "v_phash": v_phash, "waic_video_dup_finger": waic_video_dup_finger,"video_voice_pinying": video_voice_pinying, "flag": True}
    if not img_num and first_no_finger_img and ready_pid_dict["no_finger_img_num"] < 3:
        use_list.append(first_no_finger_img)
        ready_pid_dict["img_ready"][first_no_finger_img["img_video_idx"]]["flag"] = True
        ready_pid_dict["no_finger_img_num"] += 1
    use_list = selcet_img_video(use_list, query_info_dict, log_func=log_func)
    if not use_list:
        return text
    ready_pid_dict["all_ready_list"].extend([item["img_video_dict"] for item in use_list])
    if MULTIMODAL_DEBUG:
        return text.rstrip() + "<imgs-videos>" + "".join([item["img_video_str"] for item in use_list]) + "</imgs-videos>"
    else:
        # 修改为wbCustomBlock格式
        media_data = {
            "type" : "mediablock",
            "data" : [item["img_video_dict"] for item in use_list]
        }
        cur_index = len(ready_pid_dict[special_md_key])
        cur_format_wbcustomblock = format_wbcustomblock(special_md_key, cur_index)
        ready_pid_dict[special_md_key].append({"data": media_data})
        return text.rstrip() + f"{cur_format_wbcustomblock}"

def add_media_process(text: str, all_ready_list: list):
    """添加多模态内容"""
    if not all_ready_list:
        return text
    media_data = {
        "type" : "mediablock",
        "data" : all_ready_list
    }
    return text.rstrip() + f"```wbCustomBlock{json.dumps(media_data, ensure_ascii=False)}```"

def pic_process_ds(ori_text: str, pic_info_dict_all: dict, link_list: list, vector_dict:dict, video_mid_dict, mid_feature_dict, ready_text_dict, query_info_dict, ready=False, log_func=None):
    """总体对外接口，用于处理图片数据"""
    # 思考过程不处理
    if "<think>" in ori_text and "</think>" not in ori_text:
        return ori_text
    if "</think>" in ori_text:
        pre_text = ori_text.split("</think>")[0] + "</think>"
        text = ori_text.split("</think>")[1]
    else:
        pre_text = ""
        text = ori_text

    result_list = []
    texts = split_markdown_paragraphs(text)
    # print(texts)
    final_text = ""
    if not ready:
        final_text = texts[-1]
        texts = texts[:-1]

    count_limit = 300
    text_ready_list = ready_text_dict.setdefault("text_ready", [])
    ready_text_dict.setdefault("img_ready", {})
    ready_text_dict.setdefault("video_ready", {})
    ready_text_dict.setdefault("media_ready", {})
    ready_text_dict.setdefault("all_ready_list", [])
    ready_text_dict.setdefault("believable_num", 0)
    ready_text_dict.setdefault("no_finger_img_num", 0)
    count = ready_text_dict.get("text_replace_count", 0)
    for i, text in enumerate(texts):
        if i < len(text_ready_list):
            result_list.append(text_ready_list[i])
            continue
        if count >= count_limit:
            new_text = text
        else:
            new_text, final = remove_and_save_trailing(text)
            # 段落中引文处理
            # new_text, single_ready_quote = single_mid_quote_process(new_text, i, link_list, mid_feature_dict, log_func)
            single_ready_quote = set()
            # 风险处理
            # new_text = single_risk_process(new_text, i, link_list, mid_feature_dict, ready_text_dict, log_func)
            # 引文处理
            new_text = single_quote_process(new_text, i, link_list, mid_feature_dict, ready_text_dict, single_ready_quote, log_func)
            # 图片视频处理
            new_text = single_text_process(new_text, pic_info_dict_all, link_list, vector_dict, ready_text_dict, video_mid_dict, mid_feature_dict, query_info_dict, log_func=log_func)
            new_text = new_text + final
        if len(new_text) != len(text):
            count += 1
        result_list.append(new_text)
        text_ready_list.append(new_text)
    ready_text_dict["text_replace_count"] = count
    if not ready:
        # 最后没到段尾的也需要流式处理，避免前后显示不一致
        # final_text, _ = single_mid_quote_process(final_text, len(texts), link_list, mid_feature_dict, log_func)
        result_list.append(final_text)
    return pre_text + "".join(result_list)


# ============= 解析wbcustomblock数据 =============
def format_wbcustomblock(lang: str, index: int):
    """构造特殊格式"""
    return f'[^多模态_{lang}_{index}]'

def process_wbcustomblock_format(text: str, ready, logger) -> (str, dict):
    """解析wbcustomblock数据"""
    block_list = re_wb_custom_block.findall(text)
    result = defaultdict(list)
    for block in block_list:
        ori_text = f"```wbCustomBlock{block}```"
        try:
            data = json.loads(block)
        except Exception as e:
            if ready and logger:
                logger.error(f"wbCustomBlock error: {e}, data:{json.dumps(block,ensure_ascii=False)}")
            continue
        type_val = data.get("type", "") or "other"
        result[type_val].append({
            "ori_text": ori_text.strip(),
            "data": data,
            "type": type_val
        })
        text = text.replace(ori_text, format_wbcustomblock(type_val, len(result[type_val]) - 1))
    return text, result

# ============= 整体入口，回写wbcustomblock数据 =============
def back_wbcustomblock_format(text: str, result) -> str:
    """回写wbcustomblock格式"""
    for lang, blocks in result.items():
        for index, block in enumerate(blocks):
            data = block["data"]
            if data:
                replace_str = f"```wbCustomBlock{json.dumps(block['data'], ensure_ascii=False)}```"
            else:
                replace_str = ""
            text = text.replace(format_wbcustomblock(lang, index), replace_str)
    return text