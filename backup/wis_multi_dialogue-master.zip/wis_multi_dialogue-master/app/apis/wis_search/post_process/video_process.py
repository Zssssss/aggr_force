"""视频后处理"""
# -*- coding:utf-8 -*-
import json
import re
import binascii
import numpy as np
from datasketch import MinHash
from conf.config import MULTIMODAL_DEBUG
from app.apis.wis_search.post_process.picture_process import get_size_from_pid, get_pic_url

# ============= 判断视频相似度 =============
def update_hash_list(hash_list: list):
    """更新hash列表,去除纯色图片"""
    new_hash_list = []
    for hash_item in hash_list:
        if hash_item.count('0') == len(hash_item):
            continue
        new_hash_list.append(hash_item)
    return new_hash_list

def hamming_distance_hex(hex_str1, hex_str2):
    # 校验输入合法性
    if len(hex_str1) != len(hex_str2):
        return None

    # 转换为字节序列
    hex_str1 = hex_str1.encode('utf-8').hex()
    hex_str2 = hex_str2.encode('utf-8').hex()
    bytes1 = bytes.fromhex(hex_str1)
    bytes2 = bytes.fromhex(hex_str2)

    # 计算异或后的汉明距离
    return sum(bin(b1 ^ b2).count('1') for b1, b2 in zip(bytes1, bytes2))

def hex_to_minhash(hex_str):
    """将字符串还原为 MinHash 对象"""
    # 去除方括号并分割十六进制字符串
    hex_values = hex_str.strip("[]").split(",")
    int_values = [int(x, 16) for x in hex_values]
    m = MinHash(num_perm=8)
    m.hashvalues = np.array(int_values, dtype=np.uint32)
    return m

def check_video_similarity(
    video_1: str,
    video_2: str,
    v_phash_1: list,
    v_phash_2: list,
    video_voice_pinying_1: str,
    video_voice_pinying_2: str,
):    
    """计算视频相似度"""
    v_phash_1 = update_hash_list(v_phash_1)
    v_phash_2 = update_hash_list(v_phash_2)
    for i in range(len(v_phash_1)):
        for j in range(len(v_phash_2)):
            hamming_distance = hamming_distance_hex(v_phash_1[i], v_phash_2[j])
            if hamming_distance is not None and hamming_distance < 16:
                return True
    if video_voice_pinying_1 and video_voice_pinying_2:
        v_voice_minhash_1 = hex_to_minhash(video_voice_pinying_1)
        v_voice_minhash_2 = hex_to_minhash(video_voice_pinying_2)
        if v_voice_minhash_1.jaccard(v_voice_minhash_2) >= 0.15:
            return True
    return False

# ============= 视频后处理 =============
def get_all_video_data_from_quote(quote, quote_video_dict, mid_feature_dict, other_list, log_func=None):
    """从引文中提取所有视频url"""
    video_list = []
    video_old_list = quote_video_dict.get(quote, [])
    count = 1
    new_video_url = ""
    is_verfy = quote not in other_list
    for video_item in video_old_list:
        video_url = video_item.get('url', '')
        high_quality_video = video_item.get('high_quality_video', "0")
        v_phash = video_item.get('v_phash', [])
        highest_quality_label = video_item.get('highest_quality_label')
        avg =  video_item.get('avg')
        video_voice_pinying = video_item.get('video_voice_pinying', "")
        waic_video_dup_finger = video_item.get('waic_video_dup_finger', "")
        has_video_voice_pinying = True if video_voice_pinying and video_voice_pinying!="" else False
        img_ori_url = video_item.get('image', {}).get('url', '')
        img_pid = video_item.get('image', {}).get('pid', '')
        if not img_pid and img_ori_url:
            img_pid = img_ori_url.split('/')[-1].split(".")[0]
        img_h, img_w = get_size_from_pid(img_pid)
        img_url = get_pic_url(img_pid) if len(img_pid) > 21 else ""
        duration = float(video_item.get('duration', -1))
        video_index = video_item.get('video_index', 0)
        if MULTIMODAL_DEBUG:
            if not video_url or duration == -1 or not v_phash or not img_url:
                if log_func:
                    log_func(f"<物料信息不全>视频:{video_url}，duration:{duration}，phash:{v_phash}，图片:{img_url}，不符合要求")
        # 添加其他信息
        new_video_url = f'<首视频特征：video_url:{video_url}, high_quality_video:{high_quality_video}, highest_quality_label:{highest_quality_label}, avg:{avg}, duration:{duration}, img_h:{img_h}, img_w:{img_w}, v_phash:{v_phash}, has_video_voice_pinying:{has_video_voice_pinying}, img_url:{img_url}, video_index:{video_index}, 是否认证:{is_verfy}, waic_video_dup_finger:{waic_video_dup_finger}>'
        def is_valid_video(video_index, video_url, duration, avg, highest_quality_label):
            if video_index != 0:
                return False
            if not video_url:
                return False
            if duration <= 10:
                return False
            try:
                is_valid_avg = (avg > 0.4) if avg is not None else True
            except:
                is_valid_avg = True
            try:
                is_valid_label = int(highest_quality_label.split('p')[0]) > 480 if highest_quality_label else True
            except:
                is_valid_label = True
            if not is_valid_avg and not is_valid_label:
                return False
            return True
        if is_valid_video(video_index, video_url, duration, avg, highest_quality_label):
            video_list.append({'wideo_idx': f"video_{quote}_{count}", 'video_url': video_url, "v_phash": v_phash, "img_url": img_url, "img_w": img_w, "img_h": img_h})
        else:
            if log_func:
                log_func(f"{new_video_url}，不符合要求")
        count += 1
        break
    return video_list, new_video_url

def check_video_is_similar(video_idx, video_url, v_phash, waic_video_dup_finger, video_voice_pinying, ready_pid_dict, log_func=None):
    """检查视频是否重复"""
    for cur_idx, cur_pid_dict in ready_pid_dict.items():
        if cur_pid_dict["url"] == video_url:
            if log_func:
                log_func(f"视频索引{video_idx}的视频url:{video_url},与索引{cur_idx}的视频url:{cur_pid_dict['url']},重复")
            return True
        if not cur_pid_dict["flag"]:
            continue
        # 如果waic_video_dup_finger不为空，且与cur_pid_dict["waic_video_dup_finger"]相同，则打印日志，并返回True
        if waic_video_dup_finger and cur_pid_dict["waic_video_dup_finger"] == waic_video_dup_finger:
            if log_func:
                log_func(f"视频索引{video_idx}的视频url:{video_url},与索引{cur_idx}的视频url:{cur_pid_dict['url']},waic_video_dup_finger:{waic_video_dup_finger}, 视频分组重复")
            return True
        # 视频相似度判断
        if check_video_similarity(video_idx, cur_idx, v_phash, cur_pid_dict.get("v_phash", []), video_voice_pinying, cur_pid_dict.get("video_voice_pinying", '')):
            if log_func:
                log_func(f"视频索引{video_idx}的视频url:{video_url},与索引{cur_idx}的视频url:{cur_pid_dict['url']},相似度过高,重复")
            return True

    return False
