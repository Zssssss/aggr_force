"""后处理handler"""
# -*- coding:utf-8 -*-
import json
import re

from lib.safe_logger import get_logger
from app.apis.wis_search.post_process.utils import (split_think_and_content, get_weibo_link_index_list,
                                                    split_paragraphs_with_markdown_title)
from app.apis.wis_search.post_process.quote_process import standardize_quote, delete_quote
from app.apis.wis_search.post_process.multimodal_process import pic_process_ds
from app.apis.wis_search.post_process.filter_process import filter_invalid_str
from app.apis.wis_search.post_process.md_special_format_process import remove_markdown_links

class ProcessUtils:
    def __init__(self,pid):
        log_filename = "log/post_process-" + str(pid) + ".log"
        self.logger = get_logger(log_filename, self.__class__.__name__)

    def replace_invalid_str_and_log(self, s: str, query: str, trace_id: str, weibo_link_index_list: list,
                                    ready: bool = False) :
        """替换非法字符，并记录日志"""
        result, replaced_matches = standardize_quote(s, weibo_link_index_list)
        if (len(result) != len(s) or len(replaced_matches)) and ready :
            self.logger.info(
                "traceid:{}\tquery:{}\treplaced_matches_len:{}\treplaced_matches:{}\tweibo_link_index_list:{}\tbefore_result:{}".format(
                    trace_id, query, len(replaced_matches), replaced_matches, weibo_link_index_list,
                    json.dumps(s, ensure_ascii=False)))
        return result

    def filter_invalid_str_and_log(self, s: str, query: str, trace_id: str, ready: bool = False):
        """过滤非法字符，并记录日志"""
        result, filtered_matches = filter_invalid_str(s)
        if len(result) != len(s) and ready:
            self.logger.info("traceid:{}\tquery:{}\tfiltered_matches_len:{}\tfiltered_matches:{}\tbefore_result:{}".format(
                trace_id, query, len(filtered_matches), filtered_matches, json.dumps(s, ensure_ascii=False)))
        return result

    def replace_picture_and_log(self, s: str, query_info_dict, pic_url_list: list, vector_dict: dict, ready_pid_dict: dict, pid_dup_dict: dict, pic_info_dict_all, link_list: list, video_mid_dict, mid_feature_dict, ready: bool=False, is_stream=False,log_func = None ):
        """过滤图片引用字符，并记录日志"""
        # result, picture_matches = picture_process(s, pic_url_list, vector_dict, ready_pid_dict, pid_dup_dict, pic_info_dict_all, ready=ready, log_func=log_func, is_stream=is_stream)
        result = pic_process_ds(s, pic_info_dict_all, link_list, vector_dict, video_mid_dict, mid_feature_dict, ready_pid_dict, query_info_dict, ready=ready, log_func=log_func)
        if len(result) != len(s) and ready:
            self.logger.info("traceid:{}\tquery:{}\tbefore_result:{}".format(
                query_info_dict["trace_id"], query_info_dict["query"], json.dumps(s, ensure_ascii=False)))
        return result

    def process_code_block_multimodal_content(self, result):
        """处理由于4个以上空格导致的前端识别为代码块，不解析多模态内容的问题"""
        think, content = split_think_and_content(result)
        if not content:
            return think
        split_list = split_paragraphs_with_markdown_title(content)
        space_re = re.compile(r"^\s{4,}")
        for single_content in split_list:
            ori_content = single_content
            source_str = "\n"
            replace_str = "\n"
            if "```wbCustomBlock" not in single_content and "<media-block>" not in single_content:
                continue
            single_list = single_content.split("\n")
            for index, single_line in enumerate(single_list):
                if index == 0 or not single_line.strip():
                    continue
                search = space_re.search(single_line)
                if search:
                    length = search.end()
                    source_str += " " * length
                break
            if source_str == replace_str:
                continue
            single_content = single_content.replace(source_str, replace_str)
            content = content.replace(ori_content, single_content)
        return think + content

    def delete_quote_case(self, result: str):
        """删除括号里面的无用的引文"""
        l_bracket = r"[\(（]"
        r_bracket = r"[\)）]"
        pre_quote = r"(?:如|见|参考|百科|自|源|结果|案例|数据)"
        mid_quote = r"['\"‘’“” ]*"
        quote = r"\[\^\d+\]"
        other = r"[^\(（\)）\n]*"
        re_search = re.compile(rf"{l_bracket}{other}{pre_quote}{mid_quote}{quote}{other}{r_bracket}")
        check_list = list(set(re_search.findall(result)))
        for cur in check_list:
            quote_list = re.findall(quote, cur)
            replace_str = ''.join(quote_list)
            if len(cur) - len(replace_str) < 8:
                result = result.replace(cur, replace_str)
        # 删除引文前后的特殊字符
        re_search = re.compile(rf"{mid_quote}({quote}){mid_quote}")
        result = re_search.sub(r'\1', result)
        # 删除引文后的 的、等、中
        after_quote = r"(?:的|中|等)"
        re_search = re.compile(rf"({quote}){after_quote}")
        result = re_search.sub(r'\1', result)
        return result
    
    def process_invalid_quote(self, result):
        """处理正文错误的的引用格式, 在引文标准化之前"""
        think, content = split_think_and_content(result)
        # \\[^6]、\\[^6\\]
        content = re.sub(r'\\([\[\]])', r'\1', content)
        # （例如[^6]）
        content = self.delete_quote_case(content)
        return f"{think}\n{content}"

    def process_first_title(self, result):
        """处理正文第一个无用的标题"""
        think, content = split_think_and_content(result)
        split_text = content.strip().split("\n")
        if len(split_text[0]) < 15 and "关键信息" in split_text[0]:
            split_text = split_text[1:]
        content = "\n".join(split_text)
        return f"{think}\n{content}"

    def get_log_func(self, context):
        """获取日志函数"""
        query = context.get("query", "")
        trace_id = context.get("trace_id", "")
        ready = context.get("ready", False)
        def log_func(message: str):
            """日志函数"""
            if ready:
                self.logger.info("traceid:{}\tquery:{}\t{}".format(trace_id, query, message))
        return log_func

    def share_card_output(self, all_ready_list):
        """share_card页输出多模态信息"""
        if not all_ready_list:
            return {}
        result = all_ready_list[0].copy()
        # 图片改为中等图
        if result.get("img"):
            result["img"] = result["img"].replace("sinaimg.cn/large/", "sinaimg.cn/middle/")
        return result


class PostProcessHandler:

    def __init__(self, pid):
        self.pid = pid
        self.process_utils = ProcessUtils(pid)

    def handle(self, result: str, context: dict) -> str:
        raise NotImplementedError


class PostProcessor:
    def __init__(self, handlers: list[PostProcessHandler]):
        self.handlers = handlers

    def run(self, result: str, context: dict) -> str:
        for handler in self.handlers:
            result = handler.handle(result, context)
        return result


class ReplaceInvalidStrHandler(PostProcessHandler):
    def handle(self, result, context):
        result = remove_markdown_links(result)
        link_index = get_weibo_link_index_list(context["link_list"])
        result = self.process_utils.process_invalid_quote(result)
        result = self.process_utils.replace_invalid_str_and_log(result, context["query"], context["trace_id"], link_index, ready=context["ready"])
        result = self.process_utils.filter_invalid_str_and_log(result, context["query"], context["trace_id"], ready=context["ready"])
        return result


class ReplaceMultimodalHandler(PostProcessHandler):
    def handle(self, result, context):
        return self.process_utils.replace_picture_and_log(
            result,
            {
                "query": context["query"],
                "trace_id": context["trace_id"],
                "ban_object": context["ban_object"],
                "is_hot_query": context["is_hot_query"]
            },
            context["picture_urls"],
            context["vector_dict"],
            context["ready_pid_dict"],
            context["pid_dup_dic"],
            context["pic_info_dict_all"],
            context["link_list"],
            context["video_mid_dict"],
            context["mid_feature_dict"],
            ready=context["ready"],
            is_stream=context["is_stream"],
            log_func=self.process_utils.get_log_func(context)
        )


class CodeBlockFixHandler(PostProcessHandler):
    def handle(self, result, context):
        # 处理由于4个以上空格导致的前端识别为代码块，不解析多模态内容的问题
        result = self.process_utils.process_code_block_multimodal_content(result)
        # 处理正文第一个无用的标题
        result = self.process_utils.process_first_title(result)
        return result


class CardOutputHandler(PostProcessHandler):
    def handle(self, result, context):
        all_ready_list = context.get("ready_pid_dict", {}).get("all_ready_list", [])
        context["weibo_update_dict"]["share_card_multimodal"] = self.process_utils.share_card_output(all_ready_list)
        return result


class DeleteQuote(PostProcessHandler):
    def handle(self, result: str, context):
        return delete_quote(result)