"""
业务接口
"""
import os
import json
import re
import time
import aiohttp
import asyncio
import traceback

from app.apis.wis_search.material.mid_info import MidMaterial
from lib.redis_utils import async_redis_client
from app.apis.wis_search.utils.query_filter import query_filter
from lib.base import Base
from app.apis.wis_search.llm.question_answer import QuestionAnswer, WhiteboardQuestionAnswer, SixinQuestionAnswerV2
from app.apis.wis_search.llm.question_checker import QuestionChecker, SixinQuestionCheckerV2
from app.apis.wis_search.llm.simple_dialogue import SimpleDialogue, SixinSimpleDialogue
from app.apis.wis_search.llm.sixin_tool import SixinTool, SixinToolV2
from app.apis.wis_search.material.history import DialogueHistory
from app.apis.wis_search.post_process.utils import get_query_and_history, update_status_stage
from app.apis.wis_search.models import FirstRoundBack
from app.apis.wis_search.memory.session_memory import AsyncSessionMemoryProcess, UserPersona
from app.apis.wis_search.post_process.utils import delete_wbcustomblock
from app.apis.wis_search.llm.intent_recognition import IntentRecognition
from app.apis.wis_search.utils.intention import MaybeAskIntention



# 多轮对话取最后3轮
Latest_Message = 12

class DialogueService(Base) :
    def __init__(self, pid, weibo, output):
        super().__init__(pid)
        self.weibo = weibo
        self.weibo['pid'] = pid
        self.output = output
        self.trace_id = weibo.get('trace_id', "")

        self.memory_process = AsyncSessionMemoryProcess(self.pid, self.weibo)
        self.question_checker = QuestionChecker(self.pid, self.weibo)
        self.simpler_dialogue = SimpleDialogue(self.pid, self.weibo)
        self.question_answer = QuestionAnswer(self.pid, self.weibo)
        self.user_persona = UserPersona(self.pid, self.weibo)
        self.maybe_ask_intention = MaybeAskIntention(self.pid, self.weibo)

        # 保存信息
        update_output = self.weibo.setdefault("update_output", {})
        llm_trace_info = self.weibo.setdefault("llm_trace_info", [])
        chat_check_info = self.weibo.setdefault("chat_check_info", {})
        debug_info = self.weibo.setdefault("debug_info", {})

    def update_similar(self, similar_list):
        """更新历史记录"""
        for item in similar_list:
            role = item['role']
            if role == "user":
                item['role'] = '用户'
            elif role == "assistant":
                item['role'] = '微博智搜'
        return similar_list

    async def save_memory(self, query, user_id, session_id, model_resp, messages_conv, cur_txt):
        ori_conversation_id = self.weibo.get("ori_conversation_id", "")
        model_resp = await DialogueHistory(self.pid).get_conversation(self.trace_id, user_id, session_id, ori_conversation_id)
        self.logger.info(f"{self.trace_id} get_conversation: {json.dumps(model_resp, ensure_ascii=False)}")
        try:
            await asyncio.wait_for(
                asyncio.gather(
                    self.memory_process.save_message(query, user_id, session_id, model_resp, messages_conv.get("cur_round", 1)),
                    self.gen_user_profile(user_id, query)
                ),
                timeout=3.0  # 设置3秒超时
            )
        except asyncio.TimeoutError:
            self.logger.warning(f"{self.trace_id} save_memory tasks timed out after 3 seconds")
        except Exception as e:
            self.logger.error(f"{self.trace_id} save_memory tasks error: {e}")

    # 沉淀用户画像
    async def gen_user_profile(self, user_id, query):
        data = {
            "user_id": user_id,
            "query" : query,
            "trace_id": self.trace_id
        }
        await self.user_persona.run(data=data)
        self.logger.info(f"wis_dialogue_persona {self.trace_id} enqueue data:{json.dumps(data, ensure_ascii=False)}")

    # 将人物搜索信息写入redis
    async def save_person_search_to_redis(self, user_id, session_id, ori_conversation_id):
        """将人物搜索的意图和物料信息写入redis
        
        Args:
            user_id: 用户ID
            session_id: 会话ID
            ori_conversation_id: 原始对话ID
        """
        try:
            # 构造要存储的json数据
            json_data = self.weibo.get("person_search_info", {})
            if not json_data or (not json_data.get("da_intention_exact_match", "") and not json_data.get("famous_person_intention", {})):
                self.logger.info(f"{self.trace_id} person_search_info save: {json.dumps(json_data, ensure_ascii=False)}")
                return
            
            # 写入原始key（每次都执行）
            await self._write_to_redis(json_data, "wis_psearch_info_", f"{user_id}_{session_id}_{ori_conversation_id}")
            
            # 有条件写入会话key（只在有明确的人物搜索意图时执行）
            if json_data.get("da_intention_exact_match", "") == "1" or json_data.get("famous_person_intention", {}).get("is_exact_match", "") == "1":
                await self._write_to_redis(json_data, "wis_psearch_session_", f"{user_id}_{session_id}", 7 * 24 * 60 * 60)
                self.logger.info(f"{self.trace_id} write session key for person search, user_id: {user_id}, session_id: {session_id}")
            
        except Exception as e:
            self.logger.error(f"{self.trace_id} save_person_search_to_redis error: {e}")
    
    async def _write_to_redis(self, json_data, prefix, key_suffix, expire_seconds=10 * 60):
        """辅助方法：将数据写入redis
        
        Args:
            json_data: 要写入的JSON数据
            prefix: redis key前缀
            key_suffix: redis key后缀
            expire_seconds: 过期时间（秒），默认为10分钟
        """
        try:
            # 构造redis key
            redis_key = f"{prefix}{key_suffix}"
            
            # 获取redis客户端（每个key单独获取，避免分片问题）
            redis_client = async_redis_client.get_redis_server(redis_key)
            
            # 写入redis
            await redis_client.set(redis_key, json.dumps(json_data, ensure_ascii=False))
            # 设置过期时间
            await redis_client.expire(redis_key, expire_seconds)
            
            self.logger.info(f"{self.trace_id} write_to_redis success, key: {redis_key}, expire_seconds: {expire_seconds}, val:{json.dumps(json_data, ensure_ascii=False)}")
        except Exception as e:
            self.logger.error(f"{self.trace_id} write_to_redis error for key {redis_key}: {e}")

    async def calc_maybe_ask_intention(self, user_id, session_id, conversation_id, query, messages):
        data = {
            "user_id": user_id,
            "query" : query,
            "session_id": session_id,
            "conversation_id": conversation_id,
            "messages": messages,
            "trace_id": self.trace_id
        }
        await self.maybe_ask_intention.run(data=data)
        self.logger.info(f"wis_dialogue_ask_intention {self.trace_id} enqueue data:{json.dumps(data, ensure_ascii=False)}")

    async def build_message_conv(self, question, history_list):
        user_id = self.weibo.get("user_id", "")
        conversation_id = self.weibo.get("conversation_id", "")
        session_id = self.weibo.get("session_id", "") or conversation_id
        round_num = len(history_list) // 2 + 1

        # 获取相似对话
        similar_list = self.update_similar(
            await self.memory_process.get_similarity_session(
                question, user_id, session_id, round_num)
        )

        # 清一下历史
        if not history_list:
            await self.memory_process.clear_message(user_id, session_id)

        # 取历史最近三轮 + 相似对话
        messages_conv = {
            "retrieval_conv": similar_list,
            "history_conv": history_list,
            "cur_round": round_num,
        }
        return messages_conv


    async def chat_stream(self) :
        try:
            self.logger.info(f"{self.trace_id} chat_stream start.")
            weibo = self.weibo
            start_time = time.time()

            messages = weibo.get("messages", [])
            query, history_list = get_query_and_history(messages)
            query = self.weibo.get("question", query)
            self.weibo['question'] = query
            is_private_message = self.weibo.get("is_private_message", False)

            user_id = weibo.get("user_id", "")
            conversation_id = weibo.get("conversation_id", "")
            ori_conversation_id = weibo.get("ori_conversation_id", "")
            session_id = weibo.get("session_id", "")

            session_id = conversation_id or session_id
            model = weibo.get('model', '思考版')
            source_type = weibo.get('source_type', '')
            basemodel = weibo.get('basemodel', '')
            in_time_ms = weibo.get('in_time_ms', 0)
            query_in_time = weibo.get('query_in_time', 0)
            get_history_time = weibo.get('get_history_time', 0)

            # 保存信息
            update_output = weibo.setdefault("update_output", {})
            llm_trace_info = weibo.setdefault("llm_trace_info", [])
            chat_check_info = weibo.setdefault("chat_check_info", {})
            debug_info = weibo.setdefault("debug_info", {})

            debug_info.update({
                "base_info": {
                    "query": query,
                    "model": model,
                    "source_type": source_type,
                    "user_id": user_id,
                    "conversation_id": conversation_id,
                    "session_id": session_id,
                    "is_private_message": is_private_message,
                    "basemodel": basemodel
                },
                "in_time_ms": in_time_ms,
                "query_in_time": query_in_time,
                "get_history_time": get_history_time,
                "all_time_start": start_time,
            })

            chat_check_info.update(debug_info["base_info"])
            self.logger.info(f"{self.trace_id} query {query}, model: {model}")

            # 回传开始状态
            update_status_stage(self.weibo, "BEGIN")
            await self.output.output(ready='no', content="", weibo=self.weibo)

            # is_query_filter = await query_filter(weibo, self.logger)
            # if is_query_filter:
            #     weibo['special_tips'] = "抱歉，这个问题我暂时无法回答，换个问题试试吧"
            #     weibo['model_filter'] = 'query_filter'
            #     await self.output.output(ready="special_tips", content="", weibo=self.weibo)
            #     return

            messages_conv = await self.build_message_conv(query, history_list)
            self.logger.info(f"{self.trace_id} messages_conv: {json.dumps(messages_conv, ensure_ascii=False)}")
            self.weibo['message_conv'] = messages_conv
            fr_back = FirstRoundBack()
            sec_round_back = FirstRoundBack()

            # 执行可丢弃的协程，设置300ms超时，不影响主流程
            async def run_maybe_ask_intention():
                try:
                    await asyncio.wait_for(
                        self.calc_maybe_ask_intention(user_id=user_id, session_id=session_id, conversation_id=ori_conversation_id, query=query, messages=messages),
                        timeout=0.3
                    )
                except asyncio.TimeoutError:
                    self.logger.info(f"{self.trace_id} calc_maybe_ask_intention timed out")
                except Exception as e:
                    self.logger.error(f"{self.trace_id} calc_maybe_ask_intention error: {e}")
            
            await asyncio.gather(
                self.question_checker.run(messages_conv, fr_back, self.output),
                self.question_answer.get_material_task_async(messages_conv),
                run_maybe_ask_intention()
            )

            self.logger.info(f"{self.trace_id} query is_qa: {fr_back.is_qa}")
            if fr_back.is_qa:
                self.weibo["update_output"]["chat_type"] = 1
                await self.question_answer.await_material_task(fr_back, self.output)
                # 并行执行 question_answer.run 和 save_person_search_to_redis
                cur_txt_task = asyncio.create_task(self.question_answer.run(messages_conv, fr_back, sec_round_back, self.output))
                save_person_task = asyncio.create_task(self.save_person_search_to_redis(user_id, session_id, ori_conversation_id))
                await asyncio.gather(cur_txt_task, save_person_task)
                cur_txt = cur_txt_task.result()
            else:
                self.weibo["update_output"]["chat_type"] = 0
                cur_txt = await self.simpler_dialogue.run(messages_conv, sec_round_back, self.output)
                await self.question_answer.cancel_material_task()

            weibo['content'] = cur_txt
            chat_check_info["final_result"] = cur_txt
            self.logger.info(
                f"{self.trace_id} Generate LLM response end. first_think: {json.dumps(fr_back.think, ensure_ascii=False)}, first_content: {json.dumps(fr_back.content, ensure_ascii=False)}, "
                f"second_think: {json.dumps(sec_round_back.think, ensure_ascii=False)}, second_content: {json.dumps(sec_round_back.content, ensure_ascii=False)}")

            # 记忆模块存储
            debug_info["save_memory_start"] = time.time()
            await self.save_memory(query, user_id, session_id, sec_round_back.content, messages_conv, cur_txt)
            debug_info["save_memory_end"] = time.time()

            # 添加日志记录存储时间
            self.logger.info(f"{self.trace_id} save memory cost: {debug_info['save_memory_end'] - debug_info['save_memory_start']:.2f} seconds")
            debug_info["all_time_end"] = time.time()
            self.logger.info(f"{self.trace_id} all_debug_time_info: {json.dumps(debug_info, ensure_ascii=False)}")
            self.logger.info(f"{self.trace_id} -------------------------finish----------------------------")
        except Exception as e:
            await self.output.output(ready="error", content="", weibo=self.weibo)
            self.logger.error(f"{self.trace_id} weibo:{json.dumps(self.weibo, ensure_ascii=False)} error: {traceback.format_exc()}")


class WhiteboardDialogueService(DialogueService):

    def __init__(self, pid, weibo, output):
        super().__init__(pid, weibo, output)
        self.question_answer = WhiteboardQuestionAnswer(pid, weibo)

    async def save_memory(self, query, user_id, session_id, model_resp, messages_conv, cur_txt):
        memory_task = asyncio.create_task(
            self.memory_process.save_message(query, user_id, session_id, model_resp, messages_conv.get("cur_round", 1)))
        questions = await self.get_questions(query, model_resp, user_id, session_id, messages_conv)
        await self.output.output(ready="yes", content=cur_txt + questions, weibo=self.weibo)
        await memory_task

    async def get_questions(self, query:str, model_resp:str, user_id:str, session_id:str, messages_conv:dict):
        """获取追问结果，用于白板展示"""
        def format_create_parms():
            history_list = [{"用户": query, "微博智搜": delete_wbcustomblock(model_resp)}]
            history_conv = messages_conv.get("history_conv", [])[-4:]
            for i in range(len(history_conv) - 1, -1, -2):
                history_list.append({"用户": history_conv[i - 1]["content"], "微博智搜": history_conv[i]["content"]})
            parms_dict = {
                "question": query,
                "user_id": user_id,
                "session_id": session_id,
                "history": json.dumps(history_list)
                # "history": history_list
            }
            return parms_dict

        async def post_question(url: str, parms_dict: dict):
            """接口调用"""
            timeout = 0.5
            headers = {'Content-Type': 'application/json'}
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as session:
                    async with session.post(url, headers=headers, json=parms_dict) as res:
                        if res.status == 200:
                            try:
                                data = await res.json()
                            except aiohttp.ContentTypeError:
                                data = await res.text()
                            return {"success": True, "data": data}
                        else:
                            return {"success": False, "error": f"HTTP {res.status}, {res}"}
            except asyncio.TimeoutError:
                return {"success": False, "error": "Request timed out"}
            except aiohttp.ClientError as e:
                return {"success": False, "error": str(e)}

        def gen_questions(questions):
            res = ""
            meta = {'role': "system"}
            for q in questions:
                q_str = f"[{q}](#)\n"
                res += f"\n\n[//]: <> ({json.dumps(meta, ensure_ascii=False)})\n{q_str}"
            return res

        # 先生成问题
        url = "http://10.133.168.176:19787/chat_bot/generate_question_white"
        parms_dict = format_create_parms()
        error_info = ""
        for _ in range(2):
            res = await post_question(url, parms_dict)
            if res['success']:
                break
            error_info = res['error']
            if res['error'] != "Request timed out":
                await asyncio.sleep(0.5)
        else:
            self.logger.error(f"{self.trace_id} generate_question_white error: {error_info}")
            return ""
        # 再获取结果
        url = "http://10.133.168.176:19787/chat_bot/question_white"
        parms_dict.pop("history")
        questions = []
        for _ in range(6):
            res = await post_question(url, parms_dict)
            if res['success']:
                if res['data']['data']:
                    questions = res['data']['data']['data']
                    break
                else:
                    await asyncio.sleep(0.5)
                    continue
            error_info = res['error']
            if res['error'] != "Request timed out":
                await asyncio.sleep(0.5)
        else:
            self.logger.error(f"{self.trace_id} get_question_white error: {error_info}, msg: {traceback.format_exc()}")
            return ""
        return gen_questions(questions)

class SixinDialogueService(DialogueService):

    def __init__(self, pid, weibo, output):
        super().__init__(pid, weibo, output)

        # 私信闲聊用非思考版本
        self.simpler_dialogue = SixinSimpleDialogue(pid, weibo)
        self.sixin_tool = SixinTool(self.pid, self.weibo)
        self.intent_recognition = IntentRecognition(self.pid, self.weibo)

    async def chat_stream(self):
        query = self.weibo.get("question", "")
        if query in ["你好呀", "夸夸我", "撩一下", "吵个架"]:
            await self.sixin_tool.run(self.output)
        else:
            if self.weibo.get("send_from") == "comment":
                await self.update_comment_message()
            self.weibo["is_private_message"] = True
            if not await self.intent_recognition.run():
                await super().chat_stream()

    async def get_weibo_analysis(self, mid):
        url = f'http://admin.ai.s.weibo.com/api/llm/analysis_once_res.json?query={mid}'
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url=url) as res:
                    if res.status == 200:
                        res_json = await res.json()
                        ori_data = res_json.get("data", {})
                        llm_name = "deepseek_verification"
                        data = ori_data.get(llm_name, {})
                        if data:
                            ori_content = data.get('content', "")
                            if not ori_content:
                                self.logger.info(f"get weibo_analysis empty: mid: {mid}, content is empty")
                                return ""
                            return ori_content
                    else:
                        self.logger.info(f"get weibo_analysis error: mid: {mid}, status: {res.status}")
                        return ""
        except Exception as e:
            self.logger.info(f"get weibo_analysis error: mid: {mid}, error: {e}")
        return ""
    
    async def gen_comment_message(self, mid, comment, weibo_analysis):
        trace_id = self.weibo.get("trace_id", "")
        user_prompt = await MidMaterial(self.pid).get_mid_content(trace_id, mid)
        if weibo_analysis:
            assistant_prompt = weibo_analysis
            user_prompt += "\n请对这篇原博进行求证和解读。"
        else:
            assistant_prompt = "你希望我针对这篇原博做什么？"
        messages = [{"role": "user", "content": user_prompt}, {"role": "assistant", "content": assistant_prompt}, {"role": "user", "content": comment}]
        return messages

    async def update_comment_message(self):
        def _handle_comment(comment):
            # 移除表情符号
            comment = re.sub(u"\[\S+?\]", "", comment).strip()
            if re.sub(u"@[^ :：。；;]{1,20}", "", comment).strip() == "" :
                comment = "请对原博内容进行求证分析或解读。"
            return comment
        try :
            q_attr_dict = json.loads(self.weibo.get("q_attr") or "{}")
        except Exception as e :
            q_attr_dict = {}
            self.logger.warning(f"input message error: {e}")
        mid = q_attr_dict.get("mid", "")
        comment = q_attr_dict.get("pre_comment", "")
        comment = _handle_comment(comment)
        weibo_analysis = await self.get_weibo_analysis(mid)
        messages = await self.gen_comment_message(mid, comment, weibo_analysis)
        self.weibo["messages"] = messages


class SixinDialogueServiceV2(SixinDialogueService):

    def __init__(self, pid, weibo, output):
        super().__init__(pid, weibo, output)

        self.simpler_dialogue = SimpleDialogue(pid, weibo)
        self.question_checker = SixinQuestionCheckerV2(self.pid, self.weibo)
        self.question_answer = SixinQuestionAnswerV2(pid, weibo)
        self.sixin_tool = SixinToolV2(self.pid, self.weibo)


class SixinDialogueServiceNoThink(SixinDialogueService):

    def __init__(self, pid, weibo, output):
        super().__init__(pid, weibo, output)

        self.simpler_dialogue = SimpleDialogue(pid, weibo)
        self.question_checker = QuestionChecker(self.pid, self.weibo)
        self.question_answer = QuestionAnswer(pid, weibo)
        self.sixin_tool = SixinToolV2(self.pid, self.weibo)


class OnlineDialogueService(DialogueService):

    async def build_message_conv(self, question, history_list):
        user_id = self.weibo.get("user_id", "")
        conversation_id = self.weibo.get("conversation_id", "")
        session_id = self.weibo.get("session_id", "") or conversation_id
        round_num = len(history_list) // 2 + 1

        # 获取相似对话
        similar_list = []

        # 取历史最近三轮 + 相似对话
        messages_conv = {
            "retrieval_conv": similar_list,
            "history_conv": history_list,
            "cur_round": round_num,
        }
        return messages_conv

    async def chat_stream(self):
        try:
            self.logger.info(f"{self.trace_id} chat_stream start.")
            weibo = self.weibo
            start_time = time.time()

            messages = self.weibo.get("messages", [])
            query, history_list = get_query_and_history(messages)
            query = self.weibo.get("question", query)
            self.weibo['question'] = query
            is_private_message = self.weibo.get("is_private_message", False)

            user_id = weibo.get("user_id", "")
            conversation_id = weibo.get("conversation_id", "")
            ori_conversation_id = weibo.get("ori_conversation_id", "")
            session_id = weibo.get("session_id", "")

            session_id = conversation_id or session_id
            model = '非思考版'
            source_type = weibo.get('source_type', '')
            basemodel = weibo.get('basemodel', '')
            in_time_ms = weibo.get('in_time_ms', 0)
            query_in_time = weibo.get('query_in_time', 0)
            get_history_time = weibo.get('get_history_time', 0)

            # 保存信息
            update_output = weibo.setdefault("update_output", {})
            llm_trace_info = weibo.setdefault("llm_trace_info", [])
            chat_check_info = weibo.setdefault("chat_check_info", {})
            debug_info = weibo.setdefault("debug_info", {})

            debug_info.update({
                "base_info": {
                    "query": query,
                    "model": model,
                    "source_type": source_type,
                    "user_id": user_id,
                    "conversation_id": conversation_id,
                    "session_id": session_id,
                    "is_private_message": is_private_message,
                    "basemodel": basemodel
                },
                "in_time_ms": in_time_ms,
                "query_in_time": query_in_time,
                "get_history_time": get_history_time,
                "all_time_start": start_time,
            })

            chat_check_info.update(debug_info["base_info"])
            self.logger.info(f"{self.trace_id} query {query}, model: {model}")

            # is_query_filter = await query_filter(weibo, self.logger)
            # if is_query_filter:
            #     weibo['special_tips'] = "抱歉，这个问题我暂时无法回答，换个问题试试吧"
            #     weibo['model_filter'] = 'query_filter'
            #     await self.output.output(ready="special_tips", content="", weibo=self.weibo)
            #     return

            messages_conv = await self.build_message_conv(query, history_list)
            self.logger.info(f"{self.trace_id} messages_conv: {json.dumps(messages_conv, ensure_ascii=False)}")
            self.weibo['message_conv'] = messages_conv
            fr_back = FirstRoundBack()
            sec_round_back = FirstRoundBack()

            # 执行可丢弃的协程，设置300ms超时，不影响主流程
            async def run_maybe_ask_intention():
                try:
                    await asyncio.wait_for(
                        self.calc_maybe_ask_intention(user_id=user_id, session_id=session_id,
                                                      conversation_id=ori_conversation_id, query=query,
                                                      messages=messages),
                        timeout=0.3
                    )
                except asyncio.TimeoutError:
                    self.logger.info(f"{self.trace_id} calc_maybe_ask_intention timed out")
                except Exception as e:
                    self.logger.error(f"{self.trace_id} calc_maybe_ask_intention error: {e}")

            await asyncio.gather(
                self.question_checker.run(messages_conv, fr_back, self.output),
                self.question_answer.get_material_task_async(messages_conv),
                run_maybe_ask_intention()
            )

            self.logger.info(f"{self.trace_id} query is_qa: {fr_back.is_qa}")
            if fr_back.is_qa:
                self.weibo["update_output"]["chat_type"] = 1
                await self.question_answer.await_material_task(fr_back, self.output)
                # 并行执行 question_answer.run 和 save_person_search_to_redis
                cur_txt_task = asyncio.create_task(
                    self.question_answer.run(messages_conv, fr_back, sec_round_back, self.output))
                save_person_task = asyncio.create_task(
                    self.save_person_search_to_redis(user_id, session_id, ori_conversation_id))
                await asyncio.gather(cur_txt_task, save_person_task)
                cur_txt = cur_txt_task.result()
            else:
                self.weibo["update_output"]["chat_type"] = 0
                cur_txt = await self.simpler_dialogue.run(messages_conv, sec_round_back, self.output)
                await self.question_answer.cancel_material_task()

            weibo['content'] = cur_txt
            chat_check_info["final_result"] = cur_txt
            self.logger.info(
                f"{self.trace_id} Generate LLM response end. first_think: {json.dumps(fr_back.think, ensure_ascii=False)}, first_content: {json.dumps(fr_back.content, ensure_ascii=False)}, "
                f"second_think: {json.dumps(sec_round_back.think, ensure_ascii=False)}, second_content: {json.dumps(sec_round_back.content, ensure_ascii=False)}")

            # 记忆模块存储
            # debug_info["save_memory_start"] = time.time()
            # await self.save_memory(query, user_id, session_id, sec_round_back.content, messages_conv, cur_txt)
            # debug_info["save_memory_end"] = time.time()

            # 添加日志记录存储时间
            self.logger.info(
                f"{self.trace_id} save memory cost: {debug_info['save_memory_end'] - debug_info['save_memory_start']:.2f} seconds")
            debug_info["all_time_end"] = time.time()
            self.logger.info(f"{self.trace_id} all_debug_time_info: {json.dumps(debug_info, ensure_ascii=False)}")
            self.logger.info(f"{self.trace_id} -------------------------finish----------------------------")
        except Exception as e:
            await self.output.output(ready="error", content="", weibo=self.weibo)
            self.logger.error(
                f"{self.trace_id} weibo:{json.dumps(self.weibo, ensure_ascii=False)} error: {traceback.format_exc()}")