"""短期记忆处理"""
# -*- coding:utf-8 -*-
import json
import time
from datetime import datetime
import re
from typing import List
import asyncio
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from lib.base import Base
from lib.redis_utils import async_redis_client
from lib.aiomcq import mcq_cli
from lib.safe_logger import get_logger
from app.apis.wis_search.utils.summary import get_summary_answer
from app.apis.wis_search.post_process.utils import delete_wbcustomblock


def tokenize(text):
    return ' '.join(jieba.cut(text))

def calculate_similarity(text1, text2):
    text1 = tokenize(text1)
    text2 = tokenize(text2)

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([text1, text2])
    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    return similarity[0][0]


class AsyncSessionMemoryRedis:
    """异步短期记忆保存和读取redis"""

    def __init__(self,max_rounds: int = 50, expire_secs: int = 7 * 24 * 3600):
        self.redis_router = async_redis_client
        self.max_rounds = max_rounds
        self.expire_secs = expire_secs

    def _chat_key(self, user_id: str, session_id: str) -> str:
        return f"wis_multi_dialogue_chat_{user_id}_{session_id}"

    def _session_key(self, user_id: str) -> str:
        return f"wis_multi_dialogue_session_{user_id}"

    def _round_num_key(self, user_id: str, session_id: str) -> str:
        return f"wis_multi_dialogue_round_num_{user_id}_{session_id}"

    async def add_message(self, user_id: str, session_id: str, message: str):
        """
        添加一条对话消息，同时注册会话到 Sorted Set 索引
        """
        redis = self.redis_router.get_redis_server(user_id)
        key = self._chat_key(user_id, session_id)
        session_index_key = self._session_key(user_id)
        now = int(time.time())

        await redis.rpush(key, message)
        await redis.ltrim(key, -self.max_rounds, -1)
        await redis.expire(key, self.expire_secs)
        await redis.zadd(session_index_key, {session_id: now})
        await redis.expire(session_index_key, self.expire_secs)

    async def clear_message(self, user_id: str, session_id: str):
        """
        删除所有会话消息
        """
        redis = self.redis_router.get_redis_server(user_id)
        key = self._chat_key(user_id, session_id)
        session_index_key = self._session_key(user_id)

        # 删除该 session 的所有消息
        await redis.delete(key)

        # 从 session 索引中移除该 session
        await redis.zrem(session_index_key, session_id)

    async def get_round_num(self, user_id, session_id):
        """
        获取对话轮数
        """
        round_num_key = self._round_num_key(user_id, session_id)
        redis = self.redis_router.get_redis_server(user_id)
        round_num = await redis.get(round_num_key)
        if round_num is None:
            round_num = 0
        else:
            round_num = int(round_num)
        return round_num

    async def update_round_num(self, user_id, session_id, round_num):
        """
        更新对话轮数
        """
        round_num_key = self._round_num_key(user_id, session_id)
        redis = self.redis_router.get_redis_server(user_id)
        await redis.set(round_num_key, round_num)
        await redis.expire(round_num_key, self.expire_secs)

    async def get_all_messages(self, user_id: str, session_id: str) -> List[str]:
        """
        获取指定 session 的所有条对话消息
        """
        redis = self.redis_router.get_redis_server(user_id)
        key = self._chat_key(user_id, session_id)
        raw_messages = await redis.lrange(key, 0, -1)
        return raw_messages


class AsyncSessionMemoryProcess(Base):
    """异步短期记忆处理"""

    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo
        self.trace_id = weibo.get("trace_id", "")

    async def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """获取文本对应的向量"""
        return [[] for text in texts]

    async def update_round_num(self, user_id: str, session_id: str, round_num: int):
        """更新对话轮数"""
        error_info = ""
        for _ in range(2):
            try:
                cur_round_num = await AsyncSessionMemoryRedis().get_round_num(user_id, session_id)
                round_num = max(round_num, cur_round_num + 1)
                await AsyncSessionMemoryRedis().update_round_num(user_id, session_id, round_num)
            except Exception as e:
                error_info = e
                self.logger.error(f"{self.trace_id} update_round_num add message error: {e}")
                await asyncio.sleep(0.1)
            else:
                break
        else:
            self.logger.error(f"{self.trace_id} update_round_num final add message error: {error_info}")
        return round_num

    def get_qa_answer(self, question: str, answer: str, round_num: int):
        """获取向量查询文本"""
        qa_answer = f"""第{round_num}次对话，用户的问题是：{question}，回答是：{answer}"""
        return qa_answer

    def get_answer(self, answer: str, round_num: int):
        """获取向量查询文本"""
        res_answer = f"""此为和用户第{round_num}轮对话结果：{answer}"""
        return res_answer

    async def clear_message(self, user_id: str, session_id: str):
        """删除对话信息"""
        error_info = ""
        for _ in range(2):
            try:
                await AsyncSessionMemoryRedis().clear_message(user_id, session_id)
            except Exception as e:
                error_info = e
                self.logger.error(f"{self.trace_id} clear_message error: {e}")
                await asyncio.sleep(0.1)
            else:
                break
        else:
            self.logger.error(f"{self.trace_id} clear_message final add message error: {error_info}")

    async def save_message(self, question: str, user_id: str, session_id: str, answer: str, round_num: int):
        """保存一条对话消息到 redis"""
        llm_trace_info = self.weibo.get("llm_trace_info", [])
        answer = delete_wbcustomblock(answer)
        summary_task = asyncio.create_task(get_summary_answer(self.trace_id, question, answer, llm_trace_info))
        qa_answer = self.get_qa_answer(question, answer, round_num)
        embedding_task1 = asyncio.create_task(self.get_embeddings([question, answer, qa_answer]))

        summary_answer = await summary_task
        qa_summary_answer = self.get_qa_answer(question, summary_answer, round_num)
        embedding_task2 = asyncio.create_task(self.get_embeddings([summary_answer, qa_summary_answer]))

        embeddings1 = await embedding_task1
        embeddings2 = await embedding_task2
        embedding_dict = dict(zip(["question", "answer", "qa_answer", "summary_answer", "qa_summary_answer"], embeddings1 + embeddings2))

        message = {
            "round_num": round_num,
            "question": question,
            "answer": answer,
            "summary_answer": summary_answer,
            "embeddings": embedding_dict,
            "time": datetime.now().strftime("%Y年%m月%d日 %H:%M:%S")
        }
        error_info = ""
        for _ in range(2):
            try:
                await AsyncSessionMemoryRedis().add_message(user_id, session_id, json.dumps(message, ensure_ascii=False))
            except Exception as e:
                error_info = e
                self.logger.error(f"{self.trace_id} save_message add message error: {e}")
                await asyncio.sleep(0.1)
            else:
                break
        else:
            self.logger.error(f"{self.trace_id} save_message final add message error: {error_info}")


    async def get_similarity_session(self, question: str, user_id: str, session_id: str, round_num: int):
        """
        获取 session 中与 query 相似的历史对话
        """
        threshold = 0.1
        all_value_list = await AsyncSessionMemoryRedis().get_all_messages(user_id, session_id)
        self.logger.info(f"{self.trace_id} get_similarity_session all_value_list: {json.dumps(all_value_list, ensure_ascii=False)}")
        total_similar_list = []
        round_set = set()
        for _, value in enumerate(all_value_list):
            try:
                message = json.loads(value)
                cur_round_num = message.get("round_num", 0)
                if cur_round_num >= round_num - 6:
                    continue
                if cur_round_num in round_set:
                    # 避免重复轮次对话
                    continue
                round_set.add(cur_round_num)
                cur_question = message.get("question", "")
                cur_answer = message.get("answer", "")
                cur_summary_answer = message.get("summary_answer", "")


                question_similar = calculate_similarity(question, cur_question)
                assistant_similar = calculate_similarity(question, self.get_answer(cur_answer, cur_round_num))
                summary_similar = calculate_similarity(question, self.get_answer(cur_summary_answer, cur_round_num))

                cur_similar = max(question_similar, assistant_similar, summary_similar)

                if cur_similar > threshold:
                    message['similar_score'] = cur_similar
                    total_similar_list.append(message)

            except Exception:
                continue

        # 按照相似度排序（从大到小）
        total_similar_list.sort(key=lambda item: item['similar_score'], reverse=True)
        total_similar_list = total_similar_list[:3]
        self.logger.info(f"{self.trace_id} total_similar_list: {total_similar_list}")

        # 如果只需要返回最相似的 session（3组）
        if total_similar_list:
            total_similar_list.sort(key=lambda item: item['round_num'], reverse=False)
            flattened_similar_list = []
            for item in total_similar_list:
                flattened_similar_list.append({'role': 'user', 'content': item.get("question", "")})
                flattened_similar_list.append({'role': 'assistant', 'content': item.get("summary_answer", "") or item.get("answer", "")})
            return flattened_similar_list

        return []

class UserPersona(Base):
    persona_queue = mcq_cli(domain="queue.search.weibo.com", port=11233)

    def __init__(self, pid, weibo):
        super().__init__(pid)
        self.weibo = weibo

    async def run(self, data):
        await self.persona_queue.set("wis_dialogue_persona", json.dumps(data))