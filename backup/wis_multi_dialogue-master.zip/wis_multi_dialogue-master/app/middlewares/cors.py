from starlette.middleware.cors import CORSMiddleware

from fastapi import FastAPI


def init_middleware(app: FastAPI) -> None:
    # Set all CORS enabled origins
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
