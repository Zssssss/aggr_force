# -*- coding:utf-8 -*-
import asyncio
import random
import sys
import traceback
import multiprocessing
import signal
from setproctitle import setproctitle
import threading
from app.apis.wis_search.io.io import mock_input, mock_output, Input, Output, TestOutput
from app.apis.wis_search.services_v2 import DialogueService, SixinDialogueService, WhiteboardDialogueService, \
    SixinDialogueServiceV2
from app.dialogue import OnlineChat
from lib.base import Base
from lib.safe_logger import get_logger

logger = get_logger("log/wis_dialogue.log", "MAIN")

cmd_line = " ".join(sys.argv)
num_processes = 10
num_tasks     = 10
MAX_INPUT_DELAY = 8

class Chat(Base):
    def __init__(self, pid, shutdown_flag):
        super().__init__(pid)
        self.shutdown_flag = shutdown_flag
        # self.input = Input(pid)
        self.output = TestOutput(pid)
        # self.storge = KafkaStorage(pid)

    async def run(self, weibo):
        try:
            chat_service = SixinDialogueServiceV2(self.pid, weibo, self.output)
            await chat_service.chat_stream()
            print(weibo)
        except Exception as e:
            self.logger.error(f"error:{e} msg:{traceback.format_exc()}")



async def main(model):
    chat = OnlineChat("test", threading.Event())
    await chat.run(model)

if __name__ == '__main__':

    # data = {'tid': '68d5d05fea75dadec9725885858c6b3d', 'completion_option': '{"use_deep_think":1}', 'user_id': '6366345865', 'high_level': 10, 'stream_output': 1, 'conversation_id': '', 'question': '你好呀', 'in_time': 1753069753, 'q_attr': '{"new_high_level":10}', 'in_time_ms': 1753069753.793, 'ab_test': '', 'version': '2025-07-21 11:49:13.937000-9044', 'messages': [{'role': 'user', 'content': '你好'}], 'session_id': f'b5b3811d-7858-479a-8455-{random.randint(999, 9999)}', 'prompt_scene': 'chat', 'trace_id': '2025-07-21 11:49:13.937000-9044', 'model': '思考版', 'source_type': 'client', 'ori_question': '你是谁', 'ori_conversation_id': 'con_98893c7d-d077-45ed-b4a3-8ac2f4643ecc'}
    model = "deepseek_last_follow"
    asyncio.run(main(model))