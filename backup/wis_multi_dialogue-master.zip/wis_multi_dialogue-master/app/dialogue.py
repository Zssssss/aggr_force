# -*- coding:utf-8 -*-
import asyncio
import sys
import traceback
import multiprocessing
import signal
from setproctitle import setproctitle
import threading
from app.apis.wis_search.io.io import mock_input, mock_output, Input, Output, OnlineInput, OnlineOutput
from app.apis.wis_search.services_v2 import DialogueService, SixinDialogueService, SixinDialogueServiceV2, \
    SixinDialogueServiceNoThink
from app.apis.wis_search.storage.kafka_storage import KafkaStorage
from app.apis.wis_search.storage.redis_storage import RedisStorage
from lib.base import Base
from lib.safe_logger import get_logger

logger = get_logger("log/wis_dialogue.log", "MAIN")

cmd_line = " ".join(sys.argv)
num_processes = 10
num_tasks     = 100
online_num_tasks = 10
MAX_INPUT_DELAY = 8


class Chat(Base):
    def __init__(self, pid, shutdown_flag):
        super().__init__(pid)
        self.shutdown_flag = shutdown_flag
        self.input = Input(pid)
        self.output = Output(pid)
        self.storages = [KafkaStorage(pid), RedisStorage(pid)]

    async def run(self, model):

        delay = 0
        while not self.shutdown_flag.is_set():
            weibo = await self.input.input(model)
            if weibo is None:
                delay = min(delay + 1, MAX_INPUT_DELAY)
                await asyncio.sleep(delay)
                continue
            delay = 0
            try:
                chat_service = DialogueService(self.pid, weibo, self.output)
                if weibo.get("prompt_scene") == "private_chat" or weibo.get("send_from") == "comment":
                    weibo["source_type"] = "private_chat"
                    # 二期
                    p_msg_smart_search_enable = weibo.get("p_msg_smart_search_enable", 0)
                    if p_msg_smart_search_enable == 1:
                        basemodel = weibo.get('basemodel', '')
                        if basemodel in ['实验组1', '实验组2', '实验组3', '实验组4', '实验组5']:
                            chat_service = SixinDialogueServiceNoThink(self.pid, weibo, self.output)
                        else:
                            chat_service = SixinDialogueServiceV2(self.pid, weibo, self.output)
                    else:
                        chat_service = SixinDialogueService(self.pid, weibo, self.output)
                await chat_service.chat_stream()
                await asyncio.gather(*[storage.run(weibo=weibo) for storage in self.storages])
            except Exception as e:
                self.logger.error(f"error:{e} msg:{traceback.format_exc()}")

        await asyncio.gather(
            self.input.close(),
            self.output.close(),
            asyncio.gather(*[storage.close() for storage in self.storages])
        )

class OnlineChat(Chat):
    def __init__(self, pid, shutdown_flag):
        super().__init__(pid, shutdown_flag)
        self.shutdown_flag = shutdown_flag
        self.input = OnlineInput(pid)
        self.output = OnlineOutput(pid)
        self.storages = [KafkaStorage(pid), RedisStorage(pid)]


async def async_main(pid, shutdown_flag):
    chats = [Chat(pid, shutdown_flag) for _ in range(num_tasks)]
    online_chats = [OnlineChat(pid, shutdown_flag) for _ in range(online_num_tasks)]
    tasks = [asyncio.create_task(chat.run("chat")) for chat in chats]
    tasks.extend([asyncio.create_task(online_chat.run("deepseek_last_follow")) for online_chat in online_chats])

    try:
        while not shutdown_flag.is_set():
            await asyncio.sleep(5)
    except asyncio.CancelledError:
        print(f"[{pid}] 接收到取消任务请求，准备退出")
        logger.warning(f"[{pid}] 接收到取消任务请求，准备退出")
    finally:
        # for task in tasks:
        #     if not task.done():
        #         task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        print(f"pid: [{pid}] 所有任务已结束，协程退出")
        logger.warning(f"pid: [{pid}] 所有任务已结束，协程退出")

def main(pid, shutdown_flag):
    setproctitle(cmd_line + f" {pid}")
    asyncio.run(async_main(pid, shutdown_flag))


def signal_handler(sig, frame, shutdown_flag):
    """主进程中的信号处理函数"""
    print(f"收到信号 {sig}, 开始优雅退出...")
    logger.warning(f"收到信号 {sig}, 开始优雅退出...")
    shutdown_flag.set()  # 设置事件，通知子进程退出

def is_debug_mode():
    return sys.gettrace() is not None

if __name__ == '__main__':

    if is_debug_mode():
        # debug时使用multiprocessing.Event会卡死
        shutdown_flag = threading.Event()
    else:
        shutdown_flag = multiprocessing.Manager().Event()

    signal.signal(signal.SIGINT, lambda sig, frame: signal_handler(sig, frame, shutdown_flag))
    signal.signal(signal.SIGTERM, lambda sig, frame: signal_handler(sig, frame, shutdown_flag))
    setproctitle(cmd_line + " dialogue-main")

    print(f"num_processes: {num_processes}")
    pool = multiprocessing.Pool(processes=num_processes)
    for i in range(num_processes):
        processId = f"dialogue-%03d" % i
        pool.apply_async(func=main, args=(processId, shutdown_flag), )
    pool.close()
    pool.join()


    # asyncio.run(async_main("test", shutdown_flag))