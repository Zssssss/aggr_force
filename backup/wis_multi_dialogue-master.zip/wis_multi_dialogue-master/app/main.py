"""
    FastAPI 应用程序
"""
import uvicorn
from fastapi import FastAPI
from lib.safe_logger import get_logger
from app.routes import init_routers

logger = get_logger("log/wis_search_main.log", "MAIN")


class Application(FastAPI):
    """
    FastAPI 应用程序
    """
    def __init__(self):
        super().__init__()

        # 初始化 App
        self.init_app()

    def init_app(self):
        """
        初始化 App
        """
        # 注册中间件 for ..
        # jwt.init_middleware(self)
        # mysql.init_middleware(self)
        # cors.init_middleware(self)

        # 注册路由
        init_routers(self)
        self.dependencies = []


app = Application()



if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
