#!/bin/bash
source .venv/bin/activate
uv sync --upgrade-package zsmaterial
echo "starting gunicorn"
export WIS_MATERIAL_DEBUG_LOG=log
gunicorn -c gunicorn.conf app.main:app