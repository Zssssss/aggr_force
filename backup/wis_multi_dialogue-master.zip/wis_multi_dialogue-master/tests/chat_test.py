import glob
import asyncio
import multiprocessing
import signal
import random
import datetime
import json
from typing import Dict, Any
import pandas as pd

from app.apis.wis_search.io.io import TestOutput
from app.apis.wis_search.services_v2 import DialogueService

PROCESS_NUM = 5
MODEL = "思考版"
SEMAPHORE = asyncio.Semaphore(PROCESS_NUM)



def export_dialogue_dict_to_excel(data: Dict[str, Dict[str, Any]], output_path: str = "dialogues_export.xlsx") -> str:
    """
    将嵌套对话字典导出为 Excel 文件。
    
    参数:
        data: 形如 {"dialogue_0_query_0": {...}, ...} 的嵌套字典
        output_path: Excel 文件保存路径，默认当前目录

    返回:
        文件路径字符串
    """
    flat_data = []
    for key, value in data.items():
        row = {'id': key}
        # 将复杂类型转换为 JSON 字符串，便于 Excel 显示
        for k, v in value.items():
            if isinstance(v, (dict, list)):
                row[k] = json.dumps(v, ensure_ascii=False)
            else:
                row[k] = v
        flat_data.append(row)

    df = pd.DataFrame(flat_data)
    df.to_excel(output_path, index=False)
    print(f"对话数据已导出到 {output_path}")
    return output_path

def signal_handler(sig, frame, shutdown_flag):
    """主进程中的信号处理函数"""
    print(f"收到信号 {sig}, 开始优雅退出...")
    shutdown_flag.set()  # 设置事件，通知子进程退出


def load_dialogue_file():
    file_pattern = "./tests/data/dialogue_*.txt"
    matched_files = glob.glob(file_pattern)

    dialogue_list = []
    for file in matched_files:
        cur_list = []
        with open(file, 'r', encoding='utf-8') as f:
            for line in f:
                dialogue = line.strip()
                if dialogue:  # 忽略空行
                    cur_list.append(dialogue)
        if cur_list:
            dialogue_list.append(cur_list)
    return dialogue_list


def generate_numeric_id(length=33):
    return ''.join(random.choices('0123456789', k=length))


async def single_dialogue(index, dialogue, all_result):
    print(f"starting dialogue {index}: {dialogue}")
    async with SEMAPHORE:
        history_messages = []
        user_id = generate_numeric_id()
        sessionID = f"{user_id}_qgstest_{index}"
        for query_index, query in enumerate(dialogue):
            query = query.strip()
            cur_index = f"dialogue_{index}_query_{query_index}"
            trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
            print(f"trace_id: {trace_id}, Starting {cur_index}: {query}")
            if query:
                history_messages.append({"role": "user", "content": query})
                data = {
                    
                    "user_id": user_id,
                    "session_id": sessionID,
                    "messages": history_messages,
                    "model": MODEL,
                    "source_type": "client",
                    "chat_check_info": {
                        "cur_dialogue_id": index,
                        "cur_query_id": query_index,
                    }
                }

                pid = "tests"
                output = TestOutput("tests")
                await DialogueService(pid, data, output).chat_stream()
                history_messages.append({"role": "assistant", "content": data["chat_check_info"].get("final_result", "")})
                all_result[cur_index] = data["chat_check_info"]
                print(f"trace_id: {trace_id}, end {cur_index}: {query}")

async def main(dialogue_list):
    # Add logic to handle dialogues
    all_result = {}
    tasks = [single_dialogue(index, dialogue, all_result) for index, dialogue in enumerate(dialogue_list)]
    await asyncio.gather(*tasks)
    export_dialogue_dict_to_excel(all_result)


if __name__ == '__main__':

    dialogue_list = load_dialogue_file()

    shutdown_flag = multiprocessing.Manager().Event()
    signal.signal(signal.SIGINT, lambda sig, frame: signal_handler(sig, frame, shutdown_flag))
    signal.signal(signal.SIGTERM, lambda sig, frame: signal_handler(sig, frame, shutdown_flag))

    asyncio.run(main(dialogue_list))