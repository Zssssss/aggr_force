MULTIMODAL_DEBUG = False

# ============== 场景上下文开关 ==============
USE_SIMILAR_HISTORY = {
    "qa_check": {"default": True, "white_board": True, "client": True, "private_chat": True},  # 判断聊天问答开关
    "modified": {"default": True},  # 修改式问答开关
    "rewrite": {"default": True},  # 重写式问答开关
    "simple_chat": {"default": True},  # 简单聊天开关
    "qa_chat": {"default": True},  # 问答聊天开关
}
