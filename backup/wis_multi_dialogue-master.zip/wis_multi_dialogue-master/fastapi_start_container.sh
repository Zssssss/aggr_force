#!/bin/bash


set -x

source /etc/profile

APP_NAME=wis_multi_dialogue
DOCKER_NAME=registry.api.weibo.com/wbsearch/wis_multi_dialogue:v1.2


docker pull $DOCKER_NAME
docker stop -t 100 $APP_NAME
docker rm -v $APP_NAME

docker run --restart=always --name $APP_NAME  \
--init \
--env SEARCH_ENV_ECI=$SEARCH_ENV_ECI \
--env SEARCH_ENV_IP=$SEARCH_ENV_IP \
--env SEARCH_ENV_IDC=$SEARCH_ENV_IDC \
--env SEARCH_ENV_GROUP=$SEARCH_ENV_GROUP \
--env SEARCH_ENV_ENV=online  \
-v /data1/minisearch/upload/LLM_TASK/wis_multi_dialogue:/data1/minisearch/upload/LLM_TASK/wis_multi_dialogue  \
-v /data1/minisearch/upload/token:/data1/minisearch/upload/token  \
-v /etc/passwd:/etc/passwd  \
-v /etc/shadow:/etc/shadow \
-v /etc/group:/etc/group \
-p 8083:8083 \
-d $DOCKER_NAME /bin/bash /data1/minisearch/upload/LLM_TASK/wis_multi_dialogue/start.sh