# -*- coding:utf-8 -*-
import asyncio
import json
import argparse
import os
from typing import Dict, Any

from plugins.llm.deepseek import DeepSeekLLM, StreamDeepSeekLLM
from plugins.llm.mid_llm import MidLLM
from plugins.llm.xiaoyi_stream_llm import XiaoYiStreamLLM
from plugins.output.output import TestOutput

TEST_DATA_DIR = 'tests/conf/test_cases'

class TestRunner:
    def __init__(self):
        self.output = TestOutput('test_runner')
        
    async def run_test_case(self, test_case: Dict[str, Any]):
        """执行单个测试用例"""
        data = test_case["data"]
        pid = f"test_{test_case['name']}"
        
        # 根据配置选择LLM实现
        llm_map = {
            "deepseek": DeepSeekLLM,
            "deepseek_verification": MidLLM,
            "deepseek_stream" : StreamDeepSeekLLM
        }
        llm_class = llm_map.get(data["llm_name"], DeepSeekLLM)
        llm = llm_class(data, self.output, pid)
        
        try:
            result = await llm.run()
            if result:
                self._preview_result(result["result"], test_case['name'])
                return True
            else:
                print(f"结果为空，可能获取锁失败，换一个query试试")
        except Exception as e:
            print(f"❌ Test failed: {test_case['name']} - {str(e)}")
            return False

    def _preview_result(self, result, case_name):
        # 生成Markdown
        output_dir = 'tests/output'
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        preview_path = os.path.join(output_dir, f'_preview_{case_name}.md')
        with open(preview_path, 'w', encoding='utf-8') as f:
                f.write(result)
        print(f'✅ Markdown预览已在tests/output/_preview_{case_name}.md中生成，鼠标右键单击open preview')

async def main():
    # 解析命令行参数
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", help="Run specific test case by name")
    args = parser.parse_args()

    # 加载测试数据
    test_data = {}
    try:
        for filename in os.listdir(TEST_DATA_DIR):
            if filename.endswith('.json'):
                filepath = os.path.join(TEST_DATA_DIR, filename)
                with open(filepath, 'r', encoding='utf-8') as f:
                    case_data = json.load(f)
                    case_name = os.path.splitext(filename)[0]
                    test_data[case_name] = case_data
    except FileNotFoundError:
        print(f"Test data directory not found: {TEST_DATA_DIR}")
        return
    
    runner = TestRunner()
    
    if args.case:
        # 运行指定用例
        if args.case in test_data:
            await runner.run_test_case(test_data[args.case])
        else:
            print(f"Test case '{args.case}' not found")
    else:
        # 运行所有用例
        results = []
        for case_name, test_case in test_data.items():
            results.append(await runner.run_test_case(test_case))
        
if __name__ == '__main__':
    # case配置目录：tests/conf/test_cases.json
    # 指定case运行：/data1/jilin5/envs/piccolo-base/bin/python -m tests.test_runner --case ds_stream
    # 运行全部case：/data1/jilin5/envs/piccolo-base/bin/python -m tests.test_runner
    asyncio.run(main())