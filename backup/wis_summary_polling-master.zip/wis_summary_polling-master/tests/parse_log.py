#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project : wis_summary_polling 
# @file : parse_log.py
# @Author : binhe
# @time : 2024/11/22 11:09
# @Software: PyCharm
import sys
import random

import pandas as pd


def get_mid_url(x):
    if isinstance(x, list):
        x = ",".join(x)
    return "http://scout.s.weibo.com/view/regular/blogdetail?list1=%s" % x


def parse_log(file):
    lineflag = "run_unittest:  39"
    tdatas = []
    for i in open(file):
        if lineflag not in i:
            continue
        i = i.strip().split("weibo:", 1)[-1]
        try:
            v = eval(i)
            if v:
                tdatas.append(v)
        except Exception:
            pass
    tdatas_df = pd.DataFrame(tdatas)
    tdatas_df["mid_url"] = tdatas_df["mid_list"].map(lambda x: get_mid_url(x))
    print("parse_log_data:{}\tfile:{}".format(tdatas_df.shape, file))
    if "knowledge" in tdatas_df.columns:
        tdatas_df["knowledge_num"] = tdatas_df["knowledge"].apply(
            lambda x: 0 if str(x) in ['', 'nan', 'None'] else len(x.split("\n\n")))
        tdatas_df["knowledge_flag"] = tdatas_df["knowledge"].apply(lambda x: 0 if str(x) in ['', 'nan', 'None'] else 1)
        print("knowledge_num:{}".format(tdatas_df["knowledge_num"].value_counts()))
        print("knowledge_flag:{}".format(tdatas_df["knowledge_flag"].value_counts()))
        print("knowledge_label:{}".format(tdatas_df.query('knowledge_flag > 0')["label"].value_counts()))
    if "search_kwords" in tdatas_df.columns:
        tdatas_df["search_kwords_num"] = tdatas_df["search_kwords"].apply(
            lambda x: 0 if str(x) in ['', 'nan', 'None'] else len(x))
        print("search_kwords_num:{}".format(tdatas_df["search_kwords_num"].value_counts()))
    return tdatas_df


if __name__ == "__main__":
    # /data1/minisearch/upload/LLM_TASK/wis_summary_polling/log/
    file = "../log/run_unittest.log"
    if len(sys.argv) >= 2:
        file = sys.argv[1]
    outfile = "compare_test_result.%s.xlsx" % (random.randint(1000, 9999))
    if len(sys.argv) >= 3:
        outfile = sys.argv[2]
    data = parse_log(file)
    data.to_excel(outfile, index=False)
    print("outfile:{}".format(outfile))
