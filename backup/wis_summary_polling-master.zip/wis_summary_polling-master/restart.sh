#!/bin/bash

# 默认的信号类型是 SIGINT (kill -2)
SIGNAL_TYPE=-2

PIDS=$(pgrep -f "deepseek")

if [ -z "$PIDS" ]; then
    echo "No processes with 'deepseek' found."
    # exit 1
fi

echo "Found the following processes with 'deepseek':"
echo "$PIDS"

# 判断是否传递了 -f 参数
if [ "$1" = "-f" ]; then
    SIGNAL_TYPE=-9  # 设置为 SIGKILL (kill -9)
    echo "Force kill enabled. Using kill -9."
fi

echo "Sending SIGINT (kill $SIGNAL_TYPE) to the processes..."
for PID in $PIDS; do
    kill $SIGNAL_TYPE "$PID"
    echo "kill $SIGNAL_TYPE $PID"
done


for PID in $PIDS; do
    while kill -0 "$PID" 2>/dev/null; do
        echo "Waiting for process $PID to exit..."
        sleep 1
    done
done

### start cron
service cron start
cp -f cron /var/spool/cron/root && chmod -R 0644 /var/spool/cron/root
crontab /var/spool/cron/root

### start discovery
chmod +x ./tools/discovery/discovery-agent
./tools/discovery/discovery-agent -c ./tools/discovery/agent.yaml &

### start summary
echo "All 'deepseek' processes have been terminated. restarting..."
python -m bin.run_summary > online.log 2>&1