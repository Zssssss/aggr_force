"""视频后处理"""
# -*- coding:utf-8 -*-
import json
import re
import binascii
import numpy as np
from datasketch import MinHash
from conf.config import MULTIMODAL_DEBUG
from lib.safe_convert import convert_to_int, convert_to_float
from plugins.post_process.picture_process import get_size_from_pid, get_pic_url

# ============= 判断视频相似度 =============
def update_hash_list(hash_list: list):
    """更新hash列表,去除纯色图片"""
    new_hash_list = []
    for hash_item in hash_list:
        if hash_item.count('0') == len(hash_item):
            continue
        new_hash_list.append(hash_item)
    return new_hash_list

def hamming_distance_hex(hex_str1, hex_str2):
    # 校验输入合法性
    if len(hex_str1) != len(hex_str2):
        return None

    # 转换为字节序列
    hex_str1 = hex_str1.encode('utf-8').hex()
    hex_str2 = hex_str2.encode('utf-8').hex()
    bytes1 = bytes.fromhex(hex_str1)
    bytes2 = bytes.fromhex(hex_str2)

    # 计算异或后的汉明距离
    return sum(bin(b1 ^ b2).count('1') for b1, b2 in zip(bytes1, bytes2))

def hex_to_minhash(hex_str):
    """将字符串还原为 MinHash 对象"""
    # 去除方括号并分割十六进制字符串
    hex_values = hex_str.strip("[]").split(",")
    int_values = [int(x, 16) for x in hex_values]
    m = MinHash(num_perm=8)
    m.hashvalues = np.array(int_values, dtype=np.uint32)
    return m

def check_video_similarity(
    video_1: str,
    video_2: str,
    v_phash_1: list,
    v_phash_2: list,
    video_voice_pinying_1: str,
    video_voice_pinying_2: str,
    log_func
):    
    """计算视频相似度"""
    v_phash_1 = update_hash_list(v_phash_1)
    v_phash_2 = update_hash_list(v_phash_2)
    for i in range(len(v_phash_1)):
        for j in range(len(v_phash_2)):
            hamming_distance = hamming_distance_hex(v_phash_1[i], v_phash_2[j])
            if hamming_distance is not None and hamming_distance < 16:
                return True

    try:
        if video_voice_pinying_1 and video_voice_pinying_2:
            v_voice_minhash_1 = hex_to_minhash(video_voice_pinying_1)
            v_voice_minhash_2 = hex_to_minhash(video_voice_pinying_2)
            if v_voice_minhash_1.jaccard(v_voice_minhash_2) >= 0.15:
                return True
    except:
        if log_func:
            log_func("hex_to_minhash error")
    return False

# ============= 视频后处理 =============
def is_valid_video(video_url, duration, avg, highest_quality_label):
    if not video_url:
        return False, "0100"
    if duration <= 10:
        return False, "0101"
    try:
        is_valid_avg = (avg > 0.4) if avg is not None else True
    except:
        is_valid_avg = True
    try:
        is_valid_label = int(highest_quality_label.split('p')[0]) > 480 if highest_quality_label else True
    except:
        is_valid_label = True
    if not is_valid_avg and not is_valid_label:
        return False, "0102"
    return True , "0111"

def check_is_valid_video(cur_video_dict, log_func=None):
    """从引文中提取所有视频url"""
    video_url = cur_video_dict.get('url', '')
    high_quality_video = cur_video_dict.get('high_quality_video', "0")
    v_phash = cur_video_dict.get('v_phash', [])
    highest_quality_label = cur_video_dict.get('highest_quality_label')
    avg =  cur_video_dict.get('avg')
    video_voice_pinying = cur_video_dict.get('video_voice_pinying', "")
    waic_video_dup_finger = cur_video_dict.get('waic_video_dup_finger', "")
    has_video_voice_pinying = True if video_voice_pinying and video_voice_pinying!="" else False
    img_ori_url = cur_video_dict.get('image', {}).get('url', '')
    img_pid = cur_video_dict.get('image', {}).get('pid', '')
    if not img_pid and img_ori_url:
        img_pid = img_ori_url.split('/')[-1].split(".")[0]
    img_h, img_w = get_size_from_pid(img_pid)
    img_url = get_pic_url(img_pid) if len(img_pid) > 21 else ""
    duration = float(cur_video_dict.get('duration', -1))
    video_index = cur_video_dict.get('video_index', 0)
    if MULTIMODAL_DEBUG:
        if not video_url or duration == -1 or not v_phash or not img_url:
            if log_func:
                log_func(f"<物料信息不全>视频:{video_url}，duration:{duration}，phash:{v_phash}，图片:{img_url}，不符合要求")
    # 添加其他信息
    new_video_url = f'<首视频特征：video_url:{video_url}, high_quality_video:{high_quality_video}, highest_quality_label:{highest_quality_label}, avg:{avg}, duration:{duration}, img_h:{img_h}, img_w:{img_w}, v_phash:{v_phash}, has_video_voice_pinying:{has_video_voice_pinying}, img_url:{img_url}, video_index:{video_index}, waic_video_dup_finger:{waic_video_dup_finger}>'
    
    is_valid, filter_str = is_valid_video(video_url, duration, avg, highest_quality_label)
    if log_func and not is_valid:
        log_func(f"{new_video_url}，不符合要求, filter_str:{filter_str}")
    return {"is_valid": is_valid, "filter_str": filter_str, "video_log_info": new_video_url}

def check_video_is_similar(video_idx, video_url, v_phash, waic_video_dup_finger, video_voice_pinying, ready_pid_dict, log_func=None):
    """检查视频是否重复"""
    for cur_idx, cur_pid_dict in ready_pid_dict.items():
        if cur_pid_dict["url"] == video_url:
            if log_func:
                log_func(f"视频索引{video_idx}的视频url:{video_url},与索引{cur_idx}的视频url:{cur_pid_dict['url']},重复")
            return True
        if not cur_pid_dict["flag"]:
            continue
        # 如果waic_video_dup_finger不为空，且与cur_pid_dict["waic_video_dup_finger"]相同，则打印日志，并返回True
        if waic_video_dup_finger and cur_pid_dict["waic_video_dup_finger"] == waic_video_dup_finger:
            if log_func:
                log_func(f"视频索引{video_idx}的视频url:{video_url},与索引{cur_idx}的视频url:{cur_pid_dict['url']},waic_video_dup_finger:{waic_video_dup_finger}, 视频分组重复")
            return True
        # 视频相似度判断
        if check_video_similarity(video_idx, cur_idx, v_phash, cur_pid_dict.get("v_phash", []), video_voice_pinying, cur_pid_dict.get("video_voice_pinying", ''), log_func):
            if log_func:
                log_func(f"视频索引{video_idx}的视频url:{video_url},与索引{cur_idx}的视频url:{cur_pid_dict['url']},相似度过高,重复")
            return True

    return False

def get_video_dict(index, cur_mid, cur_video_dict, mid_feature_dict, ready_pid_dict, is_caibian=False, log_func=None):
    """获取视频字典"""
    mix_media_ids = mid_feature_dict.get(cur_mid, {}).get("mix_media_ids", [])

    user_name = mid_feature_dict.get(cur_mid, {}).get('user_name', '')
    user_avatar = mid_feature_dict.get(cur_mid, {}).get('user_avatar', '')
    verify_type = convert_to_int(mid_feature_dict.get(cur_mid, {}).get('verified_type', -1), -1)
    hit_score_new = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("hit_score_new", "0"))
    hit_score_final = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("hit_score_final", "0"))
    doc_score = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("doc_score", "0"))
    is_top_up = mid_feature_dict.get(cur_mid, {}).get("is_top_up", False)
    is_media_user = mid_feature_dict.get(cur_mid, {}).get("is_media_user", False)
    is_blue = 1 <= verify_type <= 7

    video_url = cur_video_dict.get('url', '')
    img_ori_url = cur_video_dict.get('image', {}).get('url', '')
    img_pid = cur_video_dict.get('image', {}).get('pid', '')
    v_phash = cur_video_dict.get('v_phash', [])
    waic_video_dup_finger = cur_video_dict.get('waic_video_dup_finger', "")
    video_voice_pinying = cur_video_dict.get('video_voice_pinying', [])
    if not img_pid and img_ori_url:
        img_pid = img_ori_url.split('/')[-1].split(".")[0]
    h, w = get_size_from_pid(img_pid)
    img_url = get_pic_url(img_pid) if len(img_pid) > 21 else ""
    video_idx = f"video_{cur_mid}_{index}"

    user_info = f'<span class="vator" style="display: none;background: url({user_avatar}) no-repeat;background-size: contain;"></span><span class="nick" style="display: none">{user_name}</span>'

    if mix_media_ids:
        cur_scheme = f"sinaweibo://multimedia?mix_mid={cur_mid}&mix_index={index}"
    else:
        cur_scheme = f"sinaweibo://video/vvs?mid={cur_mid}"
    cur_video_dict_new = {"type": "v", "scheme": cur_scheme, "img": img_url, "cur_mid": cur_mid,
                    "user_name": user_name, "user_avatar": user_avatar, "h": h, "w": w, "vtype": verify_type, "video_url": video_url,
                    "hit_score_new": hit_score_new, "hit_score_final": hit_score_final, "doc_score": doc_score, "img_pid": img_pid,
                    "similar_info": {"v_phash": v_phash, "waic_fea": waic_video_dup_finger}}
    if MULTIMODAL_DEBUG:
        cur_video_str = f'<video src="{video_url}">'
    else:
        cur_video_str = f'<div data-type="v" data-scheme="{cur_scheme}"><span class="arrow"></span>{user_info}<img src="{img_url}" data-width={h} data-height={w}></div>'
    cur_video_all_info = {"img_video_str": cur_video_str, "img_video_idx": video_idx, "img_video_dict": cur_video_dict_new, "is_selected": is_caibian,
                        "is_media_user": is_media_user, "is_blue": is_blue, "is_top_up": is_top_up}
    # 判断视频是否需要采编
    check_data = check_is_valid_video(cur_video_dict, log_func)
    cur_video_all_info["video_log_info"] = check_data["video_log_info"]
    if not check_data["is_valid"] and not is_caibian:
        cur_video_all_info["final_check"] = False
        if log_func:
            log_func(f"check_video_is_valid, video_idx={video_idx}, img_pid={img_pid}, check_data={json.dumps(check_data, ensure_ascii=False)}")
        return cur_video_all_info
    # 判断是否和已经采编的视频重复
    if check_video_is_similar(video_idx, video_url, v_phash, waic_video_dup_finger, video_voice_pinying, ready_pid_dict["video_ready"], log_func=log_func):
        if video_idx not in ready_pid_dict["video_ready"]:
            ready_pid_dict["video_ready"][video_idx] = {"url": video_url, "v_phash": v_phash, "waic_video_dup_finger": waic_video_dup_finger, "video_voice_pinying": video_voice_pinying, "flag": False}
        cur_video_all_info["final_check"] = False
        return cur_video_all_info
    ready_pid_dict["video_ready"][video_idx] = {"url": video_url, "v_phash": v_phash, "waic_video_dup_finger": waic_video_dup_finger,"video_voice_pinying": video_voice_pinying, "flag": True}
    cur_video_all_info["final_check"] = True
    return cur_video_all_info
