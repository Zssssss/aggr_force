"""卡片内容展示"""
# -*- coding:utf-8 -*-
import re
import json
import emoji

from plugins.post_process.utils import split_think_and_content
from plugins.post_process.md_special_format_process import parse_markdown_code_blocks
from plugins.post_process.picture_process import check_img_is_similar
from plugins.post_process.video_process import check_video_is_similar


def get_clean_content(content: str) -> str:
    """获取卡片内容"""
    _, content = split_think_and_content(content)
    content = remove_wb_custom_block(content)
    content = remove_media_block(content)
    content = remove_md_spe_format(content)
    return content.strip()

def remove_md_spe_format(content: str) -> str:
    """去除 markdown 特殊格式"""
    result = parse_markdown_code_blocks(content)
    for _, blocks in result.items():
        for _, block in enumerate(blocks):
            ori_text = block['ori_text']
            content = content.replace(ori_text, "")
    return content

def remove_wb_custom_block(text: str) -> str :
    """匹配并删除所有 ```wbCustomBlock{...}``` 块（支持跨行）"""
    wb_pattern = re.compile(r'```wbCustomBlock(\{.*?\})```', re.DOTALL)
    for match in wb_pattern.finditer(text):
        ori_text = match.group(0)
        wb_block = match.group(1)
        try:
            wb_data = json.loads(wb_block)
            wb_type = wb_data.get("type", "")
            if wb_type == "midquoted":
                wb_name = wb_data.get("data", "").get("name", "")
                if wb_name:
                    text = text.replace(ori_text, f"@{wb_name}")
        except:
            pass
    cleaned_text = wb_pattern.sub("", text)
    return cleaned_text

def remove_media_block(text: str) -> str:
    """匹配并删除所有 <media-block>...</media-block> 块（支持跨行）"""
    pattern = r"<media-block>.*?</media-block>"
    cleaned_text = re.sub(pattern, "", text, flags=re.DOTALL)
    return cleaned_text

def remove_single_biggest_heading(md_text: str) -> str:
    """删除 markdown 文本中只出现一次的最大标题行"""
    # 匹配形如 "# xxx" 的标题行
    heading_pattern = re.compile(r'^(#{1,6})\s.*$', re.MULTILINE)
    headings = heading_pattern.findall(md_text)

    if not headings:
        return md_text.strip()  # 没有标题，直接返回

    # 找出最小数量（最靠前）的井号数，即最大标题级别
    min_level = min(len(h) for h in headings)

    # 找出该级别的标题数量
    count_min_level = sum(1 for h in headings if len(h) == min_level)

    # 仅当该级别标题只出现一次时才删除
    if count_min_level == 1:
        # 删除这一行标题
        pattern_delete = re.compile(rf'^(#{{{min_level}}}\s.*)$', re.MULTILINE)
        md_text = pattern_delete.sub('', md_text, count=1)

    return md_text.strip()

def remove_first_heading(text: str) -> str:
    """去除文本开头的第一个标题行"""
    heading_pattern = r"^\s*(#{1,6})\s+.*?(?:\n|$)"
    return re.sub(heading_pattern, '', text, count=1, flags=re.MULTILINE)

def remove_list_item_prefix(content: str) -> str:
    """去除列表项的数字或字母前缀"""
    # is_list = re.match(r'^ *[-*+] |^ *\d+\. ', text)  # 列表项
    # is_blockquote = re.match(r'^ *> ', text)  # 引用
    pattern = re.compile(r'^ *(\d+\.\s+|[-*+>→]\s+)', re.MULTILINE)
    content = pattern.sub('', content)
    pattern = re.compile(r"^ *", re.MULTILINE)
    content = pattern.sub('', content)
    content = re.sub(r"\n+", "\n", content)
    return content.strip()

def clean_title(text):
    """清洗标题"""
    # 1. 去除井号（如 # 标记）
    text = text.replace("#", "")
    # 2. 去除 emoji
    text = emoji.replace_emoji(text, replace="")
    # 3. 去除星号
    text = text.replace("*", "")
    # 4. 去除前面的数字
    text = re.sub(r'^\s*([一二三四五六七八九十]+\、|\d+\.|（[一二三四五六七八九十]+）)\s*', '', text)
    return text.strip()

def merge_two_title(title1, title2):
    """合并两个标题"""
    title1 = clean_title(title1)
    title2 = clean_title(title2)
    if title1:
        # title2 = re.sub(r'^[一二三四五六七八九十\d]+[\、\.]\s*', '', title2)
        return title1 + " - " + title2
    else:
        return title2

def merge_title(content: str) -> str:
    """合并连续的标题"""
    result = []
    cur_line = ""
    pre_fix = ""
    title_pattern = re.compile(r'^(#{1,6})\s.*$')
    for line in content.split("\n"):
        search = title_pattern.match(line)
        if not search:
            if cur_line:
                result.append(cur_line)
                cur_line = ""
            result.append(line)
            pre_fix = ""
            continue
        if not pre_fix:
            pre_fix = search.group(1)
            emoji_list = emoji.emoji_list(line)
            if emoji_list:
                pre_fix += " " + emoji_list[0]["emoji"]
        cur_line = merge_two_title(cur_line, line)
        cur_line = pre_fix + " **" + cur_line + "**"
    if cur_line:
        result.append(cur_line)
    return "\n".join(result)

def merge_content(content: str) -> str:
    """合并连续的段落"""
    result = []
    cur_line = ""
    last_space_num = 0
    need_colon = False
    title_pattern = re.compile(r'^(#{1,6})\s.*$')
    list_pattern = re.compile(r'^( *)(\d+\.\s+|[-*+>→]\s+)')
    for line in content.split("\n"):
        if title_pattern.match(line):  # 如果是标题，则直接添加
            if cur_line:
                result.append(cur_line)
                cur_line = ""
            result.append(line)
            continue
        search = list_pattern.match(line)
        if search:
            cur_space_num = len(search.group(1))
            if cur_space_num > last_space_num and cur_line:
                line = remove_list_item_prefix(line)
            else:
                if cur_line:
                    result.append(cur_line)
                last_space_num = cur_space_num
                cur_line = line
                need_colon = True
                continue
        if need_colon:
            cur_line = cur_line.rstrip("，。：；,.:; ")  + "："
            need_colon = False
        cur_line += line.strip()

    if cur_line:
        result.append(cur_line)
    return "\n".join(result)


def get_card_content(content: str) -> str:
    """获取卡片内容，去除卡片中的图片等信息"""
    content = get_clean_content(content)
    # content = remove_single_biggest_heading(content)
    # content = merge_title(content)
    content = merge_content(content)
    content = remove_list_item_prefix(content)
    content = content.strip()
    return content[:400]

def get_card_content_v1(content: str) -> str:
    """获取卡片内容，去除卡片中的图片等信息"""
    content = get_card_content(content)
    result = []
    content_list = content.split("\n")
    title_pattern = re.compile(r'^(#{1,6})\s.*$')
    cur_content = ""
    for line in content_list:
        if title_pattern.match(line):
            line = merge_title(line)
            line = line.lstrip("# ")
            if cur_content:
                if result:
                    result[-1] += " - " + cur_content
                else:
                    result.append(cur_content)
                cur_content = ""
            result.append(line)
        else:
            cur_content += line
    if cur_content:
        if result:
            result[-1] += " - " + cur_content
        else:
            result.append(cur_content)
    return "\n".join(result)

# ============= 新的卡片内容 =============
def clean_list_content(content: str) -> str:
    """清理列表内容"""
    # 只取加粗内容
    search = re.search(r"\*\*(.*?)\*\*", content)
    if search:
        content = search.group(1)
    content = remove_list_item_prefix(content)
    # 2. 去除 emoji
    content = emoji.replace_emoji(content, replace="")
    content = re.split(r"[:：]", content)[0]
    content = content.strip(" *")
    return content

def new_title_content(content: str, pre_fix: str = "", use_emoji=True) -> str:
    """新标题内容"""
    emoji_list = emoji.emoji_list(content)
    if emoji_list and use_emoji:
        pre_fix += emoji_list[0]["emoji"] + " "
    content = clean_title(content)
    content = content.rstrip(":：")
    return pre_fix + f"**{content}**"

def update_single_title_list(title_dict: dict, limit: int = 21) -> None:
    """更新单个标题列表"""
    title = title_dict["title"]
    content_list = title_dict["content_list"]
    total_num = len(clean_title(title))
    new_content_list = []
    for content in content_list:
        cur_num = len(content) + 0.5
        if total_num + cur_num > limit:
            break
        total_num += cur_num
        new_content_list.append(content)
    if not new_content_list and total_num < limit - 7 and "：" not in title and content_list:
        length = int(limit - 2 - total_num)
        new_content_list.append(content_list[0][:length] + "...")
    title_dict["content_list"] = new_content_list

def format_title_list(title_list: list, has_list: bool) -> str:
    """格式化标题列表"""
    result = []
    for title_dict in title_list:
        title = title_dict["title"]
        content_list = title_dict["content_list"]
        if not has_list:
            result.append("- " + title)
        else:
            result.append(f"- {title} {' '.join(content_list)}")
    return "\n".join(result)

def update_title_list(title_list: list) -> str:
    """更新标题列表"""
    if not title_list[-1]["content_list"] and len(clean_title(title_list[-1]["title"])) < 6:
        title_list = title_list[:-1]
    has_list = True
    count = 0
    for title_dict in title_list:
        if len(clean_title(title_dict["title"])) < 14 and not title_dict["content_list"]:
            has_list = False
            break
        update_single_title_list(title_dict)
        if title_dict["content_list"]:
            count += 1
    if count <= 1 and len(title_list) > 2:
        has_list = False
    return format_title_list(title_list, has_list)

def merge_only_title(content: str) -> list:
    """合并标题"""
    lines = content.split("\n")
    last_space_num = None
    title_pattern = re.compile(r'^(#{1,6})\s.*$')
    list_pattern = re.compile(r'^( *)(\d+\.\s+|[-*+→]\s+)')
    result = []
    cur_list = []
    for line in lines:
        search = title_pattern.match(line)
        if search:  # 如果是标题，则直接添加
            if result and cur_list:
                result[-1]["content_list"] = cur_list
            cur_list = []
            last_space_num = None
            result.append({"title": new_title_content(line, "", use_emoji=False), "need_point": False, "content_list": []})
            continue
        search = list_pattern.match(line)
        if not search:
            continue
        cur_space_num = len(search.group(1))
        if last_space_num is None:
            last_space_num = cur_space_num
        if cur_space_num > last_space_num:
            continue
        cur_list.append(clean_list_content(line))
    if result and cur_list:
        result[-1]["content_list"] = cur_list
    return result

def get_mulu_content(content: str) -> list:
    """获取目录内容"""
    content = get_clean_content(content)
    return merge_only_title(content)

def wrap_text_keep_newlines_list(text, width=30):
    """将文本拆分为指定宽度的行，同时保留原有换行结构"""
    result_lines = []
    for line in text.split('\n'):  # 保留原有换行结构
        line = line.strip()  # 去除首尾空格
        while len(line) > width:
            result_lines.append(line[:width])
            line = line[width:]
        result_lines.append(line + '\n')  # 保留换行符
    return result_lines

def wrap_text_keep_newlines(text, width=30, max_line=6):
    """将文本拆分为指定宽度的行，同时保留原有换行结构"""
    result_lines = wrap_text_keep_newlines_list(text, width)
    return "".join(result_lines[:max_line])

def get_more_card_content(content: str, content_style: str) -> str:
    """获取卡片附加内容"""
    title_list = get_mulu_content(content)
    if not title_list:
        return ""
    return update_title_list(title_list)

def get_left_percent(content: str, content_style: str) -> int:
    """获取剩余百分比"""
    _, content = split_think_and_content(content)
    content = remove_wb_custom_block(content)
    content = remove_media_block(content)

    show_content = wrap_text_keep_newlines(content_style)

    if not content:
        return 0
    return max(100 - len(show_content) * 110 // len(content), 0)

def clean_emoji(content: str) -> str:
    """去除emoji"""
    content = emoji.replace_emoji(content, replace="")
    content = re.sub(r" +", " ", content)
    return content

def get_card_content_lab_f(content: str) -> str:
    """获取卡片内容"""
    content = get_card_content(content)
    content = clean_emoji(content)
    content = re.sub(r'^(#{1,6})\s.*$', '', content, flags=re.MULTILINE)
    content = content.replace("*", "")
    content = content.strip()
    content = re.sub(r"\n+", "\n", content)
    return content

def get_final_summary(content: str) -> str:
    """获取卡片总结"""
    content = content.strip()
    content = content.replace("*", "")
    new_lines_list = wrap_text_keep_newlines_list(content, 23)
    if len(new_lines_list) < 3:
        return ""
    return content.strip()

def get_card_more_lab_n(content: str) -> str:
    """获取卡片剩余展示长度"""
    content = get_clean_content(content)
    title_pattern = re.compile(r'^(#{1,6})\s.*$')
    text_pattern = re.compile(r'(结语|结论|总结)')
    check = False
    result = ""
    for line in content.split("\n"):
        if not line.strip(" -"):
            continue
        if title_pattern.match(line):
            if text_pattern.search(line):
                check = True
            else:
                check = False
            result = ""
        elif check:
            result += line + "\n"
    return get_final_summary(result)

def get_new_card_multimodal(all_ready_list: list):
    """按照点击率排序外显卡片"""
    limit = 3
    all_ready_list = sorted(all_ready_list, key=lambda x: x['click_rate'], reverse=True)
    if len(all_ready_list) < limit:
        return []
    # has_video = False
    # for i in range(limit):
    #     if all_ready_list[i]['type'] == "v":
    #         has_video = True
    #         break
    # if has_video:
    #     return all_ready_list[:limit]
    # v_count = 0
    # first_v = None
    # for block in all_ready_list:
    #     if block['type'] == "v":
    #         v_count += 1
    #         if first_v is None:
    #             first_v = block
    # if v_count / len(all_ready_list) > 0.4:
    #     return all_ready_list[:limit - 1] + [first_v]
    return all_ready_list[:limit]

def get_card_multimodal_lab_q(all_ready_list: list):
    limit = 3
    if len(all_ready_list) < limit:
        return []
    limit1 = 6
    if len(all_ready_list) < limit1:
        return all_ready_list[:limit]
    return all_ready_list[:limit1]

def get_card_multimodal_lab_r(all_ready_list: list):
    limit = 2
    if len(all_ready_list) < limit:
        return []
    return all_ready_list[:limit]

def get_card_multimodal_lab_v(all_ready_list: list):
    all_ready_list = sorted(all_ready_list, key=lambda x: x['click_rate'], reverse=True)
    n = len(all_ready_list)
    limit_list = [6, 3, 2]
    for limit in limit_list:
        if n >= limit:
            return all_ready_list[:limit]
    return []

def get_card_multimodal_lab_x(all_ready_list: list):
    all_ready_list = sorted(all_ready_list, key=lambda x: x['click_rate'], reverse=True)
    n = len(all_ready_list)
    limit_list = [3, 2]
    for limit in limit_list:
        if n >= limit:
            return all_ready_list[:limit]
    return []

def get_card_multimodal_lab_w(all_ready_list: list):
    all_ready_list = sorted(all_ready_list, key=lambda x: x['click_num'], reverse=True)
    n = len(all_ready_list)
    limit_list = [3]
    for limit in limit_list:
        if n >= limit:
            return all_ready_list[:limit]
    return []


def get_card_multimodal_lab_y2(all_ready_list: list):
    all_ready_list = sorted(all_ready_list, key=lambda x: x.get('sort_1',0), reverse=True)
    return all_ready_list


def get_card_multimodal_lab_y3(all_ready_list: list):
    all_ready_list = sorted(all_ready_list, key=lambda x: x.get('sort_2',0),  reverse=True)
    return all_ready_list


def format_up_card_info(up_card_multi_info: dict):
    """格式化卡片信息"""
    result = {"pic_ready": {}, "video_ready": {}}
    for multi_info in up_card_multi_info.get("data", []):
        cur_type = multi_info.get("type", "")
        if cur_type == "p":
            cur_idx = str(len(result["pic_ready"]) + 1)
            pid = multi_info.get("pid", "")
            finger = multi_info.get("finger", "")
            result["pic_ready"][cur_idx] = {"pid": pid, "pic_finger": finger, "dup_group": -1, "flag": True}
        elif cur_type == "v":
            cur_idx = str(len(result["video_ready"]) + 1)
            v_phash = multi_info.get("v_phash", [])
            url = multi_info.get("url", "")
            waic_video_dup_finger = multi_info.get("waic_fea", "")
            result["video_ready"][cur_idx] = {"v_phash": v_phash, "url": url, "waic_video_dup_finger": waic_video_dup_finger, "flag": True}
    return result

def get_card_multimodal_lab_y(all_ready_list: list, up_card_multi_info: dict, unsimilar_pic: dict):
    """过滤和卡片之前相似的多模态"""
    limit = 3
    if len(all_ready_list) < limit:
        return [], []
    all_ready_list = sorted(all_ready_list, key=lambda x: x['click_rate'], reverse=True)
    unsim_list = []
    sim_list = []
    ready_dict = format_up_card_info(up_card_multi_info)
    for multi in all_ready_list:
        if multi['type'] == 'p':
            item = {"img_pid": multi.get("img_pid", ""), "img_idx": "1_1", "dup_group": -1,
                    "pic_finger": multi.get("similar_info", {}).get("finger", "")}
            if check_img_is_similar(item, ready_dict.get("pic_ready", {}), unsimilar_pic):
                sim_list.append(multi)
            else:
                unsim_list.append(multi)
        elif multi['type'] == 'v':
            v_phash = multi.get("similar_info", {}).get("v_phash", [])
            waic_video_dup_finger = multi.get("similar_info", {}).get("waic_fea", "")
            video_url = multi.get("video_url", "")
            if check_video_is_similar("1_1", video_url, v_phash, waic_video_dup_finger, "", ready_dict.get("video_ready", {})):
                sim_list.append(multi)
            else:
                unsim_list.append(multi)
    return unsim_list, sim_list

def get_multi_pic_first(all_ready_list):
    """优先图片策略"""
    pic_list = []
    video_list = []
    for multi in all_ready_list:
        if multi['type'] == 'p':
            pic_list.append(multi)
        elif multi['type'] == 'v':
            video_list.append(multi)
    return pic_list + video_list
