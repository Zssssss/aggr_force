"""图片后处理"""
# -*- coding:utf-8 -*-
import json
import re
import binascii
from conf.config import MULTIMODAL_DEBUG
from lib.safe_convert import convert_to_int, convert_to_float


# ============= 图片处理基础函数,由普搜提供 =============
def get_size_from_pid(pid):
    """通过pid获取图片的长宽"""
    try:
        if len(pid) < 32 or pid[22] < "1":
            return 1, 1
        width = int(pid[23:26], 36)
        height = int(pid[26:29], 36)
    except:
        return 1, 1
    return height, width

letter32dict={"0":0,"1":1,"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"a":10,"b":11,"c":12,"d":13,"e":14,"f":15,"g":16,"h":17,"i":18,"j":19,"k":20,"l":21,"m":22,"n":23,"o":24,"p":25,"q":26,"r":27,"s":28,"t":29,"u":30,"v":31}
def finger2bit_raw(finger, type_num):
    """指纹处理"""
    finger_bits = ""
    prefix = finger[0:type_num]
    finger_bits += prefix
    for i in range(type_num, len(finger)):
        b = '{0:05b}'.format(letter32dict[finger[i]])
        finger_bits += b
    return finger_bits

def pic_hamming_distance(fingerpress1, fingerpress2):
    """
    计算两个指纹的汉明距离
    """
    fg1Len = len(fingerpress1)
    fg2Len = len(fingerpress2)
    if fg1Len < 5 or fg2Len < 5 or fg1Len != fg2Len:
        return 80

    # 如果指纹的前3位，即类别不致，则认为图片不同，反回距离最大值。
    if fingerpress1[:2] != fingerpress2[:2]:
        return 80
    # 下面为正常指纹第6位以后距离计算
    fp1 = finger2bit_raw(fingerpress1, 2)
    fp2 = finger2bit_raw(fingerpress2, 2)
    # print(fp1,fp2)
    # 转为二进制后，指纹更不准，故用原来的情况
    dist = max(len(fp1), len(fp2))
    if "null" not in fp1 and "null" not in fp2:
        dist = sum(el1 != el2 for el1, el2 in zip(fp1, fp2))
    return dist

def get_pic_url(pid, typ='middle', https=False):
    """ 获取图片 URL
    Args:
      pid: A picture id provided by Imgbed.
      typ: picture typ.
      https: A Boolean flag, return https url or http url.
    Returns:
      A string of picture URL.
    """
    if pid[9] == 'y' and len(pid) >= 32:
        zone = (binascii.crc32(pid.encode('utf8')) & 0xffffffff & 0x03) + 1
        ext = 'jpg' if pid[21] == 'j' else 'gif'
        fmt = "https://wx{}.sinaimg.cn/{}/{}.{}" if https else \
            "http://wx{}.sinaimg.cn/{}/{}.{}"
        return fmt.format(zone, typ, pid, ext)

    elif pid[9] == 'w':
        zone = (binascii.crc32(pid.encode('utf8')) & 0xffffffff & 0x03) + 1
        ext = 'jpg' if pid[21] == 'j' else 'gif'
        fmt = "https://ww{}.sinaimg.cn/{}/{}.{}" if https else \
            "http://ww{}.sinaimg.cn/{}/{}.{}"
        return fmt.format(zone, typ, pid, ext)

# ============= 图片判断 =============
def is_valid_pic(h, w, pic_tags, fea_1174, doc_valid_num, ocr_len, is_hot_query, special_check, has_keyword, verify_type):
    """通过属性判断图片是否为有效图片"""
    if h == 0 or w == 0:
        return False, "0000"
    if pic_tags != "0":
        return False, "0001"
    if ocr_len<=25 and has_keyword:
        return False, "0002"
    if not special_check and is_hot_query:
        return False, "0003"
    ocr_limit = 300
    size_limit = 400 if ocr_len >=0 else 1000
    ocr_ratio = True if (ocr_len * 400)/(h * w) <= 0.03 else False
    ratio_limit = 0.4 < h / w < 3.6
    bad_pic = (fea_1174 ==2 and (ocr_len>=15 or 0.9 < h/w < 1)) or fea_1174==3
    if not is_hot_query and verify_type==-1 and doc_valid_num <10:
        return False, "0004"
    if ocr_len > ocr_limit:
        return False, "0005"
    if h <=size_limit or w <= size_limit:
        return False, "0006"
    if bad_pic:
        return False, "0007"
    if not ocr_ratio:
        return False, "0008"
    if not ratio_limit:
        return False, "0009"
    return True, "1111"

def check_pic_is_valid(mid, pid, query_info_dict, mid_info_dict, pid_info_dict) -> bool:
    """检查图片是否有效"""
    # pid信息
    pid_info = pid_info_dict.get(pid, {})
    h = pid_info.get('h', 1) or 1
    w = pid_info.get('w', 1) or 1
    ocr_len = pid_info.get('ocr_len', -2)
    ocr = pid_info.get('ocr', "") if pid_info.get('ocr', "") else ""
    type_p = pid_info.get('type', '').upper()
    pic_tags = pid_info.get('pic_tags', "0")
    dup_group = pid_info.get('dup_group', -1)
    pic_finger = pid_info.get('pic_finger', "")
    fea_1174 = pid_info.get('fea_1174',-1)
    # mid信息
    mid_info = mid_info_dict.get(mid, {})
    doc_valid_num = int(mid_info.get('doc_valid_num', 0))
    verify_type = int(mid_info.get('verified_type', -1))
    is_top = mid_info.get('is_top_up', False)
    # query信息
    is_hot_query = query_info_dict.get("is_hot_query", False)  # 是否是热词

    # 合并判断
    is_jpg = pid[21] == 'j' if len(pid) > 21 else True
    if is_hot_query:
        special_check = (int(doc_valid_num) > 20 or is_top) and is_jpg
    else:
        special_check = True
    dazibao_keyword = ['最新消息', '最新,消息', '今日焦点', '今日关注', '今日辟谣', '权威发布', '最新资讯', '权威,发布', '军报快讯', '最新,俏息', '关注', '快讯', '快评', '社评', '消息', '声音', '聚焦', '最新', '重磅', '两会', '情况通报']
    has_keyword = any(keyword in ocr for keyword in dazibao_keyword)

    is_valid, filter_str = is_valid_pic(h, w, pic_tags, fea_1174, doc_valid_num, ocr_len, is_hot_query, special_check, has_keyword, verify_type)
    ocr_content = ocr.replace(",", "")
    # 添加其他信息
    pic_log_info = f"<首图特征：img_url: http://bj.service.t.sinaimg.cn/middle/{pid} ocr_len:{ocr_len}, ocr:{ocr_content}, has_keyword:{has_keyword}, verify_type:{verify_type}, type:{type_p}, fea_1174:{fea_1174}, h:{h}, w:{w}, h/w:{h / w}, dup_group:{dup_group}, pic_tags:{pic_tags}, is_hot_query:{is_hot_query}, doc_valid_num:{doc_valid_num}, is_jpg:{is_jpg}, is_hot_query:{is_hot_query}, pic_finger:{pic_finger}>"
    return {"is_valid": is_valid, "filter_str": filter_str, "pic_log_info": pic_log_info}


def check_img_is_similar(img_item: dict, ready_pid_dict, unsimilar_pic, log_func=None) -> bool:
    """检查图片是否重复"""
    img_pid = img_item["img_pid"]
    img_idx = img_item["img_idx"]  ## img_4_2
    dup_group = img_item["dup_group"]
    pic_finger = img_item["pic_finger"]
    cur_unsimilar_pic_list = unsimilar_pic.get("un_sim", {}).get(img_pid, [])
    cur_similar_pic_list = unsimilar_pic.get("sim", {}).get(img_pid, [])
    # 通过dup_group判断是否重复
    for cur_idx, cur_pid_dict in ready_pid_dict.items():
        cur_pid = cur_pid_dict["pid"]
        if cur_pid == img_pid:
            if log_func:
                log_func(f"图片索引{img_idx}的图片id:{img_pid},与索引{cur_idx}的图片id:{cur_pid},重复")
            return True
        if not cur_pid_dict["flag"]:
            continue
        cur_dup_group = cur_pid_dict["dup_group"]
        if dup_group != -1 and cur_dup_group != -1 and cur_dup_group == dup_group:
            if log_func:
                log_func(f"图片索引{img_idx}的图片id:{img_pid},图片dup_group:{dup_group},与索引{cur_idx}的图片id:{cur_pid},图片dup_group:{cur_dup_group},重复")
            return True
    # 通过指纹判断是否重复
    for cur_idx, cur_pid_dict in ready_pid_dict.items():
        if not cur_pid_dict["flag"]:
            continue
        cur_pid = cur_pid_dict["pid"]
        cur_pic_finger = cur_pid_dict["pic_finger"]
        hamming_distance = pic_hamming_distance(pic_finger, cur_pic_finger)
        if (hamming_distance <= 3 or (hamming_distance <= 10 and cur_pid not in cur_unsimilar_pic_list) or
            (10 < hamming_distance <= 20 and cur_pid in cur_similar_pic_list)):
            if log_func:
                log_func(f"图片索引{img_idx}的图片id:{img_pid},图片指纹:{pic_finger},与索引{cur_idx}的图片id:{cur_pid},图片指纹:{cur_pic_finger},汉明距离:{hamming_distance},指纹相似度过高,重复")
            return True
    return False


def get_pic_dict(mix_index, cur_mid, img_pid, ready_pid_dict, query_info_dict, mid_feature_dict, pic_info_dict_all, is_caibian=False, log_func=None):
    """获取图片信息"""
    unsimilar_pic = query_info_dict.get("unsimilar_pic", {})
    user_name = mid_feature_dict.get(cur_mid, {}).get('user_name', '')
    user_avatar = mid_feature_dict.get(cur_mid, {}).get('user_avatar', '')
    verify_type = convert_to_int(mid_feature_dict.get(cur_mid, {}).get('verified_type', -1), -1)
    hit_score_new = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("hit_score_new", "0"))
    hit_score_final = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("hit_score_final", "0"))
    doc_score = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("doc_score", "0"))
    is_top_up = mid_feature_dict.get(cur_mid, {}).get("is_top_up", False)
    is_media_user = mid_feature_dict.get(cur_mid, {}).get("is_media_user", False)
    is_blue = 1 <= verify_type <= 7

    pid_info_dict = pic_info_dict_all.get(cur_mid, {})
    pid_info = pid_info_dict.get(img_pid, {})
    h = pid_info.get('h', 0)
    w = pid_info.get('w', 0)
    dup_group = pid_info.get('dup_group', -1)
    pic_finger = pid_info.get('pic_finger', "")
    img_url = get_pic_url(img_pid)
    img_idx = f"img_{cur_mid}_{mix_index}"

    user_info = f'<span class="vator" style="display: none;background: url({user_avatar}) no-repeat;background-size: contain;"></span><span class="nick" style="display: none">{user_name}</span>'
    cur_scheme = f"sinaweibo://multimedia?mix_mid={cur_mid}&from=search&content_show=1&mix_index={mix_index}&hide_index=1"
    cur_img_dict = {"type": "p", "scheme": cur_scheme, "img": img_url, "cur_mid": cur_mid, "similar_info": {"finger": pic_finger},
                    "user_name": user_name, "user_avatar": user_avatar, "h": h, "w": w, "vtype": verify_type, "video_url": "",
                    "hit_score_new": hit_score_new, "hit_score_final": hit_score_final, "doc_score": doc_score, "img_pid": img_pid}
    if MULTIMODAL_DEBUG:
        cur_img_str = f'<img src="http://bj.service.t.sinaimg.cn/middle/{img_pid}">'
    else:
        cur_img_str = f'<div data-type="p" data-scheme="{cur_scheme}">{user_info}<img src="{img_url}" data-width={h} data-height={w}></div>'
    cur_img_all_info = {"img_video_str": cur_img_str, "img_video_idx": img_idx, "img_video_dict": cur_img_dict, "is_selected": is_caibian,
                                "is_media_user": is_media_user, "is_blue": is_blue, "is_top_up": is_top_up}
    # 判断是否需要采编
    check_data = check_pic_is_valid(cur_mid, img_pid, query_info_dict, mid_feature_dict, pid_info_dict)
    cur_img_all_info["pic_log_info"] = check_data["pic_log_info"]
    if not check_data["is_valid"] and not is_caibian:
        cur_img_all_info["final_check"] = False
        if log_func:
            log_func(f"check_pic_is_valid, img_idx={img_idx}, img_pid={img_pid}, check_data={json.dumps(check_data, ensure_ascii=False)}")
        return cur_img_all_info
    img_item = {"img_pid": img_pid, "img_idx": img_idx, "dup_group": dup_group, "pic_finger": pic_finger}
    # 判断是否和已经采编的图片重复
    if check_img_is_similar(img_item, ready_pid_dict["img_ready"], unsimilar_pic, log_func):
        cur_img_all_info["final_check"] = False
        if img_idx not in ready_pid_dict["img_ready"]:
            ready_pid_dict["img_ready"][img_idx] = {"pid": img_pid, "dup_group": dup_group,
                                                        "pic_finger": pic_finger, "flag": False}
        return cur_img_all_info
    if not pic_finger:
        cur_img_all_info["final_check"] = False
        cur_img_all_info["has_pic_finger"] = False
        if img_idx not in ready_pid_dict["img_ready"]:
            ready_pid_dict["img_ready"][img_idx] = {"pid": img_pid, "dup_group": dup_group,
                                                        "pic_finger": pic_finger, "flag": False}
        return cur_img_all_info
    cur_img_all_info["final_check"] = True
    ready_pid_dict["img_ready"][img_idx] = {"pid": img_pid, "dup_group": dup_group,
                                                        "pic_finger": pic_finger, "flag": True}
    return cur_img_all_info