"""正则基础方法"""
import re

ZH_PATTERN = re.compile(r'[\u4e00-\u9fa5]')

class BaseRE:
    """正则基础方法类"""

    @staticmethod
    def has_chinese(text: str) -> bool:
        """判断文本中是否含有中文"""
        return bool(ZH_PATTERN.search(text))
