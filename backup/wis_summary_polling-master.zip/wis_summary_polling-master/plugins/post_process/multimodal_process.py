"""多模态整体后处理"""
# -*- coding:utf-8 -*-
import json
import re
from collections import defaultdict
import aiohttp
from conf.config import MULTIMODAL_DEBUG
from lib.safe_convert import convert_to_int, convert_to_float
from plugins.post_process.utils import split_markdown_paragraphs, remove_and_save_trailing, split_think_and_content
from plugins.post_process.quote_process import single_quote_process
from plugins.post_process.picture_process import get_pic_dict
from plugins.post_process.video_process import get_video_dict
from plugins.post_process.md_special_format_process import back_special_format

re_quote_num = re.compile(r'<a>\[(\d+)\]</a>')
re_wb_custom_block = re.compile("```wbCustomBlock(.*?)```", flags=re.DOTALL)
QI_SCORE_LIMIT = 20

# ============= 整体入口 pic_process_ds =============
def get_all_quote_list(text: str, pic_info_dict_all, link_list, video_mid_dict, mid_feature_dict):
    """获取所有引文列表"""
    numbers_pic_dict = {}
    numbers_video_dict = {}
    numbers_mid_dict = {}
    a_number = re_quote_num.findall(text)
    numbers = [int(index) for index in a_number]
    numbers = list(dict.fromkeys(numbers))

    is_top_up_list = []
    is_media_user_list = []
    is_gold_orange_list = []
    is_verify_list = []
    other_list = []
    other_quote_list = []
    for reference_num in numbers:
        if reference_num > len(link_list):
            continue

        link_item = link_list[reference_num - 1]
        if "detail?mblogid=" in link_item:
            mid = link_item.split("mblogid=")[1]

            v = mid_feature_dict.get(mid, {})
            filter_tag = v.get('filter_tag', False)
            if filter_tag == True:
                continue
            doc_valid_nums = int(v.get('doc_valid_num', -1))
            verify_type = int(v.get('verified_type', -1))
            if v.get('is_top_up', False):
                is_top_up_list.append({"quote": reference_num, "is_credible": True})
            elif v.get('is_media_user', False):
                is_media_user_list.append({"quote": reference_num, "is_credible": True})
            elif v.get('is_gold_orange', False):
                is_gold_orange_list.append({"quote": reference_num, "is_credible": False})
            elif 0 <= verify_type <= 7:
                is_verify_list.append({"quote": reference_num, "is_credible": False})
            else:
                other_list.append({"quote": reference_num, "is_credible": False})
                other_quote_list.append(reference_num)

            numbers_pic_dict[reference_num] = pic_info_dict_all.get(mid, {})
            numbers_video_dict[reference_num] = video_mid_dict.get(mid, [])
            numbers_mid_dict[reference_num] = mid

    res_quote_list = is_top_up_list + is_media_user_list + is_gold_orange_list + is_verify_list + other_list

    return res_quote_list, numbers_pic_dict, numbers_video_dict, numbers_mid_dict, other_quote_list

def selcet_img_video(use_list: list, query_info_dict: dict, log_func=None):
    """
    选择图片和视频
    1. 若q_attr.ban_object = 3 不出图片和视频
    2. 若单段落采编数量小于等于3，则按照顺序直接输出
    3. 若单段落采编数量大于3，则按照顺序：权威媒体》蓝V》其他 输出前3条符合条件的多模态内容
    """
    if query_info_dict["ban_object"] == 3:
        if log_func and use_list:
            log_func("ban_object is 3, all multi is filtered")
        return []
    return use_list
    # limit_num = 3
    # if len(use_list) <= limit_num:
    #     return use_list
    # # 调整排序key以符合需求
    # if log_func:
    #     log_func(f"单段落多模态内容排序前:{json.dumps(use_list, ensure_ascii=False)}")
    # use_list.sort(key=lambda x: (x["is_selected"], x["is_top_up"], x["is_media_user"], x["is_blue"], x.get("img_video_dict", {}).get("click_rate", 0)), reverse=True)
    # if log_func:
    #     for i in range(limit_num, len(use_list)):
    #         log_func(f"单段落按规则取前3个，过滤信息: img_video_idx: {use_list[i]['img_video_idx']}, img_pid:{use_list[i]['img_video_dict']['img_pid']}")
    # # 选择前3条符合条件的多模态内容
    # return use_list[:limit_num]

def log_qi_score(mid, qi_score, source_from, log_func=None):
    if log_func:
        if qi_score == 400:
            log_func(f"check no qi_score, mid:{mid}, qi_score:{qi_score}, source_from:{source_from}")
        elif qi_score < QI_SCORE_LIMIT:
            log_func(f"check small qi_score, mid:{mid}, qi_score:{qi_score}, source_from:{source_from}")

def get_all_quote_number(text: str):
    """获取所有引用段落"""
    a_number = re_quote_num.findall(text)
    numbers = [int(cur_index) for cur_index in a_number]
    numbers = sorted(list(dict.fromkeys(numbers)))
    return numbers

def get_quote_to_mid(numbers, link_list):
    """获取引用段落对应的mid"""
    quote_mid_dict = {}
    for reference_num in numbers:
        if reference_num > len(link_list):
            continue

        link_item = link_list[reference_num - 1]
        if "detail?mblogid=" in link_item:
            mid = link_item.split("mblogid=")[1]
            quote_mid_dict[reference_num] = mid
    return quote_mid_dict

def get_mid_to_quote(link_list):
    """获取引用字符"""
    mid_to_quote = {}
    for index, link in enumerate(link_list):
        if "detail?mblogid=" in link:
            mid = link.split("mblogid=")[1]
            mid_to_quote[mid] = index + 1
    return mid_to_quote

def sort_filter_quote_number(numbers, quote_mid_dict, mid_feature_dict):
    """排序并过滤引用列表"""
    is_top_up_list = []
    is_media_user_list = []
    is_gold_orange_list = []
    is_verify_list = []
    other_list = []
    filter_dict = {}
    for reference_num in numbers:
        if reference_num not in quote_mid_dict:
            filter_dict[reference_num] = 'not weibo mid'
            continue
        mid = quote_mid_dict[reference_num]
        v = mid_feature_dict.get(mid, {})
        filter_tag = v.get('filter_tag', False)
        if filter_tag:
            filter_dict[reference_num] = f'{mid} filter_tag is true'
            continue
        verify_type = int(v.get('verified_type', -1))
        if v.get('is_top_up', False):
            is_top_up_list.append(reference_num)
        elif v.get('is_media_user', False):
            is_media_user_list.append(reference_num)
        elif v.get('is_gold_orange', False):
            is_gold_orange_list.append(reference_num)
        elif 0 <= verify_type <= 7:
            is_verify_list.append(reference_num)
        else:
            other_list.append(reference_num)
    res_quote_list = is_top_up_list + is_media_user_list + is_gold_orange_list + is_verify_list + other_list
    return res_quote_list, filter_dict

def get_multi_list(mid, mid_feature_dict, video_mid_dict):
    """获取mid对应的多模态的顺序列表"""
    mix_media_ids = mid_feature_dict.get(mid, {}).get("mix_media_ids", [])
    pic_ids = mid_feature_dict.get(mid, {}).get("pic_ids", [])
    final_list = mix_media_ids if mix_media_ids else pic_ids
    video_list = video_mid_dict.get(mid, [])
    if not final_list and video_list:
        final_list = ["http://t.cn/test"] # 站位，代表视频
    return final_list

def check_seclected_and_get_click_info(img_pid, cur_selected, dst_type):
    """检查是否选中"""
    for sel_dict in cur_selected:
        cur_type = sel_dict.get("type", "")
        is_caibian = sel_dict.get("is_caibian", 1)
        sel_pid = sel_dict.get("pid", "")
        click_rate = sel_dict.get("click_rate", 0)
        click_num = sel_dict.get("click_num", 0)
        sort_1 = sel_dict.get("sort_1", 0)
        sort_2 = sel_dict.get("sort_2", 0)
        if cur_type == dst_type and sel_pid == img_pid:
            return is_caibian, {"click_rate": click_rate, "click_num": click_num, "sort_1": sort_1, "sort_2": sort_2}
    return False, {}

def single_text_process(text:str, pic_info_dict_all: dict, link_list: list, vector_dict: dict, ready_pid_dict: dict, video_mid_dict, mid_feature_dict, query_info_dict, log_func=None, if_last_text=False):
    """单段落文本处理"""
    # 获取所有引文
    all_quote_number = get_all_quote_number(text)
    # 引文和mid映射
    quote_mid_dict = get_quote_to_mid(all_quote_number, link_list)
    # 引文排序，过滤掉风控或者有效阅读和有效粉丝的限制的引文
    all_quote_number, filter_dict = sort_filter_quote_number(all_quote_number, quote_mid_dict, mid_feature_dict)
    if log_func:
        log_func(f"single_text_process: all_quote_number: {all_quote_number}, filter_dict: {filter_dict}")

    use_list = []
    first_no_finger_img = {}
    img_num = 0
    # markdown特殊格式，```mermaid```或者是table
    special_md = query_info_dict.get('special_md', {})
    special_md_key = "mediablock"
    ready_pid_dict.setdefault(special_md_key, [])
    single_all_text = delete_multi(text)
    single_all_text = back_special_format(single_all_text, special_md)
    abtest_label = query_info_dict.get("abtest_label", "")

    for quote in all_quote_number:
        cur_mid = quote_mid_dict[quote]
        multi_list = get_multi_list(cur_mid, mid_feature_dict, video_mid_dict)
        if not multi_list:
            continue
        # 低质
        qi_score = convert_to_float(mid_feature_dict.get(cur_mid, {}).get("qi_score", 400))
        cur_selected = query_info_dict.get("selected_data", {}).get(cur_mid, [])
        source_from = mid_feature_dict.get(cur_mid, {}).get("source_from", "")
        if qi_score < QI_SCORE_LIMIT and not cur_selected:
            log_qi_score(cur_mid, qi_score, source_from, log_func=log_func)
            continue
        video_index = -1
        video_dict_list = video_mid_dict.get(cur_mid, [])
        cur_data = {}
        # 首图首视频必走
        for index, multi in enumerate(multi_list):
            if index > 0:
                break
            if multi.startswith("http:"):
                video_index += 1
                if video_index >= len(video_dict_list):
                    continue
                cur_data = get_video_dict(index, cur_mid, video_dict_list[video_index], mid_feature_dict, ready_pid_dict, log_func=log_func)
            else:
                cur_data = get_pic_dict(index, cur_mid, multi, ready_pid_dict, query_info_dict, mid_feature_dict, pic_info_dict_all, log_func=log_func)
                if not first_no_finger_img and not cur_data.get("has_pic_finger", True):
                    first_no_finger_img = cur_data
            cur_data["img_video_dict"].update({"single_all_text": single_all_text, "click_rate": 0, "click_num": 0, "sort_1": 0, "sort_2": 0})
            if cur_data.get("final_check", False):
                use_list.append(cur_data)
                if cur_data["img_video_dict"]["type"] == "p":
                    img_num += 1
        if cur_selected:
            # 接口选择
            video_index = -1
            for index, multi in enumerate(multi_list):
                if multi.startswith("http:"):
                    video_index += 1
                    if video_index >= len(video_dict_list):
                        continue
                    img_ori_url = video_dict_list[video_index].get('image', {}).get('url', '')
                    img_pid = video_dict_list[video_index].get('image', {}).get('pid', '')
                    if not img_pid and img_ori_url:
                        img_pid = img_ori_url.split('/')[-1].split(".")[0]
                    check, click_info = check_seclected_and_get_click_info(img_pid, cur_selected, "video")
                    if not check:
                        continue
                    cur_data = get_video_dict(index, cur_mid, video_dict_list[video_index], mid_feature_dict, ready_pid_dict, is_caibian=True, log_func=log_func)
                else:
                    check, click_info = check_seclected_and_get_click_info(multi, cur_selected, "pic")
                    if not check:
                        continue
                    cur_data = get_pic_dict(index, cur_mid, multi, ready_pid_dict, query_info_dict, mid_feature_dict, pic_info_dict_all, is_caibian=True, log_func=log_func)
                    if not first_no_finger_img and not cur_data.get("has_pic_finger", True):
                        first_no_finger_img = cur_data
                cur_data["img_video_dict"].update({"single_all_text": single_all_text})
                cur_data["img_video_dict"].update(click_info)
                if cur_data.get("final_check", False) and check:
                    use_list.append(cur_data)
                    if cur_data["img_video_dict"]["type"] == "p":
                        img_num += 1
        if log_func:
            # 根据是否selected打印不同的日志
            messages = "first photo/video" if not cur_selected else "cur_selected"
            base_mid = cur_data.get("img_video_dict", {}).get("cur_mid", "")
            base_pid = cur_data.get("img_video_dict", {}).get("img_pid", "")
            log_func(f"{messages}, mid:{base_mid}, pid:{base_pid}")

    if not img_num and first_no_finger_img and ready_pid_dict["no_finger_img_num"] < 3:
        use_list.append(first_no_finger_img)
        ready_pid_dict["img_ready"][first_no_finger_img["img_video_idx"]]["flag"] = True
        ready_pid_dict["no_finger_img_num"] += 1
        if log_func:
            log_func(f"img_video_idx: {first_no_finger_img['img_video_idx']}, pid: {first_no_finger_img['img_video_dict']['img_pid']}, has no finger img, add it")
    ready_pid_dict["single_all_list"] = [item["img_video_dict"] for item in use_list]
    use_list = selcet_img_video(use_list, query_info_dict, log_func=log_func)

    if not use_list:
        return text
    ready_pid_dict["all_ready_list"].extend([item["img_video_dict"] for item in use_list])

    # 修改为wbCustomBlock格式
    media_data = {
        "type" : "mediablock",
        "data" : [item["img_video_dict"] for item in use_list]
    }
    cur_index = len(ready_pid_dict[special_md_key])
    cur_format_wbcustomblock = format_wbcustomblock(special_md_key, cur_index)
    ready_pid_dict[special_md_key].append({"data": media_data})
    return text.rstrip() + f"{cur_format_wbcustomblock}"

def pic_process_ds(ori_text: str, pic_info_dict_all: dict, link_list: list, vector_dict:dict, video_mid_dict, mid_feature_dict, ready_text_dict, query_info_dict, ready=False, log_func=None):
    """总体对外接口，用于处理图片数据"""
    # 思考过程不处理
    if "<think>" in ori_text and "</think>" not in ori_text:
        return ori_text
    if "</think>" in ori_text:
        pre_text = ori_text.split("</think>")[0] + "</think>"
        text = ori_text.split("</think>")[1]
    else:
        pre_text = ""
        text = ori_text

    result_list = []
    texts = split_markdown_paragraphs(text)
    # print(texts)
    final_text = ""
    if not ready:
        final_text = texts[-1]
        texts = texts[:-1]

    count_limit = 300
    text_ready_list = ready_text_dict.setdefault("text_ready", [])
    ready_text_dict.setdefault("img_ready", {})
    ready_text_dict.setdefault("video_ready", {})
    ready_text_dict.setdefault("media_ready", {})
    ready_text_dict.setdefault("all_ready_list", [])
    ready_text_dict.setdefault("believable_num", 0)
    ready_text_dict.setdefault("no_finger_img_num", 0)
    count = ready_text_dict.get("text_replace_count", 0)
    for i, text in enumerate(texts):
        if i < len(text_ready_list):
            result_list.append(text_ready_list[i])
            continue
        if count >= count_limit:
            new_text = text
        else:
            new_text, final = remove_and_save_trailing(text)
            # 段落中引文处理
            # new_text, single_ready_quote = single_mid_quote_process(new_text, i, link_list, mid_feature_dict, log_func)
            single_ready_quote = set()
            # 风险处理
            # new_text = single_risk_process(new_text, i, link_list, mid_feature_dict, ready_text_dict, log_func)
            # 引文处理
            new_text = single_quote_process(new_text, i, link_list, mid_feature_dict, ready_text_dict, single_ready_quote, query_info_dict, log_func)
            # 图片视频处理
            if_last_text = i == len(texts) - 1
            new_text = single_text_process(new_text, pic_info_dict_all, link_list, vector_dict, ready_text_dict, video_mid_dict, mid_feature_dict, query_info_dict, log_func=log_func, if_last_text=if_last_text)
            new_text = new_text + final
        if len(new_text) != len(text):
            count += 1
        result_list.append(new_text)
        text_ready_list.append(new_text)
    ready_text_dict["text_replace_count"] = count
    if not ready:
        # 最后没到段尾的也需要流式处理，避免前后显示不一致
        # final_text, _ = single_mid_quote_process(final_text, len(texts), link_list, mid_feature_dict, log_func)
        result_list.append(final_text)
    return pre_text + "".join(result_list)

# ============= 删除所有的多模态内容 =============
def delete_multi(text):
    """删除所有的多模态内容"""
    text = re_wb_custom_block.sub("", text)
    text = re_quote_num.sub("", text)
    return text

# ============= 解析wbcustomblock数据 =============
def format_wbcustomblock(lang: str, index: int):
    """构造特殊格式"""
    return f'[^多模态_{lang}_{index}]'

def process_wbcustomblock_format(text: str, ready, logger) -> (str, dict):
    """解析wbcustomblock数据"""
    block_list = re_wb_custom_block.findall(text)
    result = defaultdict(list)
    for block in block_list:
        ori_text = f"```wbCustomBlock{block}```"
        try:
            data = json.loads(block)
        except Exception as e:
            if ready and logger:
                logger.error(f"wbCustomBlock error: {e}, data:{json.dumps(block,ensure_ascii=False)}")
            continue
        type_val = data.get("type", "") or "other"
        result[type_val].append({
            "ori_text": ori_text.strip(),
            "data": data,
            "type": type_val
        })
        text = text.replace(ori_text, format_wbcustomblock(type_val, len(result[type_val]) - 1))
    return text, result

# ============= 整体入口，回写wbcustomblock数据 =============
def back_wbcustomblock_format(text: str, result) -> str:
    """回写wbcustomblock格式"""
    for lang, blocks in result.items():
        for index, block in enumerate(blocks):
            data = block["data"]
            if data:
                replace_str = f"```wbCustomBlock{json.dumps(block['data'], ensure_ascii=False)}```"
            else:
                replace_str = ""
            text = text.replace(format_wbcustomblock(lang, index), replace_str)
    return text

# ============= 批量获取relevance_score =============
async def get_relevance_score(id, relevance_dict):
    """批量获取relevance_score"""
    url = "http://mproxy.search.weibo.com/llm/generate"

    data = {
        "payload": {
            "id": id,
            "inputs": [
                {
                    "shape": [len(relevance_dict), 2],
                    "datatype": "BYTES",
                    "name": "texts",
                    "data": list(relevance_dict.values())
                }
            ]
        },
        "model": "bce_reranker",
        "sid": "zszj_dmt"
    }
    try:
        timeout = aiohttp.ClientTimeout(total=1)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, json=data) as response:
                result = await response.json()
                scores = result["data"]["outputs"][0]["data"]
                relevance_score = {mid: score for mid, score in zip(relevance_dict.keys(), scores)}
                return relevance_score
    except Exception as e:
        return {"error": str(e)}

def process_non_overlapping(segment: str, called_account_dict):
    # 找到 @account（按长度降序避免部分匹配）
    accounts = sorted(called_account_dict.keys(), key=lambda s: -len(s))
    alternation = '|'.join(re.escape(a) for a in accounts)
    pattern = re.compile(rf"@(?:{alternation})")
    out = []
    last = 0
    counter = {}
    for m in pattern.finditer(segment):
        s, e = m.start(), m.end()
        # 是否有“单个”前导/尾随反引号 —— 单个的定义：紧邻且不与其它反引号连成串
        lead_single = (s-1 >= 0 and segment[s-1] == '`' and (s-2 < 0 or segment[s-2] != '`'))
        trail_single = (e < len(segment) and segment[e] == '`' and (e+1 >= len(segment) or segment[e+1] != '`'))

        # append the text before match, 如果要吞前导单反引号则不包含它
        if lead_single:
            out.append(segment[last:s-1])
        else:
            out.append(segment[last:s])

        account = m.group(0)[1:]
        uid = called_account_dict.get(account, {}).get('uid')
        if not uid:
            # 没有 uid 映射，保留原样（并保留单反引号）
            if lead_single:
                out.append('`')
            out.append(m.group(0))
            if trail_single:
                out.append('`')
            last = e + (1 if trail_single else 0)
            continue

        counter.setdefault(uid, 0)
        counter[uid] += 1
        cur = {"type":"midquoted","index":f"{uid}_{counter[uid]}","data":{"name":account,"scheme":f"https://weibo.com/u/{uid}"}}
        repl = f"```wbCustomBlock{json.dumps(cur, ensure_ascii=False)}```"
        out.append(repl)
        # 跳过原文本里的匹配部分，如果吞尾部单反引号则也跳过它
        last = e + (1 if trail_single else 0)

    out.append(segment[last:])
    return ''.join(out)

def process_called_account(text: str, called_account_dict) -> str:
    # 将整个文本按 triple-backtick code block 切分，code block 保留不变
    think, content = split_think_and_content(text)
    parts = re.split(r'(```.*?```)', content, flags=re.DOTALL)
    processed = []
    for part in parts:
        if part.startswith('```') and part.endswith('```') and len(part) >= 6:
            processed.append(part)   # code block 不替换
        else:
            processed.append(process_non_overlapping(part, called_account_dict))
    return think + ''.join(processed)

def format_text_from_selected_data(selected_data: dict, link_list: list):
    """从 selected_data 中获取文本格式并进行处理"""
    text = ""
    mid_to_quote = get_mid_to_quote(link_list)
    for mid in selected_data:
        if mid in mid_to_quote:
            text += f"<a>[{mid_to_quote[mid]}]</a>"
    return text

def get_single_multi_list(text:str, pic_info_dict_all: dict, link_list: list, vector_dict: dict, ready_pid_dict: dict, video_mid_dict, mid_feature_dict, query_info_dict, log_func=None):
    """获取单个所有的多模态数据"""
    ready_pid_dict["single_all_list"] = []
    _ = single_text_process(text, pic_info_dict_all, link_list, vector_dict, ready_pid_dict, video_mid_dict, mid_feature_dict, query_info_dict, log_func)
    single_all_list = ready_pid_dict.get("single_all_list", [])
    return single_all_list

def get_add_text(ready_pid_dict, single_all_list):
    """获取多模态文本"""
    special_md_key = "mediablock"
    # 修改为wbCustomBlock格式
    media_data = {
        "type" : "mediablock",
        "data" : single_all_list
    }
    ready_pid_dict.setdefault(special_md_key, [])
    cur_index = len(ready_pid_dict[special_md_key])
    cur_format_wbcustomblock = format_wbcustomblock(special_md_key, cur_index)
    ready_pid_dict[special_md_key].append({"data": media_data})
    return cur_format_wbcustomblock
