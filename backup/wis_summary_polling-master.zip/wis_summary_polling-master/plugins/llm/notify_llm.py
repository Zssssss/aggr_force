# -*- coding:utf-8 -*-
import asyncio
import json
import re
import time
import traceback

from plugins.material.material import QueryVersionMaterial, SummaryMaterial
from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.notify import NotifySummaryPrompt, NotifyVerifyPrompt
from plugins.prompt.ds import ds_factory
from api.model_api import get_deepseek_r1_model_from_weibo_sid


class NotifyLLM(DeepSeekLLM):
    """消息箱通知-明星词"""

    async def fetch_material(self):
        await asyncio.gather(
            SummaryMaterial(self.pid).run(weibo=self.weibo),
            QueryVersionMaterial(self.pid).run(weibo=self.weibo)
        )

    def make_prompt(self):
        return NotifySummaryPrompt(self.weibo)
    
    async def call_llm(self, prompt):
        try:
            q_r1_v_list = self.weibo.get("q_r1_v_list", [])
            if not q_r1_v_list:
                self.logger.info(self.pre_log_msg + f"q_r1_v_list is empty, return")
                return '无需回复'
            ds_prompt_cls = ds_factory(self.weibo)
            content = await self.call_llm_impl()
            c_list = content.split('</think>')
            if len(c_list) < 2:
                # 空字符串返回-模型出问题
                self.logger.info(self.pre_log_msg + f"content split len < 2, return")
                return '无需回复'
            content_part = c_list[1]
            thinking_part = c_list[0]
            if '无最新' in content_part or '无官方' in content_part or '无经官方' in content_part or '无符合' in content_part:
                self.logger.info(self.pre_log_msg + f"content contains '无最新' or '无官方', return")
                return '无需回复'
            if len(content_part.strip()) < 35:
                self.logger.info(self.pre_log_msg + f"conten len < 35")
                return '无需回复'
            
            self.weibo['notify_result_content'] = content_part
            verify_prompt = NotifyVerifyPrompt(self.weibo)
            sid = self.weibo.get('sid', "")
            llm_model = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "消息箱R1结果验证")
            verify_result = await llm_model.async_call(verify_prompt.prompt())
            if verify_result and isinstance(verify_result, dict):
                verify_text = verify_result.get('text', '')
                verify_label = verify_prompt.post_process(verify_text)
                if verify_label == '是':
                    self.logger.info(self.pre_log_msg + f"verify_label is 【是】, return")
                    return '无需回复'
            
            # content = "<think></think>\n\n" + content_part
            content = ds_prompt_cls.post_process(content_part)
            content = await self.filter_relevance_score(content, [], msg_box_mode=True)
            self.weibo['notify_has_res'] = True
            await self.send_response(ready='yes' if content else 'error', content=content, status_stage=4)
            return content
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"call_llm error: {traceback.format_exc()}")
            return '无需回复'


class NotifyDebugLLM(NotifyLLM):
    def __init__(self, weibo, output, pid):
        super().__init__(weibo, output, pid)
        self.weibo = weibo
        self.output = output
        self.use_struct_contentinfo = True
        self.weibo['pid'] = pid
        q_attr = self.weibo.get("q_attr", '')
        q_attr = json.loads(q_attr)
        # 取最近24小时
        now = time.time()
        start_ts = int(now - 24 * 3600)
        end_ts = int(now)
        q_attr['start_ts'] = start_ts
        q_attr['end_ts'] = end_ts
        q_attr['q_4msg_type'] = 'ip'
        q_attr['q_4msg_label'] = ''
        self.weibo['q_attr'] = json.dumps(q_attr)
        self.weibo['prompt_scene'] = 'deepseek_last'
        self.weibo['llm_name'] = 'deepseek_last'

    async def call_llm(self, prompt):
        res = await super().call_llm(prompt)
        if res == '无需回复':
            # 强制回复
            await self.send_response(ready='yes', content='当前query无需回复', status_stage=4)
        return res
