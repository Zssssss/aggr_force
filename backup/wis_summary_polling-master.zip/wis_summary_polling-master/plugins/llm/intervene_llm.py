
import copy
import time
import traceback
import json
from typing import Any
import re
from datetime import datetime

from api.model_api import get_deepseek_r1_model_from_weibo_sid
from lib.redis_utils import async_redis_client
from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.verification import VerificationPrompt


def clean_text(text):
    pattern = r'<think>.*?</think>'
    pattern1 = r'<media-block>.*?</media-block>'
    pattern2 = r'\[\^.*?\]'

    tq_pattern = r'```wbCustomBlock(\{.*?})```'
    text = re.sub(pattern, '', text, flags=re.DOTALL)
    text = re.sub(pattern1, '', text, flags=re.DOTALL)
    text = re.sub(pattern2, '', text, flags=re.DOTALL)
    text = re.sub(tq_pattern, '', text, flags=re.DOTALL)
    return text


class InterveneLLM(DeepSeekLLM):

    def rerank_weibo(self, weibo_list: list[list[dict[str, Any]]]) -> tuple[list[dict[str, Any]], list[str]]:
        top_weibo_list, other_weibo_list = [], []
        top_mid_list, other_mid_list = [], []
        seen_mids = set()  # 用于记录已经处理过的微博mid
        
        for weibo in weibo_list:
            struct_content_list = weibo.get('struct_content_list', [])
            mid_list = weibo.get('mid_list', [])
            
            for mid, item in zip(mid_list, struct_content_list):
                if mid in seen_mids:  # 如果已经处理过这个mid，跳过
                    continue
                    
                seen_mids.add(mid)  # 标记这个mid为已处理
                
                if item.get("is_good", 0) >= 1:
                    top_weibo_list.append(item)
                    top_mid_list.append(mid)
                else:
                    other_weibo_list.append(item)
                    other_mid_list.append(mid)
                    
        return top_weibo_list + other_weibo_list, top_mid_list + other_mid_list
    
    def merge_material_list(self, m_group: list[list[dict[str, Any]]]) -> list[dict[str, Any]]:
        """去重"""
        res = []
        seen = set()
        for m_list in m_group:
            for m in m_list:
                key = json.dumps(m, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    res.append(m)
        return res

    def merge_material_bool(self, m_group: list[bool]) -> bool:
        return any(m_group)
    
    def merge_material_dict(self, m_group: list[dict[Any, Any]]) -> dict[Any, Any]:
        res = {}
        for m_dict in m_group:
            res.update(m_dict)
        return res
    
    def fill_ref_table(self, link_list: list[str], content: str) -> list[dict[str, str]]:
        def _get_reference_number(text):
            # 使用正则表达式匹配<think>标签及其内容</think>
            pattern = r'<think>.*?</think>'
            # 替换匹配到的内容为空字符串
            try:
                cleaned_text = re.sub(pattern, '', text, flags=re.DOTALL)
                # a_number = re.findall(r'<a>\[\d+\]</a>', cleaned_text, flags=re.DOTALL)
                # numbers = [int(re.search(r'\d+', item).group(0)) for item in a_number]
                numbers_str = re.findall(r'\[\^(\d+)\]', cleaned_text, flags=re.DOTALL)
                numbers = [int(item) for item in numbers_str]
                # tq_pattern = r'```wbCustomBlock(\{.*?})```'
                # matches = re.findall(tq_pattern, cleaned_text, re.DOTALL)
                # numbers = []
                # for match in matches:
                #     try:
                #         dict1 = eval(match)
                #         if dict1["type"] != "quoted":
                #             continue
                #         for num in dict1["data"]["num"]:
                #             numbers.append(num)
                #     except:
                #         continue
            except:
                self.logger.warning("get_reference_number error, text:{}".format(text))
                numbers = []

            return numbers

        # mid_list = [item.split("mblogid=")[1] for item in link_list if "detail?mblogid=" in item]
        reference_nums = _get_reference_number(content)
        res = [{
            'is_ref': False,
            'is_weibo': False,
        } for _ in range(len(link_list))]
        if not reference_nums:
            return res
        try:
            for idx, reference_num in enumerate(reference_nums):
                if reference_num > len(res):
                    self.logger.warning("reference_num:{} out of range, mid_list_len:{}".format(reference_num, len(res)))
                    continue
                mid_obj = res[reference_num - 1]
                link_item = link_list[reference_num - 1]
                mid_obj['is_ref'] = True
                if "sinaweibo://detail?mblogid=" in link_item:
                    mid_obj['is_weibo'] = True
        except Exception as e:
            self.logger.warning("fill_ref_table error in for, e:{}".format(traceback.format_exc()))

        return res
    
    def process_string_array_sequential(self, string_list, start_index=1):
        """
        处理字符串数组，精确匹配并替换结果编号
        只替换 [结果 数字 begin] 和 [结果 数字 end] 中的数字
        
        Args:
            string_list: 字符串数组
            start_index: 起始编号，默认从1开始
        
        Returns:
            处理后的字符串数组
        """
        result = []
        for i, text in enumerate(string_list):
            new_index = start_index + i
            
            # 精确匹配 [结果 数字 begin] 模式
            text = re.sub(r'\[结果 \d+ begin\]', f'[结果 {new_index} begin]', text)
            
            # 精确匹配 [结果 数字 end] 模式
            text = re.sub(r'\[结果 \d+ end\]', f'[结果 {new_index} end]', text)
            
            result.append(text)
        return result
    
    def merge_material4weibo_list(self, weibo_list: list[dict]) -> dict:

        main_weibo, *other_weibo_list = weibo_list
        # 文章数量
        if 'sina_article_data' in main_weibo:
            main_weibo['sina_article_data'] = main_weibo['sina_article_data'][:3]
        for o_weibo in other_weibo_list:
            if 'sina_article_data' in o_weibo:
                o_weibo['sina_article_data'] = o_weibo['sina_article_data'][:1]
        # weibo 按照top排序
        merged_weibo = {
            # 风控信息透传
            "risk_info" : main_weibo.get("risk_info", {})
        }
        try:
            struct_content_list, mid_list = self.rerank_weibo(weibo_list)
            merged_weibo["struct_content_list"] = struct_content_list
            merged_weibo["mid_list"] = mid_list
        except Exception:
            self.logger.error(f"rerank & merge weibo error: {traceback.format_exc()}")

        for key in ['sina_article_data', 'baike_knowledge', 'history_hot_res',
                    'gaokao_agent_result', 'star_ip_result', 'current_hot_res',
                    'stock_info', 'hot_query_res', 'zs_knowledge', 'user_search_res',
                    'video_mid_list']:
            try:
                merged_weibo[key] = self.merge_material_list([weibo.get(key, []) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge list {key} error: {traceback.format_exc()}")

        for key in ['ready_pid_dict', 'pid_dup_dic', 'pic_info_dict_all', 'video_mid_dict',
                    'mid_feature_dict']:
            try:
                merged_weibo[key] = self.merge_material_dict([weibo.get(key, {}) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge dict {key} error: {traceback.format_exc()}")
        
        for key in ['blog_analysis_flag']:
            try:
                merged_weibo[key] = self.merge_material_bool([weibo.get(key, False) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge bool {key} error: {traceback.format_exc()}")
        
        return merged_weibo

    async def get_material_after_llm(self, result_with_ori_ref) -> tuple[list[str], str|None]:
        """
        param: 带有引用标签[^1]的llm结果
        """
        # 备份
        _weibo = copy.deepcopy(self.weibo)

        # llm res -> query
        self.weibo['query'] = self.weibo.get('ori_result', '')
        ori_link_list = self.weibo.get('link_list', [])
        ref_table = self.fill_ref_table(ori_link_list, result_with_ori_ref)
        ori_ds_rank_list = self.weibo.get('ds_struct_material', [])
        used_m_list = []
        for ref_dict, m_item in zip(ref_table, ori_ds_rank_list):
            if ref_dict.get('is_ref', False):
                used_m_list.append(m_item)
        used_link_list = []
        for ref_dict, link_item in zip(ref_table, ori_link_list):
            if ref_dict.get('is_ref', False):
                used_link_list.append(link_item)
        # reindex_used_m_list = self.process_string_array_sequential(used_m_list)
        used_m_list_len = len("\n\n".join(used_m_list))

        # fetch
        await self.fetch_material()
        await self.struct_material()

        # merge
        main_weibo = copy.deepcopy(_weibo)
        other_weibo_list = [self.weibo]
        weibo_list = [main_weibo] + other_weibo_list
        
        merged_weibo = self.merge_material4weibo_list(weibo_list)
        self.weibo = merged_weibo
        await self.confine_material_length(90000 - used_m_list_len)
        link_list = self.weibo.get('link_list', [])

        # 添加之前的引用
        now_ds_rank_list = merged_weibo.get('ds_struct_material', [])
        ori_now_ds_rank_list = used_m_list + now_ds_rank_list
        ori_now_ds_rank_list = self.process_string_array_sequential(ori_now_ds_rank_list)
        # 恢复self.weibo
        self.weibo = _weibo

        return used_link_list + link_list, "\n\n".join(ori_now_ds_rank_list)

    async def add_verification2material(self, v_result: str):
        """在物料中添加当前干预事实"""
        try:
            verfication_dict = json.loads(v_result)

            v_result = {
                "内容": '\n'.join(verfication_dict.get('verification_result', [])),
                "内容来源": "微博",
                "内容类型": "泛社会类干预事实",
                "发布账号类型": "媒体账号",
                "url": 'broadsocial_res://',
                "发布时间": verfication_dict.get('pub_date', ''),
            }
            self.weibo['broadsocial_res_list'] = [v_result]
            await self.confine_material_length(90000)
        except Exception as e:
            self.logger.warning(f"add_verification2material error: {e}")

    async def call_intervene(self, llm_model, prompt, result):

        sid = self.weibo.get('sid', "")
        weibo = self.weibo
        ori_link_list = copy.deepcopy(self.weibo.get("link_list", []))
        hot_social_category = weibo.get("hot_social_category", 0)
        if result and hot_social_category:
            try:
                weibo['is_intervene'] = True
                start = time.time()
                result_with_ori_ref = result
                ori_result = clean_text(result_with_ori_ref)
                self.weibo['ori_result'] = ori_result
                weibo['first_link_list'] = ori_link_list
                weibo['first_result'] = ori_result
                weibo['first_prompt'] = prompt.prompt()
                if ori_result:
                    link_list, content = await self.get_material_after_llm(result_with_ori_ref)
                    self.weibo['all_content'] = content

                    llm_model = get_deepseek_r1_model_from_weibo_sid(sid)(
                        self.weibo, self.pid, self.pre_log_msg, "可信干预知识生成")

                    begin = time.time()
                    verification_prompt = VerificationPrompt(self.weibo)
                    prompt_content = verification_prompt.prompt()
                    response = await llm_model.async_call(prompt_content)
                    await self.count_tokens(response, begin)
                    ori_verification_result = response.get("text", "")
                    verification_result = verification_prompt.post_process(ori_verification_result)
                    weibo['verification_result'] = ori_verification_result
                    weibo['verification_link_list'] = link_list
                    weibo['verification_prompt'] = prompt_content

                    if verification_result:
                        query = self.weibo.get("query", "")
                        client = async_redis_client.get_redis_server(query)
                        key = f"wis_summary_verification_{query}"
                        val = json.dumps({
                            'pub_date': datetime.now().strftime('%Y年%m月%d日'),
                            'verification_result': verification_result,
                        }, ensure_ascii=False)
                        self.logger.info(self.pre_log_msg + f"use verification result to recall llm: {val}")
                        await self.add_verification2material(val)

                        begin = time.time()
                        intervene_prompt = self.make_prompt()
                        intervene_prompt_content = intervene_prompt.prompt()
                        response = await llm_model.async_call(intervene_prompt_content)
                        await self.count_tokens(response, begin)
                        result = response.get("text", "")
                        weibo['intervene_prompt'] = intervene_prompt_content
                        weibo['intervene_result'] = result
                        weibo['intervene_link_list'] = link_list

                        # 结果写入redis
                        val = json.dumps({
                            'pub_date': datetime.now().strftime('%Y年%m月%d日'),
                            'verification_result': verification_result,
                            'result': result
                        }, ensure_ascii=False)
                        await client.set(key, val, ex=3 * 60 * 60 * 24)

                    self.logger.info(self.pre_log_msg + f"ori_result: {json.dumps(ori_result, ensure_ascii=False)} verification_result: {json.dumps(ori_verification_result, ensure_ascii=False)}, intervene_result {json.dumps(result, ensure_ascii=False)} cost: {time.time() - start}")
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"verification generate error:{e}")
        return result