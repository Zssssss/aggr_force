# -*- coding:utf-8 -*-
import json
import time
import traceback

import aiohttp

from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.ds import ds_factory
from plugins.risk_tip.risk_tip import RiskTip


class RiskTipLLM(DeepSeekLLM):
    def __init__(self, weibo, output, pid):
        super().__init__(weibo, output, pid)

    async def check_version(self):
        llm_name = self.weibo.get("llm_name", "")
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("query", "")
        start = time.time()
        url = f'http://admin.ai.s.weibo.com/api/llm/analysis_once_res.json?query={query}&trace_id={trace_id}'
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        data = res.get("data", {}).get(llm_name, {})
                        self.logger.info(self.pre_log_msg + f"fetch version cost:{time.time() - start}")
                        return trace_id == data.get('version', "")
        except Exception as e:
            self.logger.error("{} risk control error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info(self.pre_log_msg + f"fetch version cost:{time.time() - start}")
        return False

    async def run(self):
        self.weibo["debug"] = {
            "llm_name": self.weibo.get("llm_name", ""),
            "time_analysis": {"all_start": time.time(), "input_end": time.time()},
            'in_time_ms': self.weibo.get("in_time_ms", time.time()),
            'in_time': self.weibo.get('in_time', int(time.time())),
            'query_in_time': self.weibo.get('query_in_time', time.time()),
            "tokens_list": [],
        }
        self.weibo["llm_trace_info"] = []
        self.update_pre_log_msg(self.weibo)

        func_name = "RISK-TIP-LLM"
        start = time.time()
        retry = 2
        content = ""

        is_current_version = await self.check_version()
        if not is_current_version:
            self.logger.info(self.pre_log_msg + f"{func_name} is not current version")
            return

        for i in range(retry):
            try:
                prompt = ds_factory(self.weibo)
                self.weibo["debug"]["time_analysis"]["call_llm_start"] = time.time()
                risk_tip = RiskTip(self.pid)
                ori_result = await risk_tip.run(self.weibo)
                result = prompt.post_process(ori_result)
                self.weibo["debug"]["time_analysis"][f"call_cove{i}_end"] = time.time()
                if result:
                    self.weibo["debug"]["call_llm_times"] = i + 1
                    self.weibo["debug"]["time_analysis"]["call_llm_with_result_end"] = time.time()
                    json_result = self.weibo.get("json_result", {})
                    is_current_version = await self.check_version()
                    if is_current_version:
                        self.logger.info(f"{func_name} end, cost_time:{time.time() - start}\ttimes:{i + 1}\t"
                                         f"label:{self.weibo.get('label', '')}\t"
                                         f"query_category:{self.weibo.get('query_category', '')}\t"
                                         f"result:{json.dumps(result, ensure_ascii=False)}\t"
                                         f"json_result:{json.dumps(json_result, ensure_ascii=False)}\t")

                        self.weibo['result'] = result
                        await self.send_response(ready='yes', content=result)
                    break
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        self.logger.info(f"{func_name} get no result, cost_time:{time.time() - start}")
        self.weibo["debug"]["call_llm_times"] = retry
        self.weibo["debug"]["time_analysis"]["call_llm_no_result_end"] = time.time()
        self.weibo["debug"]['end_process'] = time.time()
        return content
