# -*- coding:utf-8 -*-
import asyncio
import base64
import json
import random
import re
import time
import traceback
import copy
from collections import defaultdict

import aiohttp
import requests
from aiomcache import Client
from openai import OpenAI

from alarm.alarm import alarm
from api.model_api import ModelDeepseekWrapper, HuoShanModelDeepseekWrapper, WeiboDeepseekWrapper, \
    get_deepseek_r1_model_from_weibo_sid, QWEN3_30B_ModelGaoKaoWrapper, UsersShowBatchWrapper, get_tauth_token, \
    QWEN3_30B_Wrapper, WeiboDeepseekV31Wrapper
from lib.memq import MEMQ
from lib.mongo_helper import AsyncMongoHelper
from lib.weibo_interface import get_voice, checkQualifiedOcrText
from lib.safe_convert import str_to_json, convert_to_int
from plugins.flyweight.hotsearch_bang import one_sentence_banned_dict
from plugins.llm.llm import LLM
from plugins.llm.utils import query_to_lab, McqUtils
from plugins.post_process.card_process import get_card_content_v1, remove_first_heading
from plugins.prompt.cove import cove_factory, DsCoveTruncPrompt
from plugins.prompt.ds import add_multi_modal_prompt_template
from plugins.prompt.guide_text import GuideTextPrompt
from plugins.prompt.one_sentence import OneSentencePrompt
from plugins.prompt.planning import PlanningPrompt
from plugins.prompt.reliable import ReliablePrompt
from plugins.prompt.hotsearch_abstract import HotSearchAbstractPrompt
from plugins.prompt.summarize_text import summarize_text,SummarizeTextPrompt
from plugins.recalculate.recalculate import StreamRecalculate
from plugins.regression.regression import DeepseekRegression
from plugins.risk_tip.risk_tip import RiskTip
from plugins.prompt.risk_tip import RiskTipPrompt
from plugins.material.filter import RiskLevel, USE_OFFSITE_MATERIAL, USE_ONSITE_MATERIAL
from plugins.post_process.multimodal_process import process_wbcustomblock_format, back_wbcustomblock_format, get_relevance_score, format_text_from_selected_data, get_single_multi_list, get_add_text, get_mid_to_quote
from plugins.post_process.md_special_format_process import process_special_format, back_special_format
from plugins.post_process.utils import get_paragraph_list_by_h1, split_think_and_content, get_paragraph_list_by_h1_or_above
from plugins.post_process.post_process_handler import CardOutputHandler, NewCardOutputHandler
from plugins.post_process.quote_process import delete_quote, get_weibo_mids, single_quote_process
from plugins.post_process.embding_sort import get_new_result, get_alll_text_embdings_dict, add_quote_result, remove_quote
from conf.config import MULTIMODAL_DEBUG
from plugins.material.material import HotBriefSummaryMaterial
from plugins.output.mock_output import HotSearchQuickReportOutput
from plugins.post_process.cache_multimodal import CacheMultimodal
from plugins.post_process.base_re import BaseRE
from plugins.post_process.update_click import get_card_multimodal_lab_h2
from plugins.post_process.utils import replace_first_sentence
from plugins.post_process.cache_multimodal import CacheMultimodal, ClickRateRealtime
from plugins.material.utils import Utils as MaterialUtils


#risk_tip_queue = MEMQ("wis_summary_risk_tip_queue@queue.search.weibo.com:11233")

# risk_tip_queue_key = "wis_summary_risk_tip_queue".encode('utf-8')
# risk_tip_queue = Client("queue.search.weibo.com", 11233, pool_minsize=1, pool_size=2)

query_monitor_queue_key = "wis_summary_query_monitor_queue".encode('utf8')
query_monitor_queue = Client("queue.search.weibo.com", 11233, pool_minsize=1, pool_size=2)


class DeepSeekLLM(LLM):

    async def check_result(self, result):
        actual_output = re.sub(r'<img src=[^>\n]*>', '', result)
        actual_output = re.sub(r'<video src=[^>\n]*>', '', actual_output)
        regression = DeepseekRegression(self.weibo, self.pid)
        return await regression.run(result=actual_output)

    async def compress1k(self, query, query_category, raw_time_grade, content_list,
                        content_mids, raw_material_list, need_return_struct_content):
        self.logger.warning(
            self.pre_log_msg + f"[compress1k] warning. [{query}] not compress1k")
        return [], []

    async def filter_content_viewpoint(self, query, cotent1):
        return None

    async def query_modify(self):
        start = time.time()
        session_infos = self.weibo.get('session_infos', [])
        trace_id = self.weibo.get('trace_id', "")
        ori_query = self.weibo['query']
        self.weibo['ori_query'] = ori_query
        query_category = self.weibo.get("query_category", "")

        # 账号类意图更新
        if self.weibo.get("query_category", "") in ["Account_Organization", "Account_Content", "Account_Inner"]:
            self.weibo["query_category"] = "kol"

        # 商业词
        business_query = ""
        # 新浪新闻
        weibo_client_query = ""
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                if json_data.get("flush_source", "0") == "1024" and ori_query.endswith("_sinanews"):
                    weibo_client_query = ori_query.split('_sinanews')[0]

                business_query = json_data.get("relate_theme", "")
            except Exception as e:
                self.logger.error(
                    "{} query modify {} q_attr:{}, error:{}".format(trace_id, ori_query, q_attr, e))

        if ori_query.endswith("_gaokaosp"):
            # 处理高考双拼query
            self.weibo['query'] = ori_query.split("_gaokaosp")[0]
            self.logger.info("{} gaokaosp query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))
        elif ori_query.endswith("_zhanghao"):
            # 处理账号类query
            if ori_query.endswith("_nor_zhanghao"):
                self.weibo['query'] = ori_query.split("_nor_zhanghao")[0]
                self.weibo["query_category"] = "Account_Nor"
            elif ori_query.endswith("_kol_zhanghao"):
                self.weibo['query'] = ori_query.split("_kol_zhanghao")[0]
                self.weibo["query_category"] = "kol"
            else:
                self.weibo['query'] = ori_query.split("_zhanghao")[0]
            self.logger.info("{} zhanghao query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # 明星词测试
        elif ori_query.endswith("_star_test"):
            self.weibo['query'] = ori_query.split("_star_test")[0]
            self.weibo['query_category'] = "明星"
            self.weibo['ori_query_category'] = "明星"
            self.logger.info("{} star query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # 明星百科测试
        elif ori_query.endswith("_star_baike"):
            self.weibo['query'] = ori_query.split("_star_baike")[0]
            self.weibo['query_category'] = "明星"
            self.weibo['ori_query_category'] = "明星"
            self.logger.info("{} star baike query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # card测试
        elif ori_query.endswith("_cardopt"):
            self.weibo['query'] = ori_query.split("_cardopt")[0]
            self.logger.info("{} card query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # 外显card测试
        elif ori_query.endswith("_newcard"):
            self.weibo['query'] = ori_query.split("_newcard")[0]
            self.weibo['is_newcard'] = True
            self.logger.info("{} newcard query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # new24
        elif ori_query.endswith("_new24"):
            self.weibo['query'] = ori_query.split("_new24")[0]
            self.logger.info("{} _new24 query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # 商业词
        elif business_query:
            self.weibo['query'] = business_query
            self.logger.info("{} shifan query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # 卡片目录
        elif ori_query.endswith("_mulu"):
            self.weibo['query'] = ori_query.split("_mulu")[0]
            self.logger.info("{} card mulu query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))

        # 从session_infos中获取上一次的query和zs_data，拼接成新的query
        elif session_infos:
            try:
                json_data = json.loads(session_infos)
                if json_data:
                    last_query = json_data[0].get("query", "")
                    last_result = json_data[0].get('zs_data', "")
                    if last_query:
                        self.weibo['query'] = last_query + "," + ori_query
                        self.weibo['zs_data'] = last_result
                        self.logger.info(
                            "{} session_infos query modify {} -> {}".format(trace_id, ori_query, self.weibo['query']))
            except Exception as e:
                self.logger.error(
                    "{} query modify {} error:{}".format(trace_id, ori_query, e))

        elif weibo_client_query:
            self.logger.info("{} weibo_client_query query modify {} -> {}".format(trace_id, ori_query, weibo_client_query))
            self.weibo['query'] = weibo_client_query

        elif '_ab_' in ori_query:
            modify_query, lab_n, category = query_to_lab(ori_query, query_category)
            self.weibo['query'] = modify_query
            self.weibo['manual_abtest'] = lab_n
            self.weibo['query_category'] = category
            self.weibo['ori_query_category'] = category
            self.logger.info("{} manual abtest {} query modify {} -> {}".format(trace_id, lab_n, ori_query, self.weibo['query']))

    def check_is_about_xi(self):
        """判断是否敏感"""
        about_xi = 0
        q_attr = self.weibo.get("q_attr", "")
        try:
            if q_attr:
                attr_dict = json.loads(q_attr)
                about_xi = attr_dict.get("about_xi", 0)
        except:
            about_xi = 0
        return about_xi

    def check_material(self):
        # 风控和干预
        mid_list = self.weibo.get('mid_list', [])
        if not mid_list and self.check_is_about_xi() == 1:
            self.weibo['recalc_status'] = 'nodata'
            return False

        # source = self.weibo.get("source", "")
        # if source in ['99', '999']:
        #     return True

        # diff = super().check_material()
        # llm_name = self.weibo.get("llm_name", 'qwen72b')
        # recalc_status = self.weibo.get('recalc_status', "")
        # if recalc_status == 'is_have_material_diff' and "stream" in llm_name:
        #     self.weibo['recalc_status'] = ""
        return True
    
    async def call_generate_extra_info(self):
        pass

    async def generate_hotsearch_abstract(self):
        begin = time.time()
        sid = self.weibo.get('sid', "")
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        trace_id = self.weibo.get("trace_id", "")
        content, link_list, mid_feature_dict = await self.get_hot_brief_material()
        self.weibo["hotsearch_summary_material"] = content
        self.weibo["hotsearch_summary_linklist"] = link_list
        self.weibo["hotsearch_report"] = {
            "hotsearch_summary_material" : content,
            "hotsearch_summary_linklist" : link_list,
            "mid_feature_dict" : mid_feature_dict
        }
        try:
            result = ""
            prompt = HotSearchAbstractPrompt(self.weibo)
            llm = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "热搜简报生成")
            prompt_content = prompt.prompt()
            
            # 添加重试逻辑，最多重试2次
            for retry in range(3):  # 原始1次 + 重试2次 = 总共3次
                response = await llm.async_call(prompt_content)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                result = prompt.post_process(result)
                
                # 去除前后换行符后再判断
                stripped_result = result.strip('\n')
                # 检查stripped_result长度是否大于300或者包含换行符，如果都不满足或者已经是最后一次重试，则退出循环
                if len(stripped_result) <= 300 and '\n' not in stripped_result or retry == 2:
                    break
                    
                self.logger.warning(self.pre_log_msg + f"hotsearch_abstract contains newline, retrying... attempt: {retry + 1}")
            
            self.weibo['hotsearch_abstract'] = result
            self.weibo['hotsearch_abstract_prompt'] = prompt_content
            self.logger.info(self.pre_log_msg + f"hotsearch_abstract: {result}")
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} llm error: {}, cost:{}".format(
                    query, str(e), trace_id, e, time.time() - begin))

    async def call_summarize_text(self,result):
        is_risk_control = self.weibo.get("is_risk_control", 0)
        if is_risk_control:
            return ""

        func_name = "追剧日历生成"
        start = time.time()
        query = self.weibo.get("query","")
        claims = result.split('</think>')
        sid = self.weibo.get('sid', "")
        llm_name = self.weibo.get("llm_name", "")
        if "追剧日历" in query and len(claims) == 2:
            self.weibo['summary_claim1'] = claims[1]
            llm_qwen72b = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, func_name)
            for retry in range(3):
                summarize_prompt = summarize_text(self.weibo)
                prompt_content = summarize_prompt.prompt()
                begin = time.time()
                response = await llm_qwen72b.async_call(prompt_content)
                await self.count_tokens(response, begin)
                summarize_result = response.get("text", "")
                result = summarize_prompt.post_process(summarize_result)
                self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\t"
                                                    f"summary_claim1:{json.dumps(self.weibo['summary_claim1'], ensure_ascii=False)}\t"
                                                    f"model_result:{json.dumps(summarize_result, ensure_ascii=False)}\t"
                                                    f"result:{json.dumps(result, ensure_ascii=False)}")
                if result:
                    return result
        return ""

    async def call_cove(self, result):
        is_risk_control = self.weibo.get("is_risk_control", 0)
        if is_risk_control:
            return result

        func_name = "人工事实干预"
        start = time.time()
        cove_query = self.weibo.get('cove_query', False)
        knowledge = self.weibo.get('knowledge', "").strip()
        sina_night_knowledge = self.weibo.get('sina_night_knowledge', "").strip()
        sid = self.weibo.get('sid', "")
        claims = result.split('</think>')
        if result and (knowledge or sina_night_knowledge) and len(claims) == 2:
            self.weibo['claim1'] = claims[1]
            llm_qwen72b = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, func_name)

            for retry in range(3):
                cove_prompt = cove_factory(self.weibo)
                prompt_content = cove_prompt.prompt()
                begin = time.time()
                response = await llm_qwen72b.async_call(prompt_content)
                await self.count_tokens(response, begin)
                cove_result = response.get("text", "")
                cove_result = cove_prompt.post_process(cove_result)
                self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\t"
                                                    f"claim1:{json.dumps(self.weibo['claim1'], ensure_ascii=False)}\t"
                                                    f"result:{json.dumps(cove_result, ensure_ascii=False)}")
                pattern = r'<think>(.*?)</think>'
                think_reason = re.search(pattern, result, flags=re.DOTALL)
                if think_reason:
                    think_content = think_reason.group(1)
                    cove_claims = cove_result.split('</think>')
                    if len(cove_claims) == 2:

                        # 判断是否截断
                        self.weibo['cove_result'] = cove_claims[1]
                        cove_trunc = DsCoveTruncPrompt(self.weibo)
                        prompt_content = cove_trunc.prompt()
                        response = await llm_qwen72b.async_call(prompt_content)
                        await self.count_tokens(response, begin)
                        trunc_result = response.get("text", "")
                        trunc_claims = trunc_result.split('</think>')[1]
                        if '否' in trunc_claims:
                            self.logger.info(self.pre_log_msg + f"has trunc result:{json.dumps(trunc_claims, ensure_ascii=False)}")
                            continue
                        return "<think>{}</think>{}".format(think_content, cove_claims[1])
            raise Exception("cove trunc")
        return result

    def check_is_hot_query(self):
        """判断是否为热点问题"""
        source = self.weibo.get("source", "")
        q_attr = self.weibo.get("q_attr", "")
        try:
            attr_dict = json.loads(q_attr)
            flush_source = attr_dict.get("flush_source", "")
        except:
            flush_source = ""
        if source == "3" and flush_source == "1":
            return True
        return False
    
    async def check_mid_via_redis(self):
        # copyed from plugins/prompt/risk_tip.py
        try:
            ori_all_result = self.weibo.get('ori_result', "")
            link_list = self.weibo.get("link_list", [])
            pos = ori_all_result.index("</think>")
            ori_think, ori_result = ori_all_result[:pos + 8], ori_all_result[pos + 8:]

            filtered_material_content = RiskTipPrompt.filter_material(self.weibo.get('ds_struct_material', []))
            ref_material_content, ref_pos = RiskTipPrompt.get_reference_material(ori_result, filtered_material_content)
            ref_mid_dict = RiskTipPrompt.get_ref_mid_dict(link_list, ref_pos, self.logger)
            ref_mid_label_dict = await RiskTipPrompt.get_batch_annotation_from_redis(list(ref_mid_dict.keys()), self.logger)
            if ref_mid_label_dict:
                self.logger.info(self.pre_log_msg + f"risk tips enter annotation process:{ref_mid_label_dict.keys()}")
                ref_material_content = RiskTipPrompt.make_labeld_ref_material_content_list(ref_material_content, ref_mid_label_dict, ref_mid_dict, self.logger)
                self.weibo['risk_tip_ref_m'] = ref_material_content
                return True
        except Exception:
            self.logger.error(self.pre_log_msg + "check_mid_via_redis:{}".format(traceback.format_exc()))
        return False
        

    async def check_is_need_risk_tips(self):
        """判断是否需要风险提示"""
        trace_id = self.weibo.get("trace_id", "")
        q_attr = self.weibo.get("q_attr", "")
        source = self.weibo.get("source", "")
        model = self.weibo.get("llm_name", "")
        limit_degree = self.weibo.get("limit_degree", "")
        if await self.check_mid_via_redis():
            return True
        if source == '99':
            return False
        # query风控等级BCDE不进行风险打标
        if limit_degree in ["B", "C", "D", "E"]:
            return False

        is_hot_query = self.check_is_hot_query()
        if is_hot_query:
            self.logger.info(self.pre_log_msg + "risk tips hot query")
            self.weibo['risk_tip_tag'] = 1
            return True

        if q_attr:
            try:
                json_data = json.loads(q_attr)
                if json_data.get("pv", 0) >= 50:
                    self.logger.info(self.pre_log_msg + "risk tips pv >= 50")
                    self.weibo['risk_tip_tag'] = 2
                    return True
            except Exception as e:
                self.logger.error(
                    "{} query modify {}, error:{}".format(trace_id, q_attr, e))

        # content = self.weibo.get("ori_result", "")
        # risk_list = ['争议应对', '争议焦点', '争议与说明', '争议内容', '网络争议', '争议性内容提示', '警惕',
        #              '可信度存疑的内容',
        #              '信息可信度分析', '可信度提示', '可信度存疑', '可信度评估', '风险与不确定性', '风险管控',
        #              '风险提示', '风险评估',
        #              '待验证信息', '主观推测', '群体猜测', '主观价值判断', '矛盾与辟谣', '谨慎采信', '谨慎参考']
        # for risk in risk_list:
        #     if risk in content:
        #         self.logger.info(self.pre_log_msg + "risk tips has key: {}".format(risk))
        #         self.weibo['risk_tip_tag'] = 3
        #         return True
        return False

    async def generate_risk_tips(self):
        ori_result = self.weibo.get("ori_result", "")
        if self.weibo.get("is_credential", False) and self.weibo.get("abtest", "") == "lab_k8":
            # 当本次query为封闭求证场景时(有求证可信度标签), 跳过风险评估.
            return ori_result
        if await self.check_is_need_risk_tips():
            risk_tip = RiskTip(self.pid)
            return await risk_tip.run(self.weibo)
        return ori_result

    async def calc_query_monitor(self):
        start = time.time()
        query_category = self.weibo.get("query_category", "")
        m_type4wb = ""
        if query_category == "Gossip":
            m_type4wb = "吃瓜类"
        else:
            m_type4wb = self.weibo.get("m_type4wb", "")

        data = {
            'query': self.weibo.get("query", ""),
            'traceid': self.weibo.get("traceid", ""),
            'llm_name': self.weibo.get('llm_name', ""),
            'link_list': self.weibo.get('link_list', []),
            'ori_result': self.weibo.get('ori_result', ""),
            'source': self.weibo.get('source', ""),
            'q_attr': self.weibo.get("q_attr", ""),
            "m_type4wb": m_type4wb,
            'query_category': query_category,
            'articles': self.weibo.get('monitor_article', []),
            'hot_weibo': self.weibo.get('monitor_hotweibo', []),
            'infos': self.weibo.get('monitor_info', []),
            'ds_struct_material':self.weibo.get('ds_struct_material', []),
            "mid_uid": self.weibo.get("mid_uid", ""),
            'bigv': self.weibo.get("monitor_bigv", []),
            'uid_list': self.weibo.get("monitor_uids", []),
        }

        try:
            res = await query_monitor_queue.set(query_monitor_queue_key, json.dumps(data).encode('utf8'))
        except Exception as e:
            res = 'error'
            self.logger.error(self.pre_log_msg + f"calc_query_monitor error:{traceback.format_exc()}")

        self.logger.info(self.pre_log_msg + f"calc_query_monitor cost:{time.time() - start}\tres:{res}")

    async def call_modify_star_titles_llm(self, titles: list[str]) -> list[str] :
        """批量调用LLM处理多个明星相关标题"""
        prompt_template = '''给定一到多个明星相关的标题，逐个对其进行概括大意，要求如下：
    1. 输出字数不要超过6个
    2. 专有名词如果过长可以使用通用词语代替，例如影视，音乐，综艺等
    3. 保证改写后的内容与输入大致意思一致或者能包含输入内容的主要信息
    4. 输出内容不要有标点符号

    输入：
    {}

    输出格式为：
    ```json
    {}
    ```'''

        # 构建输入和预期输出格式
        s_input = "{"
        s_output = "{"
        for i, title in enumerate(titles) :
            s_input += f'"输入{i + 1}":"{title}", '
            s_output += f'"输出{i + 1}":"第{i + 1}个标题修改后的内容", '
        s_input = s_input.rstrip(', ') + "}"
        s_output = s_output.rstrip(', ') + "}"

        prompt = prompt_template.format(s_input, s_output)

        func_name = "CALL-MODIFY-STAR-TITLE-LLM-BATCH"
        start = time.time()
        result = {}
        try :
            llm_model = QWEN3_30B_ModelGaoKaoWrapper(self.weibo, self.pid, self.pre_log_msg, "处理多个明星相关标题")
            response = await llm_model.async_call(prompt)
            text = response.get("text", "")
            _, content = split_think_and_content(text)  # 分离思考与内容
            # 提取JSON段
            re_search = re.compile(r"```json\n(.*?)\n```", re.DOTALL)
            search = re_search.search(content)
            if search :
                json_str = search.group(1).strip()
                result = json.loads(json_str)
        except Exception as e :
            self.logger.error(self.pre_log_msg + f"{e} {traceback.format_exc()}")

        cost_time = time.time() - start
        self.logger.info(
            self.pre_log_msg + f"{func_name}, cost_time: {cost_time}, titles: {titles}, result: {json.dumps(result, ensure_ascii=False)}"
        )

        # 根据结果构建输出标题列表，顺序与输入保持一致
        new_titles = [result.get(f"输出{i + 1}", "") for i in range(len(titles))]
        return new_titles

    async def star_title_modify(self) :
        emphasis_tag = self.weibo.get("emphasis_tag", [])
        title_list = [item.get("text") for item in emphasis_tag if item.get("text")]

        if not title_list :
            return

        # 拆分：短标题 vs 长标题
        short_results = []
        long_titles = []
        long_index_map = {}  # 记录长标题在原列表中的位置

        for idx, title in enumerate(title_list) :
            # 汉字、英文混合计数，按字符数处理
            if len(title) <= 6 :
                short_results.append((idx, title))  # (原索引, 原文)
            else :
                long_index_map[len(long_titles)] = idx  # 模型输入序号 -> 原列表索引
                long_titles.append(title)

        # 调用大模型进行改写（仅对长标题）
        modify_results = []
        if long_titles :
            modify_results = await self.call_modify_star_titles_llm(long_titles)

        # 组合新结果
        final_results = [""] * len(title_list)
        for idx, title in short_results :
            final_results[idx] = title
        for i, new_title in enumerate(modify_results) :
            orig_idx = long_index_map.get(i)
            if orig_idx is not None :
                final_results[orig_idx] = new_title

        # 回填结果到原始结构中
        for item, new_text in zip(emphasis_tag, final_results) :
            if new_text :
                item["text"] = new_text

        self.weibo["emphasis_tag"] = emphasis_tag

    async def update_multi_list_and_paragraph_list(self, paragraph_list, multi_list, block_dict):
        """更新multi_list和paragraph_list"""
        # 平铺获取所有多模态
        all_multi_list = [single for item in multi_list for single in item]
        if len(all_multi_list) < 2:
            return
        # 根据策略获取外显多模态
        hot_social_category = self.weibo.get("hot_social_category", 0)
        query = self.weibo.get("query", "")
        if hot_social_category:
            final_card_multi = await get_card_multimodal_lab_h2(self.weibo, self.pid, query, all_multi_list)
        else:
            context = {
                "ready_pid_dict": {"all_ready_list": all_multi_list},
                "abtest_label": "",
                "weibo_update_dict": {}
            }
            CardOutputHandler(self.pid).handle("", context)
            final_card_multi = context["weibo_update_dict"].get("card_multimodal", {}).get("data", [])
        # 取出来外显多模态
        card_multi = final_card_multi[:3]
        all_ready = [[item.get("cur_mid"), item.get("img_pid")] for item in card_multi]
        # 放到第一段最前面
        for index, cur_list in enumerate(multi_list):
            new_list = []
            for item in cur_list:
                mid = item.get("cur_mid")
                pid = item.get("img_pid")
                if [mid, pid] not in all_ready:
                    new_list.append(item)
            if index == 0:
                new_list = card_multi + new_list
            multi_list[index] = new_list
        # 更新引文
        link_list = self.weibo.get("link_list", [])
        mid_to_quote = get_mid_to_quote(link_list)
        pattern = re.compile(r"\[\^多模态_quoted_(\d+)\]")
        up_text = paragraph_list[0] if len(paragraph_list) > 0 else ""
        nums = []
        search = pattern.search(up_text)
        quote_list = block_dict.get("quoted", [])
        if search:
            ori_text = search.group(0)
            up_text = up_text.replace(ori_text, "")
            cur_num = int(search.group(1))
            if cur_num < len(quote_list):
                nums = quote_list[cur_num].get("data", {}).get("data", {}).get("num", [])
        for cur_dict in card_multi:
            mid = cur_dict.get("cur_mid", "")
            if mid and mid in mid_to_quote:
                nums.append(mid_to_quote[mid])
        cur_text = ""
        if nums:
            for num in nums:
                cur_text += f"<a>[{num}]</a>"
            single_ready_quote = set()
            mid_feature_dict = self.weibo.get("mid_feature_dict", {})
            ready_text_dict = self.weibo.get("ready_pid_dict", {})
            cur_text = single_quote_process(cur_text, 1000, link_list, mid_feature_dict, ready_text_dict, single_ready_quote, None)
        up_text += cur_text
        if len(paragraph_list):
            paragraph_list[0] = up_text

    async def filter_relevance_score(self, text, kyes=["final_card_multi_t10"], msg_box_mode=False):
        """通过相关度过滤多模态信息"""
        # 避免循环导入，先导入markdown_to_plain
        from plugins.llm.annotation_llm import markdown_to_plain

        def format_relevance_text(relevance_info):
            mid_text = relevance_info.get("mid_text", "")
            for key in ["abstract", "title", "keywords"]:
                value = relevance_info.get(key, "")
                if value:
                    mid_text += f"<{key}>{value}"
            return mid_text

        def format_media_block(media_data, msg_box_mode=False):
            """多模态格式"""
            if msg_box_mode:
                return f"```wbCustomBlock{json.dumps(media_data, ensure_ascii=False)}```"
            media_list = media_data.get("data", [])
            media_str_list = []
            for media in media_list:
                img_pid = media.get("img_pid", "")
                video_url = media.get("video_url", "")
                user_avatar = media.get("user_avatar", "")
                user_name = media.get("user_name", "")
                cur_type = media.get("type", "")
                cur_scheme = media.get("scheme", "")
                img_url = media.get("img", "")
                h = media.get("h", "")
                w = media.get("w", "")
                user_info = f'<span class="vator" style="display: none;background: url({user_avatar}) no-repeat;background-size: contain;"></span><span class="nick" style="display: none">{user_name}</span>'
                cur_media = ""
                if cur_type == "p":
                    if MULTIMODAL_DEBUG:
                        cur_media = f'<img src="http://bj.service.t.sinaimg.cn/middle/{img_pid}">'
                    else:
                        cur_media = f'<div data-type="p" data-scheme="{cur_scheme}">{user_info}<img src="{img_url}" data-width={h} data-height={w}></div>'
                    media_str_list.append(cur_media)
                elif cur_type == "v":
                    if MULTIMODAL_DEBUG:
                        cur_media = f'<video src="{video_url}">'
                    else:
                        cur_media = f'<div data-type="v" data-scheme="{cur_scheme}"><span class="arrow"></span>{user_info}<img src="{img_url}" data-width={h} data-height={w}></div>'
                    media_str_list.append(cur_media)
            if MULTIMODAL_DEBUG:
                return "<imgs-videos>" + "".join(media_str_list) + "</imgs-videos>"
            return "<media-block>" + "".join(media_str_list) + "</media-block>"      

        def generate_numeric_id(length=22):
            return ''.join(random.choices('0123456789', k=length))
        
        async def update_card(pid, new_all_ready_list, ready, query, trace_id, need_card, abtest_label):
            """更新外显和分享card"""
            context = {
                "query": query,
                "trace_id": trace_id,
                "ready": ready,
                "ready_pid_dict": {"all_ready_list": new_all_ready_list},
                "abtest_label": abtest_label,
                "weibo_update_dict": {}
            }
            if need_card and ready:
                self.logger.info(self.pre_log_msg + f"update_card_new, need_card={need_card}")
                await NewCardOutputHandler(pid).handle("", context)
            else:
                CardOutputHandler(pid).handle("", context)
            return context
        text = await self.add_emb_multi(text, kyes)
        think, content = split_think_and_content(text)
        content = content.strip()
        if not content:
            return text
        start = time.time()
        need_score = False
        # if self.weibo.get("basemodel", "") == "实验组1":
        #     need_score = True
        need_card = False
        # if self.weibo.get("basemodel", "") == "实验组2" and self.check_is_hot_query():
        #     need_card = True
        query = self.weibo.get("query", "")
        trace_id = self.weibo.get("trace_id", "")
        ready = self.weibo.get("output_all_ready", False)
        prompt_scene = self.weibo.get("prompt_scene", "")
        mid_feature_dict = self.weibo.get("mid_feature_dict", {})
        ready_pid_dict = self.weibo.setdefault("ready_pid_dict", {})
        relevance_score = ready_pid_dict.setdefault("relevance_score", {})
        # 明星卡片参数初始化
        self.weibo.setdefault("celebrity_news", [])
        # 先去除多模态信息和特殊格式的markdown格式
        content, block_dict = process_wbcustomblock_format(content, ready, self.logger)
        multi_data = copy.deepcopy(ready_pid_dict.get("mediablock", []))
        content, spe_md_dict = process_special_format(content)
        pre_list = []
        # 通过标题分段
        paragraph_list = get_paragraph_list_by_h1_or_above(content)
        paragraph_list = pre_list + paragraph_list
        re_multi = re.compile(r"\[\^多模态_mediablock_(\d+)\]")
        relevance_dict = {}
        multi_list = []
        before_count_list = []
        if ready:
            end_content = ""
        else:
            end_content = "\n" + re_multi.sub("", paragraph_list[-1])
            paragraph_list = paragraph_list[:-1]
        for pid, paragraph in enumerate(paragraph_list):
            all_multi = re_multi.findall(paragraph)
            paragraph = re_multi.sub("", paragraph)
            paragraph_list[pid] = paragraph.rstrip("\n -")
            cur_data_list = []
            for multi in all_multi:
                multi = int(multi)
                if multi >= len(multi_data):
                    continue
                current_data = multi_data[multi]["data"].get("data", [])
                cur_data_list.extend(current_data)
                before_count_list.append({"before": len(current_data)})
            if len(cur_data_list) > 0:
                # 根据点击率排序
                cur_data_list.sort(key=lambda x: x["click_rate"], reverse=True)
            for cur_data in cur_data_list:
                cur_mid = cur_data.get("cur_mid", "")
                relevance_info = mid_feature_dict.get(cur_mid, {}).get("relevance_info", {})
                cur_mid_text = format_relevance_text(relevance_info)
                single_all_text = cur_data.pop("single_all_text", "")
                if cur_mid not in relevance_score and cur_mid_text and single_all_text:
                    relevance_dict[cur_mid] = [cur_mid_text, single_all_text]
            multi_list.append(cur_data_list)

        # 获取relevance_score
        if relevance_dict and need_score:
            cur_id = generate_numeric_id()
            new_relevance_score = await get_relevance_score(cur_id, relevance_dict)
            if "error" in new_relevance_score:
                self.logger.error(self.pre_log_msg + f"fetch relevance score id: {cur_id}, error: {json.dumps(new_relevance_score, ensure_ascii=False)}")
                new_relevance_score = {cur_mid: 2 for cur_mid in relevance_dict}
            self.logger.info(self.pre_log_msg + f"fetch relevance score end, cost_time: {time.time() - start}, id: {cur_id},"
                f"newscore len/relevance list len: {len(new_relevance_score)}/{len(relevance_dict)}, new_relevance_score: {json.dumps(new_relevance_score, ensure_ascii=False)}")
            relevance_score.update(new_relevance_score)
        
        # 通过相关性过滤多模态信息
        filtered_mid = []
        all_ready_list = []
        count_list = []
        # 明星卡片中已使用的多模态
        used_multi_set = set()
        # 收集所有物料中的多模态数据，用于明星卡片需求
        all_material_multi = []
        if self.weibo.get("query_category", "") == "明星" or self.weibo.get("da_intention", ""):
            for new_item in self.weibo["celebrity_news"]:
                if new_item.get("multimodal", {}):
                    used_multi_set.add(new_item["multimodal"]["cur_mid"])

            for multi_item in multi_data:
                current_data = multi_item.get("data", {}).get("data", [])
                all_material_multi.extend(current_data)
        # 明星卡片标题统计
        celebrity_title_count = 0
        for pid, paragraph in enumerate(paragraph_list):
            new_cur_data_list = []
            count_dict = {"before": len(multi_list[pid])}
            for cur_data in multi_list[pid]:
                cur_mid = cur_data.get("cur_mid", "")
                cur_pid = cur_data.get("img_pid", "")
                score = relevance_score.get(cur_mid, 1)
                if cur_mid not in relevance_score and need_score:
                    self.logger.info(self.pre_log_msg + f"no relevance score: {cur_mid}")
                if score < 0.401:
                    if cur_mid in relevance_dict:
                        self.logger.info(self.pre_log_msg + f"【small relevance_score】: {cur_mid}, relevance_score: {score}, relevance_dict: {json.dumps(relevance_dict[cur_mid], ensure_ascii=False)}")
                    filtered_mid.append(cur_mid)
                    continue
                cur_data["scheme"] += f"&multi_paragraph={pid}&multi_count={len(new_cur_data_list)}"
                new_cur_data_list.append(cur_data)
            count_dict["after"] = len(new_cur_data_list)
            count_list.append(count_dict)

            # 明星卡片需求：查找带有emphasis_tag标记的段落，提取前三个作为明星卡片内容
            re_multi_celebrity = re.compile(r"\[\^多模态_emphasis_tag_(\d+)\]")
            search = re_multi_celebrity.search(paragraph)
            if (self.weibo.get("query_category", "") == "明星" or self.weibo.get("da_intention", "")) and len(self.weibo["celebrity_news"]) < 3 and search:
                # 获取段落索引
                index = int(search.group(1))
                # 去除首个标题
                processed_paragraph = remove_first_heading(paragraph)
                # 段落合并
                processed_paragraph = get_card_content_v1(processed_paragraph).replace("\n","").strip()
                # 去除引用和多模态标记
                processed_paragraph = remove_quote(processed_paragraph)
                # 额外清理：过滤结果字符串、删除空括号、代码块处理
                processed_paragraph = delete_quote(processed_paragraph)
                # 去除markdown格式
                processed_paragraph = markdown_to_plain(processed_paragraph)
                # 优先使用当前标题下的第一个多模态，若无则从物料中取第一个未展现的多模态
                selected_multimodal = {}
                if new_cur_data_list:
                    selected_multimodal = new_cur_data_list[0]
                    # 标记为已使用
                    used_multi_set.add(selected_multimodal["cur_mid"])
                else:
                    # 从物料中找第一个未使用的多模态
                    for material_multi in all_material_multi:
                        if material_multi["cur_mid"] not in used_multi_set:
                            selected_multimodal = material_multi
                            used_multi_set.add(material_multi["cur_mid"])
                            break
                cur_content = {"content": processed_paragraph, "multimodal": selected_multimodal, "id": f"emphasis-tag-{index}"}
                # 流式输出时，如果已存在对应索引的内容则更新，否则添加
                if celebrity_title_count < len(self.weibo["celebrity_news"]):
                    self.weibo["celebrity_news"][celebrity_title_count] = cur_content
                else:
                    self.weibo["celebrity_news"].append(cur_content)
                    celebrity_title_count += 1

            if not new_cur_data_list:
                continue
            media_data = {
                "type": "mediablock",
                "data": new_cur_data_list
            }
            all_ready_list.extend(new_cur_data_list)
            paragraph_list[pid] += format_media_block(media_data, msg_box_mode=msg_box_mode)
        content = "\n".join(paragraph_list) + end_content
        content = back_special_format(content, spe_md_dict)
        content = back_wbcustomblock_format(content, block_dict)
        abtest_label = self.weibo.get("abtest_label", "")
        new_context = await update_card(self.pid, all_ready_list, ready, query, trace_id, need_card, abtest_label)
        self.weibo["ready_pid_dict"]["all_ready_list"] = all_ready_list
        self.weibo.update(new_context["weibo_update_dict"])
        if self.weibo.get("output_all_ready", False):
            self.logger.info(self.pre_log_msg + f"filter_relevance_score end, cost_time: {time.time() - start}, filtered mid: {filtered_mid}")
            self.logger.info(self.pre_log_msg + f"【merge count info】: prompt_scene: {prompt_scene}, need_score: {need_score}, total: {len(paragraph_list)}, count: {json.dumps(count_list)}")
            self.logger.info(self.pre_log_msg + f"【merge before count info】: prompt_scene: {prompt_scene}, need_score: {need_score}, total: {len(before_count_list)}, count: {json.dumps(before_count_list)}")
            if need_score:
                self.logger.info(self.pre_log_msg + f"【small relevance_score】: filtered/lefted: {len(filtered_mid)}/{len(all_ready_list)}")
        return think + "\n" + content

    async def update_user_feature_dict(self):
        user_feature_dict = self.weibo.get("user_feature_dict", {})
        user_list = []
        for key, value in user_feature_dict.items():
            if not value.get("uid"):
                user_list.append(key)
        if user_list:
            new_user_feature_dict = await UsersShowBatchWrapper(self.pid, self.pre_log_msg).async_call(user_list)
            user_feature_dict.update(new_user_feature_dict)
            self.logger.info(self.pre_log_msg + f"【update_user_feature_dict】: update_length: {len(user_list)}, user_feature_dict: {json.dumps(user_feature_dict, ensure_ascii=False)}")
            self.weibo["user_feature_dict"] = user_feature_dict

    async def calc_planning(self, llm_model):
        prompt_scene = self.weibo.get("prompt_scene", "")
        if prompt_scene in ['deepseek', 'deepseek_stream']:
            try:
                begin = time.time()
                self.weibo["debug"]["time_analysis"][f"calc_planning_start"] = time.time()
                prompt = PlanningPrompt(weibo=self.weibo)
                prompt_content = prompt.prompt()
                response = await llm_model.async_call(prompt_content)
                await self.count_tokens(response, begin)
                ori_result = response.get("text", "")
                result = prompt.post_process(ori_result)
                self.weibo["debug"]["time_analysis"][f"calc_planning_end"] = time.time()
                self.logger.info(self.pre_log_msg + f"calc_planning len: {len(result)},  result: {json.dumps(result, ensure_ascii=False)}")
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"calc_planning error: {e}")

    async def fetch_mid_pic_v3(self, semaphore, session, query, mid, url):
        result = {}
        try:
            async with semaphore:
                async with session.get(url, params={"query": query, "mids": mid}) as response:
                    res_data = await response.json()
                    for data in res_data["data"]:
                        mid = data["mid"]
                        pids = data.get("pids", [])
                        if pids:
                            result[mid] = pids
                    return result
        except Exception as e:
            err = traceback.format_exc()
            self.logger.error(self.pre_log_msg + f"fetch_mid_pic error: {query} {mid} {err}")
        return result

    async def check_is_hot_flow(self, query):
        url = "http://10.133.12.196:17933/caibian/check_hot_flow/single"
        timeout = aiohttp.ClientTimeout(total=0.5)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, params={"query": query}) as response:
                    res_data = await response.json()
                    is_hot_flow = res_data.get("data", {}).get("is_hot_flow", "0")
                    if is_hot_flow == "1":
                        return True
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"check_is_hot_flow error: {e}")
        return False

    async def get_up_card_multi(self, query):
        url = "http://10.133.12.196:17933/v3/caibian/query_pid"
        timeout = aiohttp.ClientTimeout(total=0.5)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, params={"query": query}) as response:
                    res_data = await response.json()
                    return res_data
        except Exception as e:
            self.logger.warning(self.pre_log_msg + f"fetch_up_card_multi error: {e}")
        return {}

    async def get_final_card_multi(self, query, num=6):
        url = "http://10.133.12.196:17933/v3/caibian/zhisou_pid"
        timeout = aiohttp.ClientTimeout(total=0.5)
        result = {}
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, params={"query": query, "num": num}) as response:
                    res_data = await response.json()
                    for data in res_data["data"]:
                        mid = data["mid"]
                        pids = data.get("pids", [])
                        if pids:
                            result[mid] = pids
                    return result
        except Exception as e:
            self.logger.warning(self.pre_log_msg + f"get_final_card_multi error: {e}")
        return {}

    async def get_final_card_multi_new(self, query):
        url = "http://10.133.12.196:17933/v4/caibian/zhisou_pid/click_and_rate"
        timeout = aiohttp.ClientTimeout(total=0.5)
        result = {}
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, params={"query": query}) as response:
                    res_data = await response.json()
                    for data in res_data["data"]:
                        mid = data["mid"]
                        pids = data.get("pids", [])
                        if pids:
                            result[mid] = pids
                    return result
        except Exception as e:
            self.logger.warning(self.pre_log_msg + f"get_final_card_multi_new error: {e}")
        return {}

    async def get_last_multi_data(self, abtest):
        cahce_modal = CacheMultimodal(self.weibo, self.pid)
        last_data = await cahce_modal.get_cached_multi_modal(abtest)
        if not last_data:
            return {}
        last_data = cahce_modal.trans_cache_data(last_data)
        last_data = cahce_modal.filter_cache_multi_modal(abtest, last_data)
        return last_data

    async def fetch_up_card_multi(self):
        query = self.weibo.get("query", "")
        prompt_scene = self.weibo.get("prompt_scene", "")
        abtests = self.weibo.get("abtests", "")
        if prompt_scene in ['deepseek']:
            tasks = [
                self.get_final_card_multi(query, num=10),
                self.get_final_card_multi_new(query),
                self.get_last_multi_data("online")
            ]
            final_data_t10, final_data_new, last_data_online = await asyncio.gather(*tasks)

            # 更新点击率数据
            realtime_click_rate = ClickRateRealtime(self.weibo, self.pid)

            async def update_click_rate_data(data_dict) :
                async def update_one_card(mid, card_info) :
                    picture_id = card_info["pid"]
                    result = await realtime_click_rate.get_realtime_card(query, mid, picture_id)
                    click_num = result["click"]
                    expose_num = result["exp"]
                    click_rate = click_num / expose_num if expose_num else 0

                    card_info["click_rate"] = click_rate
                    card_info["card_click_num"] = click_num
                    card_info["expose_num"] = expose_num

                tasks = [
                    update_one_card(mid, card_info)
                    for mid, card_list in data_dict.items()
                    for card_info in card_list
                ]
                await asyncio.gather(*tasks)
            self.weibo["final_card_multi_t10"] = final_data_t10
            self.weibo["final_card_multi_new"] = final_data_new
            self.weibo["last_online"] = last_data_online
            self.logger.info(self.pre_log_msg + f"final_data_new success, data: {json.dumps(final_data_new, ensure_ascii=False)}")
            self.logger.info(self.pre_log_msg + f"[add_emb_multi], fetch_final_card_multi success, data: {json.dumps(final_data_t10, ensure_ascii=False)}")

    async def get_selected_data_v3(self, content, fetch_url="http://10.133.12.196:17933/v3/caibian/pic_video"):
        link_list = self.weibo.get("link_list", [])
        query = self.weibo.get("query", "")
        mid_list = get_weibo_mids(content, link_list)

        tasks = []
        selected_data = {}
        # 限制并发为 5
        semaphore = asyncio.Semaphore(5)
        timeout = aiohttp.ClientTimeout(total=2)
        step = 10
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for i in range(0, len(mid_list), step):
                mid = ",".join(mid_list[i:i+step])
                task = asyncio.create_task(self.fetch_mid_pic_v3(semaphore, session, query, mid, fetch_url))
                tasks.append(task)
            results = await asyncio.gather(*tasks)
            for result in results:
                if not result:
                    continue
                selected_data.update(result)

        return selected_data

    async def get_unsimilar_pic(self):
        query = self.weibo.get("query", "")
        url = "http://10.133.12.196:17933/v2/caibian/pic/sim_unsim"
        timeout = aiohttp.ClientTimeout(total=0.5)
        unsimilar_pic = {}
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, params={"query": query}) as response:
                    res_data = await response.json()
                    unsimilar_pic = res_data
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"get_unsimilar_pic error: {e}")
        return unsimilar_pic

    async def update_content2auto_monitor(self,content):
        context = {
            "query": self.weibo.get("query", ""),
            "trace_id": self.weibo.get("trace_id", ""),
            "picture_urls": self.weibo.get("picture_urls", []),
            "vector_dict": self.weibo.get("vector_dict", {}),
            "ready_pid_dict": self.weibo.setdefault("ready_pid_dict", {}),
            "pid_dup_dic": self.weibo.get("pid_dup_dic", {}),
            "link_list": self.weibo.get("link_list", []),
            "ready": self.weibo.get("output_all_ready", False),
            "video_mid_list": self.weibo.get("video_mid_list", []),
            "is_stream": False,
            # "pic_info_dict_all": self.weibo.get("pic_info_dict_all", {}),
            "pic_info_dict_all": {},
            # "video_mid_dict": self.weibo.get("video_mid_dict", {}),
            "video_mid_dict": {},
            # "mid_feature_dict": self.weibo.get("mid_feature_dict", {}),
            "mid_feature_dict": {},
            "ban_object": convert_to_int(str_to_json(self.weibo.get("q_attr", ""), {}).get("ban_object", 0)),
            "query_category": self.weibo.get("query_category", ""),
            "exact_account_query": self.weibo.get("exact_account_query", 0),
            "is_hot_query": self.check_is_hot_query(),
            "is_zhanghao_attention": False,
            "user_search_res": self.weibo.get("user_search_res", []),
            "user_feature_dict": self.weibo.get("user_feature_dict", {}),
            "business_link_list": self.weibo.get("business_link_list", []),
            "selected_data": self.weibo.get("selected_data", {}),
            "unsimilar_pic": self.weibo.get("unsimilar_pic", {}),
            "output_all_ready": self.weibo.get("output_all_ready", False),
            "extra_multi_modal_info": self.weibo.get("extra_multi_modal_info", {}),
            "highlight_word_list": self.weibo.get("highlight_word_list", []),
            "abtest_label": self.weibo.get("abtest_label", ""),
            "business_dict": self.weibo.get("business_dict", {}),
            "if_business_link": self.weibo.get("if_business_link", False),
            "max_click_rate": self.weibo.get("max_click_rate", 0),
            "max_click_first_sentence": self.weibo.get("max_click_first_sentence", ""),
            "da_intention": self.weibo.get("da_intention", {}),
            "is_hot_flow": self.weibo.get("is_hot_flow", False),
            "su_pv": json.loads(self.weibo.get("q_attr", "{}")).get("su_pv",0),
        }
        data = {
            "result": content,
            "weibo": context
        }

        # flag = random.randint(1, 10) == 10
        flag = True
        if flag:
            try:
                start = time.time()
                res = await McqUtils.send_mcq(data)
                self.logger.info(self.pre_log_msg + f"send to auto_monitor success :{res} cost: {time.time() - start}")
                return res
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"send to auto_monitor error: {e} cost: {time.time() - start}")
                return None
        return None

    async def update_mid_pic_selected(self, content):
        def get_sort_selected_data(cur_selected_data, key, limit=3):
            """对接口的内容进行排序，目前就点击量和点击率排序"""
            result = {}
            for mid, data_list in cur_selected_data.items():
                if key in ["click_rate", "click_num"]:
                    data_list = sorted(data_list, key=lambda x: (x["is_caibian"], x[key]), reverse=True)
                result[mid] = data_list[:limit]
            return result
        basemodel = self.weibo.get("basemodel", "")
        prompt_scene = self.weibo.get("prompt_scene", "")
        # 全量
        if not (prompt_scene == 'deepseek'):
            return
        query = self.weibo.get("query", "")
        selected_data_v4 = await self.get_selected_data_v3(content, fetch_url="http://10.133.12.196:17933/v3/caibian/pic_video/new2")
        self.weibo['selected_data_v4_rate'] = get_sort_selected_data(selected_data_v4, "click_rate")
        self.logger.info(self.pre_log_msg + f" selected_data_v4: {json.dumps(selected_data_v4, ensure_ascii=False)}")

        if not self.check_is_hot_query():
            is_hot_flow = await self.check_is_hot_flow(query)
            if not is_hot_flow:
                # 非热搜词也走检测
                await self.update_content2auto_monitor(content)
                return
        self.weibo['is_hot_flow'] = True
        start = time.time()
        unsimilar_pic, selected_data_v3, _ = await asyncio.gather(self.get_unsimilar_pic(), self.get_selected_data_v3(content), self.update_content2auto_monitor(content))
        self.weibo['selected_data_v3_num'] = get_sort_selected_data(selected_data_v3, "click_num")
        self.weibo['selected_data_ori'] = get_sort_selected_data(selected_data_v3, "click_rate")
        self.weibo['unsimilar_pic'] = unsimilar_pic
        self.logger.info(self.pre_log_msg + f"获取微博图片耗时：{time.time() - start}, unsimilar_pic: {json.dumps(unsimilar_pic, ensure_ascii=False)},"
            f" selected_data_v3: {json.dumps(selected_data_v3, ensure_ascii=False)}")

    async def call_intervene(self, llm_model, prompt, result):
        return result

    async def call_generate_reliable(self, ori_result):
        try:
            func_name = "可信度提示生成"
            start = time.time()
            sid = self.weibo.get('sid', "")
            is_reliable = self.weibo.get("is_reliable", 0)
            query = self.weibo.get("query", "")
            if is_reliable and query != "大s朋友圈备注死亡是必然的":
                llm_model = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, func_name)
                reliable_prompt = ReliablePrompt(self.weibo)
                prompt_content = reliable_prompt.prompt()
                begin = time.time()
                response = await llm_model.async_call(prompt_content)
                await self.count_tokens(response, begin)
                reliable_result = response.get("text", "")
                self.weibo['ori_reliable_result'] = reliable_result
                result = reliable_prompt.post_process(reliable_result)
                self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\t"
                                                    f"reliable_prompt:{json.dumps(prompt_content, ensure_ascii=False)}\t"
                                                    f"result:{json.dumps(reliable_result, ensure_ascii=False)}")
                if result:
                    return result
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"call_generate_reliable error: {e}")
        return ""

    async def call_generate_guide(self, ori_result):
        func_name = "引导语生成"
        start = time.time()
        is_guide = self.weibo.get("is_guide", 0)
        if is_guide:
            for i in range(2):
                try:
                    llm_model = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
                    guide_text_prompt = GuideTextPrompt(self.weibo)
                    prompt_content = guide_text_prompt.prompt()
                    begin = time.time()
                    response = await llm_model.async_call(prompt_content)
                    await self.count_tokens(response, begin)
                    guide_result = response.get("text", "")
                    result = guide_text_prompt.post_process(guide_result)
                    self.logger.info(self.pre_log_msg + f"{func_name} retry:{i} end, cost_time:{time.time() - start}\t"
                                                        f"guide_text_prompt:{json.dumps(prompt_content, ensure_ascii=False)}\t"
                                                        f"result:{json.dumps(guide_result, ensure_ascii=False)}")
                    if result and len(result) <= 100:
                        return result
                except Exception as e:
                    self.logger.error(self.pre_log_msg + f"call_generate_guide error: {e}")
        return ""

    def query_filter(self):
        is_query_filter = self.weibo.get('is_query_filter', False)
        if is_query_filter:
            self.weibo['finish_reason'] = "query_filter"
            return True
        return False

    async def func_call(self,*args):
        pass

    def if_func_call(self):
        return False

    def if_add_multi_modal(self):
        white_list = ["deepseek"]
        abtest = self.weibo.get("abtest", "")
        prompt_scene = self.weibo.get("prompt_scene", "")
        return False

    def if_business_link(self) :
        """判断并执行商业化链接逻辑，返回(是否命中商业逻辑, business_dict)"""
        white_list = ["deepseek", "deepseek_stream"]
        business_link_list = self.weibo.get("business_link_list", [])
        query = self.weibo.get("query", "")

        # 构建索引
        all_business_dict = {item.get("query") : item for item in business_link_list}
        precise_query_list = [item.get("query") for item in business_link_list if item.get("query_type") == 1]
        core_query_list = [item.get("query") for item in business_link_list if item.get("query_type") == 2]

        hit_dict = None

        # 精准匹配
        if query in precise_query_list :
            hit_dict = all_business_dict.get(query)
        else :
            # 模糊匹配
            for core_query in core_query_list :
                if core_query and core_query in query :
                    hit_dict = all_business_dict.get(core_query)
                    black_word = hit_dict.get("black_word")
                    black_word_list = black_word.split(",")
                    if query in black_word_list:
                        hit_dict = {}
                    break

        # 返回是否命中 + 对应的 business_dict
        prompt_scene = self.weibo.get("prompt_scene", "")
        is_gen_llm = prompt_scene in white_list
        return (bool(hit_dict) and is_gen_llm, hit_dict)

    async def gen_business_link(self, prompt, ori_content, business_dict):
        query = self.weibo.get("query", "")
        llm_model = QWEN3_30B_Wrapper(self.weibo, self.pid, self.pre_log_msg, "商业化链接逻辑")
        prompt_content = prompt.business_link_prompt(query, ori_content, business_dict)
        for _ in range(2):
            try :
                response = await llm_model.async_call(prompt_content)
                text = response.get("text", "")
                self.logger.info(
                    self.pre_log_msg + f"prompt: {prompt_content}\n response: {json.dumps(response, ensure_ascii=False)}"
                )
                json_dict = json.loads(text)
                break
            except Exception as e:
                json_dict = {}
                self.logger.error(self.pre_log_msg + f"gen_business_link error: {e}")
        return json_dict

    def get_last_quote(self, result):
        """获取最后一个引文"""
        def has_chinese(s: str) -> bool:
            return bool(re.search(r'[\u4e00-\u9fff]', s))

        lines = result.splitlines()
        # 1. 找到最后一行包含中文的行
        last_chinese_line = ""
        for line in reversed(lines):
            if has_chinese(line):
                last_chinese_line = line.strip()
                break
        # 2. 找出这行中所有 wbCustomBlock{...}
        blocks = re.findall(r'```wbCustomBlock(\{.*?\})```', last_chinese_line)
        block_text = ""
        nums = []
        for block in blocks:
            try:
                data = json.loads(block)
                if data.get("type") == "quoted":
                    nums = data.get("data", {}).get("num", [])
                    block_text = f"```wbCustomBlock{block}```"
            except:
                # 如果 JSON 解析失败，跳过
                continue
        if block_text:
            result = result.replace(block_text, "")
        return result, nums

    def add_final(self, result):
        """添加最终结果"""
        abtest_label = self.weibo.get("abtest_label", "")
        def log_func(msg):
            self.logger.info(self.pre_log_msg + f"[{abtest_label}], [add_final_multi]" +  msg)

        link_list = self.weibo.get("link_list", [])
        mid_feature_dict = self.weibo.get("mid_feature_dict", {})
        ready_text_dict = self.weibo.get("ready_pid_dict", {})  

        result, nums = self.get_last_quote(result)
        final_card_multi = self.get_all_mid_select(["final_card_multi_t10", "last_online"])
        only_pid_same = False
        result, multi_list, _ = self.add_single_multi(result, final_card_multi, "add_final_multi", log_func, only_pid_same=only_pid_same)
        mid_to_quote = get_mid_to_quote(link_list)
        for cur_dict in multi_list:
            mid = cur_dict.get("cur_mid", "")
            if mid and mid in mid_to_quote:
                nums.append(mid_to_quote[mid])
        cur_text = ""
        if nums:   
            for num in nums:
                cur_text += f"<a>[{num}]</a>"
            single_ready_quote = set()
            cur_text = single_quote_process(cur_text, 1000, link_list, mid_feature_dict, ready_text_dict, single_ready_quote, log_func)
        return result + cur_text

    def add_single_multi(self, result, final_card_multi, log_key, log_func=None, only_pid_same=True, add_multi_modal_num=0, limit=99):
        """在单个数据中添加多模态数据"""
        link_list = self.weibo.get("link_list", [])
        pic_info_dict_all = self.weibo.get("pic_info_dict_all", {})
        video_mid_dict = self.weibo.get("video_mid_dict", {})
        mid_feature_dict = self.weibo.get("mid_feature_dict", {})
        ready_pid_dict = self.weibo.setdefault("ready_pid_dict", {})
        all_ready_list = ready_pid_dict.get("all_ready_list", [])
        query_info_dict = {
            "query": self.weibo.get("query", ''),
            "trace_id": self.weibo.get("trace_id", ""),
            "ban_object": convert_to_int(str_to_json(self.weibo.get("q_attr", ""), {}).get("ban_object", 0)),
            "is_hot_query": self.check_is_hot_query(),
            "special_md": self.weibo.get("special_md", {}),
            "selected_data": final_card_multi,
            "unsimilar_pic": self.weibo.get("unsimilar_pic", {}),
            "business_link_list": self.weibo.get("business_link_list", []),
            "output_all_ready": True,
            "abtest_label": self.weibo.get("abtest_label", ""),
            "extra_multi_modal_info": self.weibo.get("extra_multi_modal_info", {}),
        }
        multi_list = []
        all_pid_list = [item.get("img_pid", "") for item in all_ready_list]
        for mid, pids in final_card_multi.items():
            if add_multi_modal_num > limit:
                break
            for pid_dict in pids:
                if add_multi_modal_num > limit:
                    break
                cur_pid = pid_dict.get("pid", "")
                if not cur_pid or cur_pid in all_pid_list:
                    log_func(f"[{log_key}], mid:{mid}, pid:{cur_pid} exist in all_ready_list, skip")
                    continue
                cur_final = {mid: [pid_dict]}
                cur_text = format_text_from_selected_data(cur_final, link_list)
                if not cur_text:
                    log_func(f"[{log_key}], mid:{mid}, pid:{cur_pid} not in material, skip")
                    continue
                query_info_dict["selected_data"] = cur_final
                if only_pid_same:
                    cur_ready = {"img_ready": {}, "video_ready": {}, "all_ready_list": [], "no_finger_img_num": 0, "mediablock": []}
                else:
                    cur_ready = ready_pid_dict
                cur_multi_list = get_single_multi_list(cur_text, pic_info_dict_all, link_list, {}, cur_ready, video_mid_dict, mid_feature_dict, query_info_dict, log_func)
                log_func(f"[{log_key}], mid:{mid}, pid:{cur_pid}, multi_list_len:{len(cur_multi_list)}")
                multi_list.extend(cur_multi_list)
                if cur_multi_list:
                    add_multi_modal_num += 1
        add_text = get_add_text(ready_pid_dict, multi_list)
        result += add_text
        log_func(f"[{log_key}], add_text:{add_text}, multi_list_len:{len(multi_list)}, multi_list:{json.dumps(multi_list, ensure_ascii=False)}")
        return result, multi_list, add_multi_modal_num

    def get_all_mid_select(self, keys):
        """获取所有mid"""
        result = {}
        cache_modal = CacheMultimodal(self.weibo, self.pid)
        abtest = self.weibo.get("abtest", "")
        for key in keys:
            cur_data = self.weibo.get(key, {})
            result = cache_modal.merge_multi_modal(abtest, result, cur_data)
        return result
        
    async def get_embdings(self, result):
        """获取向量"""
        def log_func(msg):
            self.logger.info(self.pre_log_msg + "[get_embdings]" +  msg)

        final_card_multi = self.get_all_mid_select(["final_card_multi_t10", "final_card_multi_new","last_online"])
        if not final_card_multi:
            return result
        _, content = split_think_and_content(result)
        content = content.strip()
        embedings_dict = await get_alll_text_embdings_dict(content, final_card_multi, log_func)
        self.weibo["embedings_dict"] = embedings_dict

    async def add_quote(self, result, keys):
        """获取引用微博"""
        abtest_label = self.weibo.get("abtest_label", "")
        def log_func(msg):
            self.logger.info(self.pre_log_msg + f"[{abtest_label}], [add_quote]" +  msg)

        final_card_multi = self.get_all_mid_select(keys)
        if not final_card_multi:
            return result
        link_list = self.weibo.get("link_list", [])
        mid_to_quote = get_mid_to_quote(link_list)
        think, content = split_think_and_content(result)
        content = content.strip()
        ori_embedings_dict = self.weibo.get("embedings_dict", {})
        cur_selected = {mid: value for mid, value in ori_embedings_dict.get("selected",{}).items() if mid in final_card_multi}
        # 更新为当次需要添加的多模态信息
        embedings_dict = copy.deepcopy(ori_embedings_dict)
        embedings_dict["selected"] = cur_selected
        # 根据余弦相似度来插入位置
        new_content_list = await add_quote_result(content, embedings_dict)
        for content_dict in new_content_list:
            mid_list = content_dict.get("mid_list", [])
            if not mid_list:
                continue
            add_text = ""
            for mid in mid_list:
                if mid not in mid_to_quote:
                    continue
                add_text += f"[^{mid_to_quote[mid]}]"
            log_func(f"add_text: {add_text}, mid_list: {mid_list}, content: {content_dict['content']}")
            content_dict["content"] += add_text
        new_content = "\n".join([item.get("content", "") for item in new_content_list])
        return think + new_content

    def filter_multimodal(self, data: dict, expose_num_limit, click_rate_limit):
        result = {}
        for mid, items in data.items():
            filtered_items = [
                item for item in items
                if item.get("expose_num", 0) >= expose_num_limit
                   and item.get("click_rate", 0) >= click_rate_limit
            ]
            if filtered_items:
                result[mid] = filtered_items
        return result

    def full_cache_multimodal(self,all_multi_list,final_card_multi):
        final_card_multi_list = CacheMultimodal.reverse_trans_cache_data(final_card_multi)
        all_multi_list_pids = [item.get("img_pid") for item in all_multi_list]
        unsame_final_card_multi_list = [item for item in final_card_multi_list if item.get("pid","") not in all_multi_list_pids]
        unsame_final_card_multi_list.sort(key = lambda x: x.get("click_rate", 0),reverse=True)
        num = 3 - len(all_multi_list_pids)
        full_all_multi_list = all_multi_list + unsame_final_card_multi_list[:num]
        return full_all_multi_list

    def standed_all_multi_list(self,all_multi_list):
        new_all_multi_list = []
        for item in all_multi_list:
            mid = item.get("cur_mid", "") or item.get("mid", "")
            type = item.get("type", "")
            trans = {
                "p":"pic",
                "v":"video"
            }
            trans_type = trans.get(type, type)
            data = {
                        "cur_mid" : mid,  # 微博ID
                        "img_pid" : item.get("img_pid", ""),  # 图片ID或视频封面图ID
                        "type" : trans_type,  # 类型：pic=图片，video=视频
                        "click_rate" : item.get("click_rate", 0), # 点击率
                        "sort_1": item.get("sort_1", 0), # 实验组点击率
                        "sort_2": item.get("sort_2", 0), # 实验组点击率
                        "click_num" : item.get("click_num", 0), # 点击量
                        "is_caibian" : 1, # 是否采编
                        "expose_num" : item.get("expose_num", 0) # 曝光量
                    }
            new_all_multi_list.append(data)
        return new_all_multi_list

    async def add_emb_multi(self, result, keys):
        """根据余弦相似度添加多模态数据"""
        abtest_label = self.weibo.get("abtest_label", "")
        def log_func(msg):
            self.logger.info(self.pre_log_msg + f"[{abtest_label}], [add_emb_multi]" +  msg)
        log_func("all is start")
        final_card_multi = self.get_all_mid_select(keys)
        if not final_card_multi:
            return result
        think, content = split_think_and_content(result)
        content = content.strip()
        ori_embedings_dict = self.weibo.get("embedings_dict", {})
        cur_selected = {mid: value for mid, value in ori_embedings_dict["selected"].items() if mid in final_card_multi}
        embedings_dict = copy.deepcopy(ori_embedings_dict)
        embedings_dict["selected"] = cur_selected
        content_list = await get_new_result(content, embedings_dict, log_func)
        add_multi_modal_num = 0
        all_multi_list = []
        
        """
        对于|xxxx|xxxx|这样的表格行
        需要将各行 mid 合并到一起，只在表格最后一行添加多模态标志
        """
        # 表格行的多模态mid
        table_mid_set = set()
        limit = 99
        for content_dict in content_list:
            mid_list = content_dict.get("mid_list", [])
            if not mid_list:
                continue

            # 表格行处理
            if content_dict.get("is_table", False):
                table_mid_set.update(mid_list)
                # 如果是最后一行表格行，合并所有表格行的 mid
                if content_dict.get("is_table_end", False):
                    mid_list = list(table_mid_set)
                    table_mid_set.clear()
                else:
                    continue
            else:
                # 如果遇到非表格行，清空表格 mid 集合（防止中间有非表格行）
                if table_mid_set:
                    table_mid_set.clear()

            single_select = {mid: final_card_multi.get(mid, []) for mid in mid_list}
            only_pid_same = False
            new_text, multi_list, add_multi_modal_num = self.add_single_multi(content_dict["ori_text"], single_select, "add_emb_multi", log_func, only_pid_same=only_pid_same, add_multi_modal_num=add_multi_modal_num, limit=limit)
            content_dict["ori_text"] = new_text
            all_multi_list.extend(multi_list)
        # if len(all_multi_list)<3:
        #     all_multi_list = self.full_cache_multimodal(all_multi_list, final_card_multi)
        final_all_multi_list = self.standed_all_multi_list(all_multi_list)
        if log_func:
            # 打印所有的 mid-pid
            mid_pid_list = [[item.get("cur_mid"), item.get("img_pid")] for item in final_all_multi_list]
            log_func(f"add_emb_multi, mid_pid_list: {json.dumps(mid_pid_list, ensure_ascii=False)}")
        new_content = "\n".join([item.get("ori_text", "") for item in content_list])
        log_func("all is end")
        return think + new_content

    def handle_json_response(self, response):
        return response

    async def call_llm_impl(self):
        func_name = "总结生成"
        start = time.time()
        sid = self.weibo.get('sid', "")
        if self.if_add_multi_modal():
            self.weibo["use_model"] = "deepseek-v3.1-terminus"
        llm_model = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt = self.make_prompt()
        prompt_content = prompt.prompt()
        self.weibo['prompt'] = prompt_content
        retry = 2
        content = ""
        error_name = ""
        await self.fetch_up_card_multi()
        user_task = asyncio.create_task(self.update_user_feature_dict())
        is_updated = False
        self.logger.info(self.pre_log_msg + "call llm")
        for i in range(retry):
            try:
                schema_index = None if i == 0 else prompt.schema_index()
                begin = time.time()
                if self.if_func_call():
                    self.weibo["if_func_call"] = True
                    response = await self.func_call(llm_model, prompt, schema_index)
                else:
                    response = await llm_model.async_call(prompt_content, schema_index)
                # 私信商业化处理
                response = self.handle_json_response(response)
                self.logger.info(self.pre_log_msg + "llm response")
                await self.count_tokens(response, begin)
                self.logger.info(self.pre_log_msg + "count tokens")
                self.weibo["output_all_ready"] = True
                ori_result = response.get("text", "")
                if_gen_business_link, business_dict = self.if_business_link()
                if if_gen_business_link:
                    ai_business_list = await self.gen_business_link(prompt, ori_result, business_dict)
                    business_dict["ai_business_list"] = ai_business_list
                    self.weibo["business_dict"] = business_dict
                    self.weibo["if_business_link"] = True
                ori_result = await self.call_intervene(llm_model, prompt, ori_result)
                self.weibo["debug"]["time_analysis"][f"call_cove{i}_start"] = time.time()
                ori_result = await self.call_cove(ori_result)
                self.weibo["debug"]["time_analysis"][f"call_cove{i}_end"] = time.time()
                self.weibo["debug"]["time_analysis"][f"call_summarize_text{i}_start"] = time.time()
                title_result = await self.call_summarize_text(ori_result)
                self.weibo["title_result"] = title_result
                self.weibo["debug"]["time_analysis"][f"call_summarize_text{i}_end"] = time.time()
                self.weibo["ori_result"] = ori_result
                reliable_result = await self.call_generate_reliable(ori_result)
                self.weibo["reliable_result"] = reliable_result
                guide_text = await self.call_generate_guide(ori_result)
                self.weibo["guide_text"] = guide_text
                await self.call_generate_extra_info()
                ori_result = await self.generate_risk_tips()
                if not is_updated:
                    await user_task
                    is_updated = True
                await self.update_mid_pic_selected(ori_result)
                # 预先根据线上获取embding
                self.weibo["abtest_label"] = ""
                if self.if_add_multi_modal():
                    self.weibo["abtest_label"] = self.weibo.get("abtest", "")
                self.weibo["ready_pid_dict"] = {}
                self.weibo['selected_data'] = self.weibo.get('selected_data_ori', {})
                prompt = self.make_prompt()
                result = prompt.post_process(ori_result)
                await self.get_embdings(result)
                ori_result = await self.add_quote(ori_result, ["final_card_multi_t10", "last_online"])
                # 线上
                self.weibo["abtest_label"] = ""
                if self.if_add_multi_modal():
                    self.weibo["abtest_label"] = self.weibo.get("abtest", "")
                self.weibo["ready_pid_dict"] = {}
                self.weibo['selected_data'] = self.weibo.get('selected_data_ori', {})
                prompt = self.make_prompt()
                result = prompt.post_process(ori_result)
                # result = self.add_final(result)
                result = await self.filter_relevance_score(result, ["final_card_multi_t10", "last_online"])
                error_name, no_error = await self.check_result(result)
                if no_error and result:
                    self.weibo["debug"]["call_llm_times"] = i + 1
                    self.weibo["debug"]["time_analysis"]["call_llm_with_result_end"] = time.time()
                    content = result
                    await asyncio.gather(
                        self.calc_question(content),
                        self.calc_query_monitor()
                    )
                    break
            except Exception as e:
                self.weibo['finish_reason'] = self.weibo.get("finish_reason", "llm_error")
                self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        if not is_updated:
            await user_task
            is_updated = True
        self.write_log(message=f"{func_name} get no result, cost_time:{time.time() - start}")
        self.weibo["debug"]["call_llm_times"] = retry
        self.weibo["debug"]["time_analysis"]["call_llm_no_result_end"] = time.time()
        self.weibo["debug"]['end_process'] = time.time()
        if self.weibo["query_category"] == "明星":
            await self.star_title_modify()
        return content

    async def _generate_hotsearch_content(self):
        try:
            hotsearch_output = HotSearchQuickReportOutput(self.pid)
            hotsearch_content = await hotsearch_output.run()
            return hotsearch_content
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"生成热搜速报内容异常, error={e}")
            return ""

    async def call_llm(self, prompt):
        # if self.query_filter():
        #     ready = "special_tips"
        #     special_tips = "抱歉，这个问题我暂时无法回答，换个问题试试吧"
        #     await self.send_response(ready=ready, content="", status_stage=4, special_tips=special_tips)
        #     return ""

        content = await self.call_llm_impl()
        await self.send_response(ready='yes' if content else 'error', content=content, status_stage=4)
        return content
    
    async def get_hot_brief_material(self) -> tuple[str, list, dict]:
        try:
            weibo_copy = copy.deepcopy(self.weibo)
            # 清理截断干扰
            weibo_copy['zs_knowledge'] = []
            weibo_copy['stock_info'] = []
            weibo_copy['star_ip_result'] = []
            weibo_copy['hot_query_res'] = []
            m_cls = HotBriefSummaryMaterial(self.pid)
            await m_cls.run(weibo=weibo_copy)
            await m_cls.struct_material(weibo_copy)
            # 替换self.weibo
            self_weibo_bak = copy.deepcopy(self.weibo)
            # update防止对象地址更改
            self.weibo.clear()
            self.weibo.update(weibo_copy)
            await self.confine_material_length()
            content, link_list = self.weibo.get('content', ''), self.weibo.get('link_list', [])
            mid_feature_dict = self.weibo.get("mid_feature_dict", {})
            # 还原self.weibo
            self.weibo.clear()
            self.weibo.update(self_weibo_bak)
            return content, link_list, mid_feature_dict
        
        except Exception:
            self.logger.error(self.pre_log_msg + f"get_hot_brief_material error:{traceback.format_exc()}")
            return "", [], {}
        
    def get_mats_length_new(
        self,
        data_groups: list,
        config_groups: list[dict],
        total_length: int,
        each_len: int = 300,  # 新增每条物料固定加成
    ):
        assert len(data_groups) == len(config_groups)

        def get_text(item, cfg):
            getter = cfg.get("content_getter", lambda x: x.get("内容", ""))
            return str(getter(item)) if getter else str(item)

        def item_len(item, cfg):
            return len(get_text(item, cfg)) + each_len  # 加上固定长度

        group_cnt = len(data_groups)
        selected = [[] for _ in range(group_cnt)]
        cur_len = 0

        def trim_group(group_idx):
            nonlocal cur_len
            cfg = config_groups[group_idx]
            while selected[group_idx] and cur_len > total_length:
                item = selected[group_idx].pop()
                cur_len -= item_len(item, cfg)

        def try_add(group_idx, item):
            nonlocal cur_len
            cfg = config_groups[group_idx]

            item_l = item_len(item, cfg)

            # 先加入
            selected[group_idx].append(item)
            cur_len += item_l

            if cur_len <= total_length:
                return True

            # 超限，裁剪当前 group
            trim_group(group_idx)

            # 裁剪后仍超限，回滚刚加入的 item
            if cur_len > total_length:
                if selected[group_idx]:
                    last = selected[group_idx].pop()
                    cur_len -= item_len(last, cfg)
                return False

            return True

        # ===== 1. 综合可见结果（group 0，整体放）=====
        for item in data_groups[0]:
            ok = try_add(0, item)
            if not ok:
                self.logger.info(
                    self.pre_log_msg + f"after get_mats_length_new len: {cur_len}"
                )
                return selected

        if cur_len >= total_length:
            self.logger.info(
                self.pre_log_msg + f"after get_mats_length_new len: {cur_len}"
            )
            return selected

        # ===== 2. 其余 group 统一轮询 =====
        pointers = [0] * group_cnt
        active_groups = list(range(1, group_cnt))

        while active_groups:
            next_round = []
            for idx in active_groups:
                if pointers[idx] >= len(data_groups[idx]):
                    continue

                ok = try_add(idx, data_groups[idx][pointers[idx]])
                pointers[idx] += 1

                if not ok:
                    self.logger.info(
                        self.pre_log_msg + f"after get_mats_length_new len: {cur_len}"
                    )
                    return selected

                # 该 group 仍有剩余，进入下一轮
                if pointers[idx] < len(data_groups[idx]):
                    next_round.append(idx)

            active_groups = next_round

        self.logger.info(
            self.pre_log_msg + f"after get_mats_length_new len: {cur_len}"
        )
        return selected



    
    def get_mats_length(self, data_groups: list, config_groups: list[dict], total_length: int):
        """
        根据配置过滤各组数据，确保总长度不超过限制。
        
        Args:
            data_groups: 包含多个数据列表的列表，每个元素对应一组数据
            config_groups: 配置列表，每个元素是一个包含处理参数的字典，包括：
                - content_getter: 获取内容的函数，如 lambda x: x.get("内容", "")
                - each_len: 每个元素的额外长度， 默认值300
                - prefered_limit: 首轮处理的优先限制数量，0表示无限制
            total_length: 总长度限制
            
        Returns:
            过滤后的数据组列表，保持原始顺序
        """
        if len(data_groups) != len(config_groups):
            raise ValueError("数据组和配置组的数量必须一致")
        each_mat_base_length = 300
        current_length = 0
        filtered_groups = []  # 存储过滤后的所有数据组
        remaining_indices = {}  # 记录需要二次处理的组的索引位置
        
        # 第一轮处理：按原始顺序处理每个数据组
        for group_idx, (data_list, config) in enumerate(zip(data_groups, config_groups)):
            content_getter = config.get('content_getter', lambda x: x.get("内容", ""))
            each_len = config.get('each_len', each_mat_base_length)
            prefered_limit = config.get('prefered_limit', 0)
            
            filtered_list = []
            processed_idx = 0
            
            # 处理当前组数据
            for idx, item in enumerate(data_list):
                # 检查优先限制
                if prefered_limit > 0 and idx >= prefered_limit:
                    break
                    
                # 获取内容并计算长度
                content = content_getter(item)
                item_length = len(str(content))
                
                # 检查是否超出总长度限制
                if (current_length + item_length + each_len) < total_length:
                    filtered_list.append(item)
                    current_length += item_length + each_len
                else:
                    break
                    
                processed_idx = idx + 1
                
            # 记录处理位置，用于后续可能的第二轮处理
            if prefered_limit > 0 or processed_idx < len(data_list):
                remaining_indices[group_idx] = processed_idx
                
            filtered_groups.append(filtered_list)
        
        # 第二轮处理：处理有优先限制但未处理完的数据组
        for group_idx, start_idx in remaining_indices.items():
            data_list = data_groups[group_idx]
            config = config_groups[group_idx]
            filtered_list = filtered_groups[group_idx]
            
            content_getter = config.get('content_getter', lambda x: x.get("内容", ""))
            each_len = config.get('each_len', each_mat_base_length)
            
            # 继续处理剩余的项目
            for idx in range(start_idx, len(data_list)):
                item = data_list[idx]
                
                # 跳过已添加的项目
                if item in filtered_list:
                    continue
                    
                content = content_getter(item)
                item_length = len(str(content))
                
                if (current_length + item_length + each_len) < total_length:
                    filtered_list.append(item)
                    current_length += item_length + each_len
        
        self.logger.info(self.pre_log_msg + f"after get_mats_length total_size: {current_length}")
        return filtered_groups

    def truncate_mats4stream_new(
        self,
        data_groups: list,
        config_groups: list[dict],
    ):
        """
        stream 场景压缩策略（简化稳定版）

        目标：
        - 总长度 <= 50000 字符
        - 严格按顺序执行，满足即停
        - 不依赖任何业务字段（type / is_kuake / use_xxx 等）
        """

        if len(data_groups) != len(config_groups):
            raise ValueError("data_groups 与 config_groups 数量不一致")
        if len(data_groups) != 10:
            raise ValueError("当前 data_groups 数量必须为 10")

        MAX_LEN = 50000
        each_mat_base_length = 300

        filtered_groups = [list(group) for group in data_groups]

        # ---------- 工具函数 ----------

        def getter(idx):
            return config_groups[idx].get("content_getter", lambda x: x.get("内容", ""))

        def calc_total_len():
            total = 0
            for i, grp in enumerate(filtered_groups):
                g = getter(i)
                for item in grp:
                    total += len(str(g(item))) + each_mat_base_length
            return total

        def pop_bottom(idx: int, min_keep: int = 0):
            nonlocal current_length
            g = getter(idx)

            while len(filtered_groups[idx]) > min_keep and current_length > MAX_LEN:
                item = filtered_groups[idx].pop()
                current_length -= len(str(g(item))) + each_mat_base_length

        # ---------- 初始长度 ----------

        current_length = calc_total_len()
        self.logger.info(
            self.pre_log_msg + f"stream compress initial new total_size={current_length}"
        )

        if current_length <= MAX_LEN:
            return filtered_groups

        # ================= 压缩开始 =================

        # 索引语义（与你当前统一版本一致）
        IDX_APP_ORDER = 0
        IDX_WEIBO_VS = 1
        IDX_ARTICLE_EXT = 2
        IDX_STOCK = 3
        IDX_USER_INFO = 4
        IDX_HISTORY_HOT = 6
        IDX_CURRENT_HOT = 7
        IDX_BAIKE = 8
        IDX_ZS = 9

        # 1️⃣ 历史热点（只保留 1）
        pop_bottom(IDX_HISTORY_HOT, min_keep=1)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 2️⃣ 股票财经
        pop_bottom(IDX_STOCK)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 3️⃣ 最近热点
        pop_bottom(IDX_CURRENT_HOT)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 4️⃣ 账号信息
        pop_bottom(IDX_USER_INFO)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 5️⃣ 删除 weibo_article_ext_list
        pop_bottom(IDX_ARTICLE_EXT)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 6️⃣ 删除 weibo_vs_list
        pop_bottom(IDX_WEIBO_VS)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 7️⃣ App 顺序物料（idx=0）自底向上删
        pop_bottom(IDX_APP_ORDER)

        self.logger.info(
            self.pre_log_msg + f"stream compress after total_size={current_length}"
        )

        return filtered_groups

    
    def truncate_mats4stream(self, data_groups: list, config_groups: list[dict], **kwargs):
        """
        计算所有物料的总长度，若总长度超过 50000，则按策略逐步收缩：
            1. 一般博文、一般文章/网页：自底向上删除；
            2. 历史热点：自底向上删除至只保留 1 条；
            3. 优质网页（夸克来源）：自底向上删除至只保留 1 条；
        若仍超过 50000，则不再执行。
        
        Args:
            data_groups: 各组数据的列表，如 [zs_knowledge_list, stock_info_list, ...]
            config_groups: 各组对应的配置列表，如 [{"content_getter": lambda x: x.get("内容", "")}, ...]
            
        Returns:
            收缩后的数据组列表（保持原始顺序）
        """
        if len(data_groups) != len(config_groups):
            raise ValueError("数据组和配置组的数量必须一致")
        if len(data_groups) != 13:
            raise ValueError("数据组和配置组的数量必须为13才能保证取值索引")

        each_mat_base_length = 300

        # --- 初始阶段：不过滤，全部纳入 ---
        filtered_groups = [list(group) for group in data_groups]

        # --- 计算总长度 ---
        def calc_total_len(groups):
            total = 0
            for i, grp in enumerate(groups):
                getter = config_groups[i].get('content_getter', lambda x: x.get("内容", ""))
                for item in grp:
                    total += len(str(getter(item))) + each_mat_base_length
            return total

        current_length = calc_total_len(filtered_groups)
        self.logger.info(self.pre_log_msg + f"use compress with initial total_size: {current_length}")

        # --- 🚨 超过 50000 时执行收缩策略 ---
        if current_length > 50000:
            self.logger.info(self.pre_log_msg + f"total_length {current_length} > 50000, apply shrinking strategy")

            # 索引定义（按你的 data_groups 顺序）
            idx_other_article = 10   # 一般文章/网页
            idx_other_weibo = 9      # 一般博文
            idx_history_hot = 8      # 历史热点
            idx_top_article = 5      # 优质网页（夸克来源）

            # Step 1️⃣ 一般博文、一般文章/网页 自底向上删除
            for idx in [idx_other_article, idx_other_weibo]:
                while filtered_groups[idx] and current_length > 50000:
                    item = filtered_groups[idx].pop()
                    getter = config_groups[idx].get('content_getter', lambda x: x.get("内容", ""))
                    current_length -= len(str(getter(item))) + each_mat_base_length

            # Step 2️⃣ 历史热点 自底向上删到只剩 1 条
            if current_length > 50000 and len(filtered_groups[idx_history_hot]) > 1:
                while len(filtered_groups[idx_history_hot]) > 1 and current_length > 50000:
                    item = filtered_groups[idx_history_hot].pop()
                    getter = config_groups[idx_history_hot].get('content_getter', lambda x: x.get("内容", ""))
                    current_length -= len(str(getter(item))) + each_mat_base_length

            # Step 3️⃣ 优质网页 自底向上删到只剩 1 条
            if current_length > 50000 and len(filtered_groups[idx_top_article]) > 1:
                while len(filtered_groups[idx_top_article]) > 1 and current_length > 50000:
                    item = filtered_groups[idx_top_article].pop()
                    getter = config_groups[idx_top_article].get('content_getter', lambda x: x.get("内容", ""))
                    current_length -= len(str(getter(item))) + each_mat_base_length

            self.logger.info(self.pre_log_msg + f"after shrink total_size: {current_length}")

        return filtered_groups

    def filter_materil_by_time_range4notify(self):
        """明星词、IP词按时间范围过滤： weibo/history"""
        def get_weibo_ts(mid: str) -> int:
            try:
                un_time = (int(mid) >> 22) + 515483463
                return un_time
            except Exception as e:
                return 0
        now = int(time.time())
        struct_weibo_list = self.weibo.get('struct_content_list', [])
        mid_list = self.weibo.get('mid_list', [])
        if len(struct_weibo_list) != len(mid_list):
            self.logger.error(self.pre_log_msg + f"filter_material_by_time_range4star struct_weibo_list: {len(struct_weibo_list)} != mid_list: {len(mid_list)}")
            return
        
        valid_start_ts, valid_end_ts = now - 3600 * 24, now

        res_weibo_list = []
        for mid, item in zip(mid_list, struct_weibo_list):
            mid_ts = get_weibo_ts(mid)
            if mid_ts >= valid_start_ts and mid_ts <= valid_end_ts:
                res_weibo_list.append(item)
        self.logger.info(self.pre_log_msg + (f"before filter_materil_by_time_range4star"
                                            f"\tweibo: {len(struct_weibo_list)}"
                                            "\tafter:"
                                            f"\tweibo: {len(res_weibo_list)}"
                                            ))

        self.weibo['struct_content_list'] = res_weibo_list
        # 只保留微博
        for k in ['baike_knowledge',
                  'history_hot_res',
                  'sina_article_data',
                  'zs_knowledge',
                  'ctr_res_list',
                  'broadcast_res_list',
                  'user_search_res']:
            self.weibo[k] = []

    async def confine_material_length(self,base_length=90000, use_compress=False):
        """
        对物料信息排序 + 做长度限制

        排序规则：泛社会类干预事实> 智搜知识库 > 股票财经 > 明星作品优化 > 热点榜单 > 优质博文  > 优质文章
                > 全部百科 > 高考agent物料 > 全部历史热点 > 一般博文 > 一般文章 > 账号信息 > 最近热点
        """
        if self.weibo.get('m_use_new_format', False):
            return await self.confine_material_length_new()
        # D级风控物料过滤
        if self.weibo.get("limit_material"):
            self._filter_material_by_risk_level()
        use_zhisou = False
        model = self.weibo.get("llm_name", 'qwen72b')
        account_content_list = []
        content_list = self.get_target_weibo()
        opinion_list = []
        label = self.weibo.get("label", "")
        query_type = self.weibo.get("query_type", "")
        prompt_scene = self.weibo.get("prompt_scene", "")
        q_attr = self.weibo.get('q_attr', '{}')
        q_attr_dict = json.loads(q_attr)
        comment_from_type = q_attr_dict.get('comment_from_type', '')
        if prompt_scene == 'verification_comment' and comment_from_type != 'active_comment':
            use_compress = True
        elif prompt_scene == 'deepseek_stream':
            use_compress = True
        if prompt_scene == 'deepseek_last':
            self.filter_materil_by_time_range4notify()
        knowledge = self.weibo.get("knowledge", "")
        query_category = self.weibo.get("query_category", "")
        cove_query = False
        baike_knowledge = self.weibo.get("baike_knowledge", [])
        content_mid_list = self.weibo.get("mid_list", [])
        # sina_article_list = self.get_target_article()
        sina_article_list = self.weibo.get('sina_article_data', [])
        history_hot_list = self.weibo.get('history_hot_res', [])
        gaokao_agent_list = self.weibo.get('gaokao_agent_result', [])
        star_ip_res_list = self.weibo.get('star_ip_result', [])
        current_hot_res_list = self.weibo.get('current_hot_res', [])
        stock_info_list = self.weibo.get('stock_info', [])
        hot_query_res_sql_list = self.weibo.get('hot_query_res', [])
        zs_knowledge_list = self.weibo.get('zs_knowledge', [])
        user_search_res_list = self.weibo.get('user_search_res', [])
        ctr_res_list = self.weibo.get("ctr_res_list", [])
        broadsocial_res_list = self.weibo.get("broadsocial_res_list", [])
        is_not_sort_flag = False


        top_weibo_list = [i for i in content_list if i.get("is_good", 0) >= 1]
        other_weibo_list = [i for i in content_list if i.get("is_good", 0) == 0]
        top_article_list = [i for i in sina_article_list if i.get("is_good", 0) >= 1]
        other_article_list = [i for i in sina_article_list if i.get("is_good", 0) == 0]
        if not top_weibo_list:
            top_weibo_list = other_weibo_list
            other_weibo_list = []
        if ctr_res_list:
            if history_hot_list:
                history_hot_list[0] = ctr_res_list[0]
            else:
                history_hot_list = ctr_res_list
        
        # 泛社会干预事实->资料首位
        if broadsocial_res_list:
            info_rank_dict = {
                "zs_knowledge_list": zs_knowledge_list,
                "stock_info_list": stock_info_list,
                "star_ip_res_list": star_ip_res_list,
                "hot_query_res_sql_list": hot_query_res_sql_list,
                "gaokao_agent_list": gaokao_agent_list,
                "history_hot_list": history_hot_list,
                "user_search_res_list": user_search_res_list,
                "current_hot_res_list": current_hot_res_list,
            }

            try:
                for name, lst in info_rank_dict.items():
                    if lst:
                        lst.insert(0, broadsocial_res_list[0])
                        self.logger.info(f"broadsocial_res_list inserted into: {name}, new length={len(lst)}")
                        break
            except Exception as e:
                self.logger.error(f"broadsocial_res_list insert error: {e}")

        account_mid_len = 0
        account_content_str = ""
        opinion_str = ""

        # 明星词只保留博文、百科、历史热点
        if query_category == "明星":
            stock_info_list = []
            star_ip_res_list = []
            hot_query_res_sql_list = []
            sina_article_list = []
            top_article_list = []
            other_article_list = []
            current_hot_res_list = []
            self.logger.info(self.pre_log_msg + f"clear4star")

        
        self.logger.info(self.pre_log_msg + ("before confine_material_length: "
                                            f"[extra]content_list:{len(content_list)}\t"
                                            f"[extra]sina_article_list:{len(sina_article_list)}\t"
                                            f"zs_knowledge_list:{len(zs_knowledge_list)}\t"
                                            f"stock_info_list:{len(stock_info_list)}\t"
                                            f"star_ip_res_list:{len(star_ip_res_list)}\t"
                                            f"hot_query_res_sql_list:{len(hot_query_res_sql_list)}\t"
                                            f"top_weibo_list:{len(top_weibo_list)}\t"
                                            f"top_article_list:{len(top_article_list)}\t"
                                            f"baike_knowledge:{len(baike_knowledge)}\t"
                                            f"gaokao_agent_list:{len(gaokao_agent_list)}\t"
                                            f"history_hot_list:{len(history_hot_list)}\t"
                                            f"other_weibo_list:{len(other_weibo_list)}\t"
                                            f"other_article_list:{len(other_article_list)}\t"
                                            f"user_search_res_list: {len(user_search_res_list)}\t"
                                            f"current_hot_res_list:{len(current_hot_res_list)}"))
        data_groups = [
            zs_knowledge_list,
            stock_info_list,
            star_ip_res_list,
            hot_query_res_sql_list,
            top_weibo_list,
            top_article_list,
            baike_knowledge,
            gaokao_agent_list,
            history_hot_list,
            other_weibo_list,
            other_article_list,
            user_search_res_list,
            current_hot_res_list
        ]
        config_groups = [{} for _ in range(len(data_groups))]
        # baike特殊处理
        config_groups[6] = {"content_getter": lambda x: x}

        limited_materials = self.get_mats_length(
            data_groups=data_groups,
            config_groups=config_groups,
            total_length=base_length
        )

        if use_compress:
            limited_materials = self.truncate_mats4stream(
            data_groups=limited_materials,
            config_groups=config_groups
            )

        if self.weibo.get('xiaomi_stream', False):
            limited_materials = MaterialUtils.truncate_mats4xiaomi_stream(
                data_groups=limited_materials,
                config_groups=config_groups,
                logger=self.logger,
                pre_log_msg=self.pre_log_msg
            )
        # 解包
        (
            zs_knowledge_list,
            stock_info_list,
            star_ip_res_list,
            hot_query_res_sql_list,
            top_weibo_list,
            top_article_list,
            baike_knowledge,
            gaokao_agent_list,
            history_hot_list,
            other_weibo_list,
            other_article_list,
            user_search_res_list,
            current_hot_res_list
        ) = limited_materials


        self.logger.info(self.pre_log_msg + ("after confine_material_length: "
                                            f"zs_knowledge_list:{len(zs_knowledge_list)}\t"
                                            f"stock_info_list:{len(stock_info_list)}\t"
                                            f"star_ip_res_list:{len(star_ip_res_list)}\t"
                                            f"hot_query_res_sql_list:{len(hot_query_res_sql_list)}\t"
                                            f"top_weibo_list:{len(top_weibo_list)}\t"
                                            f"top_article_list:{len(top_article_list)}\t"
                                            f"baike_knowledge:{len(baike_knowledge)}\t"
                                            f"gaokao_agent_list:{len(gaokao_agent_list)}\t"
                                            f"history_hot_list:{len(history_hot_list)}\t"
                                            f"other_weibo_list:{len(other_weibo_list)}\t"
                                            f"other_article_list:{len(other_article_list)}\t"
                                            f"user_search_res_list: {len(user_search_res_list)}\t"
                                            f"current_hot_res_list:{len(current_hot_res_list)}"))
        
        content_mid_len = len(content_list)
        baike = []
        if baike_knowledge:
            # 如果知识不为空，且非COVE，则将百科知识作为物料输入，而去重后的知识作为背景知识
            baike, knowledge = self.trans_knowledge_content(baike_knowledge, knowledge)
            self.weibo["knowledge"] = knowledge

        ranked_list = self.ds_format(
            zs_knowledge_list=zs_knowledge_list,
            stock_info_list=stock_info_list,
            star_ip_res_list=star_ip_res_list,
            hot_query_res_sql_list=hot_query_res_sql_list,
            top_weibo_list=top_weibo_list,
            top_article_list=top_article_list,
            baike_knowledge_list=baike,
            gaokao_agent_list=gaokao_agent_list,
            history_hot_list=history_hot_list,
            other_weibo_list=other_weibo_list,
            other_article_list=other_article_list,
            user_search_res_list=user_search_res_list,
            current_hot_res_list=current_hot_res_list
        )

        content_mid_len += len(baike) + len(sina_article_list) + len(history_hot_list)

        self.weibo["all_mids_num"] = content_mid_len + account_mid_len
        self.weibo['use_content_mid_len'] = content_mid_len
        self.weibo['use_account_mid_len'] = account_mid_len

        self.weibo['content'] = "\n\n".join(ranked_list)
        self.weibo['account_content'] = account_content_str
        self.weibo['opinion'] = opinion_str
        self.weibo['context'] = self.weibo.get("knowledge", "").strip()
        self.weibo['ds_struct_material'] = ranked_list

    
    async def confine_material_length_new(self,base_length=90000, use_compress=False):
        # D级风控物料过滤
        if self.weibo.get("limit_material"):
            self._filter_material_by_risk_level()
        content_list = self.get_target_weibo()
        prompt_scene = self.weibo.get("prompt_scene", "")
        q_attr = self.weibo.get('q_attr', '{}')
        q_attr_dict = json.loads(q_attr)
        comment_from_type = q_attr_dict.get('comment_from_type', '')
        if prompt_scene == 'verification_comment' and comment_from_type != 'active_comment':
            use_compress = True
        elif prompt_scene == 'deepseek_stream':
            use_compress = True
        if prompt_scene == 'deepseek_last':
            self.filter_materil_by_time_range4notify()
        knowledge = self.weibo.get("knowledge", "")
        query_category = self.weibo.get("query_category", "")
        baike_knowledge = self.weibo.get("baike_knowledge", [])
        sina_article_list = self.weibo.get('sina_article_data', [])
        history_hot_list = self.weibo.get('history_hot_res', [])
        # gaokao_agent_list = self.weibo.get('gaokao_agent_result', [])
        current_hot_res_list = self.weibo.get('current_hot_res', [])
        stock_info_list = self.weibo.get('stock_info', [])[:2]
        hot_query_res_sql_list = self.weibo.get('hot_query_res', [])
        zs_knowledge_list = self.weibo.get('zs_knowledge', [])
        user_search_res_list = self.weibo.get('user_search_res', [])
        ctr_res_list = self.weibo.get("ctr_res_list", [])
        broadsocial_res_list = self.weibo.get("broadsocial_res_list", [])

        # 拆分综合、语义接口、规划接口的数据
        weibo_article_unify_list = []
        weibo_vs_list = []
        weibo_article_ext_list = []
        for item in content_list:
            if 'ps_idx' in item:
                weibo_article_unify_list.append(item)
            elif 'vs_idx' in item:
                weibo_vs_list.append(item)
            else:
                weibo_article_ext_list.append(item)
        for item in sina_article_list:
            if 'ps_idx' in item:
                weibo_article_unify_list.append(item)
            elif 'ext_idx' in item:
                weibo_article_ext_list.append(item)
        
        weibo_article_unify_list.sort(key=lambda x: x['ps_idx'])
        weibo_vs_list.sort(key=lambda x: x['vs_idx'])
        weibo_article_ext_list.sort(key=lambda x: x['ext_idx'])

        if ctr_res_list:
            if history_hot_list:
                history_hot_list[0] = ctr_res_list[0]
            else:
                history_hot_list = ctr_res_list
        
        # 泛社会干预事实->资料首位
        if broadsocial_res_list:
            info_rank_dict = {
                "zs_knowledge_list": zs_knowledge_list,
                "stock_info_list": stock_info_list,
                "hot_query_res_sql_list": hot_query_res_sql_list,
                "history_hot_list": history_hot_list,
                "user_search_res_list": user_search_res_list,
                "current_hot_res_list": current_hot_res_list,
            }

            try:
                for name, lst in info_rank_dict.items():
                    if lst:
                        lst.insert(0, broadsocial_res_list[0])
                        self.logger.info(f"broadsocial_res_list inserted into: {name}, new length={len(lst)}")
                        break
            except Exception as e:
                self.logger.error(f"broadsocial_res_list insert error: {e}")

        # 明星词只保留博文、百科、历史热点
        if query_category == "明星":
            stock_info_list = []
            hot_query_res_sql_list = []
            sina_article_list = []
            current_hot_res_list = []
            self.logger.info(self.pre_log_msg + f"clear4star")

        
        self.logger.info(self.pre_log_msg + ("before confine_material_length: "
                                            f"[extra]content_list:{len(content_list)}\t"
                                            f"[extra]sina_article_list:{len(sina_article_list)}\t"
                                            f"weibo_article_unify_list:{len(weibo_article_unify_list)}\t"
                                            f"weibo_vs_list:{len(weibo_vs_list)}\t"
                                            f"weibo_article_ext_list:{len(weibo_article_ext_list)}\t"
                                            f"zs_knowledge_list:{len(zs_knowledge_list)}\t"
                                            f"stock_info_list:{len(stock_info_list)}\t"
                                            f"hot_query_res_sql_list:{len(hot_query_res_sql_list)}\t"
                                            f"baike_knowledge:{len(baike_knowledge)}\t"
                                            f"history_hot_list:{len(history_hot_list)}\t"
                                            f"user_search_res_list: {len(user_search_res_list)}\t"
                                            f"current_hot_res_list:{len(current_hot_res_list)}"))
        data_groups = [
            weibo_article_unify_list,
            weibo_vs_list,
            weibo_article_ext_list,
            stock_info_list,
            user_search_res_list,
            hot_query_res_sql_list,
            history_hot_list,
            current_hot_res_list,
            baike_knowledge,
            zs_knowledge_list,
        ]
        config_groups = [{} for _ in range(len(data_groups))]
        # baike特殊处理
        config_groups[8] = {"content_getter": lambda x: x}

        limited_materials = self.get_mats_length_new(
            data_groups=data_groups,
            config_groups=config_groups,
            total_length=base_length
        )

        if use_compress:
            limited_materials = self.truncate_mats4stream_new(
            data_groups=limited_materials,
            config_groups=config_groups
            )

        if self.weibo.get('xiaomi_stream', False):
            limited_materials = MaterialUtils.truncate_mats4xiaomi_stream_new(
                data_groups=limited_materials,
                config_groups=config_groups,
                logger=self.logger,
                pre_log_msg=self.pre_log_msg
            )
        # 解包
        (
            weibo_article_unify_list,
            weibo_vs_list,
            weibo_article_ext_list,
            stock_info_list,
            user_search_res_list,
            hot_query_res_sql_list,
            history_hot_list,
            current_hot_res_list,
            baike_knowledge,
            zs_knowledge_list,
        ) = limited_materials


        self.logger.info(self.pre_log_msg + ("after confine_material_length: "
                                            f"weibo_article_unify_list:{len(weibo_article_unify_list)}\t"
                                            f"weibo_vs_list:{len(weibo_vs_list)}\t"
                                            f"weibo_article_ext_list:{len(weibo_article_ext_list)}\t"
                                            f"zs_knowledge_list:{len(zs_knowledge_list)}\t"
                                            f"stock_info_list:{len(stock_info_list)}\t"
                                            f"hot_query_res_sql_list:{len(hot_query_res_sql_list)}\t"
                                            f"baike_knowledge:{len(baike_knowledge)}\t"
                                            f"history_hot_list:{len(history_hot_list)}\t"
                                            f"user_search_res_list: {len(user_search_res_list)}\t"
                                            f"current_hot_res_list:{len(current_hot_res_list)}"))
        
        content_mid_len = len(content_list)
        baike = []
        if baike_knowledge:
            # 如果知识不为空，且非COVE，则将百科知识作为物料输入，而去重后的知识作为背景知识
            baike, knowledge = self.trans_knowledge_content(baike_knowledge, knowledge)
            self.weibo["knowledge"] = knowledge

        final_m_list = weibo_article_unify_list + weibo_vs_list + weibo_article_ext_list + \
            stock_info_list + user_search_res_list + hot_query_res_sql_list + history_hot_list + \
            current_hot_res_list + baike + sina_article_list + zs_knowledge_list

        ranked_list = self.ds_format_new(
            final_m_list
        )


        self.weibo['content'] = "\n\n".join(ranked_list)
        self.weibo['context'] = self.weibo.get("knowledge", "").strip()
        self.weibo['ds_struct_material'] = ranked_list

    def _filter_material_by_risk_level(self):
        """根据风控等级过滤站内/站外物料"""
        use_material = self.weibo.get("use_material", [])
        use_onsite = USE_ONSITE_MATERIAL in use_material
        use_offsite = USE_OFFSITE_MATERIAL in use_material
        
        # 清空站外物料的情况：使用站内但不使用站外，或者都不使用
        if (use_onsite and not use_offsite) or (not use_onsite and not use_offsite):
            for field in ['sina_article_data', 'baike_knowledge', 'history_hot_res', 'gaokao_agent_result',
                        'star_ip_result', 'current_hot_res', 'stock_info', 'hot_query_res', 'zs_knowledge']:
                self.weibo[field] = []
            
            self.logger.info(self.pre_log_msg + f"clear offsite material(sina_article, baike...) by fengkong")
        
        # 清空站内物料的情况：使用站外但不使用站内
        elif use_offsite and not use_onsite:
            for field in ['mid_list', 'struct_content_list']:
                self.weibo[field] = []
            
            self.logger.info(self.pre_log_msg + f"clear onsite material only use weibo by fengkong")

class StreamDeepSeekLLM(DeepSeekLLM):

    def __init__(self, weibo, output, pid):
        super().__init__(weibo, output, pid)
        self.status_task = []

    def should_recalculate(self):
        recalculate = StreamRecalculate(self.pid)
        return recalculate

    async def create_status_task(self, status_stage):
        self.status_task.append(asyncio.create_task(
            self.send_response(ready='no', content="", status_stage=status_stage)
        ))

    async def cancel_status_task(self):
        start = time.time()
        try:
            await asyncio.gather(*self.status_task)
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"await status_task error: {e}")

        self.logger.info(self.pre_log_msg + f"cancel status_task cost: {time.time() - start}")

    async def fetch_material(self):
        await asyncio.gather(
            self.create_status_task(1),
            super().fetch_material()
        )

    async def struct_material(self):
        await asyncio.gather(
            self.create_status_task(2),
            super().struct_material()
        )

    async def query_intention_and_rewrite(self):
        await asyncio.gather(
            self.create_status_task(3),
            super().query_intention_and_rewrite()
        )

    def update_chat_status_stage(self, status) :
        dic = {
            "THINKING" : 1,
            "SEARCHING" : 2,
            "ANSWERING" : 3,
            "FINISHED" : 4
        }
        self.weibo["chat_status_stage"] = dic[status]

    async def call_llm(self, prompt):
        func_name = "总结生成"
        start = time.time()
        llm_model = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("query", "")
        q_attr = self.weibo.get("q_attr", "")
        use_zhisou = self.weibo.get("use_zhisou", False)
        llm_name = self.weibo.get('llm_name', "")
        # if self.query_filter():
        #     ready = "special_tips"
        #     special_tips = "抱歉，这个问题我暂时无法回答，换个问题试试吧"
        #     await self.cancel_status_task()
        #     await self.send_response(ready=ready, content="", status_stage=4, special_tips=special_tips)
        #     return ""

        user_task = asyncio.create_task(self.update_user_feature_dict())
        is_updated = False

        prompt_content = prompt.prompt()
        self.weibo['prompt'] = prompt_content
        try:
            begin = time.time()
            stream_response = await llm_model.async_stream_call(prompt_content)
            final_result = None
            first = True
            first_output_time = 0
            first_time = 0
            result = ""
            last_result = ""
            stream_window = 10
            async for response in stream_response:
                if first:
                    first_time = time.time()
                    self.weibo["debug"]["time_analysis"]["stream_fist_answer"] = first_time
                    self.weibo["debug"]['first_answer'] = first_time
                    self.update_chat_status_stage("THINKING")
                    first = False
                final_result = response
                result = response.get("text", "")
                result = result.strip('\n')
                if "</think>" in result and not is_updated:
                    await user_task
                    is_updated = True
                if len(result) - len(last_result) > stream_window or not first_output_time:
                    if stream_window < 30:
                        stream_window += 5
                    result_new = prompt.post_process(result)
                    if "</think>" in result_new:
                        self.update_chat_status_stage("ANSWERING")
                    result_new = await self.filter_relevance_score(result_new)
                    await self.send_response(ready='no', content=result_new.rstrip('\n'), status_stage=4)
                    if not first_output_time:
                        first_output_time = time.time()
                        self.weibo["debug"]['first_output_answer'] = first_output_time
                    last_result = result
            self.weibo["debug"]["time_analysis"]["stream_answer_end"] = time.time()
            self.weibo["debug"]['end_process'] = time.time()
            await self.count_tokens(final_result, begin, first_time)
            self.weibo["output_all_ready"] = True
            self.weibo['ori_result'] = result
            if_gen_business_link, business_dict = self.if_business_link()
            if if_gen_business_link:
                ai_business_list = await self.gen_business_link(prompt, result, business_dict)
                business_dict["ai_business_list"] = ai_business_list
                self.weibo["business_dict"] = business_dict
                self.weibo["if_business_link"] = True
            result = prompt.post_process(result)
            result = await self.filter_relevance_score(result)
            if "</think>" not in result:
                self.logger.error(self.pre_log_msg + f"no think result:{json.dumps(result, ensure_ascii=False)}\t")
                raise Exception("no think end")
            if self.weibo["query_category"] == "明星" :
                await self.star_title_modify()
            self.update_chat_status_stage("FINISHED")
            await self.send_response(ready='yes' if result else 'nodata', content=result, status_stage=4)
            error_name, no_error = await self.check_result(result)
            if no_error and result:
                await asyncio.gather(
                    self.calc_question(result),
                    self.calc_query_monitor(),
                    self.cancel_status_task()
                )
                return result
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{e}")
            self.weibo["debug"]['end_process'] = time.time()
            await self.send_response(ready='nodata', content="", status_stage=4)
        if not is_updated:
            await user_task
            is_updated = True

        await self.cancel_status_task()
        self.weibo['finish_reason'] = self.weibo.get("finish_reason", "llm_error")
        self.logger.info(self.pre_log_msg + f"{func_name} get no data, cost_time:{time.time() - start}\t")
        return ""
