import asyncio
import time
import json

from api.model_api import QWEN3_30B_XiaoYiWrapper
from plugins.llm.deepseek import StreamDeepSeekLLM
from plugins.prompt.xiaoyi import xiaoyi_factory


class XiaoYiStreamLLM(StreamDeepSeekLLM):

    def make_prompt(self):
        func_name = "MAKE-PROMPT"
        start = time.time()
        result = xiaoyi_factory(self.weibo)
        self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}")
        return result

    async def confine_material_length(self):
        await super().confine_material_length(base_length=45000)

    async def call_llm(self, prompt):
        func_name = "小艺接入"
        start = time.time()
        llm_qwen3_30b = QWEN3_30B_XiaoYiWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_content = prompt.prompt()
        # print("prompt: ", prompt_content)
        self.weibo['prompt'] = prompt_content

        try:
            begin = time.time()
            stream_response = await llm_qwen3_30b.async_stream_call(prompt_content)
            final_result = {}
            first = True
            first_time = 0
            fifty_time = 0
            result = ""
            last_result = ""
            async for response in stream_response:
                final_result = response
                result = response.get("text", "")
                result = result.strip('\n')
                process_result = prompt.post_process(result)
                # print("result: ", process_result)
                if first:
                    first_time = time.time()
                    self.weibo["debug"]["time_analysis"]["stream_fist_answer"] = first_time
                    self.weibo["debug"]['first_answer'] = first_time
                    if not self.weibo["debug"].get("first_return_time", 0):
                        self.weibo["debug"]["first_return_time"] = time.time()
                    await self.output.run(weibo=self.weibo, ready='no', content=process_result, status_stage=4)
                    if not self.weibo["debug"].get("first_return_time_behind", 0):
                        self.weibo["debug"]["first_return_time_behind"] = time.time()
                    user_request_time_ms = self.weibo.get('user_request_time_ms', 0)
                    server_request_time_ms = self.weibo.get('server_request_time_ms', 0)
                    if not self.weibo["debug"].get("user_request_time_ms", 0):
                        self.weibo["debug"]["user_request_time_ms"] = user_request_time_ms
                    if not self.weibo["debug"].get("server_request_time_ms", 0):
                        self.weibo["debug"]["server_request_time_ms"] = server_request_time_ms
                    last_result = result
                    first = False
                if len(process_result) >= 50 and fifty_time == 0:
                    fifty_time = time.time()
                if len(result) - len(last_result) > 10:
                    if not self.weibo["debug"].get("first_return_time", 0):
                        self.weibo["debug"]["first_return_time"] = time.time()
                    await self.output.run(weibo=self.weibo, ready='no', content=process_result, status_stage=4)
                    last_result = result
            self.weibo["debug"]["time_analysis"]["stream_answer_end"] = time.time()
            self.weibo["debug"]['end_process'] = time.time()
            await self.count_tokens(final_result, begin, first_time)
            self.weibo["output_all_ready"] = True
            result = prompt.post_process(result)
            await self.output.run(weibo=self.weibo, ready='yes', content=result, status_stage=4)
            self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\tfifty_time:{fifty_time-start}\tfirst_time:{first_time-start}\t"
                                                f"result:{json.dumps(result, ensure_ascii=False)}")
            return result
        except Exception as e:
            self.logger.exception(e)
            self.weibo["debug"]['end_process'] = time.time()
            await self.output.run(weibo=self.weibo, ready='nodata', content="", status_stage=4)

        self.logger.info(self.pre_log_msg + f"{func_name} get no data, cost_time:{time.time() - start}\t")
        return ""
