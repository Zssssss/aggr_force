# -*- coding:utf-8 -*-
import asyncio
import json
import traceback
import time

from api.config import DEEPSEEK_AIGC_URL
from api.model_api import get_tauth_token, ModelPicWrapper
from plugins.function.prompt import search_prompt
from plugins.function.tools import tools
from plugins.llm.deepseek import DeepSeekLLM, StreamDeepSeekLLM
from plugins.material.material import MidMaterial
from plugins.material.multiq_runner import MultiQueryMaterialRunner
from plugins.post_process.utils import split_think_and_content
from plugins.prompt.mid import mid_factory, blog_recognize_mid_factory
from plugins.prompt.risk_control import risk_control_factory


def short_content(weibo):
    """整体博文内容少于10个字符，不进行博文分析"""
    if weibo.get("is_less_than_10", False):
        weibo['finish_reason'] = "content_short"
        ready = "special_tips"
        special_tips = "抱歉，这条博文内容过短，我暂时无法分析，换条博文试试吧"
        content = "<think></think>\n" + special_tips
        return True, content, ready, special_tips

    materials = weibo.get('content', "")
    if not len(materials.strip()):
        weibo['finish_reason'] = "nodata"
        ready = "nodata"
        special_tips = ""
        content = ""
        return True, content, ready, special_tips
    return False, "", "", ""


class MidLLM(DeepSeekLLM):

    async def fetch_material(self):
        await asyncio.gather(
            super().fetch_material(),
            MidMaterial(self.pid).run(weibo=self.weibo)
        )

    def make_prompt(self):
        label = self.weibo.get("label", "")
        if label == 'risk_control':
            return risk_control_factory(self.weibo)
        return mid_factory(self.weibo)

    def make_recognize_prompt(self):
        return blog_recognize_mid_factory(self.weibo)

    async def call_llm_recognize(self) -> str:
        # 根据 pid 调用大模型识别影视剧名
        # 返回影视剧名, 搜索关键词
        pid_list = self.weibo.get("reco_pic_list", [])
        # print(f"pid_List: {pid_list}")
        image_list = [f'https://wx3.sinaimg.cn/sq480/{i}.jpg' for i in pid_list]
        func_name = "博文分析识别影视剧"
        llm = ModelPicWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_cls = self.make_recognize_prompt()
        result = await llm.async_call(prompt_cls.prompt(), img_list=image_list)
        if result and isinstance(result, dict):
            reco_pic_llm_res = result.get("text", "")
            self.weibo['reco_pic_llm_res'] = reco_pic_llm_res
            return prompt_cls.post_process(reco_pic_llm_res)
        else:
            return ""
    
    async def recognize_entrance(self):
        try:
            self.weibo["debug"]["time_analysis"]["call_llm_pic_recog_start"] = time.time()
            recognize_result = await self.call_llm_recognize()
            self.weibo["debug"]["time_analysis"]["call_llm_pic_recog_end"] = time.time()
            mid_content = self.weibo.get("mid_content", "")
            if recognize_result:
                mid_content = f"{mid_content}\n- 博文中视频内容为：{recognize_result}"
                self.weibo['mid_content'] = mid_content
                self.logger.info(self.pre_log_msg + f"add pic recognize result label: {recognize_result}")
        except Exception as e:
            self.logger.error(f"recognize_entrance error: {traceback.format_exc()}")
        

    async def call_llm(self, prompt):
        # await self.recognize_entrance()
        need_return, content, ready, special_tips = short_content(self.weibo)
        if need_return:
            await self.send_response(ready=ready, content=content, status_stage=4,
                                  special_tips=special_tips)
            return content
        return await super().call_llm(prompt)

    def if_func_call(self):
        # 调用func_call开关
        return True

    async def add_material(self, query_list):
        multi_q_runner = MultiQueryMaterialRunner(self.pid)
        await multi_q_runner.run(self.weibo, query_list)
        await self.confine_material_length()

    async def func_call(self,*args):
        llm_model, prompt, schema_index = args
        prompt_content = prompt.prompt()
        system_prompt = search_prompt
        response = await llm_model.async_func_call_new(prompt_content, system_prompt)
        text = response.get("text","")
        _, content = split_think_and_content(text)
        tool_dict = response.get("tool_dict", {})
        if not tool_dict and "{" not in content:
            # 没有任何工具调用
            self.logger.info(self.pre_log_msg + "function not calling")
            return response

        # 存在工具调用
        if "weibo_search" in tool_dict:
            function_args = tool_dict["weibo_search"]
            query_list = function_args.get("queries", [])
            self.logger.info(
                f"{self.pre_log_msg}function calling weibo_search with queries: {query_list}"
            )
            await self.add_material(query_list)
        else:
            if "{" in content:
                self.logger.info(self.pre_log_msg + f"dakuohao in content: {content}")
            self.logger.info(self.pre_log_msg + "function calling other tool")
        # 无论调用何种工具，后续执行逻辑相同
        self.weibo["if_func_call"] = False
        prompt_content = prompt.prompt()
        self.weibo["prompt"] = prompt_content
        response = await llm_model.async_call(prompt_content, schema_index)
        return response

class StreamMidLLM(StreamDeepSeekLLM):

    async def fetch_material(self):
        await asyncio.gather(
            super().fetch_material(),
            MidMaterial(self.pid).run(weibo=self.weibo)
        )

    def make_prompt(self):
        return mid_factory(self.weibo)

    async def call_llm(self, prompt):
        need_return, content, ready, special_tips = short_content(self.weibo)
        if need_return:
            await self.cancel_status_task()
            await self.send_response(ready=ready, content=content, status_stage=4,
                                  special_tips=special_tips)
            return content
        result = await super().call_llm(prompt)
        return result
