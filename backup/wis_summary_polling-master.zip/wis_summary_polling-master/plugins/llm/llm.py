# -*- coding:utf-8 -*-
import asyncio
import time
import json
from datetime import datetime
import traceback
import re
import itertools
import aiohttp
import requests
import numpy as np
import jinja2

from alarm.alarm import alarm
from api.model_api import ModelQwen, ModelApi, ModelQwenWrapper, ModelGlm4Wrapper
from lib.base import Base
from lib.memq import MEMQ
from lib.aiomcq import mcq_cli
from api.model_api import md5_hash, get_bucket_id
from plugins.intention.intention import Intention
from plugins.llm.utils import count_tokens, get_abtest
from plugins.material.material import (
    CredentialCheck,
    SummaryMaterial,
    AccountMaterial,
    ShortTvMaterial,
    KnowledgeMaterial,
    CoveMaterial,
    WisAnalysisMaterial, PreviousMaterial, StockMaterial,
    SummaryMaterialNoType,
    RiskControlMaterial, HotquerySql,
    GaoKaoAgentMaterial,
    CTRMaterial,
    BroadSocialMaterial, HotSearchBoardMaterial, QueryLastCalcTime,
    SinaNightCoveMaterial
)
from plugins.material.preview_trigger import PreviewTrigger
from plugins.material.query_filter import QueryFilter
from plugins.post_process.business_process import BussinessMaterial
from plugins.prompt.outlines import get_used_content_mid
from plugins.prompt.risk_control import risk_control_factory
from plugins.query_rewrite.query_modify import QueryModify
from plugins.query_rewrite.query_rewrite import QueryRewrite
from plugins.prompt.cove import cove_factory
from plugins.prompt.robot import robot_factory
from plugins.prompt.ds import ds_factory
from plugins.prompt.viewpoint_1k import vp_1k_factory
from plugins.prompt.overview_1k import ov_1k_factory
from plugins.prompt.hot_overview import hot_overview_factory
from plugins.recalculate.recalculate import Recalculate
from plugins.regression.regression import Regression
from plugins.storage.redis_storage import RedisBusinessCompress
from plugins.llm.restruct_mat import general_template_jinja, picture_template, general_template_pic, general_template_account, general_template_star_click
from plugins.material.utils import Utils as MaterialUtils

GENERAL_MATERIAL_TPL = jinja2.Template(general_template_jinja)

class LLM(Base):
    mcq_calc_question = mcq_cli(domain="queue.search.weibo.com", port=11233)
    def __init__(self, weibo, output, pid):
        super().__init__(pid)
        self.weibo = weibo
        self.output = output
        self.use_struct_contentinfo = True
        self.weibo['pid'] = pid

    async def fetch_material(self):
        func_name = "FETCH_MATERIAL"
        start = time.time()
        materials = [
            SummaryMaterial(self.pid), 
            # AccountMaterial(self.pid),
            # ShortTvMaterial(self.pid),
            # KnowledgeMaterial(self.pid),
            CoveMaterial(self.pid),
            # WisAnalysisMaterial(self.pid),
            # PreviousMaterial(self.pid),
            StockMaterial(self.pid),
            SummaryMaterialNoType(self.pid),
            RiskControlMaterial(self.pid),
            HotquerySql(self.pid),
            GaoKaoAgentMaterial(self.pid),
            CTRMaterial(self.pid),
            BroadSocialMaterial(self.pid),
            HotSearchBoardMaterial(self.pid),
            BussinessMaterial(self.pid),
            QueryFilter(self.pid),
            PreviewTrigger(self.pid),
            QueryLastCalcTime(self.pid),
            CredentialCheck(self.pid),
            SinaNightCoveMaterial(self.pid)
        ]

        tasks = [material.run(weibo=self.weibo) for material in materials]
        await asyncio.gather(*tasks)
        self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}")

    def should_recalculate(self):
        recalculate = Recalculate(self.pid)
        return recalculate

    def check_material(self):
        """检查物料是否发生变化"""
        query_category = self.weibo.get("query_category", "")
        mid_list = self.weibo.get('mid_list', [])
        account_mid_list = self.weibo.get('account_mid_list', [])
        all_mid_list = mid_list + account_mid_list

        previous_result = self.weibo.get("previous_result", {})
        previous_update = float(previous_result.get("update", '0'))  # 大于一天就重算
        if not previous_result or time.time() - previous_update > 24 * 60 * 60:
            self.weibo['recalc_status'] = 'nodata'
            # return bool(len(mid_list) or query_category == 'Account_Nor')
            return True

        previous_mid = previous_result.get("mid_list", "")
        previous_mid_list = previous_mid.split(',') if previous_mid else []
        previous_account_mid = previous_result.get("account_mid_list", "")
        previous_account_mid_list = previous_account_mid.split(',') if previous_account_mid else []
        previous_all_mid_list = previous_mid_list + previous_account_mid_list

        self.weibo['recalc_status'] = 'is_have_material_diff'
        # 根据不同类型判断是否需要重新计算
        if query_category == 'Account_Nor':
            # 账户前三条完全变化才重算
            return (bool(account_mid_list or previous_account_mid_list) and
                    not set(account_mid_list[:3]) & set(previous_account_mid_list[:3]))
        elif query_category == 'kol':
            # 所有物料有变化就重算
            return set(all_mid_list) != set(previous_all_mid_list)

        # 普通情况下比较 mid_list
        return set(mid_list) != set(previous_mid_list)

    def merge_summary_account(self):
        """合并落地页和个人主页，需要在各自结构化之后调用"""
        query_category = self.weibo.get("query_category", "")
        llm_name = self.weibo.get("llm_name", "")
        if query_category == "kol":
            self.weibo["filter_mids"] = self.weibo["mid_list"] + self.weibo["account_mid_list"]
        elif query_category == "Account_Nor":
            self.weibo["filter_mids"] = self.weibo["account_mid_list"]
        else:
            self.weibo["filter_mids"] = self.weibo["mid_list"]
        if len(self.weibo["filter_mids"]) == 0 and query_category == "kol":
            self.logger.info(self.pre_log_msg + f"llm_name:{llm_name} kol's analysis material is empty")
            keys = ["content_list", "mid_list", "struct_content_list", "blue_v"]
            for key in keys:
                self.weibo[key] = self.weibo["summary_material_no_type"].get(key, [])
            self.weibo["query_grade"] = self.weibo["summary_material_no_type"].get("query_grade", 30)
            self.weibo["raw_time_grade"] = self.weibo["summary_material_no_type"].get("raw_time_grade", "")
            self.weibo["summary_material_no_type"]["replace"] = True
            self.weibo["filter_mids"] = self.weibo["summary_material_no_type"].get("mid_list", [])

    async def struct_material(self):
        self.weibo["debug"]["time_analysis"]["struct_wis_material_start"] = time.time()
        WisAnalysisMaterial.struct_wis_material(self.weibo)
        self.weibo["debug"]["time_analysis"]["struct_wis_material_end"] = time.time()
        await SummaryMaterial(self.pid).struct_material(self.weibo)
        self.weibo["debug"]["time_analysis"]["struct_summary_material_end"] = time.time()
        # await SummaryMaterialNoType(self.pid).struct_material(self.weibo)
        self.weibo["debug"]["time_analysis"]["struct_summary_no_material_end"] = time.time()
        # await AccountMaterial(self.pid).struct_material(self.weibo)
        self.weibo["debug"]["time_analysis"]["struct_account_material_end"] = time.time()
        
        # SummaryMaterialNoType.struct_material(self.weibo,self.logger)
        
        # self.merge_summary_account()
        self.identifity_content_viewpoint(self.weibo["content_list"])
        await self.filter_content_viewpoint(self.weibo["query"],self.weibo["content_list"])
        self.struct_content_modified(self.weibo["viewpoint"], self.weibo["blue_v"], self.weibo["struct_content_list"])
        cove_material = self.weibo.get("cove_material", [])
        if len(cove_material):
            self.weibo['knowledge'] = '\n'.join(cove_material).strip()

    @staticmethod
    def limit_material(materials, length, flag=False, all_length=0, to_str=True):
        windows_size = 0
        filter_content = []
        for i in range(len(materials)):
            material_length = len(str(materials[i]))
            if (windows_size + material_length) < length:
                if flag is False:
                    material = "{}.{}".format(all_length+i+1, str(materials[i]))
                else:
                    material = str(materials[i])
                if to_str:
                    filter_content.append(material)
                else:
                    filter_content.append(materials[i])
                windows_size =  windows_size + material_length
        if to_str:
            content_str = "\n\n".join(filter_content)
        else:
            content_str = filter_content
        return content_str, len(filter_content)

    def trans_knowledge_content(self, bks, knowledges):
        """
        百科知识作为物料输入.
        """
        baike_strs = []
        bks_contents = [i.get('content') for i in bks if i.get('content', '').strip()]
        # bks = baike_knowledges.split("\n\n\n")
        ks = [i.strip() for i in knowledges.split("\n\n\n") if i.strip() and i.strip() not in bks_contents]
        for knowledge in bks:
            content = knowledge.get('content', '')
            url = knowledge.get('url', '')
            if content.strip():
                input = {"内容": content.strip(), "内容来源": "百度百科", "内容类型": "百科知识",
                         "发布账号类型": "普通账号", "内容可信分级": "高度可信", "url": url}
                input_str = "%s" % input
                baike_strs.append(input_str)
        ks = "\n\n\n".join(ks).strip()
        return baike_strs, ks

    def add_id_list(self, x, is_not_sort_flag, sid=0):
        rank_list = []
        for i in x:
            # 不排序 = False
            if is_not_sort_flag is False:
                ii = "%s. %s" % (len(rank_list) + 1 + sid, i)
            else:
                ii = i
            rank_list.append(ii)
        return rank_list

    def trans_content_statement(self, data, stream_output=0):
        """
        转换发博内容的表述.
        """
        # 去掉不需要的结构化字段
        # pub_account = data.pop("发布账号名", "")
        verify_info = data.pop("发布账号认证", "")
        tags = data.pop("内容标签词", "")
        # pub_time = data.pop("发布时间", "")
        if stream_output:
            # 流式输入结构化去掉下面2个字段：
            source = data.pop("内容来源", "")
            level = data.pop("内容可信分级", "")
            # 默认值的字段也去掉
            if data.get("内容类型", "") == "博文":
                qtype = data.pop("内容类型", "")
            if data.get("发布账号类型", "") == "普通账号":
                atype = data.pop("发布账号类型", "")
        data = {k: v for k, v in data.items() if v}
        return data

    def rerank_content(self, content_list, mid_list, baike_list, article_list, history_hot_list, is_not_sort_flag, sid=0, stream_output=0, label=''):
        lanv_list = []
        lanv_mid_list = []
        for i, (c, m) in enumerate(zip(content_list, mid_list)):
            # 将发博内容重新转述
            if isinstance(c, dict):
                content_list[i] = self.trans_content_statement(c, stream_output)
            lanv_list.append(content_list[i])
            lanv_mid_list.append(m)

        if content_list and isinstance(content_list[0], dict):
            # 百科有知识，且物料是结构化输入
            # 物料、百科、文章
            lanv_list.extend(article_list)
            lanv_mid_list.extend(['文章'] * len(article_list))
            lanv_list.extend(baike_list)
            lanv_mid_list.extend(['百科'] * len(baike_list))
            lanv_list.extend(history_hot_list)
            lanv_mid_list.extend(['历史热点'] * len(history_hot_list))
        rank_list = self.ds_format(content_list, article_list, baike_list, history_hot_list)

        self.weibo['ds_struct_material'] = rank_list
        return "\n\n".join(rank_list), lanv_mid_list

    @staticmethod
    def picture_format(picture_list, start=0):
        """
        处理图片的格式.
        """
        result = ""
        for i in range(len(picture_list)):
            result += picture_template.format(idx=i+1+start)
        return result

    @staticmethod
    def update_pic_url_list(picture_urls, single_pic_url_list, idx):
        """
        更新图片url列表.
        """
        for single_pic_url in single_pic_url_list:
            picture_urls.append({"pic_url": single_pic_url, "pic_idx": idx})

    @staticmethod
    def render_mat_item(idx: int, item: dict, source: str) -> str:
        return GENERAL_MATERIAL_TPL.render(
                    idx=idx,
                    content=item.get('内容', ''),
                    account_type=item.get('发布账号类型', ''),
                    pub_time=item.get('发布时间', ''),
                    source=source,
                    nickname_type=item.get('发布账号名', ''),
                    value_tag=item.get('value_tag', ''),
                    extra_info_tag=item.get('extra_info_tag', '')
                )
    
    def ds_format_new(self, raw_content_list):
        link_urls, final_output, picture_urls = list(), list(), list()
        final_ab_top3_output = []
        final_ab_good_output = []
        final_ab_top3_link_list = []
        final_ab_good_link_list = []
        monitor_article, monitor_hotweibo, monitor_info, monitor_uids = list(), list(), list(), list()
        monitor_bigv = []
        tmp_used_baike, tmp_used_article = [], []
        is_kuake_flag = False
        kuake_content_list = []
        MaterialUtils.log_final_material_feature(raw_content_list, self.logger, self.pre_log_msg + "ds_format\t")
        for idx, item in enumerate(raw_content_list, 1):
            if isinstance(item, str):
                item = eval(item)
            if isinstance(item, dict):
                content_type = item.get('内容类型', '')
                url = item.get('url')
                if content_type == '百科知识':
                    item["发布账号类型"] = ""
                    source='百科'
                    tmp_used_baike.append(url)
                    # search_baike_res.append(item)
                elif content_type == '文章':
                    source='文章'
                    tmp_used_article.append(url)
                    is_kuake = int(item.get('is_kuake', '0'))
                    if is_kuake:
                        source = '网页'
                        is_kuake_flag = True
                        kuake_content_list.append(idx)
                    # search_article_res.append(item)
                elif content_type in ['历史热点', '个人主页', '高考物料']:
                    source = '资料'
                    item["发布账号类型"] = ""
                elif content_type in ['榜单热点', '智搜知识库', '泛社会类干预事实']:
                    source = '资料'
                else:
                    content_type = '博文'
                    source='微博'
                    # struct_content_list.append(item)
                struct_blog_str = LLM.render_mat_item(idx, item, source)
                final_output.append(struct_blog_str)
                if content_type == '文章':
                    monitor_article.append(idx)
                elif source == '资料':
                    monitor_info.append(idx)
                elif source == '微博' and item.get('from', '') == 'unify_base':
                    monitor_hotweibo.append(idx)
                if url:
                    link_urls.append(url)
                    monitor_uids.append(item.get('uid', ''))
                else:
                    link_urls.append("not_weibo://")
                if item.get("is_good", 0) >= 1 and item.get("发布账号类型", "") == "大V账号":
                    monitor_bigv.append(idx)
                # ab实验， top3 + 优质搜索结果
                if idx <= 3:
                    final_ab_top3_output.append(struct_blog_str)
                    final_ab_top3_link_list.append(link_urls[-1])
                if item.get("value_tag", ''):
                    allowd_idx = len(final_ab_good_output) + 1
                    if idx != allowd_idx:
                        final_ab_good_output.append(LLM.render_mat_item(allowd_idx, item, source))
                    else:
                        final_ab_good_output.append(struct_blog_str)
                    final_ab_good_link_list.append(link_urls[-1])

            else:
                self.logger.error(self.pre_log_msg + f"[debug ds format] item is not dict type:{type(item)}, item:{item}")
        self.weibo['link_list'] = link_urls
        self.weibo['urls_used_baike'] = tmp_used_baike
        self.weibo['urls_used_article'] = tmp_used_article
        self.weibo['monitor_article'] = monitor_article
        self.weibo['monitor_hotweibo'] = monitor_hotweibo
        self.weibo['monitor_info'] = monitor_info
        self.weibo['monitor_bigv'] = monitor_bigv
        self.weibo['monitor_uids'] = monitor_uids
        self.weibo['ds_ab_top3_m_list'] = final_ab_top3_output
        self.weibo['ds_ab_good_m_list'] = final_ab_good_output
        self.weibo['ds_ab_top3_link_list'] = final_ab_top3_link_list
        self.weibo['ds_ab_good_link_list'] = final_ab_good_link_list
        self.logger.info(self.pre_log_msg + f"[debug ds format] final_output:{len(final_output)}\tlink_list:{len(link_urls)}\tmat_chatnum:{len(str(final_output))}\tuse_kuake:{is_kuake_flag}\tkuake_content_list:{kuake_content_list}")
        return final_output

    def ds_format(self, **kwargs):
        """
        排序修改需注意截断顺序！！！

        # 排序规则：智搜知识库 > 股票财经 > 明星作品优化 > 热点榜单 > 优质博文  > 优质文章
        # > 全部百科 > 高考agent物料 > 全部历史热点 > 一般博文 > 一般文章 > 账号信息 > 最近热点
        """
        link_urls, final_output, picture_urls = list(), list(), list()
        final_ab_top3_output = []
        final_ab_good_output = []
        final_ab_top3_link_list = []
        final_ab_good_link_list = []
        monitor_article, monitor_hotweibo, monitor_info, monitor_uids = list(), list(), list(), list()
        monitor_bigv = []
        user_search_res = kwargs.get('user_search_res_list', [])
        search_baike_res = kwargs.get('baike_knowledge_list', [])
        search_history_hotspot = kwargs.get('history_hot_list', [])
        gaokao_agent_list = kwargs.get('gaokao_agent_list', [])
        if gaokao_agent_list:
            search_history_hotspot = gaokao_agent_list + search_history_hotspot
        top_weibo = kwargs.get('top_weibo_list', [])
        other_weibo = kwargs.get('other_weibo_list', [])
        top_article = kwargs.get('top_article_list', [])
        other_article = kwargs.get('other_article_list', [])
        if not top_weibo:
            top_weibo = other_weibo
            other_weibo = []
        # 热点榜单
        hot_query_res_list = kwargs.get('hot_query_res_sql_list', [])
        raw_content_list = hot_query_res_list + top_weibo + top_article + search_baike_res + search_history_hotspot + other_weibo + other_article + user_search_res
        # 个人发博物料
        # if kwargs.get('account_struct_content_list', []):
        #     if self.weibo['query_category'] in ['Account_Nor', 'kol']:
        #         raw_content_list = kwargs['account_struct_content_list'] + raw_content_list
        #     else:
        #         raw_content_list = raw_content_list + kwargs['account_struct_content_list']
        #     url_set = set()
        #     new_raw_content_list = []
        #     for t in raw_content_list:
        #         if isinstance(t, str):
        #             t = eval(t)
        #         if 'url' in t and t['url'] in url_set:
        #             continue
        #         else:
        #             new_raw_content_list.append(t)
        #             url_set.add(t.get('url'))
        #     raw_content_list = new_raw_content_list            
        # 明星作品优化
        star_ip_result = kwargs.get('star_ip_res_list', [])
        if star_ip_result:
            raw_content_list = star_ip_result + raw_content_list
            self.logger.info(self.pre_log_msg + f"add star_ip_result len:{len(star_ip_result)}")
        # 最近热点
        current_hot_result = kwargs.get('current_hot_res_list', [])
        if current_hot_result:
            raw_content_list = raw_content_list + current_hot_result
            self.logger.info(self.pre_log_msg + f"add current_hot_res len:{len(current_hot_result)}")
        # 股票财经
        stock_info_list = kwargs.get('stock_info_list', [])
        if stock_info_list:
            raw_content_list = stock_info_list + raw_content_list
            self.logger.info(self.pre_log_msg + "add stock_info_list len:{}".format(len(stock_info_list)))
        # 智搜知识库
        zs_knowledge_list = kwargs.get('zs_knowledge_list', [])
        if zs_knowledge_list:
            raw_content_list = zs_knowledge_list + raw_content_list
            self.logger.info(self.pre_log_msg + "add zs_knowledge_list len:{}".format(len(zs_knowledge_list)))
        tmp_used_baike, tmp_used_article = [], []
        is_kuake_flag = False
        kuake_content_list = []
        MaterialUtils.log_final_material_feature(raw_content_list, self.logger, self.pre_log_msg + "ds_format\t")
        qdict = {}
        for idx, item in enumerate(raw_content_list, 1):
            if isinstance(item, str):
                item = eval(item)
            if isinstance(item, dict):
                content_type = item.get('内容类型', '')
                url = item.get('url')
                if content_type == '百科知识':
                    item["发布账号类型"] = ""
                    source='百科'
                    tmp_used_baike.append(url)
                    # search_baike_res.append(item)
                elif content_type == '文章':
                    source='文章'
                    tmp_used_article.append(url)
                    is_kuake = int(item.get('is_kuake', '0'))
                    if is_kuake:
                        source = '网页'
                        is_kuake_flag = True
                        kuake_content_list.append(idx)
                    # search_article_res.append(item)
                elif content_type in ['历史热点', '个人主页', '高考物料']:
                    source = '资料'
                    item["发布账号类型"] = ""
                elif content_type in ['榜单热点', '智搜知识库', '泛社会类干预事实']:
                    source = '资料'
                else:
                    content_type = '博文'
                    source='微博'
                    # struct_content_list.append(item)
                struct_blog_str = LLM.render_mat_item(idx, item, source)
                final_output.append(struct_blog_str)
                if content_type == '文章':
                    monitor_article.append(idx)
                elif source == '资料':
                    monitor_info.append(idx)
                elif source == '微博' and item.get('from', '') == 'unify_base':
                    monitor_hotweibo.append(idx)
                if url:
                    link_urls.append(url)
                    monitor_uids.append(item.get('uid', ''))
                else:
                    link_urls.append("not_weibo://")
                if item.get("is_good", 0) >= 1 and item.get("发布账号类型", "") == "大V账号":
                    monitor_bigv.append(idx)
                mid = item.get('mid', '')
                txt = item.get('内容', '')
                reports_count = item.get('reports_count', 0)
                comments_count = item.get('comments_count', 0)
                attitudes_count = item.get('attitudes_count', 0)
                if mid:
                    qdict.update({
                        mid: [mid, txt, reports_count, comments_count, attitudes_count, 0]
                    })
                # ab实验， top3 + 优质搜索结果
                if idx <= 3:
                    final_ab_top3_output.append(struct_blog_str)
                    final_ab_top3_link_list.append(link_urls[-1])
                if item.get("value_tag", ''):
                    allowd_idx = len(final_ab_good_output) + 1
                    if idx != allowd_idx:
                        final_ab_good_output.append(LLM.render_mat_item(allowd_idx, item, source))
                    else:
                        final_ab_good_output.append(struct_blog_str)
                    final_ab_good_link_list.append(link_urls[-1])

            else:
                self.logger.error(self.pre_log_msg + f"[debug ds format] item is not dict type:{type(item)}, item:{item}")
        self.weibo["qdict"] = qdict
        self.weibo['link_list'] = link_urls
        self.weibo['urls_used_baike'] = tmp_used_baike
        self.weibo['urls_used_article'] = tmp_used_article
        self.weibo['monitor_article'] = monitor_article
        self.weibo['monitor_hotweibo'] = monitor_hotweibo
        self.weibo['monitor_info'] = monitor_info
        self.weibo['monitor_bigv'] = monitor_bigv
        self.weibo['monitor_uids'] = monitor_uids
        self.weibo['ds_ab_top3_m_list'] = final_ab_top3_output
        self.weibo['ds_ab_good_m_list'] = final_ab_good_output
        self.weibo['ds_ab_top3_link_list'] = final_ab_top3_link_list
        self.weibo['ds_ab_good_link_list'] = final_ab_good_link_list
        self.logger.info(self.pre_log_msg + f"[debug ds format] final_output:{len(final_output)}\tlink_list:{len(link_urls)}\tmat_chatnum:{len(str(final_output))}\tuse_kuake:{is_kuake_flag}\tkuake_content_list:{kuake_content_list}")
        return final_output

    def good_res_rank(self, x):
        # 优质博文重新排到前面
        out = sorted(x, key=lambda i: i["is_good"], reverse=True)
        return out

    def get_target_weibo(self, ):
        struct_content_list = self.weibo.get('struct_content_list', [])
        # struct_content_list = self.good_res_rank(struct_content_list)
        return struct_content_list

    def get_target_article(self):
        article_list = self.weibo.get('sina_article_data', [])
        res_article = list()
        for item in article_list:
            try:
                longtext = item.get('content', '')
                is_kuake = int(item.get('is_kuake', '0'))
                from_web = int(item.get('from_web', '0'))
                from_kuake = 1 if from_web == 1 or is_kuake == 1 else 0
                final_qi_score = float(item.get('final_qi_score', '0'))
                hit_score_final = float(item.get('hit_score_final', '0'))
                pub_ts = item.get('pub_ts', '0')
                if pub_ts and pub_ts != '0':
                    try:
                        pub_ts = datetime.fromtimestamp(int(pub_ts)).strftime('%Y年%m月%d日')
                    except:
                        pub_ts = ''
                else:
                    pub_ts = ""
                is_credible_account = '媒体账号' if str(item.get('is_credible', '0')) == '1' else ''
                is_good = 1 if final_qi_score >= 76 and hit_score_final >= 50 else 0
                if longtext.strip():
                    inp = {"内容": longtext.strip(), "内容来源": "微博", "内容类型": "文章",
                           "发布时间": pub_ts,
                           "发布账号类型": is_credible_account, "内容可信分级": "一般可信", "url": item.get('url', ''),
                           "is_good": is_good,"is_kuake":from_kuake}
                    # input_str = "%s" % inp
                    res_article.append(inp)
            except Exception as e:
                self.logger.error(
                    self.pre_log_msg + f"get_target_article item: {json.dumps(item, ensure_ascii=False)} error: {e}")

        out = sorted(res_article, key=lambda i: i["is_good"], reverse=True)
        return out
        # now = int(time.time())
        # article_urls = set()
        # article_list = self.weibo.get('sina_article_data', [])
        # days = self.weibo.get('query_grade', 30)
        # material_list = self.weibo.get('raw_material_list', [])
        # res_article = list()
        # for i in material_list:
        #     for obj in i.get('url_objects', []):
        #         obj_item = obj.get('object', {})
        #         if obj_item.get('object_type', '') == 'article':
        #             url = obj_item.get('url')
        #             if url:
        #                 article_urls.add(url)
        # self.write_log(message=f"[debug sina article]\tsearch articles:{article_urls}")
        # for i in article_list:
        #     url = i.get('URL')
        #     publish_time = int(i.get('publish_time', 0))
        #     if url not in article_urls:
        #         self.write_log(message=f"[debug sina article]\tfilter by search:{url}")
        #         continue
        #     if now - publish_time > 86400 * days:
        #         self.write_log(message=f"[debug sina article]\tfilter by publish time:{publish_time}\tdays:{days}")
        #         continue
        #     longtext = i.get('TEXT', '')
        #     if longtext.strip():
        #         inp = {"内容": longtext.strip(), "内容来源": "新浪微博", "内容类型": "文章",
        #                  "发布账号类型": "权威可信账号", "内容可信分级": "一般可信"}
        #         input_str = "%s" % inp
        #         res_article.append(input_str)
        # return res_article[:1]

    async def _handle_wis_viewpoint(self, qwen_llm: ModelQwen, query, content_list, mid_list):
        prompt_maker = vp_1k_factory(query, content_list)
        prompt = prompt_maker.prompt()
        self.logger.info(self.pre_log_msg + f"[compress1k] [viewpoint] prompt: {prompt}")
        llm_res = await qwen_llm.async_call(prompt, prompt_maker.schema_index())
        self.logger.info(self.pre_log_msg + f"[compress1k] [viewpoint] llm_res: {llm_res}")
        try:
            re_temp = re.compile(r'\{[\s\S]+\}')
            result_temp = eval(re_temp.search(llm_res.get("text", "")).group())
            res_list = []

            if result_temp.get("大众看法",None):
                text_temp = result_temp["大众看法"]
                for i in text_temp:
                    text = i["大众观点"]
                    yw_list = i["引用博文序号"]
                    mid_tmp = []
                    for num in yw_list:
                        try:
                            mid = mid_list[num - 1]
                            mid_tmp.append(mid)
                        except:
                            continue
                    res_list.append({"观点":text,"引文":mid_tmp})
            return res_list
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"[compress1k] [viewpoint] error: {e}, traceback: {traceback.format_exc()}")
            return []

    async def _handle_wis_overview(self, qwen_llm: ModelQwen, query, content_list, mid_list):
        prompt_maker = ov_1k_factory(query, content_list)
        prompt = prompt_maker.prompt()
        self.logger.info(self.pre_log_msg + f"[compress1k] [overview] prompt: {prompt}")
        llm_res = await qwen_llm.async_call(prompt, prompt_maker.schema_index())
        self.logger.info(self.pre_log_msg + f"[compress1k] [overview] llm_res: {llm_res}")
        try:
            re_temp = re.compile(r'\{[\s\S]+\}')
            result_temp = eval(re_temp.search(llm_res.get("text", "")).group())
            res_dict = []

            if result_temp.get("概况",None):
                text_temp = result_temp["概况"]
                for i in text_temp:
                    text = i["概况正文"]
                    yw_list = i["引用博文序号"]
                    mid_tmp = []
                    for num in yw_list:
                        try:
                            mid = mid_list[num - 1]
                            mid_tmp.append(mid)
                        except:
                            continue
                    res_dict.append({"概况":text,"引文":mid_tmp})
            return res_dict
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"[compress1k] [overview] error: {e}, traceback: {traceback.format_exc()}")
            return []

    # 将物料进行压缩，输出两个池子
    async def compress1k(self, query, query_category, raw_time_grade, content_list,\
                        content_mids, raw_material_list, need_return_struct_content):
        """
        压缩物料，将其分为两种物料，content & opinion

        param: query: 原始查询
        param: query_category: 查询类别
        param: need_return_struct_content: 是否需要返回结构化核心物料内容
        param: content_list: 结构化物料
        param: content_mids: 结构化物料对应的mid
        param: raw_material_list: 原始物料
        """
        self.logger.info(self.pre_log_msg + f"[compress1k] start. \
                    query:{query}, content_list:{len(content_list)}, content_mids:{len(content_mids)}, \
                    raw_material_list:{len(raw_material_list)}, need_return_struct_content:{need_return_struct_content}")
        if len(content_list) != len(content_mids):
            self.logger.warning(self.pre_log_msg + f"[compress1k] warning. [{query}] content_list len not equal content_mids len")
            return [], []
        # 1. 重新划分为两个物料池， 事实、观点
        reality_pool = {} # mid: content
        opinion_pool = {} # mid: content

        if content_list and isinstance(content_list[0], dict):
            for i, m in enumerate(content_list):
                # 蓝V + 综合 事实
                if m.get("内容类型", "") == "博文" \
                    or m.get("发布账号类型", "") == "权威可信账号":
                    reality_pool[content_mids[i]] = m.get("内容", "")
                # 网友观点 / 普通账号
                if m.get("发布账号类型", "") != "权威可信账号":
                    opinion_pool[content_mids[i]] = m.get("内容", "")
        self.logger.info(self.pre_log_msg + f"[compress1k] [split] reality_pool:{len(reality_pool)},\
                    opinion_pool:{len(opinion_pool)}")
        
        # 2. 综合/热门/语义top30物料 核心物料 
        unify_content_list = []
        hot_content_list = []
        for m in raw_material_list:
                match m.get("from", ""):
                    case "vs":
                        if need_return_struct_content:
                            mid = m.get("mid", "")
                            if mid in content_mids:
                                index = content_mids.index(mid)
                                hot_content_list.append(content_list[index])
                        else:
                            hot_content_list.append(m.get("text", ""))
                    case "unify_base":
                        if need_return_struct_content:
                            mid = m.get("mid", "")
                            if mid in content_mids:
                                index = content_mids.index(mid)
                                unify_content_list.append(content_list[index])
                        else:
                            unify_content_list.append(m.get("text", ""))
                    case _:
                        continue
        core_pool = unify_content_list + hot_content_list[:30]

        # 3. chunk
        def _cal_chunk_size(content_list: list[str]):
                return len("".join(content_list))
        def _chunk_pool(pool: dict[str, str], chunk_size: int) \
              -> tuple[list[list[str]], list[list[str]]]:
            # 按照chunk_size切分，返回content_list, mid_list
            res_content = []
            res_mids = []

            chunk_content = []
            chunk_mids = []

            for mid, content in pool.items():
                if _cal_chunk_size(chunk_content) + _cal_chunk_size([content]) <= chunk_size:
                    chunk_content.append(content)
                    chunk_mids.append(mid)
                else:
                    res_content.append(chunk_content)
                    res_mids.append(chunk_mids)
                    chunk_content = [content]
                    chunk_mids = [mid]
            if chunk_content:
                res_content.append(chunk_content)
                res_mids.append(chunk_mids)
            return res_content, res_mids

        chunk_size = 25000 * 1.6 - 4000
        reality_pool_chunk = _chunk_pool(reality_pool, chunk_size)
        opinion_pool_chunk = _chunk_pool(opinion_pool, chunk_size)

        self.logger.info(self.pre_log_msg + f"[compress1k] [chunk result]. \
                    len of core_pool:{len(core_pool)}, \
                    len of reality_pool_chunk:{len(reality_pool_chunk[0])}, \
                    len of opinion_pool_chunk:{len(opinion_pool_chunk[0])}")


        # 4. map
        qwen_llm = ModelQwenWrapper(self.weibo, self.pid, self.pre_log_msg, "compress1k")

        opinion_res = []
        reality_res = []
        opinion_tasks = []
        reality_tasks = []

        for i, chunk in enumerate(opinion_pool_chunk[0]):
            opinion_tasks.append(self._handle_wis_viewpoint(qwen_llm, query, chunk, opinion_pool_chunk[1][i]))
        for i, chunk in enumerate(reality_pool_chunk[0]):
            reality_tasks.append(self._handle_wis_overview(qwen_llm, query, chunk, reality_pool_chunk[1][i]))
        opinion_res = await asyncio.gather(*opinion_tasks)
        reality_res = await asyncio.gather(*reality_tasks)
        # flatten
        opinion_res = [item for sublist in opinion_res for item in sublist]
        reality_res = [item for sublist in reality_res for item in sublist]
        await self.storage_redis_compress(query, query_category, opinion_res, reality_res, content_mids)

        # 移除引文, 保证和zhisou_content的格式一致
        for item in (opinion_res,  reality_res):
            for m in item:
                m.pop("引文", None)
        self.logger.info(self.pre_log_msg + f"[compress1k] finish. \
                    len of core_pool:{len(core_pool)}, \
                    len of opinion_res:{len(opinion_res)}, \
                    len of reality_res:{len(reality_res)}")
        return core_pool, opinion_res + reality_res

    async def get_redis_compress(self, query:str, query_category:str, raw_time_grade:str, content_mids:list):
        """
        从redis中获取数据
        :param query: 查询语句
        :param query_category: 查询类别
        :content_mids: 当前的物料id列表
        :return: {"need_compress": True, "opinion": None, "reality": None}
        """
        result = {"need_compress": True, "opinion": None, "reality": None}
        try:
            redis_result = await RedisBusinessCompress().get_data(query, query_category)
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error:{e}, msg:{traceback.format_exc()}")
            redis_result = None
        if not redis_result:
            return result

        return result

    async def storage_redis_compress(self, query:str, query_category:str, opinion: list, reality: list,
                                     content_mids:list):
        """
        向redis中保存数据
        :param query: 查询语句
        :param query_category: 查询类别
        :param opinion: 智搜观点
        :param reality: 智搜事实
        :param content_mids: 当前的物料id列表
        :return:
        """
        try:
            await RedisBusinessCompress().storage_data(query, query_category, opinion, reality, content_mids)
            self.logger.info(self.pre_log_msg + f"[compress1k] storage redis success. "
                                                f"query:{query}, query_category:{query_category}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error:{e}, msg:{traceback.format_exc()}")
        return

    async def confine_material_length(self):
        """对物料信息做长度限制, 依赖于意图识别label"""
        use_zhisou = self.weibo.get("use_zhisou", False)
        model = self.weibo.get("llm_name", 'qwen72b')
        stream_output = self.weibo.get("stream_output", 0)
        account_content_list = self.weibo.get('account_content_list', [])
        content_list = self.weibo.get('content_list', [])
        opinion_list = self.weibo.get("zhisou_content", [])
        label = self.weibo.get("label", "")
        query_type = self.weibo.get("query_type", "")
        knowledge = self.weibo.get("knowledge", "")
        query_category = self.weibo.get("query_category", "")
        cove_query = self.weibo.get("cove_query", False)
        baike_knowledge = self.weibo.get("baike_knowledge", [])
        content_mid_list = self.weibo.get("mid_list", [])
        sina_article_list = self.get_target_article()
        # 补充榜单词查询物料
        history_hot_list = self.weibo.get('history_hot_res', []) + self.weibo.get('hot_query_res', [])
        is_not_sort_flag = False
        base_length = 32000 * 1.6 - 4000 - len(knowledge) - sum([len(i.get('content', '')) for i in baike_knowledge]) - sum([len(i.get('内容','')) for i in sina_article_list]) - sum([len(i.get('内容','')) for i in history_hot_list])# prompt长度, knowledge
        if label == '问答':
            content_long_num = 6000
            extra_content_long_num = 2000
        else:
            content_long_num = 20000
            extra_content_long_num = 6000

        need_return_struct_content = False
        if self.use_struct_contentinfo and (model == "qwen72b" or model == "qwen72b_stream" or model == 'deepseek' or model == 'deepseek_stream'):
            account_content_list = self.weibo.get('account_struct_content_list', [])
            content_list = self.get_target_weibo()
            opinion_list = self.weibo.get("zhisou_content_struct", [])
            need_return_struct_content = True

        current_material_length = sum([len(str(item)) for item in (content_list + opinion_list)])
        # 限定非流式
        if current_material_length > base_length and stream_output == 0:
            self.logger.info(self.pre_log_msg + f"[compress1k][hit] current_material_length:{current_material_length}, \
                            base_length:{base_length}, stream_output:{stream_output}, model:{model}, label:{label}")
            try:
                content_list_new, opinion_list_new = await self.compress1k(self.weibo.get("query", ""),
                                                            self.weibo.get("query_category", ""),
                                                            self.weibo.get("raw_time_grade", ""),
                                                            self.weibo.get("struct_content_list", []),
                                                            self.weibo.get("mid_list", []),
                                                            self.weibo.get("raw_material_list", []),
                                                            need_return_struct_content)
                opinion_list = opinion_list_new + opinion_list
                if content_list_new:
                    content_list = content_list_new

                self.logger.info(self.pre_log_msg + f"[compress1k] compress success. \
                               content_list:{len(content_list)},  opinion_list:{len(opinion_list)}")
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"[compress1k] compress error. {e}")

        account_mid_len = 0
        account_content_str = ""
        opinion_str = ""
        if opinion_list:
            # 智搜物料
            opinion_str, _ = self.limit_material(opinion_list, extra_content_long_num, is_not_sort_flag, 0)

        base_length = base_length - len(opinion_str)
        if account_content_list:
            account_content_str, account_mid_len = self.limit_material(account_content_list, extra_content_long_num,
                                                                       is_not_sort_flag, 0, True)
        if label != '问答':
            # content_long_num = base_length - len(account_content_str)
            content_long_num = min(base_length - len(account_content_str), 40000)
    
        content_str, content_mid_len = self.limit_material(content_list, content_long_num, False, account_mid_len, False)

        baike = []
        if baike_knowledge and cove_query is False:
            # 如果知识不为空，且非COVE，则将百科知识作为物料输入，而去重后的知识作为背景知识
            baike, knowledge = self.trans_knowledge_content(baike_knowledge, knowledge)
            self.weibo["knowledge"] = knowledge
        content_str, sort_mid_list = self.rerank_content(content_str, content_mid_list[:content_mid_len], baike,
                                                         sina_article_list, history_hot_list, is_not_sort_flag, account_mid_len, stream_output, label)

        content_mid_len += len(baike) + len(sina_article_list) + len(history_hot_list)

        if opinion_list:
            # 智搜物料
            opinion_str, _ = self.limit_material(opinion_list, extra_content_long_num, is_not_sort_flag,
                                                 content_mid_len)

        self.weibo["all_mids_num"] = content_mid_len + account_mid_len + self.weibo.get('zhisou_mids_num', 0)
        self.weibo['use_content_mid_len'] = content_mid_len
        self.weibo['use_account_mid_len'] = account_mid_len
        self.weibo["sort_mid_list"] = sort_mid_list

        stock_info = self.weibo.get('stock_info', "")
        if stock_info:
            content_str = stock_info + "\n\n" + content_str
        self.weibo['content'] = content_str
        self.weibo['account_content'] = account_content_str
        self.weibo['opinion'] = opinion_str
        self.weibo['context'] = self.weibo.get("knowledge", "").strip()
        if (content_mid_len + account_mid_len) == 0 and query_category not in ["Account_Nor", "简报", "小结"]:
            ## 当物料为空时候，账号有夸夸逻辑, 简报的物料不一样， 小结是为了防止万一也可以不加
            pass

    async def query_intention_and_rewrite(self):
        """并行处理意图识别和query改写"""
        func_name = "INTENTION-QUERY_REWRITE"
        start = time.time()
        handles = [
            Intention(self.pid),
            QueryRewrite(self.pid),
        ]

        tasks = [handle.run(weibo=self.weibo) for handle in handles]
        await asyncio.gather(*tasks)
        self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}")

    def make_prompt(self):
        func_name = "MAKE-PROMPT"

        start = time.time()
        cases = {
            "ds": lambda: ds_factory(self.weibo),
            'risk_control': lambda: risk_control_factory(self.weibo),
            "hot_overview": lambda: hot_overview_factory(self.weibo),
            "hot_overview_gray": lambda: hot_overview_factory(self.weibo),
            'deepseek_comment': lambda: robot_factory(self.weibo),
        }

        label = self.weibo.get('label')
        prompt_factory = cases.get(label)
        result = prompt_factory()

        self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}")
        return result

    async def count_tokens(self, response, begin, first_stream=0):
        if not isinstance(response, dict):
            return
        await count_tokens(self.weibo, response, begin, first_stream)

    async def calc_question(self, content):
        if not content or self.pid == "test":
            return
        # ab实验只推送一次追问队列
        if self.weibo.get("abtest", ""):
            self.logger.info(self.pre_log_msg + "abtest not calc question, skip")
            return

        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        prompt_scene = self.weibo.get("prompt_scene", "")
        if prompt_scene == "verification_comment":
            query = self.weibo.get("cid")
        uid = self.weibo.get('uid', "5309797465")
        weibo_ai_search_mode = self.weibo.get('llm_name', "")
        source = self.weibo.get('source', '0')
        q_attr = self.weibo.get('q_attr', "")
        trace_id = self.weibo.get("trace_id", "")
        url = 'http://hotsearchweibostream.search.weibo.com/zhisou/question/async'
        data = {
            'query': query,
            'summary_str': content,
            'uid': uid if uid else '5309797465',
            'weibo_ai_search_mode': weibo_ai_search_mode,
            'source': str(source),
            'q_attr': q_attr,
            'da_intention' : self.weibo.get("da_intention", ""),
            'da_intention_exact_match' : self.weibo.get("da_intention_exact_match", ""),
            'query_category': self.weibo.get("query_category", ""),
            'famous_person_intention': self.weibo.get("famous_person_intention", {}),
            'his_hot_s_list': json.dumps(self.weibo.get("his_hot_s_list", []), ensure_ascii=False),
            'trace_id': trace_id
        }
        sid_dict = {
            "deepseek_xiaomi" : "xmapp_aisearch"
        }
        if sid_dict.get(prompt_scene, ""):
            data.update({
                "sid" : sid_dict.get(prompt_scene)
            })

        comment_type_dict = {
            "direct_comment" : "10",
            "verification_comment" : "7"
        }
        if comment_type_dict.get(prompt_scene, ""):
            data.update({
                "from" : comment_type_dict.get(prompt_scene),
                "comment": self.weibo.get("comment", "")
            })
        hash_str = md5_hash(query)
        bucket_id = get_bucket_id(hash_str, bucket_num=100)
        is_hot_query = self.weibo.get("hot_social_category", 0)
        res = ""
        queue_message = ""
        start = time.time()
        question2mcq = False
        try:
            # 非热搜/评论的流量中抽1%，走mcq生成追问链路
            if (not comment_type_dict.get(prompt_scene, "") and bucket_id < 50 and not is_hot_query) or data.get("sid", "") or uid == '2910525935':
                queue_message = json.dumps(data, ensure_ascii=False)
                res = await self.mcq_calc_question.set("wis_summary_maybeask", queue_message)
                question2mcq = True
            else:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(2)) as session:
                    async with session.post(url=url, json=data) as r:
                        if r.status == 200:
                            res = await r.json()
                        else:
                            self.logger.error(self.pre_log_msg + f"calc_question error: {json.dumps(data, ensure_ascii=False)}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"calc_question error:{e}, msg:{traceback.format_exc()}")
        self.logger.info(self.pre_log_msg + f"query:{query}\tcalc_question res:{res}\tcost:{time.time() - start}\tquestion2mcq:{question2mcq}\tdata:{queue_message}")

    async def call_llm(self, prompt):
        traceid = self.weibo.get("traceid", "")
        query = self.weibo.get("query", "")
        use_zhisou = self.weibo.get("use_zhisou", False)

        func_name = "总结生成"
        start = time.time()
        llm_qwen72b = ModelQwenWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_content = prompt.prompt()
        self.weibo['prompt'] = prompt_content
        retry = 2
        content = ""
        error_name = ""
        for i in range(retry):
            try:
                schema_index = None if i == 0 else prompt.schema_index()
                begin = time.time()
                response = await llm_qwen72b.async_call(prompt_content, schema_index)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                self.weibo["debug"]["time_analysis"][f"call_cove{i}_start"] = time.time()
                result = await self.call_cove(result)
                self.weibo["debug"]["time_analysis"][f"call_cove{i}_end"] = time.time()
                reference_mid_list = get_used_content_mid(self.weibo)
                self.weibo['reference_mid_list'] = reference_mid_list
                result = prompt.post_process(result)
                error_name, no_error = await self.check_result(result)
                if no_error:
                    self.weibo["debug"]["call_llm_times"] = i + 1
                    self.weibo["debug"]["time_analysis"]["call_llm_with_result_end"] = time.time()
                    json_result = self.weibo.get("json_result", {})
                    self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\ttimes:{i + 1}\t"
                                        f"label:{self.weibo.get('label', '')}\t"
                                        f"query_category:{self.weibo.get('query_category', '')}\t"
                                        f"result:{json.dumps(result, ensure_ascii=False)}\t"
                                        f"json_result:{json.dumps(json_result, ensure_ascii=False)}\t")
                    content = result
                    await self.calc_question(content)
                    break
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        self.write_log(message=f"{func_name} get no result, cost_time:{time.time() - start}")
        self.weibo["debug"]["call_llm_times"] = retry
        self.weibo["debug"]["time_analysis"]["call_llm_no_result_end"] = time.time()
        self.weibo["debug"]['end_process'] = time.time()
        await self.send_response(ready='yes' if content else 'error', content=content)
        if use_zhisou and error_name:
            alarm("qwen {} {} format error: {}".format(traceid, query, error_name))
        return content

    async def call_cove(self, result):
        func_name = "人工事实干预"
        start = time.time()
        cove_query = self.weibo.get('cove_query', False)
        knowledge = self.weibo.get('knowledge', "")
        if result and cove_query and knowledge:
            self.weibo['claim1'] = result
            cove_prompt = cove_factory(self.weibo)
            llm_qwen72b = ModelQwenWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
            prompt_content = cove_prompt.prompt()

            begin = time.time()
            response = await llm_qwen72b.async_call(prompt_content)
            await self.count_tokens(response, begin)
            result = response.get("text", "")
            result = cove_prompt.post_process(result)
            self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\t"
                                                f"claim1:{json.dumps(self.weibo['claim1'], ensure_ascii=False)}\t"
                                                f"result:{json.dumps(result, ensure_ascii=False)}")
        return result

    async def check_result(self, result):
        regression = Regression(self.weibo, self.pid)
        return await regression.run(result=result)

    async def query_modify(self):
        query_modify = QueryModify(self.weibo, self.pid)
        await query_modify.run()

    def post_process(self):
        model = self.weibo.get("llm_name", 'qwen72b')
        query = self.weibo.get("query", "")
        label = self.weibo.get("label", "")
        traceid = self.weibo.get("traceid", "")
        data = {
            'traceid': traceid,
            'query': query,
            'model': model,
            'time': time.time()
        }
        #if label in ['问答', '答案']:
        #    spider_baike_queue.set(json.dumps(data))

    def reset(self, weibo):
        self.weibo = weibo
        self.update_pre_log_msg(self.weibo)

    async def send_response(self, ready, content='', status_stage='', special_tips=""):
        await self.output.run(weibo=self.weibo, ready=ready, content=content, status_stage=status_stage, special_tips=special_tips)

    async def run(self, **kwargs):
        start = time.time()
        source = self.weibo.get("source", "")
        self.weibo["llm_trace_info"] = []
        llm_name = self.weibo.get("llm_name", "")
        self.weibo["debug"] = {
            "llm_name": self.weibo.get("llm_name", ""),
            "time_analysis": {
                "all_start": start,
                "input_end": time.time(),
                'add_query_info_ts_start': self.weibo.get('add_query_info_ts_start', time.time()),
                'add_query_info_ts_end': self.weibo.get('add_query_info_ts_end', time.time()),
            },
            'in_time_ms': self.weibo.get("in_time_ms", time.time()),
            'in_time': self.weibo.get('in_time', int(time.time())),
            'user_request_time_ms': self.weibo.get('user_request_time_ms', time.time()),
            'server_request_time_ms': self.weibo.get('server_request_time_ms', time.time()),
            'query_in_time': self.weibo.get('query_in_time', time.time()),
            "tokens_list": [],
        }
        self.update_pre_log_msg(self.weibo)

        recalculate = self.should_recalculate()
        async with recalculate.run(weibo=self.weibo) as lock:
            if not lock:
                self.weibo["debug"]['end_process'] = time.time()
                self.logger.info(
                    self.pre_log_msg + f"debug_info:{json.dumps(self.weibo['debug'], ensure_ascii=False)}\t")
                return

            await self.send_response(ready='begin')
            self.weibo["debug"]["time_analysis"]["query_modify_start"] = time.time()
            await self.query_modify()
            self.weibo["debug"]["time_analysis"]["query_modify_end"] = time.time()

            self.weibo["debug"]["time_analysis"]["fetch_material_start"] = time.time()
            await self.fetch_material()
            self.weibo["debug"]["time_analysis"]["fetch_material_end"] = time.time()

            self.weibo["debug"]["struct_begin"] = time.time()
            self.weibo["debug"]["time_analysis"]["check_material_end"] = time.time()
            await self.struct_material()
            self.weibo["debug"]["time_analysis"]["query_intention_and_rewrite_start"] = time.time()
            await self.query_intention_and_rewrite()
            self.weibo["debug"]["time_analysis"]["query_intention_and_rewrite_end"] = time.time()
            self.weibo["debug"]['fetch_data'] = time.time()
            await self.confine_material_length()
            prompt = self.make_prompt()
            self.weibo["debug"]["time_analysis"]["call_llm_start"] = time.time()

            weibo = self.weibo
            result = await self.call_llm(prompt)
            if weibo is not self.weibo:
                weibo.update(self.weibo)
            weibo['result'] = result
            self.post_process()
            return weibo

    async def filter_content_viewpoint(self, query, cotent1):
        if self.weibo.get("stream_output", 0) == 1:
            return None

        self.weibo["debug"]["time_analysis"]["filter_begin"] = time.time()
        def get_filter_promot(query, content):
            judge_value_template = """{[{"内容序号","","是否具有价值": "一般价值、较高价值、没有价值", "原因": ""}]}"""
            judge_value_prompt = f"""<任务说明> 请你仔细阅读并深刻理解事件词/query、内容集合/content，你的任务是：判断内容集合/content中的每一条内容对于事件词“{query}”是否具有价值,按照<输出示例>生成json。
                <价值判断准则>：
                    1. 内容集合/content的当前内容是对/query的积极评价或消极评价，并且/query和内容集合/content相关度很高，认为内容集合/content的当前内容具有较高价值。
                    2. 内容集合/content的当前内容是对/query的一般评价，并且内容集合/content的当前内容信息不全或者是不是表达大众观点，认为内容集合/content的当前内容具有一般价值。
                    3. 内容集合/content的当前内容与事件词/query不相关，则认为内容集合/content的当前内容不具有价值。相关性判断准则如下：事件词/query中的元素，例如时间、地点、人物、事件、影视作品名等都出现在当前内容中，判定为主题词/query与当前内容是相关的；如果当前内容能够满足事件词/query的意图，也可以认为是相关的；如果你无法正确理解事件词/query，事件词/query完整出现在当前内容中，也可以认为是相关的。

                <输入数据>
                1. 主题词/query：“{query}”
                2. 内容集合/content是一段文本，每行开头的数字表示当前内容是第几条数据，具体数据如下： “{content}”

                <输出示例>
                {judge_value_template}
                """
            return judge_value_prompt

        async def is_value_by_glm4(full_prompt):
            func_name = "CALL_IS_VALUE_LLM_CHATGLM4"
            llm_chatglm4 = ModelGlm4Wrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
            response = await llm_chatglm4.async_chatglm4_9b_api(full_prompt,max_tokens=2048,timeout=300)
            res = response.get("text", "")
            #result = llm_chatglm4.async_chatglm4_9b_api(full_prompt)
            return res


        def filter_keep_len(filter_value_text):
            '''
            weibo['raw_material_list'] = res_list
            weibo['content_list'] = content_list
            weibo['video_abs_list'] = video_abs_list
            weibo['mid_list'] = mid_list
            weibo['struct_content_list'] = struct_content_list
            weibo['struct_mid_list'] = struct_mid_list
            weibo['tag3_list'] = tag3_list
            weibo['verified_type_list'] = verified_type_list
            weibo['name_list'] = name_list
            weibo['from_list'] = from_list
            weibo['blue_v'] = blue_v
            '''
            res_list = []
            content_list = []
            video_abs_list = []
            mid_list = []
            struct_content_list = []
            struct_mid_list = []
            tag3_list = []
            verified_type_list = []
            name_list = []
            from_list = []
            blue_v = []
            for i in range(len(cotent1)):
                tmp_content = cotent1[i]
                if tmp_content in filter_value_text:
                    continue
                res_list.append(self.weibo['raw_material_list'][i])
                content_list.append(self.weibo['content_list'][i])
                video_abs_list.append(self.weibo['video_abs_list'][i])
                mid_list.append(self.weibo['mid_list'][i])
                struct_content_list.append(self.weibo['struct_content_list'][i])
                # struct_mid_list.append(self.weibo['struct_mid_list'][i])
                tag3_list.append(self.weibo['tag3_list'][i])
                verified_type_list.append(self.weibo['verified_type_list'][i])
                name_list.append(self.weibo['name_list'][i])
                from_list.append(self.weibo['from_list'][i])
                blue_v.append(self.weibo['blue_v'][i])
            self.weibo['raw_material_list'] = res_list
            self.weibo['content_list'] = content_list
            self.weibo['video_abs_list'] = video_abs_list
            self.weibo['mid_list'] = mid_list
            self.weibo['struct_content_list'] = struct_content_list
            self.weibo['struct_mid_list'] = struct_mid_list
            self.weibo['tag3_list'] = tag3_list
            self.weibo['verified_type_list'] = verified_type_list
            self.weibo['name_list'] = name_list
            self.weibo['from_list'] = from_list
            self.weibo['blue_v'] = blue_v
            # print('-----good job!-----')
        content_list = []
        no = 0
        for i in range(len(cotent1)):
            viewpoint = self.weibo['viewpoint'][i]
            if viewpoint == 1:
                no += 1
                string = '{}.{}'.format(no, cotent1[i])
                content_list.append(string)
        #print('cotent1 is',len(cotent1),'len(content_list):',len(content_list),query)
        content = '\n'.join(content_list)
        prompt = get_filter_promot(query, content)
        result = []
        try:
            result_1 = await is_value_by_glm4(prompt)
            #print('---------result_1--------')
            #print(result_1)
            re_temp = re.compile(r'\[[\s\S]+\]')
            result = eval(re_temp.search(result_1).group())
            #print('---------result--------')
            #print(result)
        except Exception as e:
            self.logger.info(self.pre_log_msg + "filter_promot ".format(traceback.format_exc()))
            return None
        filter_value_text = set()
        for i in range(len(content_list)):
            text = content_list[i]
            if len(result) <= i or not result:
                break
            res = result[i]
            is_value = res.get('是否具有价值', '')
            if '没有价值' == is_value:
                #print('-----add +-------')
                filter_value_text.add(text)
        if filter_value_text:
            #print('-----filter +-------')
            self.weibo['filter_weibo'] = filter_value_text
            filter_keep_len(filter_value_text)
        self.weibo["debug"]["time_analysis"]["filter_end"] = time.time()


    def identifity_content_viewpoint(self, cotent):
        def merge_splits(splits, _chunk_size=1800):
            docs = []
            current_doc = []
            total = 0
            for i, d in enumerate(splits):
                _len = len(d)  # 1
                if total + _len > _chunk_size:
                    if len(current_doc) > 0:
                        docs.append(current_doc[:])
                        current_doc = []
                        total = 0
                current_doc.append(d)
                total += _len
            if len(current_doc) > 0:
                docs.append(current_doc)
            return docs

        def req_get_viewpoint(doc_list):
            url = 'http://llm-huawei.multimedia.wml.weibo.com/mm-wb-search/t5base-reality-weibo-search-661e3e88/v2/models/t5base-reality/infer'
            headers = {'Content-Type': 'application/json'}
            datas = {"id": "42", "inputs":
                [{"shape": [len(doc_list)], "datatype": "BYTES", "name": "input",
                  "data": [item[:512] for item in doc_list]}]}
            is_viewpoint_list = [0] * len(doc_list)
            try:
                r = requests.post(url, json=datas, headers=headers,
                                  timeout=0.5 if self.weibo["stream_output"] == 1 else 2)
                res = r.json()
                scores = np.reshape(res["outputs"][0]["data"], (-1, 2))
                scores_01 = np.where(np.array(scores) < 0.9, 0, 1)
                is_viewpoint_list = scores_01[:, 0].tolist()
            except Exception as e:
                self.logger.error("doc_list:{}, request viewpoint exception:{}".format(len(doc_list), e))
            return is_viewpoint_list

        def filter_reality(sub_list):
            docs = merge_splits(sub_list)
            res_list = list()
            for i, doc_list in enumerate(docs):
                if self.weibo.get("stream_output", 0) == 1 and i > 0:
                    is_viewpoint_list = [0] * len(doc_list)
                else:
                    is_viewpoint_list = req_get_viewpoint(doc_list)
                res_list.extend(is_viewpoint_list)
            return res_list

        if self.weibo.get("llm_name", "") == "qwen72b" and self.weibo.get("stream_output", 0) == 0:
            viewpoint = filter_reality(cotent)
        else:
            viewpoint = [0] * len(cotent)
        self.weibo["viewpoint"] = viewpoint
        self.weibo["debug"]["viewpoint_get_time"] = time.time()
        return viewpoint

    def struct_content_modified(self, viewpoints, blue_v, struct_content_list):
        viewpoint_len = len(viewpoints)
        blue_v_len = len(blue_v)
        struct_content_len = len(struct_content_list)
        if struct_content_len != blue_v_len and blue_v_len != viewpoint_len:
            self.logger.error("query:{}\ttraceid:{}\content length error")
            return
        for i in range(len(viewpoints)):
            if viewpoints[i] == 1:
                struct_content_list[i].update({"内容类型": "网友观点"})
            else:
                struct_content_list[i].update({"内容类型": "博文"})

        # for i in range(len(blue_v)):
        #     if int(blue_v[i]) >= 1 and int(blue_v[i]) <= 7:
        #         struct_content_list[i].update({"发布账号类型": "权威可信账号"})
        #         struct_content_list[i].update({"内容可信分级": "权威可信"})
        #     else:
        #         struct_content_list[i].update({"发布账号类型": "普通账号"})
        #         struct_content_list[i].update({"内容可信分级": "一般可信"})
        self.weibo["struct_content_list"] = struct_content_list
