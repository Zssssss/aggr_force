import asyncio
import time
import json
import traceback

import aiohttp

from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.business import business_factory
from plugins.post_process.utils import split_think_and_content


class BusinessLLM(DeepSeekLLM):

    def make_prompt(self):
        func_name = "MAKE-PROMPT"
        start = time.time()
        result = business_factory(self.weibo)
        self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}")
        return result

    async def aio_post(self, semaphore, session, data, url):
        result = {}
        try:
            async with semaphore:
                async with session.post(url, json=data) as response:
                    res_data = await response.json()
                    result = res_data
                    return result
        except Exception as e:
            err = traceback.format_exc()
            self.logger.error(self.pre_log_msg + f"aio_post error: {data} {err}")
        return result

    async def _get_emotion_res(self, emotion_data):
        timeout = aiohttp.ClientTimeout(total=5)
        emotion_url = "http://10.54.2.38:8024/v1/wis_emation_model"
        semaphore = asyncio.Semaphore(5)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            res = await self.aio_post(semaphore, session, emotion_data, url=emotion_url)
            result = json.loads(json.loads(res.get("result", "")))
            return result

    async def _get_ciyun_res(self, ciyun_data):
        timeout = aiohttp.ClientTimeout(total=5)
        ciyun_url = "http://10.54.2.38:8024/v1/wis_query_tokenizer"
        semaphore = asyncio.Semaphore(5)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            res = await self.aio_post(semaphore, session, ciyun_data, url=ciyun_url)
            result = json.loads(res.get("result", ""))
            for item in result:
                item["name"] = item.pop("key")
            return result

    def handle_json_response(self, response):
        text = response.get("text", "")
        think, content = split_think_and_content(text)
        data = json.loads(content)
        content_list = []
        for item in data:
            title = item.get("title", "")
            content_text = item.get("content", None)
            if content_text:
                content_list.append(f"**{title}**\n{content_text}")
        content = "\n".join(content_list)
        new_text = f"{think}\n{content}"
        response["text"] = new_text
        return response

    async def call_llm(self, prompt):

        content = await self.call_llm_impl()
        tasks = []
        query = self.weibo.get("query", "")
        trace_id = self.weibo.get("trace_id", "")
        qdict = self.weibo.get("qdict", {})
        content_list = self.weibo.get("content_list", [])
        query_type = self.weibo.get('query_type',"")
        category = self.weibo.get('query_category')
        business_flag = False
        res_version = "000"
        emotation_data = {
            "weibo":{
                "query": query,
                "content_list": content_list,
                "res_version": res_version,
                "qdict": qdict
            }
        }
        ciyun_data = {
            "query": query,
            "trace_id": trace_id,
            "query_type": query_type,
            "category": category,
            "business_flag": business_flag,
            "res_version": res_version,
            "qdict": qdict
        }
        tasks.append(asyncio.create_task(self._get_ciyun_res(ciyun_data)))
        tasks.append(asyncio.create_task(self._get_emotion_res(emotation_data)))
        ciyun_res,emotion_res = await asyncio.gather(*tasks)
        emotion_res["title"] = "大众情绪"
        think, content = split_think_and_content(content)
        front_content = f"用户对{query}问题非常有兴趣，希望能获得{query}问题相关的更多信息。下面将从大众情绪、讨论词云、信息溯源、大V观点、用户观点、行业意义等角度展开论述。"
        emotion_data = {
            "type":"emotion",
            "index": "0",
            "data":emotion_res
        }
        emotion_block = f"```wbCustomBlock{json.dumps(emotion_data, ensure_ascii=False)}```"
        ciyun_data = {
            "type":"ciyun",
            "index": "1",
            "data":{
                "title": "讨论词云",
                "words":ciyun_res
                }
        }
        ciyun_block = f"```wbCustomBlock{json.dumps(ciyun_data, ensure_ascii=False)}```"
        all_content = f"{think}\n{front_content}{emotion_block}{ciyun_block}{content}"
        await self.send_response(ready='yes' if content else 'error', content=all_content, status_stage=4)
        return all_content