import asyncio
import time
import json
import traceback

from api.model_api import QWEN3_30B_XiaoYiWrapper, get_deepseek_r1_model_from_weibo_sid
from plugins.llm.deepseek import DeepSeekLLM, StreamDeepSeekLLM
from plugins.prompt.xiaomi import xiaomi_factory


class XiaoMiLLM(DeepSeekLLM):

    def make_prompt(self):
        func_name = "MAKE-PROMPT"
        start = time.time()
        result = xiaomi_factory(self.weibo)
        self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}")
        return result


class XiaoMiStreamLLM(StreamDeepSeekLLM):

    async def fetch_material(self):
        self.weibo['xiaomi_stream'] = True
        await super().fetch_material()

    def make_prompt(self):
        func_name = "MAKE-PROMPT"
        start = time.time()
        result = xiaomi_factory(self.weibo)
        self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}")
        return result


