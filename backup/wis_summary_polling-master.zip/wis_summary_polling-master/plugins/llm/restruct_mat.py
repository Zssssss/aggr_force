weibo_template = """[weibo {idx} begin]
    [content begin]{content}[content end]
    [content type begin]博文[content type end] 
    [account type begin]{account_type}[account type end]
[weibo {idx} end]
"""

baike_template = """[baike {idx} begin]
    [content begin]{content}[content end]
    [content type begin]百科知识[content type end] 
    [account type begin]权威可信账号[account type end]
[baike {idx} end]
"""

article_template = """[article {idx} begin]
    [content begin]{content}[content end]
    [content type begin]文章[content type end] 
    [account type begin]权威可信账号[account type end]
[article {idx} end]
"""

general_template = """[结果 {idx} begin]
    [type begin]{source}[type end]
    [content begin]{content}[content end]
    [date begin]{pub_time}[date end]
    [account type begin]{account_type}[account type end]
[结果 {idx} end]
"""

general_template_account = """[结果 {idx} begin]
    [type begin]{source}[type end]
    [username begin]{nickname_type}[username end]
    [content begin]{content}[content end]
    [date begin]{pub_time}[date end]
    [account type begin]{account_type}[account type end]
[结果 {idx} end]
"""

general_template_jinja = """[结果 {{ idx }} begin]
    [type begin]{{ source }}[type end]
    [username begin]{{ nickname_type }}[username end]
    [content begin]{{ content }}[content end]
    {%- if value_tag is defined and value_tag %}
    [value tag begin]{{ value_tag }}[value tag end]
    {%- endif %}
    {%- if extra_info_tag is defined and extra_info_tag %}
    [Extra information begin]{{ extra_info_tag }}[Extra information end]
    {%- endif %}
    [date begin]{{ pub_time }}[date end]
    [account type begin]{{ account_type }}[account type end]
[结果 {{ idx }} end]
"""

general_template_star_click = """[结果 {idx} begin]
    [type begin]{source}[type end]
    [username begin]{nickname_type}[username end]
    [content begin]{content}[content end]
    [content tag begin]{hot_click_tag}[content tag end]
    [date begin]{pub_time}[date end]
    [account type begin]{account_type}[account type end]
[结果 {idx} end]
"""

general_template_pic = """[结果 {idx} begin]
    [type begin]{source}[type end]
    [content begin]{content}[content end]
    [account type begin]{account_type}[account type end]
    [picture begin]{picture_urls}[picture end]
[结果 {idx} end]
"""

picture_template = """[pic:{idx}]"""

# account_type: 包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”