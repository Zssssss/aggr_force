# -*- coding:utf-8 -*-
import asyncio
import json
import re
import time
import traceback

from alarm.alarm import alarm
from api.model_api import WeiboDeepseekWrapper
from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.star_ip import star_ip_factory, STAR_STAGE_LIST, IP_STAGE_LIST


class StarIpLLM(DeepSeekLLM):

    async def call_llm(self, prompt):
        func_name = "总结生成"
        category = self.weibo.get('category', "")
        # set llm_sub_source
        self.weibo["llm_sub_source"] = "hot_band_start"
        start = time.time()
        async def _calculate(stage_index: int):
            llm_qwen72b = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
            prompt_content = prompt.prompt(stage_index)
            self.weibo['prompt'] = prompt_content
            retry = 2
            result = ""
            for i in range(retry):
                try:
                    schema_index = None
                    begin = time.time()
                    response = await llm_qwen72b.async_call(prompt_content, schema_index)
                    # self.count_tokens(response, begin)
                    self.weibo["output_all_ready"] = True
                    ori_result = response.get("text", "")
                    self.weibo["ori_result"] = ori_result
                    result = prompt.post_process(ori_result, stage_index)
                    self.weibo["debug"]["time_analysis"][f"call_cove{i}_start"] = time.time()
                    self.weibo["debug"]["time_analysis"][f"call_cove{i}_end"] = time.time()
                    return result
                except Exception as e:
                    self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
            self.weibo["debug"]["call_llm_times"] = retry
            self.weibo["debug"]["time_analysis"]["call_llm_no_result_end"] = time.time()
            self.weibo["debug"]['end_process'] = time.time()
            return result
        tasks = []
        # 101 202 203 204 明星、电影、电视剧、综艺
        if category == '101':
            for i in range(len(STAR_STAGE_LIST)):
                tasks.append(_calculate(i))
        else:
            for i in range(len(IP_STAGE_LIST)):
                tasks.append(_calculate(i))
        results = await asyncio.gather(*tasks)
        return results

    async def run(self, **kwargs):
        start = time.time()
        source = self.weibo.get("source", "")
        self.weibo["llm_trace_info"] = []
        llm_name = self.weibo.get("llm_name", "")
        self.weibo["debug"] = {
            "llm_name": self.weibo.get("llm_name", ""),
            "time_analysis": {"all_start": start, "input_end": time.time()},
            'in_time_ms': self.weibo.get("in_time_ms", time.time()),
            'in_time': self.weibo.get('in_time', int(time.time())),
            'query_in_time': self.weibo.get('query_in_time', time.time()),
            "tokens_list": [],
        }
        self.update_pre_log_msg(self.weibo)
        self.weibo["debug"]["time_analysis"]["query_modify_start"] = time.time()
        await self.query_modify()
        self.weibo["debug"]["time_analysis"]["query_modify_end"] = time.time()

        self.weibo["debug"]["time_analysis"]["fetch_material_start"] = time.time()
        await self.fetch_material()
        self.weibo["debug"]["time_analysis"]["fetch_material_end"] = time.time()

        self.weibo["debug"]["struct_begin"] = time.time()
        self.weibo["debug"]["time_analysis"]["check_material_end"] = time.time()
        await self.struct_material()
        self.weibo["debug"]["time_analysis"]["query_intention_and_rewrite_start"] = time.time()
        # await self.query_intention_and_rewrite()
        self.weibo["debug"]["time_analysis"]["query_intention_and_rewrite_end"] = time.time()
        self.weibo["debug"]['fetch_data'] = time.time()
        await self.confine_material_length()
        prompt = star_ip_factory(self.weibo)
        self.weibo["debug"]["time_analysis"]["call_llm_start"] = time.time()
        result = await self.call_llm(prompt)

        mid_list = self.weibo.get("mid_list", [])
        link_list = self.weibo.get("link_list", [])
        account_mid_list = self.weibo.get("account_mid_list", [])
        label = self.weibo.get("label", "")
        tmp_used_baike = self.weibo.get('urls_used_baike', [])
        tmp_used_article = self.weibo.get('urls_used_article', [])
        self.logger.info(self.pre_log_msg + f"llm_name:{llm_name}\tsource:{source}\tlabel:{label}\tarticle_urls:{tmp_used_article}\tbaike_urls:{tmp_used_baike}\tmid_list:{mid_list}\tlink_list:{link_list}\taccount_mid_list:{account_mid_list}\tresult:{json.dumps(result, ensure_ascii=False)}")

        self.weibo["debug"]["time_analysis"]["call_llm_end"] = time.time()
        self.weibo["debug"]['end_process'] = time.time()
        self.weibo['result'] = result
        self.weibo["debug"]["time_analysis"]["all_end"] = time.time()
        # self.logger.info(self.pre_log_msg + f"debug_info:{json.dumps(self.weibo['debug'], ensure_ascii=False)}\t" + f"material_info:{json.dumps(self.log_info(self.weibo), ensure_ascii=False)}")
        # self.post_process()
        return self.weibo