# -*- coding:utf-8 -*-
import json
import asyncio
import aiohttp
from urllib.parse import quote
from lib.base import Base
from api.base_api import BaseApi


class HotSearchQuickReportOutput(Base):
    """热搜速报mock输出类，用于模拟大模型输出"""
    EVENTS_API_URL = "http://flashbrief.search.weibo.com:19890/api/ranking/landing_brief_event"  # 事件列表
    DESC_API_URL = "https://ai.s.weibo.com/api/wis/show.json?cot=1&query={}&sid=hot_briefing"  # 获取最新进展
    MIN_RESULT_BLOCKS = 1  # 最小结果块数量阈值
    
    def __init__(self, pid):
        super().__init__(pid)
        
    async def get_hotevent_and_words(self, api_url):
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(api_url, timeout=5) as response:
                        if response.status == 200:
                            data = await response.json()
                            self.logger.info(self.pre_log_msg + f"成功获取event和word列表: {len(data)}条，重试次数: {attempt + 1}")
                            return data
                        else:
                            self.logger.error(self.pre_log_msg + f"获取event和word列表失败，状态码: {response.status}，重试次数: {attempt + 1}")
                            if attempt < max_retries - 1:
                                continue
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"获取event和word列表异常: {str(e)}，重试次数: {attempt + 1}")
                if attempt < max_retries - 1:
                    continue
        
        self.logger.error(self.pre_log_msg + f"获取event和word列表失败，已达到最大重试次数: {max_retries}")
        return []
    
    async def get_single_description(self, event):
        """
        为单个event并发获取描述信息
        
        Args:
            event (str): 标题
            
        Returns:
            tuple: (event: str, desc: str) 标题和对应的描述
        """
        max_retries = 3
        api_url = self.DESC_API_URL.format(quote(event))
        
        for attempt in range(max_retries):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(api_url, timeout=5) as response:
                        if response.status == 200:
                            data = await response.json()
                            desc = data.get("content_hot_guide", "")
                            self.logger.info(self.pre_log_msg + f"成功获取描述信息: {event}，重试次数: {attempt + 1}")
                            return event, desc
                        else:
                            self.logger.error(self.pre_log_msg + f"获取描述信息失败，状态码: {response.status}，重试次数: {attempt + 1}")
                            if attempt < max_retries - 1:
                                continue
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"获取描述信息异常: {event}, error: {str(e)}，重试次数: {attempt + 1}")
                if attempt < max_retries - 1:
                    continue
        
        self.logger.error(self.pre_log_msg + f"获取描述信息失败，已达到最大重试次数: {event}")
        return event, ""

    async def get_descriptions_concurrent(self, events):
        if not events:
            return {}
        
        # 创建并发任务
        tasks = [self.get_single_description(event) for event in events]
        
        try:
            # 并发执行所有任务
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # 处理结果
            desc_data = {}
            for result in results:
                if isinstance(result, Exception):
                    self.logger.error(self.pre_log_msg + f"并发获取描述信息异常: {str(result)}")
                    continue
                
                if isinstance(result, tuple) and len(result) == 2:
                    event, desc = result
                    desc_data[event] = desc
            
            self.logger.info(self.pre_log_msg + f"并发获取描述信息完成: {len(desc_data)}/{len(events)}")
            return desc_data
            
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"并发获取描述信息失败: {str(e)}")
            return {}
        
    async def get_descriptions_batch(self, events, batch_size=20):
        if not events:
            return {}
        
        desc_data = {}
        total_events = len(events)
        
        # 分批处理
        for i in range(0, total_events, batch_size):
            batch_events = events[i:i + batch_size]
            batch_num = i // batch_size + 1
            total_batches = (total_events + batch_size - 1) // batch_size
            
            self.logger.info(self.pre_log_msg + f"开始处理第{batch_num}/{total_batches}批，包含{len(batch_events)}个event")
            
            # 并发获取当前批次的描述信息
            batch_desc_data = await self.get_descriptions_concurrent(batch_events)
            desc_data.update(batch_desc_data)
            
            # 批次间短暂hold下，避免给服务造成过大压力
            if i + batch_size < total_events:
                await asyncio.sleep(0.1)
        
        self.logger.info(self.pre_log_msg + f"分批获取描述信息完成: {len(desc_data)}/{total_events}")
        return desc_data
    
    def build_scheme(self, event, t_value):
        """
        构建scheme链接
        
        Args:
            event (str): 标题
            t_value (int): t参数值，desc同层t=908，hotWord里t=907
            
        Returns:
            str: 构建好的scheme链接
        """
        q = quote(event)
        return f"sinaweibo://searchall?containerid=100103&type=200&q={q}&t={t_value}"

    def build_result_block(self, event, desc, words):
        """
        构建单个result块
        
        Args:
            event (str): 标题
            desc (str): 描述
            words (list): 热搜词列表
            
        Returns:
            dict: 格式化的result数据
        """
        # 构建主scheme链接（t=908）
        main_scheme = self.build_scheme(event, 908)
        
        return {
            "event": event,
            "desc": desc,
            "scheme": main_scheme
        }
    
    async def generate_mock_output(self, events_api_url):
        try:
            # 1. 获取event和word列表
            event_data = await self.get_hotevent_and_words(events_api_url)
            if not event_data:
                self.logger.error(self.pre_log_msg + "未获取到event和word数据")
                return False, "", 0
            
            # 2. 提取所有event
            events = [item.get("event_id") for item in event_data]
            
            # 3. 分批并发获取event对应的desc，每20个一个batch
            desc_data = await self.get_descriptions_batch(events, batch_size=20)
            
            # 4. 构建result块列表
            result_blocks = []
            for item in event_data:
                event = item.get("event_id")
                words = item.get("words", [])
                desc = desc_data.get(event, "")
                if not desc:
                    self.logger.info(self.pre_log_msg + f"获取速报简介失败，跳过: {event}")
                    continue

                result_block = self.build_result_block(event, desc, words)
                result_blocks.append(result_block)
            
            # 5. 拼接最终输出格式
            output_lines = []
            result = {
                "type": "hotQuickReport",
                "data" : result_blocks
            }
            result_json = json.dumps(result, ensure_ascii=False)
            output_lines.append(f"```wbCustomBlock{result_json}```")
            
            final_output = "\n".join(output_lines)
            self.logger.info(self.pre_log_msg + f"成功生成mock输出，包含{len(result_blocks)}个热搜块")
            
            return True, final_output, len(result_blocks)
            
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"生成mock输出异常: {str(e)}")
            return False, "", 0
    
    async def run(self, **kwargs):
        """
        运行mock输出生成
        
        Args:
            kwargs: 参数字典
            
        Returns:output: str

        output: 格式化的输出字符串
        失败场景包括：
        1. get_hotevent_and_words超时或者失败
        2. result_blocks的数量少于阈值（MIN_RESULT_BLOCKS=1）
        3. 其他可能失败的场景
        """
        events_api_url = self.EVENTS_API_URL
        min_result_blocks = self.MIN_RESULT_BLOCKS
        
        success, output, result_blocks_count = await self.generate_mock_output(events_api_url)

        if not success:
            self.logger.error(self.pre_log_msg + "生成mock输出失败")
            return ""
        
        if result_blocks_count < min_result_blocks:
            self.logger.error(
                self.pre_log_msg +
                f"result_blocks数量不足：{result_blocks_count} < {min_result_blocks}"
            )
            return ""
        
        self.logger.info(
            self.pre_log_msg +
            f"成功生成mock输出，result_blocks数量：{result_blocks_count}"
        )
        return output

async def main():
    """测试HotSearchQuickReportOutput类的run方法"""
    import sys
    
    # 创建HotSearchQuickReportOutput实例
    pid = "test_mock_output"
    mock_output = HotSearchQuickReportOutput(pid)

    try:
        # 直接调用run方法进行测试
        output = await mock_output.run()
        print(output)
    except Exception as e:
        print(f"测试过程中发生异常: {str(e)}")

if __name__ == "__main__":
    # 运行异步main函数
    asyncio.run(main())