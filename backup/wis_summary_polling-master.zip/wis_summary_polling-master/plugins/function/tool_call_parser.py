import json
import re
from dataclasses import dataclass

@dataclass
class ToolCall:
    """工具调用的数据结构"""

    name: str
    arguments: dict | str
    id: str = "auto_generated"

@dataclass
class ParseResult:
    """解析结果"""

    success: bool
    tool_calls: list[ToolCall] | None = None
    text_content: str | None = None
    error: str | None = None

class ToolCallParser:
    """
    通用的工具调用解析器

    支持从文本中提取工具调用，并转换为标准格式。

    参数:
        action_marker: 工具调用的标记关键字（如 "Action:", "TOOL:", "<function_call>"）
        observation_marker: 观察结果的标记关键字（如 "Observation:", "RESULT:"）
    """

    def __init__(
        self,
        action_marker: str = "tool_calls",
        observation_marker: str = "Observation:"
    ):
        self.action_marker = action_marker
        self.observation_marker = observation_marker

    def parse(self, text: str) -> ParseResult:
        """
        解析文本，提取工具调用

        Args:
            text: LLM 输出的文本

        Returns:
            ParseResult: 解析结果
        """
        if self.observation_marker in text:
            return ParseResult(
                success=False, error=f"Text contains observation marker '{self.observation_marker}', should not happen"
            )

        if self.action_marker not in text:
            return ParseResult(success=True, text_content=text)

        try:
            tool_calls = self._extract_tool_calls(text)
            if not tool_calls:
                return ParseResult(success=True, text_content=text)

            return ParseResult(success=True, tool_calls=tool_calls)
        except Exception as e:
            return ParseResult(success=False, error=f"Failed to parse tool calls: {e}")

    def _extract_tool_calls(self, text: str):
        """提取所有 <tool_calls> 中的工具调用，支持多个 JSON 对象 & 括号匹配容错"""
        tool_calls = []

        # 先提取 <tool_calls> 内容块
        matches = re.findall(r"<tool_calls>\s*(.*?)\s*</tool_calls>", text, re.DOTALL)
        for match in matches:
            blocks = self._extract_json_blocks(match)
            for block in blocks:
                try:
                    action_dict = json.loads(block)
                except json.JSONDecodeError:
                    # 容错：尝试补齐右花括号再解析
                    try:
                        action_dict = json.loads(block + "}")
                    except Exception:
                        continue

                if "function_name" in action_dict:
                    name = action_dict["function_name"]
                    arguments = action_dict.get("parameters", {})
                elif "name" in action_dict:
                    name = action_dict["name"]
                    arguments = action_dict.get("arguments", {})
                else:
                    continue

                tool_calls.append(ToolCall(name=name, arguments=arguments))

        return tool_calls

    def _extract_json_blocks(self, s: str):
        """从字符串中提取多个独立 JSON 对象（按花括号平衡匹配）"""
        blocks = []
        start = None
        depth = 0

        for i, ch in enumerate(s):
            if ch == '{':
                if depth == 0:
                    start = i
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0 and start is not None:
                    blocks.append(s[start:i + 1])
                    start = None

        # 若最后一个 JSON 没闭合，也尝试记录
        if start is not None and start < len(s):
            blocks.append(s[start:])
        return blocks

    @classmethod
    def react(cls) -> "ToolCallParser":
        """ReAct 格式解析器（默认格式）"""
        return cls(action_marker="Action:", observation_marker="Observation:")

    @classmethod
    def markdown_style(cls) -> "ToolCallParser":
        """Markdown 代码块风格解析器"""
        return cls(
            action_marker="tool_calls",
            observation_marker="```function_result"
        )


if __name__ == "__main__":
    parser = ToolCallParser.markdown_style()
    text = """
<tool_calls>
{
    "function_name": "baike_search",
    "parameters": {
        "queries": ["虞书欣"]
    }
}
</tool_calls>"""
    result = parser.parse(text)
    print(f"result: {result}")
    print(f"result: {result.tool_calls}")
