"""单元测试"""
# -*- coding:utf-8 -*-
import json
import asyncio
from copy import deepcopy
from plugins.query_rewrite.query_rewrite import QueryRewrite


async def run_task(weibo):
    """协程运行任务"""
    intention = QueryRewrite(1)
    query = weibo.get("query", "")
    old_label = weibo.get("query_analysis", "")
    await intention.run(weibo)
    new_label = weibo.get("query_analysis", "")
    print(f"query:{query}\told_label:{old_label}, new_label:{new_label}")


def main():
    file_path = r"D:\work\code\wis_summary_polling_refector\wis_summary_polling\data\test.json"
    with open(file_path, "r", encoding="utf-8") as f:
        all_weibo = json.load(f)

    async def execute_materials():
        tasks = []
        for weibo in all_weibo:
            current = deepcopy(weibo)
            tasks.append(run_task(current))
        await asyncio.gather(*tasks)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(execute_materials())
    print("unit_test is end")


if __name__ == "__main__":
    main()
