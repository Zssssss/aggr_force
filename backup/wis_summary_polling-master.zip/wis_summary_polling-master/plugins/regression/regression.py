# -*- coding:utf-8 -*-
import json
import re
from datetime import datetime

from simhash import Simhash

from api.model_api import ModelQwen, ModelApi, ModelQwenWrapper, ModelGlm4Wrapper
from lib.base import Base
from plugins.regression.prompts import truncation_prompt, material_error_content, material_prompt
# from plugins.regression.tables import STAR_TABLE


class BaseRegression(Base):
    def __init__(self, weibo, pid):
        super().__init__(pid)
        self.weibo = weibo

    async def check(self, result):
        raise NotImplementedError

    async def run(self, **kwargs):
        result = kwargs.get("result", "")
        if not result:
            return True

        return await self.check(result)


class SpecialSymbolRegression(BaseRegression):

    async def check(self, result):
        trace_id: str = self.weibo.get('trace_id', "")
        if '不确定信息验证' in result:
            self.logger.info('{} has outlines symbol'.format(result))
            return True

        for sym in ['{', "}", "<", ">", '\\']:
            if sym in result:
                self.logger.info('[{}] {} has special symbol: {}'.format(trace_id, result, sym))
                return True
        return False


class TruncationRegression(BaseRegression):
    @staticmethod
    def get_last_three_sentences(text):
        if not text:
            return text

        try:
            sentences = re.findall(r'.+?[。\n]', text, re.DOTALL)
            if len(sentences) < 3:
                return text.strip()

            sub = text.rfind(sentences[-3])
            return text[sub:].strip() if sub != -1 else text.strip()
        except Exception as e:
            pass
        return text

    async def check(self, result):
        trace_id: str = self.weibo.get('trace_id', "")
        query: str = self.weibo.get('query', "")
        actual_output = result.strip()
        func_name = "CALL_CHECK_LLM_QWEN72B"
        emoji_pattern = re.compile(
            "["
            u"\U0001F600-\U0001F64F"  # 表情符号
            u"\U0001F300-\U0001F5FF"  # 符号与象形符号
            u"\U0001F680-\U0001F6FF"  # 运输和地图符号
            u"\U0001F1E0-\U0001F1FF"  # 旗帜
            u"\U00002702-\U000027B0"
            u"\u2600-\u2B55"  # 一些其他常见的符号
            u"\U00010000-\U0010ffff"  # 补充字符集
            "]+", flags=re.UNICODE
        )

        # 如果是表情结尾
        if emoji_pattern.search(actual_output[-1:]):
            self.logger.error(f"emoji [{trace_id}] {query} res: {actual_output[-1:]}")
            return False

        for sym in ['！', '。', '”', '？', '’', '）', '\'', '\"', '.', '》', '!', '～', '~', '#', '**', ')', ']', '】', '>']:
            if actual_output.endswith(sym):
                return False

        final = self.get_last_three_sentences(actual_output)
        if re.search(r'@[\w\u4e00-\u9fa5]+$', final):
            self.logger.info(f"at symbol [{trace_id}]\t{query}\t{final}")
            return False

        # if final:
        #     full_prompt = truncation_prompt.format(content=final)
        #     llm_qwen72b = ModelQwenWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        #     response = await llm_qwen72b.async_call(full_prompt)
        #     llm_res = response.get("text", "")
        #     if '是' in llm_res:
        #         return False
        #     self.logger.error(f"[{trace_id}]\t{query}\t{final}\t{llm_res}")
        return True


class EnglishRegression(BaseRegression):

    async def check(self, result):
        actual_output = result
        if len(actual_output) < 50:
            return False

        english_words = len(re.findall(r'[a-zA-Z]', actual_output))
        total_chars = len(re.findall(r'[\u4e00-\u9fff]|[a-zA-Z]', actual_output))
        probe = english_words / total_chars if total_chars > 0 else 0
        if probe > 0.75:
            return True

        # 检查是否有连续超过30个英文字符
        if re.search(r'[a-zA-Z]{31,}', actual_output):
            return True

        return False


class DuplicateRegression(BaseRegression):

    @staticmethod
    def clean_text(text):
        if not text:
            return text
        text = re.sub("^\d+\.\s*", "", text)
        return text

    @staticmethod
    def split_text(text, limit):
        sentences = text.split("\n")
        return [sentence for sentence in sentences if len(sentence) > limit]

    @staticmethod
    def find_duplicates_sentences(doc, threshold=10):
        if not doc:
            return []
        sentences = [DuplicateRegression.clean_text(doc) for doc in DuplicateRegression.split_text(doc, 20) if len(doc)]
        simhash_sentences = [Simhash(sentence) for sentence in sentences]
        duplicates = []
        for i in range(len(simhash_sentences)):
            for j in range(i + 1, len(simhash_sentences)):
                distance = simhash_sentences[i].distance(simhash_sentences[j])
                if distance < threshold:
                    duplicates.append((sentences[i], sentences[j], distance))
        return duplicates

    @staticmethod
    def find_similar_sentences(doc1, doc2, threshold=10):
        if not doc1 or not doc2:
            return []

        sentences1 = [DuplicateRegression.clean_text(doc) for doc in DuplicateRegression.split_text(doc1, 20) if
                      len(doc)]
        sentences2 = [DuplicateRegression.clean_text(doc) for doc in DuplicateRegression.split_text(doc2, 20) if
                      len(doc)]
        simhash_sentences1 = [Simhash(sentence) for sentence in sentences1]
        simhash_sentences2 = [Simhash(sentence) for sentence in sentences2]

        similar_pairs = []
        for i in range(len(simhash_sentences1)):
            for j in range(len(simhash_sentences2)):
                distance = simhash_sentences1[i].distance(simhash_sentences2[j])
                if distance < threshold:
                    similar_pairs.append((sentences1[i], sentences2[j], distance))
        return similar_pairs

    async def check(self, result):
        trace_id: str = self.weibo.get('trace_id', "")
        query: str = self.weibo.get('query', "")
        actual_output: str = result
        content_list = self.weibo.get("content_list", [])
        account_content_list = self.weibo.get("account_content_list", [])
        all_count = len(actual_output)
        if not all_count:
            return False

        materials = "\n".join(content_list + account_content_list)
        duplicates_sentences = self.find_duplicates_sentences(actual_output, 5)
        if len(duplicates_sentences):
            self.logger.info(
                f"duplicates_sentences: [{trace_id}]\t{query}\t{duplicates_sentences}\t{json.dumps(actual_output, ensure_ascii=False)}")
            return True

        similar_sentences = self.find_similar_sentences(actual_output, materials, 5)
        similar_count = sum([len(r1) for r1, r2, _ in similar_sentences])
        prob = float(similar_count) / all_count
        if len(similar_sentences):
            self.logger.info(
                f"similar_sentences: [{trace_id}]\t{query}\t{similar_sentences}\t{json.dumps(actual_output, ensure_ascii=False)}\t{prob}")
            if prob >= 0.3:
                return True
        return False


class NickOrTimeRegression(BaseRegression):

    def hasNickName(self, text, names):
        hit_names = []
        for name in names:
            if name in text:
                hit_names.append(name)
        return hit_names

    def hasWeiboTime(self, text, dates):
        hit_dates = []
        format_dates = set()
        for date in dates:
            timestamp = datetime.strptime(date, "%Y-%m-%d %H:%M:%S").timestamp()
            for fmt in ["%Y-%m-%d", "%Y_%m_%d", "%Y年%m月%d日"]:
                format_times = datetime.fromtimestamp(timestamp).strftime(fmt)
                formatted_date = re.sub(r'0(\d)月', r'\1月', format_times)
                formatted_date = re.sub(r'0(\d)日', r'\1日', formatted_date)
                format_dates.add(formatted_date)
                format_dates.add(format_times)
        for date in format_dates:
            count = text.count(date)
            if count:
                hit_dates.extend([date for i in range(count)])
        return hit_dates

    def hasMisc(self, text):
        hit_content = []
        if '[内容]' in text:
            hit_content.append('[内容]')
        if '[背景知识]' in text:
            hit_content.append('[背景知识]')
        if '发博账号名' in text:
            hit_content.append('发博账号名')
        matches = re.findall('^很抱歉', text)
        if len(matches):
            hit_content.extend(matches)
        return hit_content

    async def check(self, result):
        trace_id: str = self.weibo.get('trace_id', "")
        query: str = self.weibo.get('query', "")
        actual_output: str = result
        materials_misc: dict = self.weibo.get('materials_misc', {})

        names = materials_misc.get('发博账号名', set())
        hit_names = self.hasNickName(actual_output, names)
        if hit_names and len(hit_names) >= 7:
            self.logger.info(
                f"nick name: [{trace_id}]\t{query}\t{len(hit_names)}\t{hit_names}\t{json.dumps(actual_output, ensure_ascii=False)}")
            # if len([name for name in hit_names if name not in STAR_TABLE]) >= 7:
            #     return True

        dates = materials_misc.get('发布时间', set())
        hit_dates = self.hasWeiboTime(actual_output, dates)
        if hit_dates and len(hit_dates) >= 6:
            self.logger.info(
                f"weibo date: [{trace_id}]\t{query}\t{len(hit_dates)}\t{hit_dates}\t{json.dumps(actual_output, ensure_ascii=False)}")
            return True

        misc = self.hasMisc(actual_output)
        if misc:
            self.logger.info(
                f"misc: [{trace_id}]\t{query}\t{len(misc)}\t{misc}\t{json.dumps(actual_output, ensure_ascii=False)}")
            return True

        return False


class ReferenceRegression(BaseRegression):

    def check_reference_abuse(self, text):
        pattern = r"（.*?[\d一二三四五六七八九十\@]+.*?）|\[.*?[\d一二三四五六七八九十\@]+.*?\]|^很抱歉"
        paragraphs = text.split("\n")
        abuse_results = []
        for index, paragraph in enumerate(paragraphs):
            matches = re.findall(pattern, paragraph)
            if len(matches):
                abuse_results.extend(matches)
        return abuse_results

    async def check(self, result):
        trace_id: str = self.weibo.get('trace_id', "")
        query: str = self.weibo.get('query', "")
        actual_output: str = result
        logger = self.weibo.get('logger', None)

        matches = self.check_reference_abuse(actual_output)
        if logger and len(matches):
            logger.info(
                f"reference abuse: [{trace_id}]\t{query}\t{len(matches)}\t{matches}\t{json.dumps(actual_output, ensure_ascii=False)}")
            if len(matches) >= 6:
                return True
        return False


class MaterialRegression(BaseRegression):

    def __init__(self, weibo, pid):
        super().__init__(weibo, pid)
        self.word_table = {'疑问', '额外', '分析', '整理', '为了', '问题', '具体', '执行', '服务', '背景', '帮助',
                           '无法', '规划',
                           '观点', '错误', '细节', '生成', '总结', 'opinion', '两者之间', '确定', '更好', '相关性',
                           '信息内容',
                           '关于', '既定', '修正', '确切', '集合', '从中', '进一步', '上述', '相关', '地点', '查询',
                           '以及',
                           '实际', '告诉', '有关', '数据', '因此', '找到', 'context', '继续', '或者', '补充', '部分',
                           '详细信息',
                           '任何', '所以', '如果', 'query', '依据', '日期', '精准', '协助', '我能', '提取', '抱歉',
                           '按照',
                           '开始', '才能', '准确无误', '事实', '工作', 'JSON', '校正', '信息', '目前', '需求', '基于',
                           '根据',
                           '需要', '内容', '没有', '尚未', '输入', '知识', '或是', '有效', '包含', '详细', '符合要求',
                           '请求',
                           '缺乏', '详情', '随时', '以便', '完整', '进行', '谢谢', '由于', '步骤', 'content', '输出',
                           '完成',
                           '操作', '核心', '提供', '主题词', '必要', '任务', '具体内容', '相应', '对应', '要求', '特定',
                           '情况',
                           '格式', '反馈', '为空', '指示', '确保', '回答', '查找', '主题'}

    @staticmethod
    def check_response(text):
        try:
            if re.match(r'^\s*是', text):
                return True
        except Exception as e:
            pass
        return False

    async def check(self, result):
        trace_id: str = self.weibo.get('trace_id', "")
        query: str = self.weibo.get('query', "")
        llm: str = self.weibo.get('llm', "")
        actual_output: str = result
        func_name = "CALL_CHECK_LLM_GLM4"

        count = 0
        words = []
        first = actual_output.split('\n')[0]
        for word in self.word_table:
            total = first.count(word)
            if total:
                words.append(word)
                count += total

        # 阈值设为 8
        if count >= 8 and len(actual_output) < 200:
            self.logger.info(
                f"material error: [{trace_id}]\t{query}\t{llm}\t{count}\t{words}\t{json.dumps(actual_output, ensure_ascii=False)}")
            full_prompt = material_prompt.format(query=actual_output, content=material_error_content)
            llm_chatglm4 = ModelGlm4Wrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
            response = await llm_chatglm4.async_chatglm4_9b_api(full_prompt, max_tokens=50, timeout=10)
            res = response.get("text", "")
            if self.check_response(res):
                return True
        return False


class Regression(Base):
    def __init__(self, weibo, pid):
        super().__init__(pid)
        self.weibo = weibo
        self.regressions = [
            SpecialSymbolRegression(weibo, pid),
            EnglishRegression(weibo, pid),
            DuplicateRegression(weibo, pid),
            # ReferenceRegression(weibo, pid),
            # NickOrTimeRegression(weibo, pid),
            # MaterialRegression(weibo, pid),
            # TruncationRegression(weibo, pid),
        ]

    async def run(self, **kwargs):
        trace_id: str = self.weibo.get('trace_id', "")
        query: str = self.weibo.get('query', "")
        try:
            for regression in self.regressions:
                has_error = await regression.run(**kwargs)
                if has_error:
                    name = regression.__class__.__name__
                    return name, False
        except Exception as e:
            self.logger.exception("trace_id:{}\tquery:{}\tregression test error: {}".format(trace_id, query, e))
        return "", True


class DeepseekRegression(Base):
    def __init__(self, weibo, pid):
        super().__init__(pid)
        self.weibo = weibo
        self.regressions = [
            # EnglishRegression(weibo, pid),
            # DuplicateRegression(weibo, pid),
            # ReferenceRegression(weibo, pid),
            # NickOrTimeRegression(weibo, pid),
            # MaterialRegression(weibo, pid),
            # TruncationRegression(weibo, pid),
        ]

    async def run(self, **kwargs):
        trace_id: str = self.weibo.get('trace_id', "")
        query: str = self.weibo.get('query', "")
        try:
            for regression in self.regressions:
                has_error = await regression.run(**kwargs)
                if has_error:
                    name = regression.__class__.__name__
                    return name, False
        except Exception as e:
            self.logger.exception("trace_id:{}\tquery:{}\tregression test error: {}".format(trace_id, query, e))
        return "", True
