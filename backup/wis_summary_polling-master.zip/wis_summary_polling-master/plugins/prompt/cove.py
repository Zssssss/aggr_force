# -*- coding:utf-8 -*-
from jinja2 import Template

from plugins.prompt.base import BasePrompt


class CovePrompt(BasePrompt):
    def prompt(self):
        query = self.weibo['query']
        claim1 = self.weibo.get('claim1', "")
        knowledge = self.weibo.get('knowledge', "")
        assert claim1 and knowledge
        prompt = f'''
<任务说明> 基于我提供给你的真实且确信无疑的'事实'数据，重新审视输入的关于{query}观点中是否存在事实错误并进行修正,并严格按照原始json格式输出结果。
你需要按顺序思考以完成任务：
1.分析我提供给你的json格式数据，提取关键信息
2.基于正确且确信无疑的事实信息，审视你从观点中提取到的关键信息是否存在事实匹配错误
3.若存在错误事实，基于正确的事实信息对错误的信息进行修正。
4.若不存在事实错误，直接输出原始数据。
5.最后输出修正后的观点。

观点：
{claim1}
事实：
{knowledge}


逐步思考，严格按照原始json格式输出数据，否则你将受到严厉的惩罚。只输出修正后关于'{query}'的观点，禁止输出注释类的信息：
'''
        return prompt


class DsCoveTruncPrompt(BasePrompt):
    def prompt(self):
        query = self.weibo['query']
        claim1 = self.weibo.get('claim1', "")
        knowledge = self.weibo.get('knowledge', "")
        search_result = self.weibo.get('cove_result', "")
        summary_instr = f"""
        以下内容是我提供给你的关于“{query}”的回答：
        {search_result}

        请你判断提供的回答是否完整,完整包括内容完整和结构完整。
        请直接回答“是”或“否”。
        """
        return summary_instr


class DsCovePrompt(BasePrompt):
    def prompt(self):
        query = self.weibo['query']
        claim1 = self.weibo.get('claim1', "")
        knowledge = self.weibo.get('knowledge', "").strip()
        summary_instr = f"""以下内容是我提供给你的关于“{query}”的文章：
{claim1}

你的任务是根据我提供的要求或正确的事实内容修改提供给你的文章的对应内容；
以下是我提供的要求或正确的事实内容：
{knowledge}

修改要求：
- 完整输出提供的文章的每一部分内容(包括开头和每一小节的内容)，输出时保持文章的原有结构。
- 修改与我提供的要求或正确事实内容相对应的内容。
- 对应内容后的引用格式（如 `[^1]`）需完全保留。
- 输出结果中不得包含任何其他额外信息。
- 无需在修改后的完整文章开头输出任何其他额外信息，例如“以下是根据要求修改后的文章”等类似内容。
请直接输出完整的修改后的文章："""

        return summary_instr
    
    def post_process(self, result):
        """后处理"""
        result = result.replace("```","")
        return result


class SinaNightCovePrompt(BasePrompt):
    def prompt(self):
        query = self.weibo['query']
        claim1 = self.weibo.get('claim1', "")
        knowledge = self.weibo.get('sina_night_knowledge', "").strip()
        content = self.weibo.get('content', "")
        prompt_template = Template("""以下内容是基于用户发送的/query：“{{ question }}”的搜索结果:
{{ search_result }}
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。请按照引用编号[^X]的格式在答案中对应部分引用所参考的搜索结果。如果一句话参考了多个搜索结果，请列出所有相关的引用编号，例如[^3][^5]，切记不要将引用集中在最后返回引用编号，而是在答案对应部分列出，且回答结尾处不要输出任何引用说明内容。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。

以下内容是我提供给你的关于“{{question}}”的文章：
{{claim1}}

你的任务是根据我提供的要求或正确的事实内容修改提供给你的文章的对应内容；
以下是我提供的要求或正确的事实内容：
{{knowledge}}

修改要求：
- 完整输出提供的文章的每一部分内容(包括开头和每一小节的内容)，输出时保持文章的原有结构。
- 修改与我提供的要求或正确事实内容相对应的内容。
- 对应内容后的引用格式（如 `[^1]`）需完全保留。
- 输出结果中不得包含任何其他额外信息。
- 无需在修改后的完整文章开头输出任何其他额外信息，例如“以下是根据要求修改后的文章”等类似内容。
请直接输出完整的修改后的文章：""")

        prompt = prompt_template.render(
            question=query,
            search_result=content,
            claim1=claim1,
            knowledge=knowledge
        )
        return prompt

    def post_process(self, result):
        """后处理"""
        result = result.replace("```", "")
        return result

def cove_factory(weibo):
    weibo['configs'] = []
    model = weibo.get('llm_name', "")
    sina_night_knowledge = weibo.get('sina_night_knowledge', "").strip()
    if sina_night_knowledge:
        return SinaNightCovePrompt(weibo)
    return DsCovePrompt(weibo)