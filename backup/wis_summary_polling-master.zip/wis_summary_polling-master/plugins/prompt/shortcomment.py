# -*- coding:utf-8 -*-
import re
from datetime import datetime
import json
import traceback

from jinja2 import Template

from plugins.prompt.base import BasePrompt
from plugins.post_process.filter_process import filter_invalid_str, filter_jieguo_str
from plugins.post_process.utils import delete_empty_brackets

# QUERY_MODIFY_SYSTEM_PROMPT = """
# <角色定位>
# 你是一个专业的查询改写助手。
# """

SHORT_COMMENT_QUERY_CHECK_SYSTEM_PROMPT = """
## 角色定位
你是微博智搜，核心任务是判断用户@微博智搜是否属于闲聊。
"""

SHORT_COMMENT_SYSTEM_PROMPT_TPL="""
##角色定位
你是微博智搜，核心任务是判断用户@微博智搜的内容是否需要回复，若需要，则回复好用户。
##能力边界
- 作为文本AI模型，你仅有回复用户的能力，不具备任何其他操作的能力，回复时避免请求或引导用户执行任何操作。
"""

def render_short_comment_system_prompt(weibo: dict):
    try:
        mid_category_v2 = int(weibo.get("mid_category_v2", -1)) + 1
    except:
        mid_category_v2 = 0
    # 博文领域为明星1、电影3、电视剧22、综艺21
    is_star = (mid_category_v2 in [1, 3, 21, 22])
    template = Template(SHORT_COMMENT_SYSTEM_PROMPT_TPL)
    return template.render(is_star=is_star)

class ShortCommentActivePrompt(BasePrompt):
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """以下是由“{{nick_name}}”在{{publish_time}}发布的原博内容：
{{blog_content}}

以下是用户在原博的评论区评论的内容为：
<comment>{{comment_text}}</comment>

## 任务要求
充分理解原博内容和用户在原博评论区评论的背景和需求，将用户在原博评论区评论的内容归类到以下类别之一：
<category>
    <label>信息获取、求证类</label>
    <content>需同时满足以下几点，则为“信息获取、求证类”：
        - 用户评论的内容是一个完整、清晰的问题，且该问题属于主流共识或通用方法问题。
        - 该问题不具有指向性，没有显式或隐式向任何可互动的特定主体(如博主)进行提问。
        - 该问题没有显式或隐式涉及主观表达、情绪宣泄、质疑或即时性实时查询。
    </content>
</category>
<category>
    <label>其他类</label>
    <content>不满足上述"信息获取、求证类"的任一条件。
    </content>
</category>

请按照以下格式输出你判断的理由及类别标签：
<reason>理由：...</reason>
<label>...</label>"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        comment = self.weibo.get("comment", "")
        # 移除表情符号
        comment = re.sub(u"\[\S+?\]", "", comment).strip()
        # user: 用户名
        # query: 用户评论内容
        query = comment
        blog_content = self.weibo.get('sc_mid_ori_content', '')
        # 使用博文内容、评论内容获取搜索结果
        nick_name = self.weibo.get('nick_name', '')
        publish_time = self.weibo.get('pub_time', '')
        try:
            dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
            publish_time = dt.strftime("%Y年%m月%d日")
        except:
            pass

        if query.strip() == "@微博智搜":
            query = "深入理解原博内容，结合智搜分析结果及搜索结果，对内容进行分析、解释，提炼关键结论，提供相较于原博更具信息增量的回复。如果原博信息存在真实性问题，优先核查原博信息的准确性，明确回复核查结论。"
        # 准备实际数据
        context = {
            "nick_name": nick_name,
            "publish_time": publish_time,
            "blog_content": blog_content,
            "comment_text": query,
            # "cur_date": datetime.now().strftime('%Y年%m月%d日'),
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nshort comment active prompt is: \n{prompt}")
        return prompt

    def post_process(self, text):
        """
        从文本中提取<label></label>标签中的内容
        
        参数:
        text (str): 输入的文本字符串
        
        返回:
        str: 第一个<label>标签中的内容，如果未找到则返回None
        """
        if '</think>' in text:
            text = text.split('</think>')[-1]
        pattern = r'<label>(.*?)</label>'
        match = re.search(pattern, text)
        if match:
            return match.group(1)
        return ""
    
class ShortCommentBlogProcQuestionPrompt(BasePrompt):
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """## 背景信息
现在有一篇由博主“{{nick_name}}”发布的原博，博文内容如下：
{{blog_content}}

## 任务说明
充分分析并理解博文内容，分析博文的意图，判断博文意图是否适合回复：
【不适合回复的博文判定标准】
- 涉及人际或合作对接需求：内容主要为寻找特定对象互动、私人交流或寻求合作，本质属于定向对接，而非公开信息咨询。
- 聚焦私人事务诉求：内容围绕博主个人专属事务，无公开通用信息可提供。
【适合回复的博文判定标准】
- 以信息咨询为核心：内容明确请求具体答案、规则解释、操作指引、资源推荐等，需要通过提供客观信息来满足需求。

## 筛选步骤
第一步：检查博文是否属于“人际或合作对接需求”，若符合则判定为不适合回复。
第二步：检查博文是否属于“聚焦私人事务诉求”，若符合则判定为不适合回复。
第三步：若博文核心为“信息咨询需求”，则判定为适合回复。

请按照以下格式输出你判断的类别的理由及标签：
<reason>理由：...</reason>
<label>是/否</label>"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        # 重新根据mid获取结构化原博内容，包括OCR
        blog_content = self.weibo.get('sc_mid_ori_content', '')
        # 使用博文内容、评论内容获取搜索结果
        nick_name = self.weibo.get('nick_name', '')
        publish_time = self.weibo.get('pub_time', '')
        try:
            dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
            publish_time = dt.strftime("%Y年%m月%d日")
        except:
            pass


        # 准备实际数据
        context = {
            "nick_name": nick_name,
            "blog_content": blog_content
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nshort comment blog_proc prompt is: \n{prompt}")
        return prompt

    def post_process(self, text):
        """
        从文本中提取<label></label>标签中的内容
        
        参数:
        text (str): 输入的文本字符串
        
        返回:
        str: 第一个<label>标签中的内容，如果未找到则返回None
        """
        if '</think>' in text:
            text = text.split('</think>')[-1]
        pattern = r'<label>(.*?)</label>'
        match = re.search(pattern, text)
        if match:
            return match.group(1)
        return ""
    
class ShortCommentBlogProcSummaryPrompt(BasePrompt):
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """以下是由“{{nick_name}}”在{{publish_time}}发布的原博内容：
{{blog_content}}

## 任务要求
按照下列筛选标准，判断当前微博是否具备总结价值。

## 筛选标准
如果微博内容符合以下任一特征，则视为“不适合总结”，否则为“适合总结”：
1. 个人情感表达或日常琐事分享：内容涉及发布者的个人生活、情感、观点或状态。
2. 无效文本：包含大量表情符号/网络用语、无实质意义的互动内容、重复性语句、或无有效信息的文本堆砌。
3. 小说或内容推广片段：为小说、文章的不完整章节或推广片段，旨在引导至外部平台，无完整信息或独立观点。

请按照以下格式输出你判断的类别标签及理由：
<label>适合总结/不适合总结</label>
<reason>理由：...</reason>"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        # 重新根据mid获取结构化原博内容，包括OCR
        blog_content = self.weibo.get('sc_mid_ori_content', '')
        # 使用博文内容、评论内容获取搜索结果
        nick_name = self.weibo.get('nick_name', '')
        publish_time = self.weibo.get('pub_time', '')
        try:
            dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
            publish_time = dt.strftime("%Y年%m月%d日")
        except:
            pass


        # 准备实际数据
        context = {
            "nick_name": nick_name,
            "blog_content": blog_content,
            "publish_time": publish_time
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nshort comment blog_proc prompt is: \n{prompt}")
        return prompt

    def post_process(self, text):
        """
        从文本中提取<label></label>标签中的内容
        
        参数:
        text (str): 输入的文本字符串
        
        返回:
        str: 第一个<label>标签中的内容，如果未找到则返回None
        """
        if '</think>' in text:
            text = text.split('</think>')[-1]
        pattern = r'<label>(.*?)</label>'
        match = re.search(pattern, text)
        if match:
            return match.group(1)
        return ""
    
class ShortCommentBlogProcPrompt(BasePrompt):
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """## 背景信息
现在有一篇由博主“{{nick_name}}”发布的原博，博文内容如下：
{{blog_content}}

## 任务说明
充分分析并理解博文内容，将博文内容归类到以下类别之一：
<category>
    <label>问题类</label>
    <content>满足下列要求，则为“问题类”：
        - 博文内容是一个明确的问题；
        - 博主期望通过该问题获得知识、数据、定义等信息、或通过该问题验证已有信息的真实性；
        - 博主并非通过该问题宣泄情绪，表达不满；
    </content>
</category>
<category>
    <label>其他类</label>
    <content>满足下列其中一点，则为“其他类”：
        - 博文内容是在陈述事实，不是一个明确的问题；
        - 博文内容是一个明确的问题，但该问题是博主在玩梗；
        - 博文内容不符合“问题类”的类别说明，则为“其他类”；
    </content>
</category>

请按照以下格式输出你判断的类别标签及理由：
<label>...</label>
<reason>理由：...</reason>"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        comment = self.weibo.get("comment", "")
        # 移除表情符号
        comment = re.sub(u"\[\S+?\]", "", comment).strip()
        # user: 用户名
        # query: 用户评论内容
        query = comment
        # 重新根据mid获取结构化原博内容，包括OCR
        blog_content = self.weibo.get('sc_mid_ori_content', '')
        # 使用博文内容、评论内容获取搜索结果
        nick_name = self.weibo.get('nick_name', '')
        publish_time = self.weibo.get('pub_time', '')
        try:
            dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
            publish_time = dt.strftime("%Y年%m月%d日")
        except:
            pass


        # 准备实际数据
        context = {
            "nick_name": nick_name,
            "blog_content": blog_content
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nshort comment blog_proc prompt is: \n{prompt}")
        return prompt

    def post_process(self, text):
        """
        从文本中提取<label></label>标签中的内容
        
        参数:
        text (str): 输入的文本字符串
        
        返回:
        str: 第一个<label>标签中的内容，如果未找到则返回None
        """
        if '</think>' in text:
            text = text.split('</think>')[-1]
        pattern = r'<label>(.*?)</label>'
        match = re.search(pattern, text)
        if match:
            return match.group(1)
        return ""

class ShortCommentQueryCheckPrompt(BasePrompt):
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """
## 背景信息
{%- if have_weibo %}
现在有一篇由“{{ nick_name }}”在{{ publish_time }}发布的原博，内容如下：
{{ blog_content }}
{%- endif %}

{%- if have_analysis %}
微博智搜对这篇博文的求证和解读信息，可以作为回答的参考信息：
{{ mid_content_analysis }}
{%- endif %}

{%- if retrieval_conv %}
便于理解这些对话，现提供与这些对话可能有关系的历史对话上下文，使用的时候请先甄别是否和最近与用户的对话相关：{{ retrieval_conv }}
{%- endif %}

{%- if search_results %}
对回复@微博智搜内容可能有帮助的搜索结果：
{{ search_results }}
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。
如果回复中参考了相关搜索结果，在一段话的末尾引用对应的搜索结果。请按照引用编号[^X]的格式在答案中对应部分引用所参考的搜索结果。如果一句话参考了多个搜索结果，请列出所有相关的引用编号，例如[^3][^5]，切记不要将引用集中在最后返回引用编号，而是在答案对应部分列出，且回答结尾处不要输出任何引用说明内容。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。
{%- endif %}

## 用户@微博智搜的场景
{%- if from_weibo %}
用户在原博博文正文中@微博智搜。
{%- elif from_comment %}
用户在原博的评论区@微博智搜：{{ query }}
{%- else %}
用户@微博智搜：{{ query }}
{%- endif %}

## 任务说明
严格依据微博智搜的<角色定位>，深入理解用户@微博智搜的背景和需求，判断用户@微博智搜是否属于闲聊，判断标准如下：
- 非闲聊类：用户@微博智搜具有明确的目的或诉求。
- 闲聊类：如果不满足上述情况，则均归为闲聊类。

## 输出格式示例
需求分类：...
理由：...
"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        comment = self.weibo.get("comment", "")
        # 移除表情符号
        comment = re.sub(u"\[\S+?\]", "", comment).strip()
        # user: 用户名
        # query: 用户评论内容
        query = comment
        # 重新根据mid获取结构化原博内容，包括OCR
        blog_content = self.weibo.get('mid_content', '')
        # 使用博文内容、评论内容获取搜索结果
        nick_name = self.weibo.get('nick_name', '')
        publish_time = self.weibo.get('pub_time', '')
        try:
            dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
            publish_time = dt.strftime("%Y年%m月%d日")
        except:
            pass
        # 智搜分析结果
        mid_content_analysis = self.weibo.get('mid_content_analysis_res', '')
        search_results = self.weibo.get('content', '')
        history_conv= f"现在有一篇由“{nick_name}”在{publish_time}发布的原博，内容如下：{blog_content}"
        history_conv = str({"role": "assistant", "content": history_conv})
        retrieval_conv = f"微博智搜对这篇博文的求证和解读信息，可以作为回答的参考信息：\n{mid_content_analysis}"
        from_weibo = False
        from_comment = True
        have_weibo = True if blog_content else False
        have_analysis = True if mid_content_analysis else False
        to_comment = True
        if query.strip() == "@微博智搜":
            query = "深入理解原博内容，结合智搜分析结果及搜索结果，对内容进行分析、解释，提炼关键结论，提供相较于原博更具信息增量的回复。如果原博信息存在真实性问题，优先核查原博信息的准确性，明确回复核查结论。"
        if self.weibo.get('prompt_scene', '') == 'direct_comment':
            query = ''
            from_comment = False
            from_weibo = True
        # 准备实际数据
        context = {
            "have_weibo": have_weibo,
            "nick_name": nick_name,
            "publish_time": publish_time,
            "blog_content": blog_content,
            # "have_analysis": have_analysis,
            # "mid_content_analysis":  mid_content_analysis, 
            "from_weibo": from_weibo,
            "from_comment": from_comment,
            "query": query,
            "cur_date": datetime.now().strftime('%Y年%m月%d日'),
            "to_comment": to_comment,
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nshort comment query modify prompt is: \n{prompt}")
        return prompt

    def post_process(self, output_text):
        # 解析是否闲聊结果
        chat_result = re.search(r'需求分类：(\S+)', output_text)
        if chat_result:
            is_chat = chat_result.group(1).strip()
        else: 
            is_chat = "闲聊类"
        is_chat = 1 if is_chat != '非闲聊类' else 0
        return is_chat

class ShortCommentQueryModifyPrompt(BasePrompt):
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """
## 背景信息
你是微博智搜。
{%- if history_conv %}
以下是和微博智搜的{{ num_history_conv }}轮对话，对话内容按照对话顺序给出：
{{ history_conv }}
{%- endif %}
{%- if retrieval_conv %}
与对话可能相关的上下文：
{{ retrieval_conv }}
{%- endif %}
{%- if search_results %}
相关的搜索结果：
{{ search_results }}
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。
{%- endif %}

用户最新对话或问题：
{%- if from_weibo %}
用户在原博博文正文中@微博智搜。
{%- elif from_comment %}
{{ query }}
{%- else %}
{{ query }}
{%- endif %}

## 任务要求
请结合背景信息，深入理解用户最新对话或问题的意图，并将其拆解为若干任务步骤以回答好用户最新的对话或问题。输出步骤前应先完成内部的语义与意图判断；若仍不确定或存在歧义，可在任务步骤中直接通过<search>检索。
- 任务步骤应简洁清晰。
- 若需要额外信息支持，必须在当前任务步骤中发起检索，且检索词只能出现在 <search> 标签中，否则视为错误。
- <search>检索词应为简洁、聚焦的关键词或短语，保持语义完整，能直接用于搜索。
- 同一任务步骤中可使用多个<search>。
- 严格控制任务步骤数量：若`用户最新对话或问题`能够在单一任务步骤内完成，则禁止再进行拆分。

## 注意事项
- 今天是{{cur_date}}。
- 仅做任务规划，不要直接回答。

## 输出格式
每个任务步骤应单独一行，其中i表示编号（从1开始），格式如下:
```
任务步骤i: ... <search>检索词</search>
"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        comment = self.weibo.get("comment", "")
        # 移除表情符号
        comment = re.sub(u"\[\S+?\]", "", comment).strip()
        # user: 用户名
        # query: 用户评论内容
        query = comment
        # 重新根据mid获取结构化原博内容，包括OCR
        blog_content = self.weibo.get('mid_content', '')
        # 使用博文内容、评论内容获取搜索结果
        nick_name = self.weibo.get('nick_name', '')
        publish_time = self.weibo.get('pub_time', '')
        try:
            dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
            publish_time = dt.strftime("%Y年%m月%d日")
        except:
            pass
        # 智搜分析结果
        mid_content_analysis = self.weibo.get('mid_content_analysis_res', '')
        search_results = self.weibo.get('content', '')
        history_conv= f"现在有一篇由“{nick_name}”在{publish_time}发布的原博，内容如下：{blog_content}"
        history_conv = str({"role": "assistant", "content": history_conv})
        retrieval_conv = f"微博智搜对这篇博文的求证和解读信息，可以作为回答的参考信息：\n{mid_content_analysis}"
        from_weibo = False
        from_comment = True if query else False
        if self.weibo.get('prompt_scene', '') == 'direct_comment':
            query = ''
            from_comment = False
            from_weibo = True
        if re.sub(u"@[^ :：。；;]{1,20}", "", query).strip() == "":
            query = "请对原博内容进行求证分析或解读。"
        # 准备实际数据
        context = {
            "history_conv": history_conv, "num_history_conv": 1, 
            "retrieval_conv": retrieval_conv, 
            # "search_results": search_results, 
            "from_weibo": from_weibo, "from_comment": from_comment, 
            "query": query, 
            "cur_date": datetime.now().strftime('%Y年%m月%d日'),
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nshort comment query modify prompt is: \n{prompt}")
        return prompt

    def post_process(self, output_text):
        """解析模型返回的多版本输出"""
        rewrites = []
        pattern = r'<search>(.*?)</search>'
        try:
            # 使用findall提取所有匹配的检索词
            rewrites = re.findall(pattern, output_text)
        except:
            self.logger.warning("query modify rewrites parsing error, output_text: \n" + str(output_text))
        return rewrites

class ShortCommentIntentionPrompt(BasePrompt):
    def prompt(self):
        trace_id = self.weibo.get("trace_id", "")
        blog_content = self.weibo.get("mid_content", "")
        comment = self.weibo.get("comment", "")

        prompt = f"""你是微博智搜，正在微博平台上回复用户评论。

以下是原博：
{blog_content}

以下是用户在原博评论区提及你（@微博智搜）的评论内容：
{comment}

请你仔细阅读原博与评论内容，然后判断用户提及你的意图：
[求证]：用户要你对原博进行求证。
[其它]：用户没有让你对原博求证。
请先输出理由再输出意图。
理由: ...
意图：[求证/其它]"""
        return prompt

    def post_process(self, result):
        result = result.split("</think>")[-1]
        pattern = r'意图[:：]\s*([\s\S]*)$'
        match = re.search(pattern, result)
        if match:
            intent = match.group(1)
        else:
            intent = ""
        if '求证' in intent:
            return '求证'
        return '其他'


class ShortCommentPrompt(BasePrompt):

    def get_comment_type(self) -> str:
        try:
            q_attr = self.weibo.get('q_attr', '{}')
            q_attr_dict = json.loads(q_attr)
            comment_from_type = q_attr_dict.get('comment_from_type', '')
            return comment_from_type
        except Exception:
            self.logger.error(f"error get comment type: {traceback.format_exc()}")
            return ''

    def prompt(self):
        prompt_tpl = """
## 背景信息
{%- if have_weibo %}
现在有一篇由“{{ nick_name }}”在{{ publish_time }}发布的原博，内容如下：
{{ blog_content }}
{%- endif %}

{%- if have_analysis %}
微博智搜对这篇博文的求证和解读信息，可以作为回答的参考信息：
{{ mid_content_analysis }}
{%- endif %}

{%- if retrieval_conv %}
便于理解这些对话，现提供与这些对话可能有关系的历史对话上下文，使用的时候请先甄别是否和最近与用户的对话相关：{{ retrieval_conv }}
{%- endif %}

{%- if search_results %}
对回复@微博智搜内容可能有帮助的搜索结果：
{{ search_results }}
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。
如果回复中参考了相关搜索结果，在一段话的末尾引用对应的搜索结果。请按照引用编号[^X]的格式在答案中对应部分引用所参考的搜索结果。如果一句话参考了多个搜索结果，请列出所有相关的引用编号，例如[^3][^5]，切记不要将引用集中在最后返回引用编号，而是在答案对应部分列出，且回答结尾处不要输出任何引用说明内容。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。
{%- endif %}

## 用户@微博智搜的场景
{%- if from_weibo %}
用户在原博博文正文中@微博智搜。
{%- elif from_comment %}
用户在原博的评论区@微博智搜：{{ query }}
{%- else %}
用户@微博智搜：{{ query }}
{%- endif %}

## 任务说明
严格依据微博智搜的<角色定位>，深入理解用户@微博智搜的背景和需求，判断是否需要进行回复，如果需要回复，参考提供的相关背景信息，回复好用户，并确保回复内容相对原博/用户评论提供更多信息增量。{{ '如果自身知识与其他信息无冲突时，可以使用自身知识。' if parametric_knowledge }}

##时间
- 今天是{{ cur_date }}。

## 参考结果使用要求
{%- if parametric_knowledge %}
- 自身知识可以直接使用，无需添加引用或来源说明。
{%- endif %}
- 并非搜索结果的所有内容都与当前回复密切相关，你需要结合用户需求{{ '与自身知识' if parametric_knowledge }}，对搜索结果进行甄别、筛选，然后输出满足用户需求的回复。

## 生成要求
回复边界要求：
{%- if use_cmt_not_active %}
- 若@微博智搜的内容涉及粉丝引战、造谣抹黑、攻击谩骂、饭圈互撕、诬陷、地域歧视、隐私泄露等相关负面内容时，避免参与讨论，造成舆论风险，则无需回复。
{%- if is_star %}
- 若@微博智搜的内容涉及负面的评价，且该负面评价未被权威来源证实，避免回复不确定的结论，则无需回复。
{%- endif %}
- 若@微博智搜的内容不包含需要微博智搜回应的实质性信息或具体诉求，则无需回复。
- 若自身知识和搜索结果不能回复或不能完整的、明确的回复@微博智搜的内容时，避免回复不准确，则无需回复。
{%- else %}
- 若@微博智搜的内容涉及粉丝引战、造谣抹黑、攻击谩骂、饭圈互撕、诬陷、地域歧视、隐私泄露等相关负面内容时，请直接回复“无需回复”。
{%- if is_star %}
- 若@微博智搜的内容涉及负面的评价，且该负面评价未被权威来源证实，请直接回复“无需回复”。
{%- endif %}
- 若@微博智搜的内容不包含需要微博智搜回应的实质性信息或具体诉求，则无需回复。
- 若{{ '自身知识和' if parametric_knowledge }}搜索结果不能回复{{ '或不能完整的、明确的回复' if weibo_question }}@微博智搜的内容时，请直接回复“无需回复”。
{%- endif %}
{%- if from_comment %}
- 当原博及原博的求证和解读信息与用户的评论不相关时，无需参考原博及原博的求证和解读信息，仅回复评论内容。
{%- endif %}

内容组织&呈现要求：
{%- if to_comment %}
- 严禁输出markdown格式。
- 最终回复展示在评论区，回复内容必须简洁、精炼、信息密集，便于用户高效地获取信息。{{ "请将最终回复控制在380个字符以内。" if too_long }}
{%- else %}
- 回复内容必须简洁、精炼、信息密集，便于用户高效地获取信息。
{%- endif %}
- 回复时避免使用如“根据搜索结果...”、“结合多方信息...”形式的表述。
- 回复时禁止输出具体账号（如@账号名）的内容，在生成结果的末尾部分，不要解释信息的来源。
- 你的回复应该综合多个相关内容来回答，不能重复引用一个内容。
- 除非用户要求，否则你回答的语言需要和用户提问的语言保持一致。
- 在提及不确定的可能引起误解或具有争议的内容时，应使用谨慎的语言，避免将不确定的信息作为事实。
- 当回答中存在不可信的内容时，向用户提供必要的风险提示，确保提示内容清晰明确，用户能够准确理解。如果回答已经使得用户能够清楚区分内容是否可信，则不需要提供风险提示。

{%- if use_cmt_not_active %}
## 输出格式如下：
<analyze>简要分析是否需要回复：...</analyze>
<label>无需回复/需要回复</label>
<result>....</result>
{%- else %}
针对用户@微博智搜的场景的回复的内容为：
{%- endif %}
"""
        # 创建模板
        template = Template(prompt_tpl)
        comment = self.weibo.get("comment", "")
        q_attr = self.weibo.get('q_attr', '{}')
        q_attr_dict = json.loads(q_attr)
        reply_type = q_attr_dict.get('reply_type', 0)
        comment = re.sub(u"\[\S+?\]", "", comment).strip()
        if comment == "@微博智搜":
            comment = "深入理解原博内容，结合智搜分析结果及搜索结果，对内容进行分析、解释，提炼关键结论，提供相较于原博更具信息增量的回复。如果原博信息存在真实性问题，优先核查原博信息的准确性，明确回复核查结论。"
        # 提醒账号处理
        def _replace_user_mentions(content: str) -> str:
            try:
                nickname_pattern = re.compile(
                    r'@([\u4e00-\u9fff'       # 基本汉字区
                    r'\u3400-\u4dbf'          # 扩展A
                    r'A-Za-z0-9_\-'
                    r'\u00b7\u2022'           # 中点 · 和 •
                    r']+)(?:\s|\u3000)'   # 英文空格 或 中文全角空格
                )

                def repl(match):
                    name = match.group(1)
                    if name == "微博智搜":   # 跳过特殊账号
                        return match.group(0)   # 原样返回（就是 @微博智搜）
                    return f" 提醒账号:{name} "

                return nickname_pattern.sub(repl, content)
            except Exception as e:
                self.logger.error(f"replace_user_mentions error: " + e)
                return content
        
        comment = _replace_user_mentions(comment)
        trace_id = self.weibo.get("trace_id", "")
        # user: 用户名
        # query: 用户评论内容
        # 重新根据mid获取结构化原博内容，包括OCR
        blog_content = self.weibo.get('mid_content', '')
        # 使用博文内容、评论内容获取搜索结果
        search_results = self.weibo.get('content', '')
        nick_name = self.weibo.get('nick_name', '')
        publish_time = self.weibo.get('pub_time', '')
        too_long = self.weibo.get("too_long", False)
        try:
            dt = datetime.strptime(publish_time, "%Y-%m-%d %H:%M:%S")
            publish_time = dt.strftime("%Y年%m月%d日")
        except:
            pass
        try:
            mid_category_v2 = int(self.weibo.get("mid_category_v2", -1)) + 1
        except:
            mid_category_v2 = 0
        # 博文领域为明星1、电影3、电视剧22、综艺21
        is_star = (mid_category_v2 in [1, 3, 21, 22])
        # 智搜分析结果
        mid_content_analysis = self.weibo.get('mid_content_analysis_res', '')
        have_weibo = True if blog_content else False
        have_analysis = True if mid_content_analysis else False
        from_weibo = False
        from_comment = True
        to_comment = True
        query = comment
        weibo_question = False
        prompt_scene = self.weibo.get('prompt_scene', '')
        if prompt_scene == 'direct_comment':
            if not isinstance(reply_type, int):
                self.logger.error(f"reply_type is not int in prompt & direct_comment, default mid_from_type to [summary] : {type(reply_type)}:{reply_type}")
                reply_type = 2
            mid_from_type = 'question' if reply_type == 1 else 'summary'
            if mid_from_type == 'summary':
                # 总结
                query = "@微博智搜帮我总结一下"
                from_comment = True
                from_weibo = False
                search_results = ''
            else:
                query = ''
                from_comment = False
                from_weibo = True
                weibo_question = True
            self.logger.info(trace_id + f"\t direct comment with {mid_from_type}: {query}")
        parametric_knowledge_permit = True
        # 评论非主动-> True
        self.use_cmt_not_active = False
        comment_from_type = self.get_comment_type()
        if prompt_scene == 'verification_comment' and comment_from_type != 'active_comment':
            self.use_cmt_not_active = True
            self.logger.info(trace_id + f"\t use_cmt_not_active {self.use_cmt_not_active}")

        # query命中D级风控禁用参数化知识
        if self.weibo.get("limit_material"):
            parametric_knowledge_permit = False
        context = {
            "have_weibo": have_weibo,
            "nick_name": nick_name,
            "publish_time": publish_time,
            "blog_content": blog_content,
            "have_analysis": have_analysis,
            "mid_content_analysis": mid_content_analysis,
            "retrieval_conv": "",
            "search_results": search_results,
            "weibo_question": weibo_question,
            "from_weibo": from_weibo,
            "parametric_knowledge" : parametric_knowledge_permit,
            "from_comment": from_comment,
            "query": query,
            "cur_date": datetime.now().strftime('%Y年%m月%d日'),
            "to_comment": to_comment,
            "too_long": too_long,
            "is_star": is_star,
            "use_cmt_not_active": self.use_cmt_not_active,
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\t short comment main prompt is: \n{prompt}")
        return prompt

    def post_process(self, result):
        try:
            if self.use_cmt_not_active:
                pattern = r'<label>(.*?)</label>'
                match = re.search(pattern, result)
                if match:
                    label =  match.group(1)
                    if '无需回复' in label:
                        return '无需回复'
                pattern = r'<result>(.*?)</result>'
                match = re.search(pattern, result, re.DOTALL)
                if match:
                    result = match.group(1)
                    self.logger.info(f"post_process use result: {result}")
                else:
                    if '<result>' in result:
                        result = result.split('<result>')[-1]
                    else:
                        self.logger.info("post_process set result to none")
                        result = ''
            res = result.split("</think>")[-1]
            res = re.sub("\[(\d+)\]", "", res)
            res, _ = filter_invalid_str(res)
            res = filter_jieguo_str(res)
            res = res.replace("\n\n", "\n")
            res = res.replace("**", "")
            res = re.sub(r'@微博智搜(的)?[:：\s]*', '', res)
            res = re.sub(r'\[\^[^\]]*\]', '', res)
            res = re.sub(r'（[^（）]*）$', '', res)
            res = re.sub("\s", "", res)
            res = delete_empty_brackets(res)
            res = res.replace('@用户：', '')
            res = res.replace('@我', '@微博智搜 ')
            res = res.replace('@智搜', '@微博智搜 ')
            return res
        except Exception as e:
            self.logger.warning(f"post_process error: {e}")
        return ""
