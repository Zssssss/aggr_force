import re
from datetime import datetime

from plugins.post_process.filter_process import filter_invalid_str, filter_jieguo_str
from plugins.prompt.base import BasePrompt
from jinja2 import Environment, FileSystemLoader

from plugins.prompt.json_utils import parse_json

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/reliable.j2')


def clean_jieguo(text):
    l_bracket = r"[\(（\[【]"
    r_bracket = r"[\)）\]】]"

    mid = r"[^\n\(（\[【\)）\]】]*"
    jieguo = r"(?:\d+号?结果|结果\d+)"
    pattern = re.compile(rf"{l_bracket}{mid}{jieguo}{mid}{r_bracket}")
    text = pattern.sub("", text)
    return text


class ReliablePrompt(BasePrompt):

    def prompt(self):
        query = self.weibo.get("query", "")
        content = self.weibo.get('content', "")
        response = self.weibo.get('ori_result', "")

        if "</think>" in response:
            response = response.split("</think>")[1]

        cur_date = datetime.now().strftime('%Y年%m月%d日')
        prompt = prompt_template.render(question=query,
                                        response=response,
                                        search_result=content,
                                        cur_date=cur_date
                                        )
        return prompt

    def post_process(self, result):
        try:
            content = parse_json(result)
            summary = content.get("summary", "")
            is_necessary = content.get("is_necessary", "")
            score = content.get("score", "")
            summary, _ = filter_invalid_str(summary)
            summary = filter_jieguo_str(summary)
            summary = clean_jieguo(summary)
            if is_necessary == '是' and score != "":
                reliable_score = int(score)
                self.weibo['reliable_score'] = reliable_score
                if summary and reliable_score <= 7:
                    self.weibo['reliable_summary'] = summary
                return summary
        except Exception as e:
            pass
        return ""
