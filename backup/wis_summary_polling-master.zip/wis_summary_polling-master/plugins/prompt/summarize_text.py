# -*- coding:utf-8 -*-
from plugins.prompt.base import BasePrompt
import re

class SummarizeTextPrompt(BasePrompt):
    def prompt(self):
        query = self.weibo['query']
        claim1 = self.weibo.get('summary_claim1', "")
        output_json = {"总结":"x年x日起在xx平台播出，目前更新至x集，共x集"}
        prompt = f'''
我将给你提供一段电视剧的追剧日历的信息，请你帮我总结提炼成一句话，要求语句通顺，逻辑合理，语义完整。尽量保证在30字以内。
追剧日历：
{claim1}

输出示例如下：
{output_json}
'''
        return prompt

    def post_process(self, result):
        try:
            re_temp = r'\{[\s\S]+\}'
            pattern = r'<think>.*?</think>'
            clean_text = re.sub(pattern, '', result, flags=re.DOTALL)
            final_result = eval(re.findall(re_temp, clean_text, re.DOTALL)[0])
            return final_result["总结"]
        except :
            return ""
def summarize_text(weibo):
    weibo['configs'] = []
    return SummarizeTextPrompt(weibo)
