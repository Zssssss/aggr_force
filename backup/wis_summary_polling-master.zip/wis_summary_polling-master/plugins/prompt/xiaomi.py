# -*- coding:utf-8 -*-
import json
import re
from datetime import datetime

import aiohttp
import requests

from lib.safe_convert import str_to_json, convert_to_int
from plugins.llm.utils import is_stream_output, get_abtest
from plugins.material.query_search import get_hot_query
from plugins.post_process.utils import get_paragraph_list_by_h1_or_above, split_think_and_content, \
    split_markdown_paragraphs
from plugins.prompt.base import BasePrompt
from plugins.material.filter import RiskLevel
from plugins.post_process.post_process_handler import PostProcessor, ReplaceInvalidStrHandler, ReplaceMultimodalHandler, \
    QuoteHandler, AccountIntentionHandler, CodeBlockFixHandler

from jinja2 import Environment, FileSystemLoader

from plugins.prompt.ds import DsPrompt

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/xiaomi_template.j2')
add_multi_modal_prompt_template = env.get_template('plugins/prompt/add_multi_modal_prompt.j2')
highlight_word_prompt_template = env.get_template('plugins/prompt/ds_highlight_word.j2')
business_link_prompt_template = env.get_template('plugins/prompt/business_link.j2')
HOT_TEST_DICT = get_hot_query()

class XiaoMiPrompt(DsPrompt):

    def prompt(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        query_category = self.weibo.get("query_category", "")
        plan_knowledge = self.weibo.get("plan_knowledge", "")
        is_star = query_category == '明星'
        is_star_test = False
        is_account = self.weibo.get('account_struct_content_list', []) or self.weibo.get('query_category', "") in ['Account_Nor', 'kol']
        blog_analysis_flag = self.weibo.get('blog_analysis_flag', False)
        is_nor_account = query_category == 'Account_Nor'
        is_kol_account = query_category == 'kol'
        is_gaokao = query_category == 'Education_Gaokao'
        is_medical = query_category == 'Medical'
        card_optimization = True
        basemodel = self.weibo.get("basemodel", "")
        abtest = get_abtest(self.weibo)
        hot_social_category = self.weibo.get("hot_social_category", 0)
        is_special_query = False
        is_star_baike = False
        # ai_gossip_g1 = False
        ai_xiaoning1 = False
        ai_xiaoning2 = False
        # ai_xiaoning3 = False
        # ai_ip_g1 = False
        hot_test = (hot_social_category == 1 and len(query) <= 5) or query in HOT_TEST_DICT
        # hot_test = False
        is_model_v31 = False
        resou_fenceng = False
        resou_fenceng2 = False

        # if abtest == 'lab_cc':
        #     ai_gossip_g1 = True

        if abtest == 'lab_ee':
            ai_xiaoning1 = True

        if abtest == 'lab_ff':
            ai_xiaoning2 = True
        #
        # if abtest == 'lab_gg':
        #     ai_xiaoning3 = True

        # if abtest == 'lab_hh':
        #     ai_ip_g1 = True
        if abtest == 'lab_kk':
            resou_fenceng = True

        if abtest == 'lab_q6':
            resou_fenceng2 = True

        if abtest in ['lab_a1', 'lab_a2']:
            is_model_v31 = True

        extra_info_q_tag = self.weibo.get("extra_info_q_tag", [])
        fenceng = self.make_fields(extra_info_q_tag)

        # 新浪新闻
        if query.endswith("_sinanews"):
            query = modify_query

        # 账号类query处理
        if self.is_zhanghao_intention():
            query = modify_query

        # 明星测试
        if query.endswith("_star_test"):
            query = modify_query
            is_star = True
            is_star_test = True

        # 明星百科测试
        if query.endswith("_star_baike"):
            query = modify_query
            is_star = True
            is_star_baike = True

        if query.endswith("_cardopt"):
            query = modify_query
            card_optimization = True

        if query.endswith("_newcard"):
            query = modify_query
            self.weibo["is_newcard"] = True

        if '赵露思' in query:
            is_special_query = True

        if '_ab_' in query:
            query = modify_query

        # 商业定制
        business_query = self.business_query()
        if business_query:
            query = business_query

        content = self.weibo.get('content', "")

        cur_date = datetime.now().strftime('%Y年%m月%d日')
        cur_prompt_template = prompt_template

        parametric_knowledge_permit = True
        # query命中D级风控禁用参数化知识
        if self.weibo.get("limit_material"):
            parametric_knowledge_permit = False
        prompt = cur_prompt_template.render(question=query,
                                        search_result=content,
                                        cur_date=cur_date,
                                        is_account=is_account,
                                        is_star=is_star,
                                        parametric_knowledge=parametric_knowledge_permit,
                                        is_gaokaosp=False,
                                        is_normal_account = is_nor_account,
                                        is_kol_account = is_kol_account,
                                        is_gaokao = is_gaokao,
                                        is_need_card = True,
                                        is_star_test = is_star_test,
                                        card_optimization = card_optimization,
                                        blog_analysis = blog_analysis_flag,
                                        is_medical = is_medical,
                                        is_special_query=is_special_query,
                                        plan_knowledge=plan_knowledge,
                                        is_star_baike=is_star_baike,
                                        hot_test=hot_test,
                                        fenceng=fenceng,
                                        is_model_v31=is_model_v31,
                                        # ai_gossip_g1=ai_gossip_g1,
                                        ai_xiaoning1=ai_xiaoning1,
                                        ai_xiaoning2=ai_xiaoning2,
                                        resou_fenceng=resou_fenceng,
                                        resou_fenceng2=resou_fenceng2,
                                        is_xiaomi_appstore=True
                                        # ai_xiaoning3=ai_xiaoning3,
                                        # ai_ip_g1=ai_ip_g1
                                        )
        return prompt


    def post_process(self, result) :
        context = {
            "query" : self.weibo.get("query", ""),
            "trace_id" : self.weibo.get("trace_id", ""),
            "picture_urls" : self.weibo.get("picture_urls", []),
            "vector_dict" : self.weibo.get("vector_dict", {}),
            "ready_pid_dict" : self.weibo.setdefault("ready_pid_dict", {}),
            "pid_dup_dic" : self.weibo.get("pid_dup_dic", {}),
            "link_list" : self.weibo.get("link_list", []),
            "ready" : self.weibo.get("output_all_ready", False),
            "video_mid_list" : self.weibo.get("video_mid_list", []),
            "is_stream" : is_stream_output(self.weibo),
            "pic_info_dict_all" : self.weibo.get("pic_info_dict_all", {}),
            "video_mid_dict" : self.weibo.get("video_mid_dict", {}),
            "mid_feature_dict" : self.weibo.get("mid_feature_dict", {}),
            "ban_object" : convert_to_int(str_to_json(self.weibo.get("q_attr", ""), {}).get("ban_object", 0)),
            "query_category" : self.weibo.get("query_category", ""),
            "exact_account_query" : self.weibo.get("exact_account_query", 0),
            "is_hot_query" : self.check_is_hot_query(),
            "is_zhanghao_attention" : self.is_zhanghao_intention(),
            "user_search_res": self.weibo.get("user_search_res", []),
            # weibo_update_dict 最后会更新到weibo结构里面，故key不要和原有的key重复
            "weibo_update_dict": {},
            "user_feature_dict": self.weibo.get("user_feature_dict", {}),
            "business_link_list": self.weibo.get("business_link_list", []),
            "selected_data": self.weibo.get("selected_data", {}),
            "unsimilar_pic": self.weibo.get("unsimilar_pic", {}),
            "output_all_ready" : self.weibo.get("output_all_ready", False),
            "extra_multi_modal_info" : self.weibo.get("extra_multi_modal_info", {}),
            "highlight_word_list" : self.weibo.get("highlight_word_list", []),
            "abtest_label": self.weibo.get("abtest_label", ""),
            "abtest": get_abtest(self.weibo),
            "business_dict": self.weibo.get("business_dict", {}),
            "if_business_link": self.weibo.get("if_business_link", False),
            "da_intention": self.weibo.get("da_intention", {})
        }
        pid = self.weibo.get("pid", "")
        processor = PostProcessor([
            ReplaceInvalidStrHandler(pid),
            ReplaceMultimodalHandler(pid),
            QuoteHandler(pid),
            AccountIntentionHandler(pid),
            CodeBlockFixHandler(pid),
            # HighLightWordHandler(pid),
            # BusinessLinkHandler(pid)
            # CardOutputHandler(pid),
        ])
        result = processor.run(result, context)
        self.weibo.update(context["weibo_update_dict"])
        return result


def xiaomi_factory(weibo):
    weibo['configs'] = []
    return XiaoMiPrompt(weibo)
