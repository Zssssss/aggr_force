# -*- coding:utf-8 -*-
import re


def get_uncertain_info(llm_res):
    # 获取不确定信息， 返回需要联网搜索的关键词
    re_temp = re.compile(r'\{[\s\S]+\}')
    result_temp = eval(re_temp.search(llm_res).group())
    search_keywords = []
    for info in result_temp.get("不确定信息验证", []):
        flag = info.get("是否需要联网搜索", "否")
        keyword = info.get("搜索关键词", "").strip()
        if "是" in flag or 'yes' in flag:
            if keyword:
                search_keywords.append(keyword)
    return search_keywords


def sort_mid_list(original_list, mentions_list):
    mention_counts = {}
    for item in mentions_list:
        if item in mention_counts:
            mention_counts[item] += 1
        else:
            mention_counts[item] = 1
    sorted_list = sorted(original_list, key=lambda x: (-mention_counts.get(x, 0), original_list.index(x)))

    return sorted_list


def get_yw_list(yw_xh,mid_list,mid_tmp):
    tmp_yw_list = []
    for num in yw_xh:
        try:
            mid = mid_list[num - 1]
            if len(mid) != 16:
                continue
            mid_tmp.append(mid)
            tmp_yw_list.append({"num": num, "mid": mid})
        except:
            print(num)
            continue
    return tmp_yw_list,mid_tmp


def outlines_json_to_content_str(json_list):
    res = ""
    for tmp_dict in json_list:
        mk_title = tmp_dict["模块标题"]
        if tmp_dict["是否出模块标题"] == "是":
            res += "### {}\n".format(mk_title)
        for text_dict in tmp_dict["正文"]:
            title = text_dict.get("小标题","")
            text = text_dict["段落正文"]
            if title :
                res += "**{}**：{}\n".format(title, text)
            else:
                res += "{}\n".format(text)
    return res


def get_query_citation_mid(json_reult,sorted_content_mid):
    query_citation_dict = {}
    query_citation_mid = []
    try:
        for mk_dict in json_reult:
            citation_flag = mk_dict.get("引文隐藏",False)
            title = mk_dict.get("模块标题","")
            if title == "大众看法":
                mk_dict["m_key"] = "public_viewpoint"
            for content_dict in mk_dict["正文"]:
                citation_list = content_dict.get("引文",[])
                if citation_list:
                    for tmp in citation_list:
                        mid = tmp["mid"]
                        # 过滤百科的物料
                        if mid in ['百科']:
                            continue
                        num = sorted_content_mid.index(mid)
                        tmp["num"] = num+1
                        if mid in query_citation_dict:
                            query_citation_dict[mid] +=1
                        else:
                            query_citation_dict[mid] = 1
                    sorted_list = sorted(citation_list, key=lambda x: x['num'])
                    content_dict["引文"] = sorted_list
                else:
                    continue
                if citation_flag:
                    content_dict["引文"] = []
        sorted_dict = dict(sorted(query_citation_dict.items(), key=lambda item: item[1],reverse=True))
        for mid,num in sorted_dict.items():
            query_citation_mid.append({"mid":mid,"citation_num":str(num)})
    except:
        query_citation_mid = []
    return query_citation_mid,json_reult


def get_used_content_mid(weibo):
    content_mid_len = weibo.get('use_content_mid_len', 0)
    use_kol_mid_len = weibo.get('use_account_mid_len', 0)
    mid_list = []
    if use_kol_mid_len:
        kol_mid_list = weibo.get("account_mid_list", [])
        tmp_mid_list = kol_mid_list[:use_kol_mid_len]
        mid_list = tmp_mid_list
    if content_mid_len != 0:
        content_mid_list = weibo.get("sort_mid_list", [])
        if weibo.get("query_type", '') == "stock":
            content_mid_list = content_mid_list[1:]
        mid_list += content_mid_list[:content_mid_len]

    return mid_list

def get_candidate_pic_urls(weibo):
    struct_content_list = weibo.get('struct_content_list', [])
    pic_urls_set = set()
    #从结构化数据中获取图片url_list的候选集合
    for struct_data in struct_content_list:
        pic_url_list = struct_data.get('图片url_list', [])
        for pic_url in pic_url_list:
            pic_urls_set.add(pic_url)
    return pic_urls_set


def outlines_post_process(schema_index, outlines_res, mid_list, post_process_handle):
    search_keywords = []
    if schema_index in [0, 1, 2, 3, 4, 5, 6, 7, 10, 11, 12]:
        search_keywords = get_uncertain_info(outlines_res)

    outlines_res, sorted_mid_list = post_process_handle(outlines_res, mid_list)
    query_citation_mid, json_result = get_query_citation_mid(outlines_res, sorted_mid_list)
    result = outlines_json_to_content_str(outlines_res)
    return result, json_result, search_keywords, query_citation_mid, sorted_mid_list