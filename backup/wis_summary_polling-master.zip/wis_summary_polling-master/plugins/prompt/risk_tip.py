# -*- coding:utf-8 -*-
import json
import re
from collections import Counter
from datetime import datetime
import traceback

from lib.redis_utils import async_redis_client
from plugins.prompt.base import BasePrompt
from plugins.post_process.utils import split_markdown_paragraphs
from plugins.post_process.filter_process import filter_invalid_str

risk_tip_prompt_ori_mat = """以下内容是基于用户发送的/query：“{}”，给出的回答:
{}
在我给你的回答中，每个段落的内容数据都是[段落 X begin]...[段落 X end]格式的，X代表回答中每个段落的数字索引。
回答时参考了以下信息：
{}
回答时参考的信息中，每个参考博文都是[结果 X begin]...[结果 X end]格式的，X代表回答中每个博文的数字索引。
每个博文的内容数据都是[content begin]...[content end]格式，是每个博文中的内容部分。
每个博文若被标记为谣言或包含错误信息，会包含一个该博文的内容分析字段，格式为严格的 [analysis begin]...[analysis end]；正常博文则不包含此标记字段。"""

risk_tip_prompt_piyao_mat = """
可能与段落内容相关的最近官方信源已经辟谣的信息：
{}"""

risk_tip_prompt_task = """
请根据以上信息，分析回答内容的可信度并判断是否需要可信度风险提示，仔细思考并分析整理出内容高度不可信的段落，只在非常有必要的情况下向用户提供可信度风险提示标签和信息。
当需要可信度风险提示时，根据提示信息给出对应标签，标签为“多来源矛盾”、“当事人说法不一”、“完全不可信”、“存疑”其中之一。
- 多来源矛盾：段落内容相关的多方来源存在分歧或相互冲突，但全文所有段落中均未提及其他来源信息，只呈现单方面信息；
- 当事人说法不一：事件当事人观点或看法存在冲突，段落内容仅片面呈现一方观点，且未在全文其他部分补充其他方观点；
- 完全不可信：已验证为错误并且会严重误导用户的信息，或者已经辟谣的谣言；
- 存疑：不满足上述标签的情况，如段落内容缺乏可靠证据支持（如未经证实、刻意夸大），或来源不明/可信度低。
输出格式说明如下：
首行必须明确声明："需要可信度风险提示" 或 "不需要可信度风险提示"
需要提示时列出对应段落：[段落 X] : [标签] : [可信度风险提示信息] 
不需要提示时：简要说明理由

请注意：
- 今天是 {}。
- 每个段落只输出一次针对段落内容的可信度风险提示。
- 你提供的每个可信度风险提示都将直接展示给用户，你需要慎重判断每个段落内容的可信性，对不确定是否需要输出的段落都不用输出，避免出现错判的情况。
- 段落内容中已经包含不确定性相关的表述或不可信的提示使得用户能够清楚区分内容是否可信，则不需要提供可信度风险提示。
- 存在多来源矛盾或当事人说法不一的情况，但是全文中已经说明了具体争议点，则该段不需要输出。
- 如果段落内容没有明显不实信息，不需要质疑引用来源是否可信。
- 当内容属于没有科学依据但被广泛接受的文化心理暗示（如吉祥物祈福、头像性格解读），且不会造成实际影响时，不需要输出。
- 若段落内容中存在引述，例如“有观点指出”、“一些评论认为”...，则不需要输出。
- 若段落内容中未使用参考博文中低可信内容，则不需要输出。  
- 无高度不可信的段落内容或无引用博文的段落内容，不需要输出。
- 当段落中已经说明内容可信度或真实性，例如“涉及夸大”、“有待考证”、“存在矛盾”、“推测为”...，则不需要输出。
- 当段落内容与自身知识矛盾时，应该首先考虑你的自身知识是否已过时，然后参考引文中最新信息判断段落内容可信度。
- 可信度风险提示信息需要具体明确，简要说明原因，控制在50字以内。
"""


class RiskTipPrompt(BasePrompt):
    def __init__(self, weibo):
        super().__init__(weibo)
        self.result_list = []
        self.ori_think = ""
        self.ori_result = ""
        self.sep_material = []
        self.filtered_material_content = []

    tag_normal_colors = {
        "存疑": '#EF8B00',
        "不可信": '#B94141',
        "有争议": '#F26B2B'
    }

    tag_dark_colors = {
        "存疑": '#D77D00',
        "不可信": '#CE4848',
        "有争议": '#C2673D'
    }

    @staticmethod
    def parse_result(res_txt):
        res = split_markdown_paragraphs(res_txt)

        '''
        st, n = 0, len(res_txt)
        end_mark = ["。", "?", "？", "!", "！"]
        res = []
        ed = st + 1
        while st < n and ed < n:
            while ed < n and res_txt[ed] != '\n':
                ed += 1
            temp_p = ed - 1
            # import pdb;pdb.set_trace()
            while ed < n and res_txt[ed] == '\n':
                ed += 1
            # import pdb;pdb.set_trace()
            if res_txt[temp_p] in end_mark:
                res.append(res_txt[st:ed])
                st = ed
                ed = st + 1
        if st != ed and ed == n:
            res.append(res_txt[st:ed])
        '''
        return res

    @staticmethod
    def get_reference_material(result, material_list):
        if not material_list:
            return [], []
        # print(type(material_list))
        pos = re.findall("\[\^(\d+)\]", result)

        re_mid_quote = re.compile(r'\[?(?:结果|资料)(\d+)(?:[、/和\-至\[\]\^]+[结资]*[果料]*(\d+))*[等中\]]*')
        res1 = re_mid_quote.findall(result)
        res1 = [index for item in res1 for index in item if index]
        pos += res1
        # pattern = re.compile(r'\[?结果\d+(?:[、/和\-至\[\]\^]+结?果?\d+)*[等中\]]*')
        # pos += pattern.findall(result)
        # remove out range index, valid index is 1~len(material_list)
        pos = [int(p) for p in pos if int(p) <= len(material_list) and int(p) > 0]
        pos = sorted(list(set(pos)))
        # print(pos)
        res = [material_list[p - 1] for p in pos]
        return res, pos

    @staticmethod
    def get_splited_material_account_type(text):
        # 按照 [type begin] 分割
        parts = text.split("[account type begin]")
        before = parts[0]  # 前置部分

        # 按照 [type end] 分割中间部分
        middle_parts = parts[1].split("[account type end]")
        middle = middle_parts[0]  # 中间部分
        after = middle_parts[1]  # 后置部分
        assert before + "[account type begin]" + middle + "[account type end]" + after == text
        return before, middle, after

    @staticmethod
    def change_history_material_account(text):
        pattern = r'\[account type begin\](.*?)\[account type end\]'  # 匹配 [account type begin] 和 [account type end] 之间的内容
        replacement = "[account type begin]认证账号[account type end]"  # 替换为固定字符串
        new_text = re.sub(pattern, replacement, text, flags=re.S)  # flags=re.S 使得 . 可以匹配换行符
        return new_text

    @staticmethod
    def change_net_material_account(text):
        pattern = r'\[account type begin\](.*?)\[account type end\]'  # 匹配 [account type begin] 和 [account type end] 之间的内容
        replacement = "[account type begin][account type end]"  # 替换为固定字符串
        new_text = re.sub(pattern, replacement, text, flags=re.S)  # flags=re.S 使得 . 可以匹配换行符
        return new_text

    @staticmethod
    def get_material_type(text):
        pattern = r'(\[type begin\].*?\[type end\])'
        matches = re.findall(pattern, text, re.DOTALL)
        result = ''.join([match.strip() for match in matches])
        return result

    @staticmethod
    def get_material_account_type(text):
        pattern = r'\[account type begin\](.*?)\[account type end\]'
        matches = re.findall(pattern, text, re.DOTALL)
        result = ''.join([match.strip() for match in matches])
        return result

    @staticmethod
    def filter_material(material_content_list):
        res = []
        for material in material_content_list:
            material_type = RiskTipPrompt.get_material_type(material)
            if "资料" in material_type:
                material = RiskTipPrompt.change_history_material_account(material)
            if "网页" in material_type or "百科" in material_type:
                material = RiskTipPrompt.change_net_material_account(material)
            res.append(material)
        return res

    @staticmethod
    def time_line_wrong(tip):
        try:
            tip = tip.strip()
            # print(tip)
            pattern_time = r"((\d{2,4}年)?\d{1,2}月(\d{1,2}日)?)|(\d{2,4}年(\d{1,2}月)?(\d{1,2}日)?)"
            time_res = re.search(pattern_time,tip)
            # print(time_res)

            pattern_wrong = r"(时间.*(矛盾|错误|过期|冲突))|((矛盾|错误|过期|冲突).*时间)"
            wrong_res = re.search(pattern_wrong,tip)
            # print(wrong_res)
            if time_res and wrong_res:
                # print("命中时间线：{}|{}".format(time_res.group(),wrong_res.group()))
                return 1
            else:
                pattern = r"时间线.*(矛盾|错误|冲突)"
                res = re.search(pattern,tip)
                if res:
                    return 1
        except:
            pass
        return 0

    @staticmethod
    def filter_time_conflict(res):
        ans = []
        for item_dict in res:
            if not RiskTipPrompt.time_line_wrong(item_dict['tip']):
                ans.append(item_dict)
        return ans

    @staticmethod
    def extract_tips(judge_txt):
        temp = [txt for txt in judge_txt.split('\n') if len(txt)]
        res = []
        for item in temp:
            try:
                pattern = r"\[段落\s*(\d+)\s*\]\s*:\s*\[?([^:]+)\]?\s*:\s*(.*)"
                match = re.search(pattern, item)
                if match and all(match.group(i + 1).strip() for i in range(3)):
                    res.append({
                        'number': int(match.group(1).strip()),
                        'title': match.group(2).strip(),
                        'tip': match.group(3).strip()
                    })
            except:
                pass
        if len(res):
            res = RiskTipPrompt.filter_time_conflict(res)
        return res

    def combine_part(self, result_list, risk_result_tips, ori_res):
        result = ori_res
        result_tags = {}

        number_set = set()
        text_ready = self.weibo.get("ready_pid_dict", {}).get('text_ready', [])
        for item in risk_result_tips[:3]:
            number = item.get('number', 0)
            title = item.get('title', "")
            tip = item.get('tip', '')
            if not number or not title or not tip:
                continue

            if '多来源矛盾' in title or '当事人说法不一' in title:
                title = '有争议'

            if '不可信' in title:
                title = '不可信'
            if title not in ['有争议', '存疑', '不可信']:
                continue

            if number in number_set:
                continue

            if number <= len(result_list):
                text = result_list[number - 1].strip()
                if not text:
                    continue

                pos = result.find(text)
                tip, _ = filter_invalid_str(tip)
                normal_color = self.tag_normal_colors.get(title, "")
                dark_color = self.tag_dark_colors.get(title, "")
                if not normal_color or not dark_color:
                    continue

                number_set.add(number)
                tips_data = {
                    "type": "reliability",
                    "data": {
                        "tag_name": title,
                        "tag_normal_color": normal_color,
                        "tag_dark_color": dark_color,
                        "tips": tip
                    }
                }

                tips = f"""```wbCustomBlock{json.dumps(tips_data, ensure_ascii=False)}```"""
                if pos != -1 and tip:
                    pos += len(text)
                    result = result[:pos] + tips + result[pos:]
                if number <= len(text_ready):
                    ori_text = text_ready[number - 1]
                    # if "该信息高度可信，主要来源于权威媒体，请合理参考。" in ori_text:
                    #     continue
                    split_text_list = ["```wbCustomBlock", "<media-block>"]
                    for split_text in split_text_list:
                        if split_text in ori_text:
                            ori_list = ori_text.split(split_text)
                            text_ready[number - 1] = ori_list[0] + tips + split_text + split_text.join(ori_list[1:])
                            break
        return result, result_tags

    def result_format(self, result_list):
        return '\n'.join(
            ["[段落" + str(p + 1) + " begin]\n" + content.strip() + "\n[段落" + str(p + 1) + " end]" for p, content in
             enumerate(result_list)])
    
    @staticmethod
    def get_ref_mid_dict(link_list: list[str], ref_pos: list[int], logger=None) -> dict[str, int]:
        """
        获取引用mid和在ref_material_content中对应的位置
        """
        ref_mid_dict = {}
        try:
            for idx, ref_pos_item in enumerate(ref_pos):
                # remove out range index, valid index is 1~len(material_list)
                if ref_pos_item < 1 or ref_pos_item > len(link_list):
                    continue
                link_item = link_list[ref_pos_item - 1]
                if "sinaweibo://detail?mblogid=" in link_item:
                    mid = link_item.split("mblogid=")[1]
                    ref_mid_dict[f"zhisou_annotation_{mid}"] = idx
        except:
            if logger:
                logger.error(traceback.format_exc())
        return ref_mid_dict

    @staticmethod
    def make_labeld_ref_material_content_list(ref_material_content_list: list[str],
                                            ref_mid_label_dict: dict[str, str|None],
                                            ref_mid_dict: dict[str, int], logger=None) -> list[str]:
        def _clean_text(text):
            pattern = r'<think>.*?</think>'
            pattern1 = r'<media-block>.*?</media-block>'
            pattern2 = r'\[\^.*?\]'
            
            tq_pattern = r'```wbCustomBlock(\{.*?})```'
            text = re.sub(pattern, '', text, flags=re.DOTALL)
            text = re.sub(pattern1, '', text, flags=re.DOTALL)
            text = re.sub(pattern2, '', text, flags=re.DOTALL)
            text = re.sub(tq_pattern, '', text, flags=re.DOTALL)
            return text
        if not ref_mid_label_dict:
            return ref_material_content_list
        res = ref_material_content_list[:]
        try:
            for key, label in ref_mid_label_dict.items():
                if not label:
                    continue
                analysisd_text = _clean_text(label)
                ref_pos_item = ref_mid_dict[key]
                m_item = res[ref_pos_item]
                matches = list(re.finditer(r'\[结果 \d+ end\]', m_item))
                if matches:
                    pos_index = matches[-1].start()  # 最后一个匹配的位置
                else:
                    pos_index = -1
                if pos_index != -1:
                    new_m_item = m_item[:pos_index] + f"[analysis begin]{analysisd_text}[analysis end]\n" + m_item[pos_index:]
                    res[ref_pos_item] = new_m_item
        except:
            if logger:
                logger.error(traceback.format_exc())
        return res
    
    @staticmethod
    async def get_batch_annotation_from_redis(batch_keys: list[str], logger=None) -> dict[str, str]:
        # return await async_redis_client.batch_get_hash_specific_fields(batch_keys, fields=['result'])
        try:
            results = await async_redis_client.batch_get_hash_all_kv(batch_keys)
            return {key: json.loads(value.get('result', '')) for key, value in results.items() if value}
        except:
            if logger:
                logger.error(f"get_batch_annotation_from_redis error: {traceback.format_exc()}")
        return {}
            

    def prompt(self):
        query = self.weibo.get('query', "")
        refute_material_outstr = self.weibo.get('refute_material_outstr', "")
        ori_all_result = self.weibo.get('ori_result', "")
        pos = ori_all_result.index("</think>")
        self.ori_think, self.ori_result = ori_all_result[:pos + 8], ori_all_result[pos + 8:]
        self.result_list = self.parse_result(self.ori_result)
        self.sep_material = self.weibo.get('ds_struct_material', [])
        self.filtered_material_content = RiskTipPrompt.filter_material(self.sep_material)

        pre_ref_material_content = self.weibo.get('risk_tip_ref_m', [])
        if pre_ref_material_content:
            ref_material_content = pre_ref_material_content
        else:
            ref_material_content, _ = RiskTipPrompt.get_reference_material(self.ori_result, self.filtered_material_content)


        prompt = ""
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        format_result_list = self.result_format(self.result_list)
        self.weibo['risk_tips_result_list'] = format_result_list
        if len(ref_material_content):
            if refute_material_outstr:
                prompt = risk_tip_prompt_ori_mat.format(query, format_result_list, '\n'.join(ref_material_content)) + risk_tip_prompt_piyao_mat.format(refute_material_outstr) + risk_tip_prompt_task.format(cur_date)
            else:
                prompt = risk_tip_prompt_ori_mat.format(query, format_result_list, '\n'.join(ref_material_content)) + risk_tip_prompt_task.format(cur_date)
        return prompt

    def post_process(self, result):
        query = self.weibo.get("query", "")
        if not result or "</think>" not in result:
            raise Exception('no think')
        pos = result.index("</think>")
        think_part, result_part = result[:pos + 8].strip(), result[pos + 8:].strip()
        tips = self.extract_tips(result_part)
        if len(self.result_list) and len(tips):
            add_tip_result, result_tags = self.combine_part(self.result_list, tips, self.ori_result)
            self.weibo['risk_tips_dict'] = tips
            self.logger.info(
                f"{query}\t{json.dumps(think_part, ensure_ascii=False)}\t{json.dumps(result_part, ensure_ascii=False)}\t{result_tags}")
            return self.ori_think + add_tip_result

        self.logger.info(
            f"{query}\t{json.dumps(think_part, ensure_ascii=False)}\t{json.dumps(result_part, ensure_ascii=False)}\t")
        return self.ori_think + self.ori_result


def risk_tip_factory(weibo):
    weibo['configs'] = []
    return RiskTipPrompt(weibo)


if __name__ == '__main__':
    text = '需要可信度风险提示  \n[段落 3] : 基层形式主义问题减少38%、政务接待费用下降超70%的数据未在参考博文中明确提及，缺乏具体数据来源。  \n\n理由：  \n- 段落3引用的统计数据（38%、70%）在提供的参考博文中未找到明确出处，存在数据来源不明确的风险。  \n- 其他段落内容均与参考博文信息一致，且引用了具体案例或公开政策，符合可信度要求。'

    data = RiskTipPrompt.extract_tips(text)
    print(data)
