# -*- coding:utf-8 -*-
import json
import re
from datetime import datetime

import aiohttp
import requests

from lib.safe_convert import str_to_json, convert_to_int
from plugins.llm.utils import is_stream_output, get_abtest
from plugins.material.query_search import get_hot_query
from plugins.post_process.utils import get_paragraph_list_by_h1_or_above, split_think_and_content, \
    split_markdown_paragraphs
from plugins.prompt.base import BasePrompt
from plugins.material.filter import RiskLevel
from plugins.post_process.post_process_handler import PostProcessor, ReplaceInvalidStrHandler, ReplaceMultimodalHandler, \
    QuoteHandler, AccountIntentionHandler, CodeBlockFixHandler, CardOutputHandler,\
    BusinessLinkHandler

from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/ds_template.j2')
prompt_template2 = env.get_template('plugins/prompt/ds_template2.j2')
add_multi_modal_prompt_template = env.get_template('plugins/prompt/add_multi_modal_prompt.j2')
highlight_word_prompt_template = env.get_template('plugins/prompt/ds_highlight_word.j2')
business_link_prompt_template = env.get_template('plugins/prompt/business_link.j2')
HOT_TEST_DICT = get_hot_query()

class DsPrompt(BasePrompt):


    def make_fields(self, extra_info_q_tag):
        ##信息价值
        # { % - if hot_fenceng or star_shixiao_hot_fenceng %}
        # - “热源”：当前热门事件发酵的源头信息。
        # - “置顶”：当前查询下的关键信息。
        # ##发布人类型
        # - “当事人”：当前查询下所描述事件的当事人发布的信息。
        # - “当事方”：当前查询下所描述事件主体（机构或组织账号）的发布信息。
        # - “官方通报”：官方媒体针对当前事件发布信息。
        # { % - endif %}
        # { % - if star_shixiao_hot_fenceng %}
        # ##时效性
        # - “当天发布”：当前内容为当天发布，表示内容比较新鲜。

        infos = []
        if '热源' in extra_info_q_tag:
            infos.append("- 热源：当前事件的源头博文。")
        if '置顶' in extra_info_q_tag:
            infos.append("- 置顶：在当前查询结果中经过人工评估的关键博文。")

        parties = []
        if '当事人' in extra_info_q_tag:
            parties.append("- 当事人：当前查询事件的当事人发布的信息，对理解当事人立场和动机较为重要。")
        if '当事方' in extra_info_q_tag:
            parties.append("- 当事方：当前查询事件主体的发布事件相关回应。")
        if '官方通报' in extra_info_q_tag:
            parties.append("- 官方通报：权威媒体针对当前事件发布的信息，值得重点关注。")

        header = "为了便于区分每个搜索结果在当前查询下的价值，每个搜索结果中可能附带一些额外信息，以[Extra information begin]...[Extra information value end]格式呈现，其中标签的含义如下:"
        result = []
        if infos:
            result.append('## 信息价值\n' + '\n'.join(infos))
        if parties:
            result.append('## 发布人类型\n' + '\n'.join(parties))

        body = '\n'.join(result)
        return header + '\n' + body if body else ""


    def prompt(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        query_category = self.weibo.get("query_category", "")
        plan_knowledge = self.weibo.get("plan_knowledge", "")
        is_star = query_category == '明星'
        is_star_test = False
        is_account = self.weibo.get('account_struct_content_list', []) or self.weibo.get('query_category', "") in ['Account_Nor', 'kol']
        blog_analysis_flag = self.weibo.get('blog_analysis_flag', False)
        is_nor_account = query_category == 'Account_Nor'
        is_kol_account = query_category == 'kol'
        is_gaokao = query_category == 'Education_Gaokao'
        is_medical = query_category == 'Medical'
        card_optimization = True
        basemodel = self.weibo.get("basemodel", "")
        abtest = get_abtest(self.weibo)
        hot_social_category = self.weibo.get("hot_social_category", 0)
        is_special_query = False
        is_star_baike = False
        hot_test = (hot_social_category == 1 and len(query) <= 5) or query in HOT_TEST_DICT
        query_field = self.weibo.get("query_field", -1)
        is_competition = query_field == 19
        famous_person_intention = self.weibo.get("famous_person_intention", {})
        sina_night_prompt_knowledge = self.weibo.get("sina_night_prompt_knowledge", "")
        da_intention = self.weibo.get("da_intention", "")
        extra_info_q_tag = self.weibo.get("extra_info_q_tag", [])
        fenceng = self.make_fields(extra_info_q_tag)
        is_credential = self.weibo.get("is_credential", False) and self.weibo.get("abtest", "") == "lab_k8"

        is_account_search = False
        if abtest == 'lab_p1':
            is_account_search = True

        simple_question_youhua = False
        if abtest == 'lab_p2':
            simple_question_youhua = True

        correlation_opt = False
        if abtest == 'lab_r1':
            correlation_opt = True

        # 新浪新闻
        if query.endswith("_sinanews"):
            query = modify_query

        # 账号类query处理
        if self.is_zhanghao_intention():
            query = modify_query

        # 明星测试
        if query.endswith("_star_test"):
            query = modify_query
            is_star = True
            is_star_test = True

        # 明星百科测试
        if query.endswith("_star_baike"):
            query = modify_query
            is_star = True
            is_star_baike = True

        if query.endswith("_cardopt"):
            query = modify_query
            card_optimization = True

        if query.endswith("_newcard"):
            query = modify_query
            self.weibo["is_newcard"] = True

        if '赵露思' in query:
            is_special_query = True

        if '_ab_' in query:
            query = modify_query

        # 商业定制
        business_query = self.business_query()
        if business_query:
            query = business_query

        content = self.weibo.get('content', "")
        if abtest == 'lab_k9':
            cur_prompt_template = prompt_template2
        else:
            cur_prompt_template = prompt_template

        cur_date = datetime.now().strftime('%Y年%m月%d日')
        parametric_knowledge_permit = True
        # query命中D级风控禁用参数化知识
        if self.weibo.get("limit_material"):
            parametric_knowledge_permit = False
        prompt = cur_prompt_template.render(question=query,
                                        search_result=content,
                                        cur_date=cur_date,
                                        is_account=is_account,
                                        is_star=is_star,
                                        parametric_knowledge=parametric_knowledge_permit,
                                        is_gaokaosp=False,
                                        is_normal_account = is_nor_account,
                                        is_kol_account = is_kol_account,
                                        is_gaokao = is_gaokao,
                                        is_need_card = True,
                                        is_star_test = is_star_test,
                                        card_optimization = card_optimization,
                                        blog_analysis = blog_analysis_flag,
                                        is_medical = is_medical,
                                        is_special_query=is_special_query,
                                        plan_knowledge=plan_knowledge,
                                        is_star_baike=is_star_baike,
                                        hot_test=hot_test,
                                        fenceng=fenceng,
                                        is_competition=is_competition,
                                        famous_person_intention=famous_person_intention,
                                        da_intention=da_intention,
                                        is_credential=is_credential,
                                        sina_night_prompt_knowledge=sina_night_prompt_knowledge,
                                        is_account_search=is_account_search,
                                        simple_question_youhua=simple_question_youhua,
                                        correlation_opt=correlation_opt
                                        )
        return prompt

    def business_query(self):
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                # if json_data.get("business_project", 0) & 1 == 1:
                return json_data.get("relate_theme", "")
            except Exception as e:
                pass
        return ""

    def check_is_hot_query(self):
        """判断是否为热点问题"""
        source = self.weibo.get("source", "")
        q_attr = self.weibo.get("q_attr", "")
        try:
            attr_dict = json.loads(q_attr)
            flush_source = attr_dict.get("flush_source", "")
        except:
            flush_source = ""
        if source == "3" and flush_source == "1":
            return True
        return False

    def is_zhanghao_intention(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        query_category = self.weibo.get("query_category", "")
        if query.endswith("_zhanghao"):
            return True
        if query_category in ['Account_Nor', 'kol']:
            return True
        return False

    def post_process(self, result) :
        context = {
            "query" : self.weibo.get("query", ""),
            "trace_id" : self.weibo.get("trace_id", ""),
            "picture_urls" : self.weibo.get("picture_urls", []),
            "vector_dict" : self.weibo.get("vector_dict", {}),
            "ready_pid_dict" : self.weibo.setdefault("ready_pid_dict", {}),
            "pid_dup_dic" : self.weibo.get("pid_dup_dic", {}),
            "link_list" : self.weibo.get("link_list", []),
            "ready" : self.weibo.get("output_all_ready", False),
            "video_mid_list" : self.weibo.get("video_mid_list", []),
            "is_stream" : is_stream_output(self.weibo),
            "pic_info_dict_all" : self.weibo.get("pic_info_dict_all", {}),
            "video_mid_dict" : self.weibo.get("video_mid_dict", {}),
            "mid_feature_dict" : self.weibo.get("mid_feature_dict", {}),
            "ban_object" : convert_to_int(str_to_json(self.weibo.get("q_attr", ""), {}).get("ban_object", 0)),
            "query_category" : self.weibo.get("query_category", ""),
            "exact_account_query" : self.weibo.get("exact_account_query", 0),
            "is_hot_query" : self.check_is_hot_query(),
            "is_zhanghao_attention" : self.is_zhanghao_intention(),
            "user_search_res": self.weibo.get("user_search_res", []),
            # weibo_update_dict 最后会更新到weibo结构里面，故key不要和原有的key重复
            "weibo_update_dict": {},
            "user_feature_dict": self.weibo.get("user_feature_dict", {}),
            "business_link_list": self.weibo.get("business_link_list", []),
            "selected_data": self.weibo.get("selected_data", {}),
            "unsimilar_pic": self.weibo.get("unsimilar_pic", {}),
            "output_all_ready" : self.weibo.get("output_all_ready", False),
            "extra_multi_modal_info" : self.weibo.get("extra_multi_modal_info", {}),
            "highlight_word_list" : self.weibo.get("highlight_word_list", []),
            "abtest_label": self.weibo.get("abtest_label", ""),
            "abtest": get_abtest(self.weibo),
            "business_dict": self.weibo.get("business_dict", {}),
            "if_business_link": self.weibo.get("if_business_link", False),
            "max_click_rate": self.weibo.get("max_click_rate", 0),
            "max_click_first_sentence": self.weibo.get("max_click_first_sentence", ""),
            "is_credential": self.weibo.get("is_credential", False) and self.weibo.get("abtest", "") == "lab_k8",  # 是否是封闭求证场景
            "da_intention": self.weibo.get("da_intention", {})
        }
        pid = self.weibo.get("pid", "")
        processor = PostProcessor([
            ReplaceInvalidStrHandler(pid),
            ReplaceMultimodalHandler(pid),
            QuoteHandler(pid),
            AccountIntentionHandler(pid),
            CodeBlockFixHandler(pid),
            BusinessLinkHandler(pid)
            # CardOutputHandler(pid),
        ])
        result = processor.run(result, context)
        self.weibo.update(context["weibo_update_dict"])
        return result

    async def _req_top_pic(self, ele) :
        ele = ele.strip()
        url = f"http://10.2.32.47:8000/query?name={ele}"

        async with aiohttp.ClientSession() as session :
            async with session.get(url) as resp :
                res = await resp.json()

        query = self.weibo.get("query", "")
        trace_id = self.weibo.get("trace_id", "")
        self.logger.info(f"query: {query}, trace_id: {trace_id}, [v3.1 add media], res: {res}")
        if "未找到" in res.get("message", "") :
            return [], [], []
        pic_list, id_list = [], []
        top6_list = res.get("top6", [])
        for it in top6_list :
            if it["type"] == "video" :
                pic_list.append(it["vids"])
                id_list.append(it["id"])
            else :
                pic_list.append(it["url"])
                id_list.append(it["mid"])

        return top6_list, pic_list, id_list

    async def gen_add_multi_modal_prompt(self, query, result):
        paragraph_list = get_paragraph_list_by_h1_or_above(result)
        for i in range(len(paragraph_list)):
            paragraph_list[i] = f"[PART {i+1} begin]\n" + paragraph_list[i] + f"\n[PART {i+1} end]\n"
        content = "\n".join(paragraph_list)
        multi_modal_info_list, pic_list, id_list = await self._req_top_pic(query)
        prompt_content = add_multi_modal_prompt_template.render(query=query, content=content, num=len(pic_list))
        return multi_modal_info_list, pic_list, prompt_content

    def highlight_word_prompt(self, query, result):
        prompt = highlight_word_prompt_template.render(question=query,
                                                    answer=result)
        self.logger.info(f"highlight word prompt: {prompt}")
        return prompt

    def parse_scene_mapping(self, scene_text: str, detail_text: str):
        """
        将两段文本解析为 scene_enum 和 possible_scenes。
        scene_text: 一级场景字符串（以换行分隔）
        detail_text: 二级场景描述（以\n分隔，每段包含多个“：”分组）
        """
        # 拆分一级场景
        scene_enum = [s.strip() for s in scene_text.strip().split('\n') if s.strip()]

        # 拆分二级描述段
        detail_blocks = [b.strip() for b in detail_text.strip().split('\n') if b.strip()]

        possible_scenes = {}

        # 一一对应
        for scene, block in zip(scene_enum, detail_blocks):
            # 提取“：”前面的关键词
            items = re.findall(r'([^：:;；]+)：', block)
            possible_scenes[scene] = [i.strip() for i in items]
        return scene_enum, possible_scenes

    def business_link_prompt(self, query, ori_content, business_dict):
        scene = business_dict.get("intention", "")
        intention = business_dict.get("intention_desc", "")
        scene_enum, intention_dic = self.parse_scene_mapping(scene, intention)
        think, content = split_think_and_content(ori_content)
        content = content.lstrip('\n')
        paragraph_list = split_markdown_paragraphs(content)
        for i in range(len(paragraph_list)) :
            paragraph_list[i] = f"[PART {i + 1} begin]\n" + paragraph_list[i] + f"\n[PART {i + 1} end]\n"
        content = "\n".join(paragraph_list)
        prompt_content = business_link_prompt_template.render(query=query, content_part=content, scene=scene_enum, intention=intention_dic)
        return prompt_content

def ds_factory(weibo):
    weibo['configs'] = []
    return DsPrompt(weibo)
