# -*- coding:utf-8 -*-
import json
import re
from datetime import datetime
from plugins.prompt.base import BasePrompt


common_prompt_tpl = """
以下内容是基于用户发送的/query：“{query}”的搜索结果:
{search_result}
结合搜索结果，从{stage}这1个角度整理与“{query}”的相关信息，尽可能多的保留细节。
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。如果回答中参考了相关搜索结果，在一段话的末尾引用对应的搜索结果。请按照引用编号[^X]的格式在答案中对应部分引用所参考的搜索结果。如果一句话参考了多个搜索结果，请列出所有相关的引用编号，例如[^3][^5]，切记不要将引用集中在最后返回引用编号，而是在答案对应部分列出，且回答结尾处不要输出任何引用说明内容。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。

在回答时，请注意以下几点：
- 今天是{cur_date}。
- 并非搜索结果的所有内容都与用户的问题密切相关，你需要结合问题，对搜索结果进行甄别、筛选。
- 回答正文不能使用信息整合型句式开头（如“根据搜索结果...”、“结合多方信息...”）。
- 在输出时避免简单罗列具体账号（如@账号名）的内容，在生成结果的末尾部分，不要解释信息的来源，不要生成其他的引导语。
- 保留细节：确保关键事实、数据和人物细节等得到完整呈现。
- 如果回答很长，请尽量结构化、分段落总结。如果需要分点作答，尽量控制在10个点以内，并合并相关的内容。
- 你需要根据用户要求和回答内容选择合适、美观的回答格式，确保可读性强。
- 你的回答应该综合多个相关内容来回答，不能重复引用一个内容。
- 除非用户要求，否则你回答的语言需要和用户提问的语言保持一致。
- 在提及不确定的可能引起误解或具有争议的内容时，应使用谨慎的语言，避免将不确定的信息作为事实。
- 内容真实性：当回答中存在真实性存疑的内容时，请给出风险提示，并说明理由。

{query}
"""

STAR_STAGE_LIST = ["最新动态", "口碑评价"]
IP_STAGE_LIST = ["最新动态", "剧情讨论", "口碑评价"]

class StarIpPrompt(BasePrompt):
    def prompt(self, stage_index: int):
        query = self.weibo.get("query", "")
        content = self.weibo.get('content', "")
        # 101 202 203 204 明星、电影、电视剧、综艺
        category = self.weibo.get('category', "")

        cur_date = datetime.now().strftime('当前时间 %Y年%m月%d日.')
        if category == "101":
            if stage_index < 0 or stage_index >= len(STAR_STAGE_LIST):
                self.logger.error(f"star stage_index: {stage_index} is not valid")
                return ""
            prompt_with_data = common_prompt_tpl.format(query=query, search_result=content, cur_date=cur_date, stage=STAR_STAGE_LIST[stage_index])
        else:
            if stage_index < 0 or stage_index >= len(IP_STAGE_LIST):
                self.logger.error(f"ip stage_index: {stage_index} is not valid")
                return ""
            prompt_with_data = common_prompt_tpl.format(query=query, search_result=content, cur_date=cur_date, stage=IP_STAGE_LIST[stage_index])
        self.logger.info(f"query: {query}, category: {category}, stage_index: {stage_index}, prompt_with_data: {prompt_with_data}")
        return prompt_with_data

    def remove_extra_info(self, text):
        think_pattern = r'<think>.*?</think>'
        ref_pattern = r'```(\w*)(.*?)```'
        media_pattern = r'<media-block>(.*?)</media-block>'
        ref_ori_pattern = r'\[\^\d+\]'
        text = re.sub(think_pattern, '', text, flags=re.DOTALL)
        text = re.sub(ref_pattern, '', text, flags=re.DOTALL)
        text = re.sub(media_pattern, '', text, flags=re.DOTALL)
        text = re.sub(ref_ori_pattern, '', text, flags=re.DOTALL)
        return text

    def post_process(self, result, stage_index: int):
        """后处理"""
        query = self.weibo.get("query", "")
        trace_id = self.weibo.get("trace_id", "")
        # 101 202 203 204 明星、电影、电视剧、综艺
        category = self.weibo.get('category', "")

        result = self.remove_extra_info(result).strip()
        if category == "101":
            result = {
                STAR_STAGE_LIST[stage_index]: result
            }
        else:
            result = {
                IP_STAGE_LIST[stage_index]: result
            }
        self.logger.info(f"query: {query}, trace_id: {trace_id}, result: {result}")
        return result


def star_ip_factory(weibo):
    weibo['configs'] = []
    return StarIpPrompt(weibo)
