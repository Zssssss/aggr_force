# -*- coding:utf-8 -*-
import re
from datetime import datetime
from plugins.prompt.base import BasePrompt
from plugins.prompt.json_utils import parse_json

from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/title.j2')

class AnnotationIntention(BasePrompt):
    PROMPT_TEMPLATE = """
以下是用户发表的博文：
{}
博文中视频和图片的结果分别由音频和图像识别技术得到，忽略识别错误或语义不清的信息。

理解博文主旨，按照下列标准判断该博文有没有求证的必要并给出原因。
- 如果博文缺乏实质性、可验证的信息，或其内容仅限于影响范围比较小的个人兴趣等范畴，或博文描述非真实发生的事，则无需进行事实求证。
- 如果博文的意图是向公众传递一个可能严重误导公众判断的，可被证实或证伪的具体信息、指控或传闻（例如明星八卦），则需要求证。

输出格式：
```json
{{
  "type": "是/否",
  "reason": ".."
}}
"""

    def prompt(self):
        blog_content = self.weibo.get("mid_content", "")
        prompt_str = self.PROMPT_TEMPLATE.format(blog_content)
        return prompt_str

    def post_process(self, result):
        try:
            json_str = parse_json(result)
            ttype = json_str.get("type", "否")
            return ttype.strip() == '是'
        except Exception as e:
            pass
        return False


class AnnotationPrompt(BasePrompt):
    PROMPT_TEMPLATE = """
以下是用户发表的博文：
{}
博文中视频和图片的结果分别由音频和图像识别技术得到，忽略识别错误或语义不清的信息。

以下是针对上述博文给出的博文分析，包含对博文内容的求证和解读：
[content begin]
{}
[content end]

仔细阅读博文和博文分析结果，对博文分析中的求证结论进行分类，分类类别如下：
- 谣言类
    - 定义：博文表达的核心信息为假，会造成严重的社会负面影响（如引发恐慌、煽动对立、损害重大声誉、导致重大损失、涉及重要公共领域）
    - 例：社会政策，关于明星的传言、谣言
- 信息不实类
    - 定义：核心信息为假，但是不会造成严重的社会负面影响
    - 例：信息过期、数据笔误、非关键性历史细节错误、非重大健康知识偏差、影响较小的个人事务错误
- 其他类
    - 定义：求证结论表明博文的核心信息正确；或者核心信息在当前条件下无法被可靠证实或证伪；或者博文包含混合/模糊信息，难以明确归入单一类别

输出格式：
``json
{{
  "category": "..",
  "reason": ".."
}}
"""
    def prompt(self):
        blog_content = self.weibo.get("mid_content", "")
        llm_res = self.weibo.get("ori_result", "")
        prompt_str = self.PROMPT_TEMPLATE.format(blog_content, llm_res)
        return prompt_str

    def post_process(self, result):
        vals = {"谣言类": 1, "信息不实类": 1}
        try:
            json_str = parse_json(result)
            category = json_str.get("category", "其他类")
            verification = vals.get(category, 0)
            return category, verification
        except Exception as e:
            pass
        return "其他类", 0



class TitlePrompt(BasePrompt):    
    def prompt(self):
        blog_content = self.weibo.get("mid_content", "")
        llm_res = self.weibo.get("ori_result", "")
        sid = self.weibo.get('sid', "")
        external_site = False
        verification = self.weibo.get('is_verification_title', False)
        # 新浪新闻求证标识
        if sid == "sina_news_verification":
            external_site=True
        prompt = prompt_template.render(
            text=blog_content,
            analysis=llm_res,
            verification=verification,
            external_site=external_site
        )
        return prompt

    def post_process(self, result):
        if "</think>" in result:
            result = result.split("</think>")[1]

        match = re.search(r'<title>(.*?)</title>', result)
        if match:
            result = match.group(1)
            return result
        return ""