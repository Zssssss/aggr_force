# -*- coding:utf-8 -*-
import json
import re
from datetime import datetime

from jinja2 import Environment, FileSystemLoader

from plugins.prompt.ds import DsPrompt

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/business_template.j2')

class BusinessPrompt(DsPrompt):

    def prompt(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        content = self.weibo.get('content', "")

        cur_date = datetime.now().strftime('%Y年%m月%d日')
        cur_prompt_template = prompt_template
        prompt = cur_prompt_template.render(question=query,
                                        search_result=content,
                                        CURRENT_TIME=cur_date
                                        )
        return prompt


def business_factory(weibo):
    weibo['configs'] = []
    return BusinessPrompt(weibo)
