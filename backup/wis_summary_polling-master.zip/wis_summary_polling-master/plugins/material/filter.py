# -*- coding:utf-8 -*-
from abc import ABC, abstractmethod
from enum import Enum, auto
from plugins.user.user_type import is_redv_user
from plugins.material.material_api import material_filter, shorttv_material_filter, media_material_filter
from plugins.material.query_search import get_reliable_5level_uids, get_filtered_keywords

RELIABLE_5LEVEL_UIDS = get_reliable_5level_uids()
FILTERED_KEYWORDS = get_filtered_keywords()

USE_ONSITE_MATERIAL = 1 # 使用站内物料
USE_OFFSITE_MATERIAL = 2 # 使用站外物料

class RiskLevel(str, Enum):
    """风控等级枚举常量定义"""
    A = "A"  # A级：不允许使用智搜提问
    B = "B"  # B级：仅使用标准回答库
    C = "C"  # C级：屏蔽思考过程（思考链、预览版）
    D = "D"  # D级：限制模型泛化联想（参数化知识、可信物料）
    E = "E"  # E级：隐藏智搜部分风险模块展示

class FilterReason(Enum):
    """过滤原因枚举"""
    CONTENT = auto()  # R1: 内容过滤
    BLACKLIST = auto()  # R2: 黑名单过滤
    SELF = auto()  # R3: 自身mid过滤
    SHORTTV = auto()  # R4: ShortTv分类过滤
    MEDIA = auto()  # R5: Media分类过滤
    RISK = auto()  # R6: 高风险等级过滤
    SAFETAG = auto()  # R7: SAFETAG过滤
    TIMERANGE = auto()  # R8: 时间过滤
    RELIABLEUID = auto()  # R9: 可信UID过滤

class MaterialFilter(ABC):
    """过滤器基类"""
    @abstractmethod
    def should_filter(self) -> tuple[bool, FilterReason]:
        """返回是否应该过滤当前物料和过滤原因"""
        return False, None

class FilterChain:
    """过滤器链，实现短路逻辑(任一命中即停止)"""
    def __init__(self, *filters):
        self.filters = filters
    
    def apply(self) -> FilterReason:
        """应用所有过滤器，返回第一个命中的过滤原因"""
        for filter in self.filters:
            should_filter, reason = filter.should_filter()
            if should_filter:
                return reason
        return None

class MaterialContentFilter(MaterialFilter):
    """物料内容过滤器"""
    def __init__(self, query: str, text: str):
        self.query = query
        self.text = text
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        result = material_filter(self.query, self.text)
        return result, FilterReason.CONTENT if result else None

class BlackMidFilter(MaterialFilter):
    """黑名单mid过滤器"""
    def __init__(self, mid: str, black_mids: set):
        self.mid = mid 
        self.black_mids = black_mids
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        result = self.mid in self.black_mids
        return result, FilterReason.BLACKLIST if result else None

class SelfMidFilter(MaterialFilter):
    """自身mid过滤器"""
    def __init__(self, mid: str, query: str):
        self.mid = mid
        self.query = query
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        result = self.mid == self.query
        return result, FilterReason.SELF if result else None

class CategoryFilter(MaterialFilter):
    """分类特殊过滤器"""
    def __init__(self, from_: str, query_category: str, all_tag: dict):
        self.from_ = from_
        self.query_category = query_category
        self.all_tag = all_tag
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        if not self.from_ or self.from_ == 'unify_base':
            return False, None
        if self.query_category == 'ShortTv':
            result = shorttv_material_filter(self.all_tag)
            return result, FilterReason.SHORTTV if result else None
        if self.query_category == 'Media':
            result = media_material_filter(self.all_tag)
            return result, FilterReason.MEDIA if result else None
        return False, None

class SafeTagFilter(MaterialFilter):
    """安全标签过滤器"""
    def __init__(self, safe_tags: str, uid: str, utype: int):
        self.safe_tags = safe_tags
        self.uid = uid
        self.utype = utype
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        if not self.safe_tags:
            return False, None
            
        try:
            safe_tags = int(float(self.safe_tags))
        except:
            return False, None
            
        # 检查40和43标签
        for tag in [40, 43]:
            if safe_tags & (1 << (tag - 1)) != 0:
                # 媒体账号或utype=5豁免
                if self.uid in RELIABLE_5LEVEL_UIDS or self.utype == 5:
                    return False, None
                return True, FilterReason.SAFETAG
        return False, None

class RiskLevelFilter(MaterialFilter):
    """风险等级过滤器"""
    def __init__(self, query_risk_level: str, verified_type: int, verified_type_ext: int, user_v_type: list, limit_material = False):
        self.query_risk_level = query_risk_level
        self.verified_type = verified_type
        self.verified_type_ext = verified_type_ext
        self.user_v_type = user_v_type
        self.limit_material = limit_material
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        # 如果上游不下发user_v_type，则认为不进行物料过滤
        if not self.limit_material or not self.user_v_type:
            return False, None
        # # 先兼容线上，至少出红V
        # if not self.user_v_type:
        #     self.user_v_type = [{'verified_type': 3, 'verified_type_ext': 53}]
        for v_type in self.user_v_type:
            verified_type = v_type.get("verified_type")
            verified_type_ext = v_type.get("verified_type_ext")
            
            # 检查verified_type和verified_type_ext
            if verified_type is not None and verified_type_ext is None:
                if verified_type == self.verified_type:
                    return False, None
            elif verified_type is not None and verified_type_ext is not None:
                if verified_type == self.verified_type and verified_type_ext == self.verified_type_ext:
                    return False, None
        return True, FilterReason.RISK

class TimeRangeFilter(MaterialFilter):
    """时间范围过滤器"""
    def __init__(self, ts: int, material_time_range: list, limit_material = False):
        self.ts = ts
        self.material_time_range = material_time_range or []
        self.limit_material = limit_material
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        # 如果material_time_range为空或者非CD级，则不进行时间过滤
        if not self.material_time_range or not self.limit_material:
            return False, None
            
        # 循环遍历material_time_range列表
        for time_range in self.material_time_range:
            if not isinstance(time_range, dict):
                continue
                
            start_time = time_range.get("start")
            end_time = time_range.get("end")
            
            # 检查是否在时间范围内
            in_range = True
            
            if start_time:
                try:
                    start_time = int(start_time)
                except (ValueError, TypeError):
                    in_range = False
                if in_range and self.ts < start_time:
                    in_range = False
                    
            if end_time and in_range:
                try:
                    end_time = int(end_time)
                except (ValueError, TypeError):
                    in_range = False
                if in_range and self.ts > end_time:
                    in_range = False
            
            # 如果在时间范围内，则过滤掉
            if in_range:
                return True, FilterReason.TIMERANGE
            
        return False, None
    
class ReliableUIDFilter(MaterialFilter):
    """可信UID过滤器"""
    def __init__(self, uid, limit_degree_reliable_uids, limit_material = False):
        self.uid = uid
        self.limit_degree_reliable_uids = limit_degree_reliable_uids
        self.limit_material = limit_material
        
    def should_filter(self) -> tuple[bool, FilterReason]:
        # 如果limit_degree_reliable_uids为空或者非CD级，则不进行时间过滤
        if not self.limit_degree_reliable_uids or not self.limit_material:
            return False, None
        
        # 检查是否在uid白名单内
        if self.uid not in self.limit_degree_reliable_uids:
            return True, FilterReason.RELIABLEUID

        return False, None