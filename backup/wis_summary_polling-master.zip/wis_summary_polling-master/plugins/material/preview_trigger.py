import time
import aiohttp
from lib.base import Base


class PreviewTrigger(Base):
    async def run(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        prompt_scene = weibo.get("prompt_scene", "")
        self.update_pre_log_msg(weibo)
        if prompt_scene == 'deepseek_stream':
            url = "http://admin.ai.s.weibo.com/api/llm/analysis_once_queue.json?query={}&models=preview&source=220".format(query)
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=1)) as session:
                    async with session.get(url=url) as r:
                        if r.status == 200:
                            res = await r.json()
                            self.logger.info(self.pre_log_msg + "{} analysis_once_queue response:{}".format(trace_id, res))
            except Exception as e:
                self.logger.error(self.pre_log_msg + " analysis_once_queue error:{}".format(e))

            self.logger.info(self.pre_log_msg + "preview trigger cost: {}".format(time.time() - start))
