import asyncio
import copy
import json
from typing import Any, Literal
import traceback

from plugins.material.material import (
    SummaryMaterial,
    AccountMaterial,
    ShortTvMaterial,
    KnowledgeMaterial,
    CoveMaterial,
    WisAnalysisMaterial, PreviousMaterial, StockMaterial,
    SummaryMaterialNoType,
    RiskControlMaterial, HotquerySql,
    GaoKaoAgentMaterial,
    CTRMaterial,
    BroadSocialMaterial
)

from lib.base import Base

class MultiQueryMaterialRunner(Base):
    """
    多 Query 物料聚合器。
    给定一个主 weibo（含多个子 query），并行获取各类物料并聚合结果。
    """

    def __init__(self, pid: str, material_classes: list[type[Base]] | None = None):
        super().__init__(pid)
        self.material_classes = material_classes or [
            SummaryMaterial,
            KnowledgeMaterial,
            CoveMaterial,
            # PreviousMaterial,
            StockMaterial,
            RiskControlMaterial,
            HotquerySql,
            GaoKaoAgentMaterial,
            CTRMaterial,
            BroadSocialMaterial
        ]
        self.material_instances = [cls(self.pid) for cls in self.material_classes]

    async def run(self, weibo: dict[str, Any], query_list: list[str], query_weight: list[int]=None, refresh_main: bool=False, used_materials:list[str]=None) -> dict[str, Any]:
        """
        并发执行物料任务后聚合。
        Args:
            weibo: 主 weibo
            query_list: 用于重新获取物料的子 query 列表
            query_weight: 文章比重， 长度需为len(query_list) + 1
            refresh_main: 是否刷新主微博，默认不刷新
            used_materials: 使用的物料列表, 默认使用所有物料,如果仅使用站内物料，可以赋值['zs_knowledge']
        Returns:
            聚合后的 weibo，除物料外，其他key不变， 是weibo的引用， weibo也会被改动
        """
        try:
            self.update_pre_log_msg(weibo)
            
            if query_weight and (len(query_weight) != len(query_list) + 1):
                self.logger.error(f"query_weight length error: {query_weight}, use default 3:1:1")
                query_weight = None

            self.logger.info(self.pre_log_msg + f"query_list: {query_list}, query_weight: {query_weight}")
            weibo_list = self._build_query_weibos(weibo, query_list)
            if refresh_main:
                weibo_list = [weibo] + weibo_list
            await asyncio.gather(*[self._run_single_query(w) for w in weibo_list])
            if not refresh_main:
                weibo_list = [weibo] + weibo_list
            return self._merge_all_results(weibo_list, query_weight, used_materials)
        except Exception:
            self.logger.error(f"run error, fallback to original weibo: {traceback.format_exc()}")
            return weibo

    def _build_query_weibos(self, weibo: dict[str, Any], query_list: list[str]) -> list[dict[str, Any]]:
        """根据 contain_hotword 构造多 query weibo 列表"""
        weibo_list = [self._clone_with_query(weibo, q) for q in query_list]
        return weibo_list

    @staticmethod
    def _clone_with_query(weibo: dict[str, Any], query: str) -> dict[str, Any]:
        new_wb = copy.deepcopy(weibo)
        new_wb['query'] = query
        return new_wb

    async def _run_single_query(self, weibo: dict[str, Any]):
        """单 query 执行所有物料"""
        await asyncio.gather(
            *[m.run(weibo=weibo) for m in self.material_instances],
            return_exceptions=True
        )
        # summary 特殊处理
        s_cls = SummaryMaterial(self.pid)
        await s_cls.struct_material(weibo=weibo)
        self.logger.info(self.pre_log_msg + f"query: {weibo.get('query', '')} run single done")

    def _merge_all_results(self, weibo_list: list[dict[str, Any]], query_weight: list[int]=None, used_materials:list[str]=None) -> dict[str, Any]:
        """统一合并逻辑"""
        main, *others = weibo_list
        if not query_weight or len(query_weight) != len(weibo_list):
            query_weight = [3] + [1] * len(others)

        main_weight, *other_weight = query_weight
        main['sina_article_data'] = main.get('sina_article_data', [])[:main_weight]
        for o, w in zip(others, other_weight):
            if 'sina_article_data' in o:
                o['sina_article_data'] = o['sina_article_data'][:w]

        try:
            struct_list, mid_list = self._rerank_weibo(weibo_list)
            main["struct_content_list"], main["mid_list"] = struct_list, mid_list
        except Exception:
            self.logger.error(f"rerank error: {traceback.format_exc()}")

        need_merge_material_str_list = ['sina_article_data', 'baike_knowledge', 'history_hot_res', 'gaokao_agent_result',
                     'star_ip_result', 'current_hot_res', 'stock_info', 'hot_query_res', 'zs_knowledge',
                     'user_search_res']
        if used_materials and isinstance(used_materials, list):
            need_merge_material_str_list = [m for m in need_merge_material_str_list if m in used_materials]
            self.logger.info(self.pre_log_msg + f"used_materials to merge: {used_materials}")

        # 合并不同类型字段
        merge_fields = {
            "list": ['video_mid_list'] + need_merge_material_str_list,
            "dict": ['ready_pid_dict', 'pid_dup_dic', 'pic_info_dict_all', 'video_mid_dict', 'mid_feature_dict'],
            "bool": ['blog_analysis_flag'],
            "str" : ['cove_material']
        }

        for f in merge_fields["list"]:
            main[f] = self._merge_list([w.get(f, []) for w in weibo_list])
        for f in merge_fields["dict"]:
            main[f] = self._merge_dict([w.get(f, {}) for w in weibo_list])
        for f in merge_fields["bool"]:
            main[f] = any([w.get(f, False) for w in weibo_list])
        for f in merge_fields["str"]:
            main[f] = self._merge_str([w.get(f, []) for w in weibo_list])

        try:
            merged_cove_material_list = main.get('cove_material', [])
            if merged_cove_material_list:
                main['knowledge'] = '\n'.join(merged_cove_material_list).strip()
        except Exception:
            self.logger.error(f"merge list 'cove_material' error: {traceback.format_exc()}")

        return main

    def _merge_list(self, lists: list[list[Any]]) -> list[Any]:
        seen, res = set(), []
        for lst in lists:
            for item in lst:
                key = json.dumps(item, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    res.append(item)
        return res

    def _merge_dict(self, dicts: list[dict[Any, Any]]) -> dict[Any, Any]:
        merged = {}
        for d in dicts:
            merged.update(d)
        return merged
    
    def _merge_str(self, m_group: list[list[str]]) -> list[str]:
        seen = set()
        res = []
        for m_list in m_group:
            for item in m_list:
                if item not in seen:
                    seen.add(item)
                    res.append(item)
        return res

    def _rerank_weibo(self, weibos: list[dict[str, Any]]):
        """合并排序微博"""
        top_weibo_list, other_weibo_list = [], []
        top_mid_list, other_mid_list = [], []
        seen_mids = set()  # 用于记录已经处理过的微博mid
        
        for weibo in weibos:
            struct_content_list = weibo.get('struct_content_list', [])
            mid_list = weibo.get('mid_list', [])
            
            for mid, item in zip(mid_list, struct_content_list):
                if mid in seen_mids:  # 如果已经处理过这个mid，跳过
                    continue
                    
                seen_mids.add(mid)  # 标记这个mid为已处理
                
                if item.get("is_good", 0) >= 1:
                    top_weibo_list.append(item)
                    top_mid_list.append(mid)
                else:
                    other_weibo_list.append(item)
                    other_mid_list.append(mid)
                    
        return top_weibo_list + other_weibo_list, top_mid_list + other_mid_list
