# -*- coding:utf-8 -*-
import asyncio
import copy
import datetime
import json
import random
import time
import traceback
import aiohttp
from aiomcache import Client
from typing import Literal

from api.model_api import md5_hash, get_bucket_id
from conf.config import TASK_CONCURRENCY
from lib.aiomcq import mcq_cli
from lib.base import Base
from lib.timeit import timeit
from plugins.flyweight.hotsearch_bang import hotsearch_bang_dict
from plugins.material.filter import RiskLevel
import tools.discovery.dconf as discovery


def discovery_get(key, default):
    try:
        config_value = discovery.configget("wis_summary_service", key)
        if config_value:
            return int(config_value)
    except Exception as e:
        print("discovery_get error")
    return default


class SummaryInput(Base):

    def __init__(self, pid, model):
        super().__init__(pid)
        self.model = model
        self.name = model
        self.session = None
        self.is_stream = 0
        self._lock = asyncio.Lock()

    async def get_session(self):
        async with self._lock:
            if self.session is None or self.session.closed:
                self.session = aiohttp.ClientSession()
        return self.session

    async def request(self):
        params = {'model': self.model, 'is_stream': self.is_stream}
        # url = "http://admin.ai.s.weibo.com/intfs/llm/getOnceQueueQuery"
        url = "http://admin.ai.s.weibo.com/api/wis/get_task.json"
        session = await self.get_session()
        timeout = aiohttp.ClientTimeout(total=3)
        async with session.get(url, params=params, timeout=timeout) as response:
            response.raise_for_status()
            return await response.json()
    
    @timeit(logger_mode='self')
    async def add_query_info(self, weibo: dict):
        """
        重构query_category/query_field/raw_time_grade获取
        """

        def _get_da_intention(level):
            try:
                for item in level:
                    if item.get("category", "") == 'StarWhiteList':
                        return item.get("star_track", ""), str(item.get("is_exact_match", 0))
            except:
                pass
            return "", ""
        
        def _get_famous_person_intention(level, query):
            try:
                # 临时先兼容下jin这个case
                if "jin" in query and "&" in query:
                    return
                for item in level:
                    if item.get("category", "") == 'FamousPerson':
                        weibo["famous_person_intention"] = {
                            "domain" : item.get("domain", ""),
                            "is_exact_match" :str(item.get("is_exact_match", 0))
                        }
            except:
                pass

        async def _get_via_http(query: str) -> tuple[str, int, str, str, str] | None:
            URL = f"http://i.search.weibo.com/search/wis/query_info.json"
            timeout = aiohttp.ClientTimeout(total=2)
            for _ in range(2):
                try:
                    session = await self.get_session()
                    async with session.post(URL, data={'query': query}, timeout=timeout) as r:
                        if r.status == 200:
                            res = await r.json()
                            raw_time_grade = res.get('data').get('get_time_grade', "")
                            query_field = res.get('data').get('query_field', -1)
                            query_category = res.get('data').get('query_category', "")
                            da_intention, is_exact_match = _get_da_intention(
                                res.get('data').get('ac_res', {}).get("da_intention", {}).get("level_1", []))
                            _get_famous_person_intention(res.get('data').get('ac_res', {}).get("da_intention", {}).get("level_1", []), query)
                            return query_category, query_field, raw_time_grade, da_intention, is_exact_match
                        else:
                            self.logger.error(self.pre_log_msg + f'[get_query_info error] intf_res:{r}')
                except Exception as e:
                    self.logger.warning(self.pre_log_msg + f'[get_query_info error] {e}')
            
            return '', -1, '', "", ""
        query = weibo.get('query', '')
        start_time = time.time()
        query_info = await _get_via_http(query)
        weibo['add_query_info_ts_start'] = start_time
        weibo['add_query_info_ts_end'] = time.time()
        weibo['query_category'], weibo['query_field'], weibo['query_raw_time_grade'], weibo['da_intention'], weibo['da_intention_exact_match'] = query_info

    def update(self, weibo):
        pass

    def check_is_hot_query(self, source, q_attr):
        """判断是否为热点问题"""
        try:
            attr_dict = json.loads(q_attr)
            flush_source = attr_dict.get("flush_source", "")
        except:
            flush_source = ""
        if source == "3" and flush_source == "1":
            return True
        return False

    async def run(self, **kwargs):
        try:
            start = time.time()
            data = await self.request()
            data = data.get("data", {})
            if not data:
                self.logger.warning("{} Queue is empty".format(self.name))
                return None
            json_dict = json.loads(data)
            trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
            trace_id = json_dict.get('version', trace_id) or trace_id
            await self.add_query_info(json_dict)
            json_dict['trace_id'] = trace_id
            json_dict['traceid'] = trace_id
            json_dict['query_type'] = json_dict.get("query_category", "")
            json_dict['ori_query_category'] = json_dict.get("query_category", "")
            json_dict.update({'llm_name': self.name})
            json_dict.update({'query_in_time': time.time()})
            self.update(json_dict)

            query = json_dict.get('query', '')
            is_hot_query = await hotsearch_bang_dict.get(query, 0)
            if query and is_hot_query:
                json_dict['hot_social_category'] = 1

            self.logger.info("queue in: {}, cost: {}".format(json_dict, time.time() - start))

            source = json_dict.get("source", "")
            if source == '99':
                self.logger.warning("source is 99 : {}".format(trace_id))
                return None

            sid = json_dict.get('sid', "")
            if sid == 'ab_test_push':
                json_dict['abtests'] = 'ab_test_push'
                json_dict['abtest'] = 'lab_yy'

            q_attr = json_dict.get("q_attr", "")
            try:
                if q_attr:
                    limit_degree_data = self._parse_q_attr(q_attr)
                    json_dict.update(limit_degree_data)

            except Exception as e:
                self.logger.error("{} de-serialize q_attr error:{}".format(q_attr, e))

            origin_input = copy.deepcopy(json_dict)
            json_dict['origin_input'] = origin_input
            return json_dict
        except Exception as e:
            self.logger.error("Input exception:{}".format(str(e)))
        return None

    async def close(self):
        async with self._lock:
            if self.session and not self.session.closed:
                await self.session.close()

    def _parse_q_attr(self, q_attr: str) -> dict:
        """解析q_attr JSON字符串并提取风控相关字段
        
        Args:
            q_attr: 原始JSON字符串
            
        Returns:
            dict: 包含解析后的风控字段，格式为:
                {
                    'limit_degree': str,  # 风控限制等级
                    'user_v_type': list[dict]  # 风控D等级指定物料类型数组，默认为空数组，格式:
                        # {
                        #     "verified_type": int,
                        #     "verified_type_ext": Optional[int]
                        # }
                }
        """
        try:
            if not q_attr:
                return {'limit_degree': '', 'user_v_type': [], 'use_material' : []}
                
            q_attr_data = json.loads(q_attr)
            limit_degree = q_attr_data.get("limit_degree", "")
            search_query_type = q_attr_data.get("search_query_type", "") 
            
            # 仅当limit_degree为D时才处理user_v_type
            user_v_type = []
            use_material = []
            limit_material = False
            limit_degree_reliable_uids = []
            material_time_range = []
            # 仅当limit_degree为C、D时处理user_v_type
            if limit_degree in [RiskLevel.D.value, RiskLevel.C.value]:
                user_v_type = q_attr_data.get("extra", {}).get("user_v_type", [])
                use_material = q_attr_data.get("extra", {}).get("material", [])
                material_time_range = q_attr_data.get("extra", {}).get("publish_times", [])
                # 兼容上游返回空字典的情况，确保始终返回数组
                if not isinstance(material_time_range, list):
                    material_time_range = []
                limit_degree_reliable_uids = q_attr_data.get("extra", {}).get("specific_user", {}).get("reliable_uids", [])
                limit_material = True 
            return {
                'limit_degree': limit_degree,
                'user_v_type': user_v_type,
                'use_material' : use_material,
                'limit_material' : limit_material,
                'material_time_range' : material_time_range,
                'limit_degree_reliable_uids': limit_degree_reliable_uids,
                'search_query_type' : search_query_type
            }
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse q_attr JSON: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error parsing q_attr: {e}")
        return {'limit_degree': '', 'user_v_type': [], 'use_material' : [], 'search_query_type': search_query_type}

class DeepseekSummaryInput(SummaryInput):
    # 强制走非流式模板
    def update(self, weibo):
        weibo['stream_output'] = 0


class HotOverviewInput(SummaryInput):
    """
    热点概况卡片
    model == 'hot_overview' / 'hot_overview_gray'
    """
    def __init__(self, pid, model=Literal["hot_overview", "hot_overview_gray"]):
        super().__init__(pid, model)
        self.model = model
        self.name = model
        self.session = None

    def update(self, weibo):
        if weibo:
            weibo["hot_overview_override"] = self.model  # 标记为热点概况卡片
            weibo['stream_output'] = 0
            weibo["llm_name"] = 'deepseek'

class RobotInput(SummaryInput):
    """
    评论罗伯特， 复用Deepseek
    model == 'deepseek_comment'
    """
    def __init__(self, pid, model):
        super().__init__(pid, model)
        self.model = model
        self.name = model
        self.session = None

    def update(self, weibo):
        if weibo:
            weibo["robot_override"] = self.model  # 标记为robot流程
            weibo['stream_output'] = 0
            weibo["llm_name"] = 'deepseek'
            # 移除query中的'@评论罗伯特'
            try:
                if "@评论罗伯特" in weibo["query"]:
                    weibo["query"] = weibo["query"].replace("@评论罗伯特", "").strip()
                    self.logger.info(self.pre_log_msg + f"remove @robot in query:{weibo.get('query')}")
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"remove @robot in query error:{e}")


class StarIpInput(Base):
    def __init__(self, pid):
        super().__init__(pid)
        # self.memq_cli = MEMQ("wis_zhisou_star_ip_special@searchlogqueue.search.weibo.com:11233")
        self.key = "wis_zhisou_star_ip_special".encode('utf8')
        self.queue = Client("searchlogqueue.search.weibo.com", 11233, pool_minsize=1, pool_size=2)
        self.mode = "prod"
        # self.mode = "dev"

    def mock_input(self):
        import random
        data = [{'query': '刘诗诗', 'category': '101'},
                {'query': '复仇者联盟:毁灭日', 'category': '204'}]
        return json.dumps(data[random.randint(0, 1)],ensure_ascii=False)

    async def run(self, **kwargs):
        if self.mode == "prod":
            task_input = await self.queue.get(self.key)
            if isinstance(task_input, bytes):
                task_input = task_input.decode('utf-8')
        else:
            task_input = self.mock_input()
        if not task_input:
            self.logger.info("StarIpInput Queue is empty")
            return None
        task_dict = json.loads(task_input) # query, category
        task_dict["llm_name"] = "deepseek"
        task_dict["query_category"] = task_dict.get("category", "")
        task_dict["stream_output"] = 0
        task_dict["source"] = ""
        task_dict["label"] = "ds" # 使用deepseek格式物料
        self.logger.info("StarIpInput queue in: {}".format(task_dict))
        return task_dict


class MergeSummaryInput(SummaryInput):

    def __init__(self, pid, model, is_stream):
        super().__init__(pid, model)
        self.is_stream = is_stream

    def abtest(self, weibo):
        query = weibo.get('query', "")
        hash_str = md5_hash(query)
        bucket_id = get_bucket_id(hash_str, bucket_num=10)
        weibo['basemodel'] = "实验组{}".format(bucket_id + 1)

    def update(self, weibo):
        self.abtest(weibo)
        prompt_scene = weibo.get("prompt_scene", self.model) or self.model
        query = weibo.get('query', "")
        weibo['llm_name'] = prompt_scene
        if prompt_scene == 'deepseek' or prompt_scene == 'deepseek_stream':
            if query.endswith("_new24"):
                weibo["ori_prompt_scene"] = prompt_scene
                weibo["prompt_scene"] = 'deepseek_last2'
        elif prompt_scene == 'deepseek_verification' or prompt_scene == 'deepseek_analyze':
            pass
        elif prompt_scene == 'hot_overview' or prompt_scene == 'hot_overview_gray':
            weibo["hot_overview_override"] = prompt_scene
            weibo['llm_name'] = 'deepseek'
        elif prompt_scene == 'deepseek_comment':
            weibo["robot_override"] = prompt_scene
            weibo['llm_name'] = 'deepseek'
            query = weibo.get("query", "")
            if "@评论罗伯特" in query:
                weibo["query"] = query.replace("@评论罗伯特", "").strip()
                self.logger.info(self.pre_log_msg + f"remove @robot in query:{query}")
        elif prompt_scene == 'verification_comment':
            weibo["llm_name"] = "deepseek_verification"
            weibo['verification_comment'] = 'verification_comment'
            weibo["is_short"] = 1
            trace_id = weibo.get('trace_id', "")
            q_attr = weibo.get('q_attr', "")
            try:
                if q_attr:
                    json_data = json.loads(q_attr)
                    new_data = {
                        "cid": weibo.get('query'),  # 评论ID
                        "comment_uid": json_data.get("comment_uid", ""),  # 评论人uid
                        "mid": json_data.get("mid", "") ,  # 微博mid
                        "comment": json_data.get("comment", ""),  # 评论内容
                        "uid":json_data.get("mid_uid", "") ,  # 发博人用户id
                        "page_id":json_data.get("verification_page_id", "")  # 智搜结果id
                    }
                    weibo['query'] = new_data['mid']
                    weibo.update(new_data)
            except Exception as e:
                self.logger.error("{} {} de-serialize q_attr error:{}".format(trace_id, q_attr, e))
        elif prompt_scene == 'sina_news_analyze':
            weibo["llm_name"] = 'sina_news_analyze'
        elif prompt_scene == 'direct_comment':
            weibo["llm_name"] = 'direct_comment'
        elif prompt_scene == 'deepseek_last':
            weibo['llm_name'] = 'deepseek_last'
        elif prompt_scene == 'deepseek_annual_message':
            weibo['llm_name'] = 'deepseek_annual_message'
        else:
            self.logger.warning(self.pre_log_msg + f"invalid input weibo: {weibo}")



class AnnotationInput(SummaryInput):

    def __init__(self, pid, model, is_stream):
        super().__init__(pid, model)
        self.is_stream = is_stream

    def abtest(self, weibo):
        query = weibo.get('query', "")
        hash_str = md5_hash(query)
        bucket_id = get_bucket_id(hash_str, bucket_num=10)
        weibo['basemodel'] = "实验组{}".format(bucket_id + 1)

    def update(self, weibo):
        self.abtest(weibo)
        weibo['llm_name'] = 'deepseek_verification'
        weibo['verification_note'] = 'verification_note'

        trace_id = weibo.get("trace_id", "")
        q_attr = weibo.get("q_attr", "")
        try:
            if q_attr:
                json_data = json.loads(q_attr)
                verification_note_page_id = json_data.get("verification_note_page_id", "")
                verification_note_version = json_data.get("verification_note_version", "")
                note_page_id = json_data.get("page_id", "")
                weibo['verification_note_version'] = verification_note_version
                weibo['verification_note_page_id'] = verification_note_page_id
                weibo['note_page_id'] = note_page_id
        except Exception as e:
            self.logger.error("{} {} de-serialize q_attr error:{}".format(trace_id, q_attr, e))


class ChatVerificationInput(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.session = None
        self._lock = asyncio.Lock()

    async def get_session(self):
        async with self._lock:
            if self.session is None or self.session.closed:
                self.session = aiohttp.ClientSession()
        return self.session


    async def get_history(self, trace_id, user_id, session_id, num=6):
        retry = 2
        for i in range(retry):
            try:
                messages = []
                params = {'user_id': user_id, 'session_id': session_id, 'num': num, "filter_tag": 36}
                timeout = aiohttp.ClientTimeout(total=2)
                headers = {'Content-Type': 'application/json'}
                session = await self.get_session()
                async with session.get("http://admin.ai.s.weibo.com/api/chat/history.json",
                                       params=params, timeout=timeout, headers=headers) as response:
                    # response.raise_for_status()
                    content_type = response.headers.get("Content-Type", "")
                    if "application/json" in content_type:
                        data = await response.json()
                    else:
                        text = await response.text()
                        self.logger.info(f"{trace_id} text: {json.dumps(text, ensure_ascii=False)}")
                        data = json.loads(text)
                    history = data.get('data', [])
                    if history:
                        for chat in reversed(history):
                            blacked = str((chat.get('risk_control') or {}).get("blacked") or 0)
                            question = chat.get('question', "")
                            content = chat.get('content', "")
                            if question and content and blacked != '1':
                                messages.append({'role': 'user', 'content': question})
                                messages.append({'role': 'assistant', 'content': content})
                self.logger.info(f"{trace_id} history len: {len(messages)}")
                return messages
            except Exception as e:
                self.logger.error(f"{trace_id} get history error: {e}")
        return []


    async def run(self, model: str) -> dict | None:
        start = time.time()
        params = {'model': model}
        timeout = aiohttp.ClientTimeout(total=2)

        try:
            headers = {'Content-Type': 'application/json'}
            session = await self.get_session()
            async with session.get("http://admin.ai.s.weibo.com/api/chat/get_task.json", params=params, timeout=timeout, headers=headers) as response:
                response.raise_for_status()
                data = await response.json()
                if not data:
                    self.logger.warning(f"{self.pid} Queue is empty")
                    return None

                data_str = data.get("data", "")
                if not data_str:
                    self.logger.warning(f"{self.pid} Queue is empty")
                    return None

                self.logger.info(f"queue ori {data_str}")
                json_dict = json.loads(data_str)

                trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
                trace_id = json_dict.get('version', trace_id)
                json_dict['trace_id'] = trace_id
                json_dict['traceid'] = trace_id

                # 思考版还是非思考版
                use_deep_think = 1
                try:
                    completion_option = json.loads(json_dict.get("completion_option") or "{}")
                    use_deep_think = int(completion_option.get("use_deep_think", 1))
                except Exception as e:
                    self.logger.warning(f"input message error: {e}")
                json_dict["model"] = model

                # 测试case
                json_dict['source_type'] = "client"
                question = json_dict.get("question", "")
                json_dict["ori_question"] = question
                if question.endswith("_chattest"):
                    question = question.split("_chattest")[0]
                    json_dict['source_type'] = "client"
                json_dict["question"] = question
                json_dict["query"] = question
                json_dict["llm_name"] = "deepseek_verification"
                json_dict["query_category"] = ""
                # 获取历史
                user_id = json_dict.get('user_id', "")
                session_id = json_dict.get('session_id', "")

                self.logger.info(f"get_history: {user_id} {session_id}")
                messages = await self.get_history(trace_id, user_id, session_id)
                messages.append({"role": "user", "content": question})
                json_dict["messages"] = messages

                json_dict['ori_conversation_id'] = json_dict.get('conversation_id', "")
                json_dict['conversation_id'] = ""
                self.logger.info(f"queue in {json_dict}, cost: {time.time() - start}")
                return json_dict
        except Exception as e:
            self.logger.error(f"input error cost: {time.time() - start}, msg: {traceback.format_exc()}")

        return None

    async def close(self):
        async with self._lock:
            if self.session and not self.session.closed:
                await self.session.close()



class ChatVerificationQueueInput(ChatVerificationInput):
    intent_queue = mcq_cli(domain="queue.search.weibo.com", port=11233)
    async def run(self, model: str) -> dict | None:
        start = time.time()

        try:
            data_str = await self.intent_queue.get("wis_dialogue_intent_recognition")
            if not data_str:
                self.logger.warning(f"{self.pid} Queue is empty")
                return None

            self.logger.info(f"queue ori {data_str}")
            json_dict = json.loads(data_str)

            trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
            trace_id = json_dict.get('version', trace_id)
            json_dict['trace_id'] = trace_id
            json_dict['traceid'] = trace_id

            # 思考版还是非思考版
            use_deep_think = 1
            try:
                completion_option = json.loads(json_dict.get("completion_option") or "{}")
                use_deep_think = int(completion_option.get("use_deep_think", 1))
            except Exception as e:
                self.logger.warning(f"input message error: {e}")
            json_dict["model"] = model

            # 测试case
            json_dict['source_type'] = "client"
            question = json_dict.get("question", "")
            json_dict["ori_question"] = question
            if question.endswith("_chattest"):
                question = question.split("_chattest")[0]
                json_dict['source_type'] = "client"
            json_dict["question"] = question
            json_dict["query"] = question
            # json_dict["llm_name"] = "deepseek_analyze"
            # json_dict["prompt_scene"] = 'deepseek_analyze'
            json_dict["query_category"] = ""
            # 获取历史
            user_id = json_dict.get('user_id', "")
            session_id = json_dict.get('session_id', "")

            self.logger.info(f"get_history: {user_id} {session_id}")
            messages = await self.get_history(trace_id, user_id, session_id)
            messages.append({"role": "user", "content": question})
            json_dict["messages"] = messages

            json_dict['ori_conversation_id'] = json_dict.get('ori_conversation_id', "")
            json_dict['conversation_id'] = ""
            # json_dict['sid'] = "sina_news_verification"

            json_dict['inner_prompt_scene'] = 'chat_url'
            self.logger.info(f"queue in {json_dict}, cost: {time.time() - start}")
            return json_dict
        except Exception as e:
            self.logger.error(f"input error cost: {time.time() - start}, msg: {traceback.format_exc()}")

        return None

    async def close(self):
        async with self._lock:
            if self.session and not self.session.closed:
                await self.session.close()


class TestInput(Base):
    def __init__(self, pid):
        super().__init__(pid)

    async def run(self, **kwargs):
        # 测试热点概况卡片专用
        # data = {'query': '刘诗诗', 'llm_name': 'deepseek', 'uid': '', 'query_question': '', 'query_category': '', 'version': '', 'ab_test': '0', 'high_level': 7, 'source': '', 'in_time': 1734710397, 'in_time_ms': 1734710397.987, 'sens_words': '', 'self_account': 0, 'q_attr': '{"new_high_level":7,"async":1,"strategy_source":7,"orifid":"102803_ctg1_1780_-_ctg1_1780$$0","m_top5_status":1,"action_from":3011,"lfid":"100103type=1&t=3","m_top10_status":1,"m_top3_status":1,"m_top5_40diff_status":1,"qwen72b":1,"chatglm4":1,"mtop5_diff_num":2}', 'level2_uid': '1239246050', 'stream_output': 0, "hot_overview_override": "hot_overview"}
        # 评论罗伯特专用
        data = {'query': '刘诗诗123', 'llm_name': 'deepseek', 'uid': '', 'query_question': '', 'query_category': '', 'version': '', 'ab_test': '0', 'high_level': 7, 'source': '', 'in_time': 1734710397, 'in_time_ms': 1734710397.987, 'sens_words': '', 'self_account': 0, 'q_attr': '{"new_high_level":7,"async":1,"strategy_source":7,"orifid":"102803_ctg1_1780_-_ctg1_1780$$0","m_top5_status":1,"action_from":3011,"lfid":"100103type=1&t=3","m_top10_status":1,"m_top3_status":1,"m_top5_40diff_status":1,"qwen72b":1,"chatglm4":1,"mtop5_diff_num":2, "mid": "12345"}', 'level2_uid': '1239246050', 'stream_output': 0, "robot_override": "deepseek_comment"}

        # data = {'query': '继林5', 'llm_name': 'deepseek', 'uid': '', 'query_question': '', 'query_category': '', 'version': '', 'ab_test': '0', 'high_level': 7, 'source': '99', 'in_time': 1734710397, 'in_time_ms': 1734710397.987, 'sens_words': '', 'self_account': 0, 'q_attr': '{"new_high_level":7,"async":1,"strategy_source":7,"orifid":"102803_ctg1_1780_-_ctg1_1780$$0","m_top5_status":1,"action_from":3011,"lfid":"100103type=1&t=3","m_top10_status":1,"m_top3_status":1,"m_top5_40diff_status":1,"qwen72b":1,"chatglm4":1,"mtop5_diff_num":2}', 'level2_uid': '1239246050', 'stream_output': 0}
        #data = {'query': 'msgbox_brief_600adc2ad8b89d835d3c65a5bd8c7470', 'list': ['#吴柳芳粉丝仅剩4.4万#', '#吴柳芳账号已被禁言#', '#哈尔滨冰雕有血印视频系1月发布#', '#张继科199元录播课3小时卖了25万元#', '#张馨予为何捷发声#', '#张馨予老公年薪#', '#洪尧抽烟让吴谨言吸二手烟#', '#还有8天刑满释放男子被改判死缓#', '平安夜', '微信蓝包'], 'in_time': 1735069949, 'res_version': '1320241225035229'}
        #data = {'query': '跨年晚会', 'res_version': '1320241225002704', 'need_hot_summary': '1'}
        #data = {'ab_test': '', 'version': '', 'stream_output': 1, 'sens_words': '', 'self_account': 0, 'high_level': 3, 'in_time_ms': 1735720889.062, 'query': 'jilin5', 'level2_uid': '', 'source': '99', 'llm_name': 'qwen72b', 'query_category': 'ShortTv', 'q_attr': '{"m_top5_status":1,"m_top5_40diff_status":0,"pv":4,"m_top10_status":1,"new_high_level":3,"m_top3_status":1,"async":1}', 'query_question': '', 'uid': '', 'in_time': 1735720889, 'trace_id': '17357208895338485', 'traceid': '17357208895338485', 'query_type': 'ShortTv'}
        # data = {'in_time': 1735883943, 'in_time_ms': 1735883943.079, 'version': '17358838435549496', 'source': '99', 'ab_test': '', 'uid': '', 'query_category': '', 'level2_uid': '', 'query': '蛇钞', 'query_question': '', 'high_level': 3, 'stream_output': 0, 'sens_words': '', 'self_account': 0, 'q_attr': '{"qwen72b":1,"sens_status":2,"old_high_level":3,"new_high_level":3,"qwen72b_stream":1}', 'trace_id': '17358839431729681', 'traceid': '17358839431729681', 'query_type': ''}
        trace_id = str(int(time.time() * 1000)) + str(random.randrange(1000, 9999, 1))
        data.update({'trace_id': trace_id})
        return data


class XiaoYiStreamInput(SummaryInput):
    async def request(self):
        params = {'model': self.model, 'is_stream': 1}
        # url = "http://admin.ai.s.weibo.com/intfs/llm/getOnceQueueQuery"
        url = "http://admin.ai.s.weibo.com/api/wis/get_task.json"
        session = await self.get_session()
        timeout = aiohttp.ClientTimeout(total=2)
        async with session.get(url, params=params, timeout=timeout) as response:
            response.raise_for_status()
            return await response.json()


class ShortCommentInput(Base):
    def __init__(self, pid):
        super().__init__(pid)
        self.mcq_obj = mcq_cli(domain="fe.queue.search.weibo.com", port=11233)

    def mock_input(self):
        import random
        data = []
        # {
        #     "cid": cid,  # 评论ID
        #     "mid": mid,  # 微博mid
        #     "comment": comment,  # 评论内容
        #     "uid": uid,  # 发博人用户id
        #     "page_id": page_id  # 智搜结果id
        # }
        return json.dumps(data[random.randint(0, 1)], ensure_ascii=False)

    async def run(self, **kwargs):
        task_input = await self.mcq_obj.get("zs_zhijie_reply")
        if not task_input:
            self.logger.info("ShortCommentInput Queue is empty")
            return None
        task_dict = json.loads(task_input)
        origin_input = copy.deepcopy(task_dict)

        trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
        trace_id = task_dict.get('version', trace_id) or trace_id
        task_dict['query'] = task_dict.get("mid", "")
        task_dict['trace_id'] = trace_id
        task_dict['traceid'] = trace_id
        task_dict["llm_name"] = "deepseek_verification"
        task_dict['verification_comment'] = 'verification_comment'
        task_dict["query_category"] = task_dict.get("category", "")
        task_dict["stream_output"] = 0
        task_dict["source"] = ""
        task_dict["is_short"] = 1
        task_dict['origin_input'] = origin_input

        self.logger.info("queue in: {}".format(task_dict))
        return task_dict


class SinaNewsAnalyzeInput(SummaryInput):
    pass

class StarAwardAnalyzeInput(SummaryInput):
    pass