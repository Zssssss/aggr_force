import time
import asyncio
import json
from contextlib import asynccontextmanager

from plugins.input.input import SummaryInput
from plugins.llm.deepseek import StreamDeepSeekLLM
from plugins.recalculate.recalculate import Recalculate
from api.model_api import WeiboDeepseekWrapper


class OverrideStreamSummaryInput(SummaryInput):

    def __init__(self, pid, query):
        super().__init__(pid, "deepseek_stream")
        self.query = query

    async def request(self):
        await asyncio.sleep(0.01)
        result = {
            "query": self.query,
            "query_category": "",
            "uid": "",
            "query_question": "",
            "stream_output": 1
        }
        return {"data": json.dumps(result)}


class OverrideStreamRecalculate(Recalculate):
    """计算控制器：负责判断是否需要计算以及保存计算结果

    使用方式：
    async with Recalculate(pid).computing_context(weibo) as should_compute:
        if not should_compute:
            return
        # 执行计算逻辑
    """

    @asynccontextmanager
    async def run(self, **kwargs):
        yield True


class OverrideStreamLLM(StreamDeepSeekLLM):

    def __init__(self, weibo, output, pid, base_length):
        super().__init__(weibo, output, pid)
        self.base_length = base_length

    def should_recalculate(self):
        recalculate = OverrideStreamRecalculate(self.pid)
        return recalculate

    async def call_llm(self, prompt):
        return None

    async def confine_material_length(self,base_length=90000):
        return await super().confine_material_length(self.base_length)

    async def override_call_llm(self, prompt):
        func_name = "CALL_OVERRIDE_STREAM_LLM"
        start = time.time()
        llm_qwen72b = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_content = prompt

        try:
            stream_response = await llm_qwen72b.async_stream_call(prompt_content)
            result = ""
            last_result = ""
            has_yielded = False
            
            # 使用 async for 来迭代异步生成器
            async for response in stream_response:
                if response is None:  # 处理可能的 None 响应
                    continue
                    
                result = response.get("text", "")
                if not result:  # 如果没有文本内容，跳过
                    continue
                    
                result = result.strip('\n')
                
                # 修改判断逻辑：降低阈值并确保有内容变化就输出
                if len(result) > len(last_result) and (len(result) - len(last_result) >= 5 or not has_yielded):
                    yield result
                    last_result = result
                    has_yielded = True
                    
            # 确保最终结果被返回（即使长度差异小于阈值）
            if result and result != last_result:
                self.logger.info(self.pre_log_msg + f"{func_name} yielding final result, length: {len(result)}")
                yield result
                
            self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\t"
                                                    f"result_length:{len(result)}\tfinal_result:{json.dumps(result[-100:] if len(result) > 100 else result, ensure_ascii=False)}")
                
        except Exception as e:
            self.logger.exception(f"{self.pre_log_msg}{func_name} exception: {e}")
            # 异常时返回空字符串
            yield ""
        
        # 如果没有获取到任何数据，记录日志并返回空字符串
        if not result:
            self.logger.info(self.pre_log_msg + f"{func_name} get no data, cost_time:{time.time() - start}\t")
            yield ""
