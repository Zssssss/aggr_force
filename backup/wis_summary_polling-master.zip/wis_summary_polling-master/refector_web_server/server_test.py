# -*- coding:utf-8 -*-
import time
import requests


def server_test(query, external_prompt, search_querys):
    datas = {
        'query': query,
        'external_prompt': external_prompt,
        "search_querys": search_querys
    }

    start = time.time()
    headers = {'Content-Type': 'application/json'}
    response = requests.post("http://10.133.168.176:921/v1/wis_summary", json=datas, headers=headers, stream=True)
    print(response.headers)

    data = bytearray()
    for chunk in response.iter_content(4096):
        if chunk:
            data.extend(chunk)
            split_symbol = b'\n'
            while split_symbol in data:
                index = data.find(split_symbol)
                split = data[0:index]
                data = data[index + 1:]
                content = split.decode("utf-8")

                pos = content.find("data:")
                if pos != -1:
                    content = content[len("data:"):]

                content = content.strip()
                if content:
                    print(time.time() - start)
                    print(content)


if __name__ == '__main__':
    external_prompt = "总结以下内容：<materials>{materials}</materials>"
    for i in range(2):
        server_test("你好", external_prompt, ["你好", "吃了吗", "昨天怎么样"])
