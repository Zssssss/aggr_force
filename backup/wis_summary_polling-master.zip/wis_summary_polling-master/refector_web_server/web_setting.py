proc_name = "refector_chat_server"
workers = 12
host='0.0.0.0'
port=921
bind = f"{host}:{port}"
timeout = 100
process_id = 0
