proc_name = "whiteboard"
workers = 6
bind = "0.0.0.0:9099"
timeout = 100
