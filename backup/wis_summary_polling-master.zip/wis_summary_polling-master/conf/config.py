# -*- coding:utf-8 -*-

RUN_SETTING = {
    "deepseek": {
        'processes': 15,
        'tasks': 125
    },
    "deepseek_stream": {
        'processes': 16,
        'tasks': 30
    },
    # "deepseek_hot": {
    #     'processes': 1,
    #     'tasks': 10
    # },
    "deepseek_star_ip": {
        'processes': 2,
        'tasks': 3
    },
    # "deepseek_robot": {
    #     "processes": 1,
    #     "tasks": 10
    # },
    # "deepseek_verification": {
    #     "processes": 5,
    #     "tasks": 64
    # },
    "qwen3_30b_xiaoyi_stream": {
        "processes": 1,
        "tasks": 5
    },
    # "deepseek_shortcomment": {
    #     "processes": 1,
    #     "tasks": 10
    # },
    "deepseek_annotation": {
        "processes": 1,
        "tasks": 70
    },
    "chat_verification": {
        "processes": 1,
        "tasks": 20
    },
    "chat_verification_queue": {
        "processes": 1,
        "tasks": 20
    },
    "sina_news_analyze_stream": {
        "processes": 1,
        "tasks": 20
    },
    "deepseek_annual_message": {
        "processes": 5,
        "tasks": 20
    }
}

TASK_CONCURRENCY = 200
MULTIMODAL_DEBUG = False

RISK_CONTROL_3_6_SWITCH = False
GAOKAO_STATEMENT = "\n\n本内容由AI生成，仅供参考，请结合自身情况及官方信息谨慎决策。"

DICT_GAOKAO_KW = {'city': '城市',
 'province': '省份',
 'type': '类型',
 'school_type': '办学层次',
 'school_nature': '办学类型',
 'dual_class': '双一流建设高校',
 'f211': '211工程院校',
 'f985': '985工程院校',
 'dual_class_subject_list': '双一流建设学科',
 'school_name': '学校名称',
 'emblem': 'logo',
 'live': '宣传片',
 'address': '地址',
 'site': '学校官网',
 'admission_site': '招生官网',
 'phone': '招生电话',
 'first_num_master': '一级学科硕士点',
 'second_num_master': '二级学科硕士点',
 'first_num_doctor': '一级学科博士点',
 'second_num_doctor': '二级学科博士点',
 'create_date': '创建年份',
 'school_live': '食宿条件',
 'fengguang': '校园风光',
 'ruanke_rank': '软科排名',
 'QS_rank': 'QS世界大学排名',
 'US_rank': 'US News排名',
 'xiaoyou_rank': '校友会排名',
 'place': '省份',
 'year': '年份',
 'student': '考生类别',
 'luqupici': '批次',
 'zslx': '招生类型',
 'low': '最低分',
 'rank': '最低位次',
 'fencha': '批次线差',
 'group_name': '专业组',
 'elective_info': '选科要求',
 'batch_for_one': '批次',
 'major': '专业名称',
 'major_detail': '专业备注/方向',
 'major_group': '专业组',
 'major_group_subject': '选科要求',
 'min': '最低分',
 'batch': '批次',
 'major_code': '专业代码',
 'group_content': '选科要求',
 'number': '招生人数',
 'major_year': '学制',
 'tuitionfee': '学费',
 'rate': '就业率/考研率/出国率',
 'salary_info': '毕业薪酬数据',
 'region': '就业地区分布',
 'jobs': '就业单位性质分布',
 'company': '就业单位',
 'major_name': '专业名称',
 'major_type': '专业大类',
 'major_national': '特色',
 'title': '标题',
 'intro': '专业简介',
 'major_category': '专业大类',
 'major_subject': '专业门类',
 'time': '时间',
 'degree': '授予学位',
 'course': '开设课程',
 'postgraduate_direction': '考研方向',
 'cengci': '专业层次',
 'Selection_uggestions': '选科建议',
 'nan_ratio': '男生比例',
 'nv_ratio': '女生比例',
 'wen_ratio': '文科比例',
 'li_ratio': '理科比例',
 'major_hot': '专业热度',
 'year_after_graduation': '毕业年限',
 'salary': '本专业平均薪酬',
 'salary_all': '全国平均薪酬',
 'work_industry': '就业行业分布',
 'industry': '行业名称',
 'work_job': '就业岗位分布',
 'job': '岗位名称',
 'work_area': '就业地区分布',
 'major_college': '开设院校信息',
 'major_college_link': '院校列表链接',
 'item': '院校列表',
 'name': '名称',
 'logo': '院校logo',
 'prov': '院校位置',
 'genre': '院校类型',
 'bxlx': '办学层次',
 'school_tag': '院校特色',
 'time_info': '高考时间信息',
 'start_time': '开始时间戳',
 'end_time': '结束时间戳',
 'subject_time_list': '各科目考试时间',
 'date': '考试日期',
 'time_str': '考试时间段',
 'subject': '科目',
 'point_info': '成绩查询信息',
 'subtext': '说明',
 'url': '网址',
 'volunteer_info': '志愿填报信息',
 'batch_time_list': '各批次时间',
 'enroll_info': '录取查询信息',
 'list': '列表',
 'score': '分数',
 'weici': '最低位次',
 'classify': '考生类型',
 'level': '层次',
 'detail': '分数位次数组',
 'num': '人数',
 'total_num': '累计人数',
 'previous_year_score': '往年同分数信息数组',
 'provinceCode': '省份代码',
 'use': '使用地区',
 'tab': '信息',
 'zhentiurl': '真题链接',
 'daanurl': '答案链接',
 'jiexiurl': '解析链接',
 'gufenurl': '估分链接',
 'abstract': '作文题目详细内容',
 'jumpurl': '作文链接'}