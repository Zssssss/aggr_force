# -*- coding:utf-8 -*-
import socket
import urllib
import urllib.parse
import urllib.request

def alarm(content, group='wis_summary', title='智搜综述异常报警'):
    hostname = socket.gethostname()
    re_param = {'content': "[{}] ".format(hostname) + content, 'group': group, 'title': title}
    re_param = urllib.parse.urlencode(re_param)
    alarm_api = "http://falcon.search.weibo.com/falcon/alarm?%s" % re_param
    req = urllib.request.Request(url=alarm_api)
    try:
        res = urllib.request.urlopen(req, timeout=3)
        res = res.read().strip()
        print("alarm send alarm content: {}, res: {}".format(content, res))
    except Exception as e:
        print("alarm exception:{}, content: {}".format(e, content))
