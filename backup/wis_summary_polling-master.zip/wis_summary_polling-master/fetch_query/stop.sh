#!/bin/bash

PID_FILE="rank.pid"

if [ -f $PID_FILE ]; then
    PID=$(cat $PID_FILE)
    kill $PID && echo "🛑 Process $PID stopped"
    rm -f $PID_FILE
else
    echo "⚠️ PID file not found: $PID_FILE"
fi