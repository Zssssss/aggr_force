#!/bin/bash

set -x

source /etc/profile

APP_NAME=wis_summary
DOCKER_NAME=registry.api.weibo.com/wbsearch/wis_summary:v1.8


docker rmi $(docker images -f "dangling=true" -q)
docker pull $DOCKER_NAME
docker stop $APP_NAME
docker rm -fv $APP_NAME

# online
docker run --restart=always --privileged --net=host --name $APP_NAME  \
--env SEARCH_ENV_ECI=$SEARCH_ENV_ECI \
--env SEARCH_ENV_IP=$SEARCH_ENV_IP \
--env SEARCH_ENV_IDC=$SEARCH_ENV_IDC \
--env SEARCH_ENV_GROUP=$SEARCH_ENV_GROUP \
--env SEARCH_ENV_ENV=online  \
-v /data1/minisearch/upload/LLM_TASK/wis_summary_ds:/data1/minisearch/upload/LLM_TASK/wis_summary_ds  \
-v /data1/minisearch/upload/token:/data1/minisearch/upload/token  \
-v /data1/minisearch/upload/LLM_TASK:/data1/minisearch/upload/LLM_TASK  \
-v /etc/passwd:/etc/passwd  \
-v /etc/shadow:/etc/shadow \
-v /etc/group:/etc/group \
-itd $DOCKER_NAME /bin/sh /data1/minisearch/upload/LLM_TASK/wis_summary_ds/restart.sh -f

