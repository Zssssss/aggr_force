import threading


class ReadWriteLock:
    def __init__(self):
        self._readers = 0
        self._writers = 0
        self._lock = threading.Lock()  # 锁保护计数器的修改
        self._read_ready = threading.Condition(self._lock)  # 用于管理读写线程的Condition

    def acquire_read(self):
        with self._lock:
            while self._writers > 0:  # 如果有写线程在执行，读线程需要等待
                self._read_ready.wait()
            self._readers += 1  # 增加读线程计数

    def release_read(self):
        with self._lock:
            self._readers -= 1  # 减少读线程计数
            if self._readers == 0:
                self._read_ready.notify_all()  # 如果没有读线程了，通知等待的写线程

    def acquire_write(self):
        with self._lock:
            while self._readers > 0 or self._writers > 0:  # 等待所有读写线程完成
                self._read_ready.wait()
            self._writers += 1  # 增加写线程计数

    def release_write(self):
        with self._lock:
            self._writers -= 1  # 减少写线程计数
            self._read_ready.notify_all()  # 通知等待的读或写线程