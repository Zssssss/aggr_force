# -*- coding:utf-8 -*-
import re
from dataclasses import dataclass
from typing import List, Optional, Iterable


@dataclass
class MdSection:
    level: int
    title: str
    content: str
    start_line: int  # line index (0-based) where heading occurs
    end_line: int  # line index (inclusive) of last line in this section's content block


_HEADING_ATX_RE = re.compile(r"""
    ^(?P<indent>[ \t]*)          # optional leading spaces
    (?P<hashes>\#{1,6})          # 1‑6 literal “#”
    [ \t]+                       # at least one space before text
    (?P<text>.*?)                # heading text (non‑greedy)
    [ \t]*\#*[ \t]*$             # optional closing “###” and spaces
""", re.VERBOSE)

# Setext heading detection needs two lines; we detect marker lines separately.
_SETEXT_RE = re.compile(r'^[ \t]*(?P<marker>=+|-+)[ \t]*$')


def _strip_md_inline(text: str) -> str:
    """
    非严格 Markdown inline 清理：去掉围绕标题的行内格式（*, _, `, [], () 等简单场景）。
    只是为了让标题更干净；如需完整 Markdown 渲染请使用 markdown 库。
    """
    txt = text.strip()
    # remove surrounding backticks, asterisks, underscores if balanced
    if (txt.startswith(("`", "*", "_"))
            and len(txt) > 1
            and txt[0] == txt[-1]
            and txt.count(txt[0]) >= 2):
        txt = txt.strip(txt[0])
    # strip leading/trailing markdown link [text](url) -> text
    m = re.match(r'^\[(?P<label>[^\]]+)\]\([^)]+\)$', txt)
    if m:
        txt = m.group('label')
    return txt.strip()


def split_markdown_by_headings(md_text: str, *, include_heading_in_content: bool = False) -> List[MdSection]:
    """
    将 Markdown 文本按标题分块。

    参数
    ----
    md_text: str
        原始 Markdown 字符串。
    include_heading_in_content: bool = False
        若为 True，返回的 content 将包含标题行本身（及 setext 标题第二行标记）。

    返回
    ----
    List[MdSection]
    """
    if not md_text:
        return []

    lines = md_text.splitlines()
    n = len(lines)
    headings: List[tuple[int, str, int, int]] = []
    # tuple: (level, title, heading_start_line, heading_end_line)
    # heading_end_line 对 ATX = start_line；对 Setext = marker_line

    i = 0
    while i < n:
        line = lines[i]
        # --- 1. ATX ---
        m = _HEADING_ATX_RE.match(line)
        if m:
            level = len(m.group('hashes'))
            title = _strip_md_inline(m.group('text'))
            headings.append((level, title, i, i))
            i += 1
            continue

        # --- 2. Setext (need lookahead line) ---
        if i + 1 < n:
            next_line = lines[i + 1]
            sm = _SETEXT_RE.match(next_line)
            if sm and lines[i].strip() != "":  # valid setext only if text line non-blank
                marker = sm.group('marker')
                level = 1 if marker.startswith('=') else 2
                title = _strip_md_inline(line)
                headings.append((level, title, i, i + 1))
                i += 2
                continue

        i += 1

    # 若文档开头不是标题，可选择虚拟 root（可选，这里不自动添加；需要可自行加）
    if not headings:
        # 整个文档无标题：作为 level=0 匿名段落
        return [MdSection(level=0, title="", content=md_text, start_line=0, end_line=n - 1)]

    sections: List[MdSection] = []
    for idx, (lvl, ttl, h_start, h_end) in enumerate(headings):
        # 当前标题内容开始行:
        content_start = h_start if include_heading_in_content else (h_end + 1)

        # 查找下一个“同级或更高级”标题，以此确定结束行
        # headings 已经按源顺序；向后搜索直到找到 level <= 当前 level
        content_end_line = n - 1  # default to end-of-doc
        for j in range(idx + 1, len(headings)):
            next_lvl, _, next_h_start, _ = headings[j]
            if next_lvl <= lvl:
                content_end_line = next_h_start - 1
                break

        # 提取文本
        if include_heading_in_content:
            # heading lines: h_start..h_end; plus body
            raw_lines = lines[h_start:content_end_line + 1]
        else:
            raw_lines = lines[content_start:content_end_line + 1]

        content = "\n".join(raw_lines).rstrip("\n")
        sections.append(MdSection(
            level=lvl,
            title=ttl,
            content=content,
            start_line=h_start,
            end_line=content_end_line
        ))

    return sections
