# -*- coding:utf-8 -*-
# import sys
# reload(sys)
# sys.setdefaultencoding('utf8')
from collections import defaultdict


# trie树
class Node(object):
    def __init__(self, is_end=False):
        self.is_end = False
        self.node = {}


class Trie(object):

    def __init__(self, words=None):
        self.size = 0
        self.root = Node()
        if words:
            self.build(words)

    def build(self, words):
        for w in words:
            self.add(w)

    def add(self, word):
        """字典树添加word
        """
        cur = self.root  # node
        for w in word:
            if cur.node.get(w) is None:
                cur.node[w] = Node()
            cur = cur.node[w]

        if not cur.is_end:
            cur.is_end = True
            self.size += 1

    def __len__(self):
        return self.size

    def __contains__(self, word):
        cur = self.root
        for w in word:
            if cur.node.get(w) is None:
                return False
            cur = cur.node[w]
        return cur.is_end

    def search(self, title):
        """从一个字符串查找匹配到的最长产品词
        """
        res = []
        cur = self.root
        n = len(title)
        t = -1
        pro = ""
        for i, w in enumerate(title):
            if w in cur.node:
                tmp = cur.node[w]
                j = i + 1
                while j < n:
                    # t保存匹配过的最长索引，例如糖果枕头 产品词 枕 枕头包，会导致无法出现 枕 产品词
                    if tmp.is_end:
                        t = j
                    if title[j] in tmp.node:
                        tmp = tmp.node[title[j]]
                        j += 1
                    else:
                        break
                if tmp.is_end:
                    pro = title[i:j]
                else:
                    # 匹配失败，匹配保留过的最大长度t
                    if t > i:
                        pro = title[i:t]
                if pro != "":
                    if res:
                        if pro not in res[-1]:
                            res.append(pro)
                    else:
                        res.append(pro)
                    pro = ""
                t = -1
        return res

    def search_idx(self, title):
        """从一个字符串查找匹配到的最长产品词。
        已经匹配的不再匹配，例如糖果枕头匹配后，不再匹配枕头
        返回匹配词的索引位置
        """
        res, idx = [], []
        cur = self.root
        n = len(title)
        t = -1
        pro = ""
        i = 0
        while i < n:
            if title[i] not in cur.node:
                i += 1
                continue
            # title[i] in cur.node
            tmp = cur.node[title[i]]
            j = i + 1
            while j < n:
                # t保存匹配过的最长索引，例如糖果枕头 产品词 枕 枕头包，会导致无法出现 枕 产品词
                if tmp.is_end:
                    t = j
                if title[j] in tmp.node:
                    tmp = tmp.node[title[j]]
                    j += 1
                else:
                    break
            if tmp.is_end:
                pro = title[i:j]
                new_start = j
            else:
                # 匹配失败，匹配保留过的最大长度t
                if t > i:
                    pro = title[i:t]
                    new_start = t
                else:
                    new_start = i + 1
            if pro != "":
                res.append(pro)
                idx.append((i, i + len(pro) - 1))
                pro = ""
            t = -1
            i = new_start
        return res, idx

    def search_all(self, title):
        """从一个字符串查找匹配到的所有词
        """
        res = defaultdict(list)
        cur = self.root
        n = len(title)
        # t = -1
        # pro = ""
        for i, w in enumerate(title):
            # print(w)
            if w in cur.node:
                tmp = cur.node[w]
                j = i + 1
                while j < n:
                    # t保存匹配过的最长索引，例如糖果枕头 产品词 枕 枕头包，会导致无法出现 枕 产品词
                    if tmp.is_end:
                        res[title[i:j]].append((i, j))
                        # t = j
                    if title[j] in tmp.node:
                        tmp = tmp.node[title[j]]
                        j += 1
                    else:
                        break
                if j == n and tmp.is_end:
                    res[title[i:j]].append((i, j))
        return res


class MidTrie:
    class TrieNode:
        def __init__(self):
            self.children = {}
            self.is_end_of_word = False

    def __init__(self, keywords):
        self.root = self.TrieNode()
        for keyword in keywords:
            self.insert(keyword)

    def insert(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = self.TrieNode()
            node = node.children[char]
        node.is_end_of_word = True

    def search(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                return False
            node = node.children[char]
        return node.is_end_of_word

    def contains_any_keyword(self, text):
        node = self.root
        for ch in text:
            if ch in node.children:
                node = node.children[ch]
                if node.is_end_of_word:
                    return True
            else:
                node = self.root  # 重置
                if ch in node.children:  # 立刻再用 ch 匹配一次
                    node = node.children[ch]
                    if node.is_end_of_word:
                        return True
        return False
    

class KeywordMatcher:
    """
    通用关键词匹配工具类
    使用给定的 Trie 实现
    支持 "+" 表示必须同时出现的逻辑
    """

    def __init__(self, keywords: list[str]):
        """
        :param keywords: 关键词列表，如 ["苹果", "香蕉+水果", "手机+充电器"]
        """
        self.raw_keywords = list(set(keywords))  # 去重
        self.basic_terms = set()
        self.compound_keywords = []
        self._split_keywords()

        # 初始化 Trie
        self.trie = Trie(self.basic_terms)

    def _split_keywords(self):
        """拆分复合关键词"""
        for kw in self.raw_keywords:
            parts = [p.strip() for p in kw.split('+') if p.strip()]
            if len(parts) == 1:
                self.basic_terms.add(parts[0])
            else:
                self.compound_keywords.append(parts)
                self.basic_terms.update(parts)

    def match(self, text: str) -> list[str]:
        """
        匹配文本，返回命中的关键词（+ 逻辑必须全部满足）
        """
        found_dict = self.trie.search_all(text)
        found_terms = set(found_dict.keys())

        matched = []

        # ✅ 先匹配复合词（必须所有子词都出现）
        for parts in self.compound_keywords:
            if all(p in found_terms for p in parts):
                matched.append('+'.join(parts))

        # ✅ 再匹配单词（但要排除那些属于复合词的部分）
        # 例如“香蕉+水果”匹配成功后，不单独返回“香蕉”或“水果”
        compound_subterms = set(p for parts in self.compound_keywords for p in parts)
        for term in self.basic_terms:
            if term in found_terms and term not in compound_subterms:
                matched.append(term)

        return matched



if __name__ == '__main__':
    trie = Trie(['aaa', 'a', 'bbb', 'abc'])
    res = trie.search_all('aabcbbbaaa')
    print(res)

    print('KeywordMatcher test...............')
    kws = ["苹果", "香蕉+水果", "手机+充电器", "北京+天气+预报"]
    matcher = KeywordMatcher(kws)

    text = "北京今天"
    result = matcher.match(text)

    print("匹配结果：", result)

