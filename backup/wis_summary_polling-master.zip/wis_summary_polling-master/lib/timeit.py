import time
import functools
import inspect
from typing import Callable, Any, Optional, Literal, Union
import loguru

def timeit(func=None, *, logger_mode: Literal['self', 'param', None] = None):
    """
    装饰器：计算同步或异步函数的执行时间
    
    参数:
        func: 被装饰的函数
        logger_mode: 指定如何获取logger对象
            - 'self': 从实例方法的self.logger获取
            - 'param': 从名为'logger'的参数获取
            - None: 不使用logger，直接打印结果
    """
    def decorator(func):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            # 获取logger对象
            logger, pre_log = _get_logger_from_args(func, args, kwargs, logger_mode)
            
            start_time = time.time()
            result = await func(*args, **kwargs)
            end_time = time.time()
            
            execution_time = end_time - start_time
            _log_execution_time(func.__name__, execution_time, logger, pre_log)
            
            return result
            
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            # 获取logger对象
            logger, pre_log = _get_logger_from_args(func, args, kwargs, logger_mode)
            
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            
            execution_time = end_time - start_time
            _log_execution_time(func.__name__, execution_time, logger, pre_log)
            
            return result
        
        def _get_logger_from_args(func: Callable, args: tuple, kwargs: dict,
                                  mode: str) -> tuple[Optional['loguru.Logger'], str]:
            """
            根据指定的模式从函数参数中获取logger对象
            """
            if mode is None:
                return None, ""
                
            if mode == 'self' and args:
                # 从第一个参数(self)中获取logger属性
                self = args[0]
                if hasattr(self, 'logger'):
                    # print("Get logger from self.logger")
                    if hasattr(self, 'pre_log_msg'):
                        return self.logger, self.pre_log_msg
                    else:
                        return self.logger, ""
                # print("No logger found in self")
                return None, ""
                
            if mode == 'param':
                # 从函数签名获取参数
                sig = inspect.signature(func)
                parameters = list(sig.parameters.keys())
                
                logger_instance, pre_log = None, ''
                # 检查位置参数
                for i, param_name in enumerate(parameters):
                    if param_name == 'logger' and i < len(args):
                        logger_instance = args[i]
                    if param_name == 'pre_log_msg' and i < len(args):
                        pre_log = args[i]
                    if param_name == 'trace_id' and i < len(args):
                        pre_log = args[i]
                    if logger_instance and pre_log:
                        return logger_instance, pre_log
                
                # 检查关键字参数
                if 'logger' in kwargs:
                    logger_instance = kwargs['logger']
                if 'pre_log_msg' in kwargs:
                    pre_log = kwargs['pre_log_msg']
                if 'trace_id' in kwargs:
                    pre_log = kwargs['trace_id']
                    
                if logger_instance and pre_log:
                    return logger_instance, pre_log
                    
            return None, ""
        
        def _log_execution_time(func_name: str, execution_time: float, logger: Optional['loguru.Logger'],
                                pre_log: str) -> None:
            """打印函数执行时间"""
            message = f"func: {func_name}\texec_time: {execution_time:.6f}"
            
            if logger:
                logger.info(pre_log + message)
            else:
                print(pre_log + message)
        
        # 根据函数类型选择合适的包装器
        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    # 支持两种使用方式：@timeit 或 @timeit(logger_mode='self')
    if func is None:
        return decorator
    return decorator(func)

# 使用示例
if __name__ == "__main__":
    import asyncio
    
    # 创建一个测试用logger
    test_logger = loguru.logger
    
    # 1. 默认模式：参数名为logger
    @timeit
    def func_with_logger_param(n: int, logger=None):
        """默认模式：使用名为logger的参数"""
        total = 0
        for i in range(n):
            total += i
        return total
    
    # 2. None模式：不使用logger
    @timeit(logger_mode=None)
    def func_without_logger(n: int):
        """无logger模式：直接使用print"""
        total = 0
        for i in range(n):
            total += i
        return total
    
    # 3. self模式：从实例方法获取
    class MyClass:
        def __init__(self):
            self.logger = test_logger
        
        @timeit(logger_mode='self')
        def method_with_self_logger(self, n: int):
            """self模式：从self.logger获取"""
            total = 0
            for i in range(n):
                total += i
            return total
        
        @timeit(logger_mode='self')
        async def async_method_with_self_logger(self, n: int):
            """异步self模式"""
            total = 0
            for i in range(n):
                total += i
                if i % 100000 == 0:
                    await asyncio.sleep(0.001)
            return total
    
    # 4. param模式：使用名为logger的参数
    @timeit(logger_mode='param')
    def func_with_last_arg_logger(n: int, logger):
        """param模式：最后一个参数作为logger"""
        total = 0
        for i in range(n):
            total += i
        return total
    
    # 5. 异步函数示例
    @timeit(logger_mode='param')
    async def async_function(n: int, logger=None):
        """异步函数带logger参数"""
        total = 0
        for i in range(n):
            total += i
            if i % 100000 == 0:
                await asyncio.sleep(0.001)
        return total
    
    # 测试各种模式
    print("默认模式：使用logger参数")
    func_with_logger_param(100000)
    print("None模式：不使用logger")
    func_without_logger(100000)
    print("self模式：从实例方法获取logger")
    my_obj = MyClass()
    my_obj.method_with_self_logger(100000)
    print("param模式：使用最后一个参数作为logger")
    func_with_last_arg_logger(100000, test_logger)
    async def main():
        await async_function(100000, logger=test_logger)
        await my_obj.async_method_with_self_logger(100000)
    
    asyncio.run(main())