"""api相关url及参数"""

# 大模型api
CHATGLM4_9B_URL = "http://glm-4-9b-weibo-search-topic-66cd92c2-66c3188e.weibo.com/v2/models/llm/generate"
QWEN_72B_URL = 'http://llm-yizhuang.multimedia.wml.weibo.com/mm-wb-search/qwen25-72b-instruct-weibo-search-6751297a/v2/models/llm/generate'
STREAM_QWEN_72B_URL = 'http://llm-yizhuang.multimedia.wml.weibo.com/mm-wb-search/qwen25-72b-instruct-weibo-search-674573c4/v2/models/llm/generate_stream'
EMOTION_URL = "http://admin.ai.s.weibo.com/api/llm/analysis_tab.json"
DEEPSEEK_R1_URL = 'http://deepseek-r1-wbsearch.offline.weibo.com/v2/models/llm/generate'
STREAM_DEEPSEEK_R1_URL = 'http://deepseek-r1-wbsearch.offline.weibo.com/v2/models/llm/generate_stream'
DEEPSEEK_AIGC_URL = 'http://i.aigc.weibo.com/completion'
XiaoYi_QWEN3_30B_URL = "http://qwen3-30b-a3b-0512.preview.search.weibo.com/v2/models/llm/generate_stream"
QWEN3_30B_URL = "http://qwen3-30b-a3b-0512.preview.search.weibo.com/v2/models/llm/generate"
DEEPSEEK_DEFAULT_APPKEY = '2165752702'
DEEPSEEK_DEFAULT_MODEL_ID = 'deepseek-r1'
DEEPSEEK_DEFAULT_MODEL_TYPE = 'weibo'
DEEPSEEK_APPKEYS = {
    'dispatch_ds_query': '3516334673',
    'sina_news': '1837282108',
    'sina_news_verification': '1837282108',
    'sina_news_analyze': '1837282108',
    'deepseek_stream_pool': '1237452496',
    'video_Identify_authenticity': '3061639762'
}
DEEPSEEK_MODEL_ID = {
    "deepseek_stream_pool" : "deepseek-r1-online"
}