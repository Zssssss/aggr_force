"""大模型相关api接口"""
import asyncio
import base64
import hashlib
import hmac
import os
import random
import time
import re
import urllib.parse
from hashlib import sha1
from datetime import datetime
import requests
import json

import aiohttp

from api.base_api import BaseApi
from api.config import CHATGLM4_9B_URL, QWEN_72B_URL, STREAM_QWEN_72B_URL, EMOTION_URL, DEEPSEEK_R1_URL, \
    STREAM_DEEPSEEK_R1_URL, DEEPSEEK_DEFAULT_APPKEY, DEEPSEEK_APPKEYS, DEEPSEEK_AIGC_URL, \
    XiaoYi_QWEN3_30B_URL, QWEN3_30B_URL, DEEPSEEK_MODEL_ID, DEEPSEEK_DEFAULT_MODEL_ID, DEEPSEEK_DEFAULT_MODEL_TYPE
from plugins.function.tool_call_parser import ToolCallParser
from plugins.function.tools import tools
from plugins.llm.utils import get_abtest


def md5_hash(query):
    return hashlib.md5(query.encode()).hexdigest()


def get_bucket_id(md5_str, bucket_num=100):
    # 方法1：将MD5字符串转换为整数后取模
    hash_int = int(md5_str, 16)
    return hash_int % bucket_num


def token_loader(token_file):
    def read_token():
        try:
            with open(token_file, "r") as f:
                return f.readline().strip()
        except FileNotFoundError:
            print(f"token 文件不存在")
            return ""  # 处理文件不存在的情况
        except Exception as e:
            print(f"读取 token 文件出错: {e}")
            return ""

    token_update_time_sec = int(os.path.getmtime(token_file))
    token = read_token()

    def wrapper():
        nonlocal token
        nonlocal token_update_time_sec
        now_sec = int(time.time())
        if now_sec - token_update_time_sec > 3600:
            new_token = read_token()
            if new_token:
                token = new_token
                token_update_time_sec = now_sec
        return token

    return wrapper


load_tauth_token = token_loader(
    r'/data1/minisearch/upload/token/tauth_token_file')


def get_tauth_token(uid):
    token_str = load_tauth_token()
    token_obj = json.loads(token_str)
    tauth_token = token_obj['tauth_token']
    tauth_token_secret = token_obj['tauth_token_secret']
    param = f"uid={uid}"
    sign_hmac = hmac.new(tauth_token_secret.encode(),
                         param.encode(), hashlib.sha1).digest()
    sign_base64 = base64.b64encode(sign_hmac).decode()
    sign = urllib.parse.urlencode({"sign": sign_base64})[5:]
    return {
        r'Authorization': f'TAuth2 token="{urllib.parse.quote(tauth_token)}", param="{urllib.parse.quote(param)}", sign="{sign}"',
        "Content-Type": "application/json"
    }


def count_tokens(weibo, response, model, begin, llm_stage="", first_stream=None):
    if not response:
        return
    query = weibo.get("query", "")
    traceid = weibo.get("version", "")
    input_token = response.get("prompt_tokens", 0)
    output_token = response.get("completion_tokens", 0)
    json_data = {
        "query": query,
        "version": traceid,
        "data_type": "zs_call_model",
        "llm_stage": llm_stage,
        "prompt_tokens": input_token,
        "completion_tokens": output_token,
        "model_type": model,
        "in_time_ms": begin,
        "end_process": time.time(),
    }
    if first_stream:
        json_data["first_answer"] = first_stream
    weibo["llm_trace_info"].append(json_data)
    return json_data


class ModelApi(BaseApi):
    """大模型相关api接口"""

    @staticmethod
    async def async_process_res(res):
        """返回数据处理，便于打印信息，此类为json格式返回"""
        return await res.json()

    async def async_chatglm4_9b_api(self, prompt, max_tokens=50, timeout=2, retry=1):
        """chatglm4_9b_api"""
        url = CHATGLM4_9B_URL
        datas = {
            "temperature": "0.1",
            "max_tokens": max_tokens,
            "repetition_penalty": "1.15",
            "messages": ["user", prompt]
        }
        api_name = "CHATGLM4_9B"
        return await self.async_post(url, api_name, datas, timeout=timeout, retry=retry)


class ModelGlm4Wrapper(ModelApi):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage

    async def async_chatglm4_9b_api(self, prompt, max_tokens=50, timeout=2, retry=1):
        begin = time.time()
        result = await super().async_chatglm4_9b_api(prompt, max_tokens,timeout, retry)
        if result:
            json_data = count_tokens(self.weibo, result, "chatglm4", begin, self.llm_call_stage)
            self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
        return result


class ModelQwen(BaseApi):

    @staticmethod
    def process_res(res):
        """返回数据处理，便于打印信息，此类为json格式返回"""
        return res.json()

    def call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        """chatglm4_9b_api"""
        url = QWEN_72B_URL
        datas = {
            "temperature": temperature,
            "max_tokens": 2000,
            "rid": "31000",
            "repetition_penalty": 1.15,
            "model": "qwen15-72b-chat",
            "messages": ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt]
        }
        if schema_index is not None:
            datas.update({"schema_idx": schema_index})

        api_name = "QWEN_72B"
        return self.post(url, api_name, datas, timeout=timeout, retry=retry)

    async def async_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        """chatglm4_9b_api"""
        url = QWEN_72B_URL
        datas = {
            "temperature": temperature,
            "max_tokens": 2000,
            "rid": "31000",
            "repetition_penalty": 1.15,
            "model": "qwen15-72b-chat",
            "messages": ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt]
        }
        if schema_index is not None:
            datas.update({"schema_idx": schema_index})

        api_name = "QWEN_72B"
        return await self.async_post(url, api_name, datas, timeout=timeout, retry=retry)

    def stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        """stream_qwen_72b_api"""
        url = STREAM_QWEN_72B_URL
        datas = {
            "temperature": temperature,
            "stream": True,
            "max_tokens": 2000,
            "rid": "31000",
            "repetition_penalty": 1.2,
            "model": "qwen15-72b-chat",
            "messages": ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt]
        }
        api_name = "STREAM_QWEN_72B"
        return self.stream_post(url, api_name, datas, timeout=timeout, retry=retry)

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        """stream_qwen_72b_api"""
        url = STREAM_QWEN_72B_URL
        datas = {
            "temperature": temperature,
            "stream": True,
            "max_tokens": 2000,
            "rid": "31000",
            "repetition_penalty": 1.2,
            "model": "qwen15-72b-chat",
            "messages": ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt]
        }
        api_name = "STREAM_QWEN_72B"
        return self.async_stream_post(url, api_name, datas, timeout=timeout, retry=retry)


class ModelQwenWrapper(ModelQwen):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage

    async def async_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        begin = time.time()
        result = await super().async_call(prompt, schema_index, max_tokens, temperature, timeout, retry)
        if result:
            json_data = count_tokens(self.weibo, result, "qwen72b", begin, self.llm_call_stage)
            self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
        return result

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):

        async def async_stream_call_inner():
            begin = time.time()
            result = None
            first_time = None

            stream_response = await super(ModelQwenWrapper, self).async_stream_call(prompt, schema_index, max_tokens, temperature, timeout, retry)
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                yield result

            if result:
                json_data = count_tokens(self.weibo, result, "qwen72b_stream", begin, self.llm_call_stage, first_time)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")

        return async_stream_call_inner()


class ModelDeepseekWrapper(ModelQwen):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage

    async def async_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1):
        from openai import AsyncOpenAI
        api_name = "DEEPSEEK_R1"
        begin = time.time()
        first_time = None
        async with AsyncOpenAI(base_url="http://10.195.16.12:40000/v1", api_key="EMPTY", timeout=timeout) as client:
            response = await client.chat.completions.create(
                model="default",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=temperature,
                max_tokens=2000,
            )

            content = response.choices[0].message.content
            result = response.usage
            if result:
                data = {'prompt': prompt, 'content': content, 'completion_tokens': result.completion_tokens,
                        'prompt_tokens': result.prompt_tokens, 'text': content}
                self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                json_data = count_tokens(self.weibo, data, "deepseek_r1", begin, self.llm_call_stage, first_time)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                return data
        return None

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1):
        api_name = "DEEPSEEK_R1_STREAM"
        from openai import AsyncOpenAI

        async def async_stream_call_inner():
            begin = time.time()
            first_time = None
            async with AsyncOpenAI(base_url="http://10.195.16.12:40000/v1", api_key="EMPTY", timeout=timeout) as client:
                response = await client.chat.completions.create(
                    model="default",
                    messages=[
                        {"role": "user", "content": prompt}
                    ],
                    temperature=temperature,
                    stream=True,
                    max_tokens=2000,
                    stream_options={"include_usage": True},
                )

                content = ""
                result = None
                async for r in response:
                    if first_time is None:
                        first_time = time.time()

                    result = r.usage
                    if r.choices:
                        token = r.choices[0].delta.content
                        content += token
                        yield {'text': content}

                if result:
                    data = {'prompt': prompt, 'content': content, 'completion_tokens': result.completion_tokens, 'prompt_tokens': result.prompt_tokens, 'text': content}
                    self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                    json_data = count_tokens(self.weibo, data, "deepseek_r1_stream", begin, self.llm_call_stage, first_time)
                    self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")

        return async_stream_call_inner()


class SelfModelDeepseekWrapper(ModelQwen):

    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage

    async def async_func_call(self,prompt_content, schema_index):
        return await self.async_call(prompt_content, schema_index=schema_index)

    async def async_call(self, prompt, schema_index=None, max_tokens=3000, temperature=0.6, timeout=500, retry=1, no_think=False):
        async def async_call_inner(prompt, schema_index=None, max_tokens=3000, temperature=0.6, timeout=None, retry=1):
            url = DEEPSEEK_R1_URL
            datas = {
                "temperature": temperature,
                "max_tokens": max_tokens,
                "rid": "31000",
                "repetition_penalty": 1.15,
                "model": "deepseek_r1",
                "messages": ["user", prompt]
            }
            if no_think:
                datas["messages"].extend(["assistant", "<think></think>"])
            if schema_index is not None:
                datas.update({"schema_idx": schema_index})

            api_name = "deepseek_r1"
            return await self.async_post(url, api_name, datas, timeout=timeout, retry=retry)

        begin = time.time()
        result = await async_call_inner(prompt, schema_index, max_tokens, temperature, timeout, retry)
        if result:
            # 检查think是否有内容，没有的话抛出异常
            ori_text = result.get("text", "")
            if "</think>" not in ori_text:
                raise ValueError("think内容为空")
            # 检查think内容是否有中文，没有的话抛出异常
            ori_think_text = ori_text.split("</think>")[0]
            if not re.search(r"[\u4e00-\u9fa5]", ori_think_text): # 检测中文内容
                raise ValueError("think中文内容为空")
            json_data = count_tokens(self.weibo, result, "deepseek_r1", begin, self.llm_call_stage)
            self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
        return result

    async def async_stream_post2(self, url, api_name, data, headers=None, timeout=None, retry=1):
        """协程发送post请求，并记录日志"""
        prompt = data
        start = time.time()
        if headers is None:
            headers = self.default_headers
        error_info = ""
        error_code = 0
        final_result = None
        content_str = ""
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as session:  # 200
                    async with session.post(url, headers=headers, json=data) as res:
                        error_code = res.status
                        if res.status == 200:
                            data = bytearray()
                            async for chunk in res.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        content_str += dict_text['text']
                                        dict_text["text"] = content_str
                                        final_result = dict_text
                                    next_str = dict_text['text']
                                    if next_str:
                                        yield dict_text
                            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{prompt}\theaders:{headers}\t"
                                                            f"timeout:{timeout}\ttry_times:{i + 1}\tres:{final_result}")
            except Exception as e:
                error_info = str(e)
        self.write_log(write_type="INFO", message=f"api_name:{api_name}\ttry_times:{retry}\t"
                                                   f"cost_time:{time.time() - start}\tjson:{prompt}\theaders:{headers}\t"
                                                   f"timeout:{timeout}\terror_info:{error_info}\tres:{error_code}")

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=500, retry=1, no_think=False):
        async def async_stream_call_inner():
            url = STREAM_DEEPSEEK_R1_URL
            datas = {
                "stream": True,
                # "temperature": temperature,
                # "max_tokens": max_tokens,
                # "rid": "31000",
                # "repetition_penalty": 1.15,
                # "model": "deepseek_r1",
                "messages": ["user", prompt]
            }
            if no_think:
                datas["messages"] = ["assistant", "<think></think>", "user", prompt]
            api_name = "STREAM_DEEPSEEK"
            return self.async_stream_post2(url, api_name, datas, timeout=timeout, retry=retry)

        async def async_stream_call_wrapper():
            begin = time.time()
            result = None
            first_time = None

            stream_response = await async_stream_call_inner()
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                yield result

            if result:
                json_data = count_tokens(self.weibo, result, "deepseek_r1_stream", begin, self.llm_call_stage, first_time)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")

        return async_stream_call_wrapper()


class HuoShanModelDeepseekWrapper(ModelQwen):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage
        self.post_type = "volcengine"

    async def async_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1):
        api_name = "HUO_SHAN_DEEPSEEK_R1"
        self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")

        begin = time.time()
        url = "http://mproxy.search.weibo.com/llm/generate"
        headers = {'Content-Type': 'application/json'}
        model_ext = {
            "messages": [{"role": "user", "content": prompt}]
        }
        data = {
            "payload": {
                "type": 'weibo',
                "model_id": "deepseek-r1",
                "use_ext_first": 1,
                "message": "你好",
                # "model_ext": json.dumps(model_ext, ensure_ascii=False)
                "model_ext": json.dumps(model_ext, ensure_ascii=False)
            },
            "model": "aigc_weibo",
            "sid": "smart_app_zszj"
        }
        response = await self.async_post(url, api_name, data, headers=headers, retry=retry, timeout=timeout)
        if response:
            data = response.get('data', "")
            response_data = json.loads(data)
            result = response_data.get('response_data', {})
            content = result['choices'][0]['message'].get('content', "")
            reasoning_content = result['choices'][0]['message'].get('reasoning_content', "")
            if not reasoning_content or not content:
                self.logger.error(self.pre_log_msg + f"response error: {response}")
                return None

            content = f"<think>\n{reasoning_content}\n</think>\n{content}"
            if content:
                data = {'prompt': prompt, 'content': content, 'completion_tokens': result['usage']["completion_tokens"],
                        'prompt_tokens': result['usage']["prompt_tokens"], 'text': content}
                self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                json_data = count_tokens(self.weibo, data, "deepseek_r1", begin, self.llm_call_stage)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                return data

        self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")
        return None

    async def async_stream_post(self, url, api_name, data, headers=None, timeout=None, retry=1):
        """协程发送post请求，并记录日志"""
        prompt = data
        start = time.time()
        if headers is None:
            headers = self.default_headers

        content_str = ""
        reasoning_content_str = ""
        merge_result = ""
        error_info = ""
        error_code = ""
        final_result = None
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, headers=headers, json=data) as res:
                        error_code = res.status
                        if res.status == 200:
                            data = bytearray()
                            async for chunk in res.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        final_result = dict_text

                                        result = final_result.get('response_data', {})
                                        choices = result.get('choices', [])
                                        if not choices:
                                            final_result = {'prompt': prompt, 'content': merge_result, 'text': merge_result,
                                                            'completion_tokens': result['usage']["completion_tokens"],
                                                            'prompt_tokens': result['usage']["prompt_tokens"]
                                                            }
                                            yield final_result
                                            break

                                        content_str += result['choices'][0].get('delta', {}).get('content', "")
                                        reasoning_content_str += result['choices'][0].get('delta', {}).get('reasoning_content', "")
                                        if not reasoning_content_str:
                                            self.logger.error(self.pre_log_msg + f"response error:{result}")
                                            raise Exception('no think')
                                        elif content_str:
                                            merge_result = f"<think>\n{reasoning_content_str}\n</think>{content_str}"
                                        else:
                                            merge_result = f"<think>\n{reasoning_content_str}"

                                        if result:
                                            usage = result.get('usage', {}) or {}
                                            final_result = {'prompt': prompt, 'content': merge_result, 'text': merge_result,
                                                            'completion_tokens': usage.get("completion_tokens", 0),
                                                            'prompt_tokens': usage.get("prompt_tokens", 0)
                                                            }
                                            yield final_result

                            self.logger.info(
                                self.pre_log_msg + f"api_name:{api_name}\tjson:{prompt}\theaders:{headers}\t"
                                                   f"timeout:{timeout}\ttry_times:{i + 1}\tres:{final_result}")
            except Exception as e:
                error_info = str(e)
        self.write_log(write_type="INFO", message=f"api_name:{api_name}\ttry_times:{retry}\t"
                                                  f"cost_time:{time.time() - start}\tjson:{prompt}\theaders:{headers}\t"
                                                  f"timeout:{timeout}\terror_info:{error_info}\tres:{error_code}")

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1):
        api_name = "HUO_SHAN_DEEPSEEK_R1_STREAM"
        url = "http://mproxy.search.weibo.com/llm/generate_stream"
        headers = {'Content-Type': 'application/json'}
        model_ext = {
            "messages": [{"role": "user", "content": prompt}]
        }
        data = {
            "payload": {
                "type": 'weibo',
                "model_id": "deepseek-r1",
                "use_ext_first": 1,
                "message": "你好",
                # "model_ext": json.dumps(model_ext, ensure_ascii=False)
                "model_ext": json.dumps(model_ext, ensure_ascii=False)
            },
            "model": "aigc_weibo",
            "sid": "smart_app_zszj"
        }

        async def async_stream_call_inner():
            begin = time.time()
            self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
            result = None
            first_time = None

            stream_response = self.async_stream_post(url, api_name, data, headers)
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                yield result

            if result:
                json_data = count_tokens(self.weibo, result, "deepseek_r1_stream", begin, self.llm_call_stage, first_time)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")

            self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")

        return async_stream_call_inner()


class ALiYunModelDeepseekWrapper(HuoShanModelDeepseekWrapper):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        super().__init__(weibo, pid, pre_log_msg, llm_call_stage)
        self.post_type = "dashscope"


class WeiboDeepseekWrapper(BaseApi):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage
        self.llm_name = 'deepseek_r1'

    def make_params(self, prompt, stream=False, no_think=False, system_prompt=''):
        sid = self.weibo.get('sid', "")
        llm_sub_source = self.weibo.get("llm_sub_source", "")
        abtest = get_abtest(self.weibo)
        appkey = DEEPSEEK_APPKEYS.get(sid, DEEPSEEK_DEFAULT_APPKEY)
        model_id = DEEPSEEK_MODEL_ID.get(sid, DEEPSEEK_DEFAULT_MODEL_ID)
        model_type = DEEPSEEK_DEFAULT_MODEL_TYPE

        use_model = self.weibo.get("use_model", "")
        if use_model == 'DeepSeek-V3.1-terminus':
            model_type = 'volcengine'
            model_id = 'DeepSeek-V3.1-terminus'
            self.llm_name = 'deepseek_v3.1'
        elif use_model == 'deepseek-v3.1-terminus':
            model_type = 'weibo'
            model_id = 'deepseek-v3.1-terminus'
            self.llm_name = 'deepseek_v3.1'

        if sid == 'sina_news':
            model_type = 'dashscope'
            model_id = DEEPSEEK_DEFAULT_MODEL_ID

        sub_source = "zszj_app" if not llm_sub_source else llm_sub_source
        sub_source += abtest
        params = {
            "appkey": appkey,
            "type": model_type,
            "model_id": model_id,
            "smart_schedule": 1,
            "message": '你好',
            "use_ext_first": 1,
            # 大家自己调用的时候记得修改一下sub_source, 联系jilin5
            "sub_source": sub_source,
        }
        if stream:
            params.update({"stream": "true"})

        model_ext: dict = {
            "messages": [{"role": "user", "content": prompt}]
        } if not system_prompt else {
            "messages": [{"role": "system", "content": system_prompt},{"role": "user", "content": prompt}]
        }

        if 'terminus' in model_id:
            if no_think:
                model_ext['thinking'] = {'type': 'disabled'}
            else:
                model_ext['thinking'] = {'type': 'enabled'}
        if model_type == 'dashscope':
            model_ext['enable_thinking'] = True

        if no_think and 'terminus' not in model_id:
            model_ext["messages"].append({"role": "assistant", "content": "<think></think>"})

        ext = {
            "model_ext": model_ext
        }

        if model_type == 'dashscope':
            api_ext = {
                "X-DashScope-DataInspection": {
                    "input": "disable",
                    "output": "disable"
                }
            }
            ext["api_ext"] = api_ext

        data = json.dumps(ext, ensure_ascii=False)
        return params, data

    async def async_post2(self, url, api_name, params, data, headers=None, timeout=200, retry=1):
        """协程发送post请求，并记录日志"""
        start = time.time()
        if headers is None:
            headers = self.default_headers
        error_info = ""
        error_code = 0
        response = None
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url=url, params=params, data=data, headers=headers) as r:
                        content_type = r.headers.get('Content-Type', '')
                        error_code = r.status
                        if r.status == 200:
                            if 'application/json' in content_type:
                                res = await r.json()
                            else:
                                res = await r.text()
                                res = json.loads(res)

                            if isinstance(res, dict):
                                model_ext = res.get('request_params', {}).get('model_ext', {})
                                model_ext.pop('messages', None)

                            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{i + 1}\tcost_time:{time.time() - start}\t"
                                        f"json:{data}\theaders:{headers}\ttimeout:{timeout}\tresponse:{res}")
                            return res
                        response = r
            except Exception as e:
                error_info = str(e)
        self.logger.error(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                           f"cost_time:{time.time() - start}\tjson:{data}\theaders:{headers}\t"
                                           f"timeout:{timeout}\terror_info:{error_info}\tresponse:{error_code}\tmsg:{response}")
        return self.default_get_res

    async def async_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1, no_think=False, system_prompt=''):
        begin = time.time()
        api_name = "WEIBO_DEEPSEEK_R1"
        self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
        params, data = self.make_params(prompt, no_think=no_think, system_prompt=system_prompt)
        headers = get_tauth_token(7867080892)
        response = await self.async_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers=headers, retry=retry, timeout=300)
        if response:
            result = response.get('response_data', {})
            choices = result.get('choices', [])
            if not choices:
                self.logger.error(self.pre_log_msg + f"response error: {response}")
                return None

            content = result['choices'][0]['message'].get('content', "")
            reasoning_content = result['choices'][0]['message'].get('reasoning_content', "")
            finish_reason = result['choices'][0].get('finish_reason', "")
            if not content or finish_reason == 'content_filter':
                self.logger.error(self.pre_log_msg + f"response error: {response}")
                self.weibo['finish_reason'] = finish_reason
                return None
            if not no_think and not reasoning_content:
                self.logger.error(self.pre_log_msg + f"response no reasoning error: {response}")
                self.weibo['finish_reason'] = finish_reason
                return None
            if reasoning_content:
                content = f"<think>\n{reasoning_content}\n</think>\n{content}"
            if content:
                data = {'prompt': prompt, 'completion_tokens': result['usage']["completion_tokens"],
                        'prompt_tokens': result['usage']["prompt_tokens"], 'text': content}
                # self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                json_data = count_tokens(self.weibo, data, self.llm_name, begin, self.llm_call_stage)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                return data

        self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")
        return None

    async def async_func_call(self,prompt_content, schema_index):
        begin = time.time()
        api_name = "WEIBO_DEEPSEEK_R1"
        headers = get_tauth_token(7867080892)
        params, data = self.make_params(prompt_content)
        data = json.loads(data)
        messages = [
            {"role" : "system",
             "content" : """评估参考结果中是否含有足够信息进行博文分析，如果信息不足调用工具获取更多相关参考结果。"""},
            {"role" : "user", "content" : prompt_content + "\n评估参考结果中是否含有足够信息进行博文分析，如果信息不足调用工具获取更多信息。可用的工具有：weibo_search。按照要求的格式输出工具调用内容。"}
        ]
        data["model_ext"]["messages"] = messages
        data["model_ext"]["tools"] = tools
        data = json.dumps(data,ensure_ascii=False)
        response = await self.async_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers=headers,
                                              retry=1, timeout=300)
        if response:
            result = response.get('response_data', {})
            choices = result.get('choices', [])
            if not choices:
                self.logger.error(self.pre_log_msg + f"response error: {response}")
                return None

            message_data = result['choices'][0].get('message', {})
            content = message_data.get('content', "")
            reasoning_content = message_data.get('reasoning_content', "")
            finish_reason = result['choices'][0].get('finish_reason', "")
            tool_calls = message_data.get('tool_calls', [])
            tool_dict = {}
            for tool_call in tool_calls:
                function_name = tool_call.get('function', {}).get('name', "")
                try:
                    function_args = json.loads(tool_call.get('function', {}).get('arguments', "{}"))
                except json.JSONDecodeError as e:
                    self.logger.error(self.pre_log_msg + f"tool_call error: {e}")
                    function_args = {}
                tool_dict[function_name] = function_args
            content = message_data.get('content', "")
            if not reasoning_content or not content or finish_reason == 'content_filter':
                self.logger.error(self.pre_log_msg + f"response error: {response}")
                self.weibo['finish_reason'] = finish_reason
                return None

            content = f"<think>\n{reasoning_content}\n</think>\n{content}"
            if content:
                data = {'prompt': prompt_content, 'completion_tokens': result['usage']["completion_tokens"],
                        'prompt_tokens': result['usage']["prompt_tokens"], 'text': content, "tool_dict": tool_dict}
                # self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                json_data = count_tokens(self.weibo, data, self.llm_name, begin, self.llm_call_stage)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                return data

        self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")
        return None

    async def async_func_call_new(self,prompt_content, system_prompt):
        begin = time.time()
        api_name = "WEIBO_DEEPSEEK_R1"
        headers = get_tauth_token(7867080892)
        params, data = self.make_params(prompt_content, no_think=False, system_prompt=system_prompt)
        response = await self.async_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers=headers,
                                              retry=1, timeout=300)
        if response:
            result = response.get('response_data', {})
            choices = result.get('choices', [])
            if not choices:
                self.logger.error(self.pre_log_msg + f"response error: {response}")
                return None

            message_data = result['choices'][0].get('message', {})
            content = message_data.get('content', "")
            reasoning_content = message_data.get('reasoning_content', "")
            finish_reason = result['choices'][0].get('finish_reason', "")
            parser = ToolCallParser.markdown_style()
            tool_calls = parser.parse(content).tool_calls
            tool_dict = {}
            if tool_calls:
                for tool_call in tool_calls:
                    function_name = tool_call.name
                    try:
                        function_args = tool_call.arguments
                    except json.JSONDecodeError as e:
                        self.logger.error(self.pre_log_msg + f"tool_call error: {e}")
                        function_args = {}
                    tool_dict[function_name] = function_args
            if not reasoning_content or not content or finish_reason == 'content_filter':
                self.logger.error(self.pre_log_msg + f"response error: {response}")
                self.weibo['finish_reason'] = finish_reason
                return None

            content = f"<think>\n{reasoning_content}\n</think>\n{content}"
            if content:
                data = {'prompt': prompt_content, 'completion_tokens': result['usage']["completion_tokens"],
                        'prompt_tokens': result['usage']["prompt_tokens"], 'text': content, "tool_dict": tool_dict}
                # self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                json_data = count_tokens(self.weibo, data, self.llm_name, begin, self.llm_call_stage)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                return data

        self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")
        return None

    async def async_stream_post2(self, url, api_name, params, data, headers=None, timeout=None, retry=2):
        """协程发送post请求，并记录日志"""
        prompt = data
        start = time.time()
        if headers is None:
            headers = self.default_headers

        content_str = ""
        reasoning_content_str = ""
        merge_result = ""
        error_info = ""
        error_code = ""
        result = {}
        first_result = None
        final_result = None
        last_dict = {}
        i = 0
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url, headers=headers, params=params, data=prompt) as res:
                        first_result = res
                        error_code = res.status
                        if res.status == 200:
                            data = bytearray()
                            async for chunk in res.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        final_result = dict_text

                                        result = final_result.get('response_data', {})
                                        choices = result.get('choices', [])
                                        if not choices:
                                            final_result = {'prompt': prompt, 'text': merge_result,
                                                            'completion_tokens': result['usage']["completion_tokens"],
                                                            'prompt_tokens': result['usage']["prompt_tokens"]
                                                            }
                                            yield final_result
                                            break

                                        content_str += result['choices'][0].get('delta', {}).get('content', "") or ""
                                        reasoning_content_str += result['choices'][0].get('delta', {}).get('reasoning_content', "") or ""
                                        finish_reason = result['choices'][0].get('finish_reason', "")
                                        if finish_reason == 'content_filter':
                                            self.logger.error(self.pre_log_msg + f"response error:{dict_text}")
                                            self.weibo['finish_reason'] = finish_reason
                                            yield None
                                            break

                                        if not merge_result and not content_str and not reasoning_content_str:
                                            self.logger.warning(self.pre_log_msg + f"first response empty:{dict_text}")
                                            continue

                                        elif content_str:
                                            merge_result = f"<think>\n{reasoning_content_str}\n</think>\n{content_str}"
                                        else:
                                            merge_result = f"<think>\n{reasoning_content_str}"

                                        if result:
                                            usage = result.get('usage', {}) or {}
                                            final_result = {'prompt': prompt, 'text': merge_result,
                                                            'completion_tokens': usage.get("completion_tokens", 0),
                                                            'prompt_tokens': usage.get("prompt_tokens", 0)
                                                            }
                                            yield final_result

                            if data:
                                try:
                                    last_event = data.decode("utf-8")
                                    last_dict = json.loads(last_event)
                                    last_dict.pop('request_params', None)
                                    self.logger.info(self.pre_log_msg + f"处理最终事件: {last_dict}")
                                except json.JSONDecodeError :
                                    self.logger.info(f"无法解析最终数据: {data.decode('utf-8', errors='replace')}")
                                except Exception as e :
                                    self.logger.info(f"处理最终事件失败: {e}")

            except Exception as e:
                error_info = str(e)

            if not result:
                self.logger.error(self.pre_log_msg + f"llm error, result is empty last_dict:{last_dict}\terror_info:{error_info}\terror_code:{error_code}\t")
                continue
            break
        self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{i}\tcost_time:{time.time() - start}\t"
                                            f"json:{prompt}\theaders:{headers}\tparams:{params}\ttimeout:{timeout}\t"
                                            f"error_info:{error_info}\terror_code:{error_code}\t"
                                            f"res:{last_dict}\tfinal:{json.dumps(merge_result,ensure_ascii=False)}")

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1, no_think=False):
        async def async_stream_call_inner():
            begin = time.time()
            api_name = "WEIBO_DEEPSEEK_R1"
            self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
            result = None
            first_time = None
            params, data = self.make_params(prompt, stream=True, no_think=no_think)
            headers = get_tauth_token(7867080892)
            stream_response = self.async_stream_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers)
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                yield result

            if result:
                json_data = count_tokens(self.weibo, result, self.llm_name + "_stream", begin, self.llm_call_stage, first_time)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")

            self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")

        return async_stream_call_inner()

class WeiboDeepseekV31Wrapper(WeiboDeepseekWrapper):

    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        super().__init__(weibo, pid, pre_log_msg, llm_call_stage)
        self.llm_name = 'deepseek_v3.1'

    def make_params(self, prompt, stream=False, no_think=False, system_prompt=''):
        sid = self.weibo.get('sid', "")
        llm_sub_source = self.weibo.get("llm_sub_source", "")
        abtest = get_abtest(self.weibo)
        appkey = DEEPSEEK_APPKEYS.get(sid, DEEPSEEK_DEFAULT_APPKEY)
        model_type = 'weibo'
        model_id = 'deepseek-v3.1-terminus'

        sub_source = "zszj_app" if not llm_sub_source else llm_sub_source
        sub_source += abtest
        params = {
            "appkey": appkey,
            "type": model_type,
            "model_id": model_id,
            "smart_schedule": 1,
            "message": '你好',
            "use_ext_first": 1,
            # 大家自己调用的时候记得修改一下sub_source, 联系jilin5
            "sub_source": sub_source,
        }
        if stream:
            params.update({"stream": "true"})

        model_ext: dict = {
            "messages": [{"role": "user", "content": prompt}]
        } if not system_prompt else {
            "messages": [{"role": "system", "content": system_prompt},{"role": "user", "content": prompt}]
        }

        if 'terminus' in model_id:
            if no_think:
                model_ext['thinking'] = {'type': 'disabled'}
            else:
                model_ext['thinking'] = {'type': 'enabled'}
        if model_type == 'dashscope':
            model_ext['enable_thinking'] = True

        if no_think and 'terminus' not in model_id:
            model_ext["messages"].append({"role": "assistant", "content": "<think></think>"})

        ext = {
            "model_ext": model_ext
        }

        if model_type == 'dashscope':
            api_ext = {
                "X-DashScope-DataInspection": {
                    "input": "disable",
                    "output": "disable"
                }
            }
            ext["api_ext"] = api_ext

        data = json.dumps(ext, ensure_ascii=False)
        return params, data


class ModelEmotion(BaseApi):
    """情感获取api"""

    @staticmethod
    async def async_process_res(res):
        """返回数据处理，便于打印信息，此类为json格式返回"""
        res = await res.text()
        return json.loads(res)

    async def async_call(self, query):
        """情感分析结果协程获取"""
        query = query.strip("#").lower()
        url = EMOTION_URL + f"?query={query}"
        api_name = "EMOTION"
        return await self.async_post(url, api_name, None, retry=3)


class QWEN3_30B_Wrapper(ModelQwen):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        self.llm_call_stage = llm_call_stage
        super().__init__(pid, pre_log_msg)

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        """stream_qwen3_xiaoyi_api"""
        async def async_stream_call_inner():

            url = XiaoYi_QWEN3_30B_URL
            data = {
                "temperature": temperature,
                "stream": True,
                "max_tokens": 2000,
                "id": "123",
                "messages" : ["user", prompt]
            }
            headers = {
                'Content-Type': 'application/json'
            }
            api_name = "STREAM_QWEN3_30B"
            begin = time.time()
            first_time = None
            result = None

            content_text = ""
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                try:
                    async with session.post(url, json=data, headers=headers) as response:
                        if response.status == 200:
                            # 逐块处理流式响应
                            data = bytearray()
                            async for chunk in response.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        result = dict_text
                                        content_text += dict_text['text']
                                        dict_text['text'] = content_text
                                        yield dict_text
                            if result:
                                data = {'prompt': prompt, 'content': content_text, 'completion_tokens': result.get("completion_tokens"),
                                        'prompt_tokens': result.get("prompt_tokens"), 'text': content_text}
                                self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                                json_data = count_tokens(self.weibo, data, "xiaoyi_stream", begin, self.llm_call_stage,
                                                         first_time)
                                self.logger.info(
                                    self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                        else:
                            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\theaders:{headers}\t"
                                                                f"timeout:{timeout}\tresponse:{response}")
                except aiohttp.ClientError as e:
                    self.logger.error(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\theaders:{headers}\t"
                                                            f"timeout:{timeout}\terror:{e}")
        return async_stream_call_inner()

    async def async_call(self, prompt, schema_index=None, max_tokens=3000, temperature=0.6, timeout=500, retry=1, no_think=False):
        async def async_call_inner(prompt, schema_index=None, max_tokens=3000, temperature=0.6, timeout=None, retry=1):
            url = QWEN3_30B_URL
            data = {
                "temperature": temperature,
                "max_tokens": 2000,
                "id": "123",
                "messages": ["user", prompt]
            }
            api_name = "QWEN3_30B"
            return await self.async_post(url, api_name, data, timeout=timeout, retry=retry)

        begin = time.time()
        result = await async_call_inner(prompt, schema_index, max_tokens, temperature, timeout, retry)
        if result:
            json_data = count_tokens(self.weibo, result, "qwen3-30b", begin, self.llm_call_stage)
            self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
        return result


class QWEN3_30B_XiaoYiWrapper(QWEN3_30B_Wrapper):
    pass


class ZJZWThirdModelWrapper(BaseApi):
    """第三方模型封装"""

    async def async_stream_post2(self, url, api_name, params, data, headers=None, timeout=None, retry=1):
        """协程发送post请求，并记录日志"""
        prompt = json.dumps(data)
        start = time.time()
        if headers is None:
            headers = self.default_headers

        content_str = ""
        error_info = ""
        error_code = ""
        result = {}
        first_result = None
        final_result = None
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url, data=prompt, headers=headers) as res:
                        first_result = res
                        error_code = res.status
                        # print(res)
                        if res.status == 200:
                            data = bytearray()
                            async for chunk in res.content.iter_any():
                                if chunk:
                                    # print(chunk)
                                    data.extend(chunk)
                                    split_symbol = b'\n\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 2:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        if strip_text.startswith("data: "):
                                            strip_text = strip_text[6:]
                                        dict_text = json.loads(strip_text)
                                        final_result = dict_text

                                        
                                        choices = final_result.get('choices', {})
                                        is_available = final_result.get("is_available", True)
                                        content_str += choices.get("message", {}).get("hybridContent", {}).get("commands", {}).get("body", {}).get("text", "")
                                        
                                        final_result = {'text': content_str, "is_available": is_available}
                                        yield final_result
            except Exception as e:
                error_info = str(e)

            if not content_str:
                self.logger.error(self.pre_log_msg + f"llm error, result is empty : {first_result}")
                continue
            break
        self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                                  f"cost_time:{time.time() - start}\tjson:{prompt}\theaders:{headers}\t"
                                                  f"timeout:{timeout}\terror_info:{error_info}\terror_code:{error_code}\t"
                                                  f"res:{result}\tfirst:{first_result}\tfinal:{json.dumps(content_str,ensure_ascii=False)}")


    async def async_stream_call(self, query):
        """高考结果协程获取"""
        api_name = "ZJZW"
        api_url = "https://api-chat.zjzw.cn/third/weibo/v1/chat"
        data = {
            "requestId": "test-id", # 请求ID
            "messages": [ # 输⼊消息
                {
                    "role": "user",
                    "content": query,
                }
            ],
            "stream": True, # true:是流式
            "session": {
                "sessionId": "sessionId-001", # 会话ID
                "attributes": "{\"attribute1\":\"value1\"}" # 临时会话扩展数据
            }
        }
        params = {}
        headers = {
            'Authorization': 'Bearer sbivvf6ent6e7g6pro4qb9azgiwpo15wpaleo39k7htqghz29onf4o3tjb40ku42',
            'Content-Type': 'application/json'
        }
        return self.async_stream_post2(api_url, api_name, params, data, headers=headers, timeout=100)


def get_deepseek_r1_model_from_id(cloud_id: int = 0):
    """获取deepseek-r1模型, 默认商用接口模型"""
    business_clouds = {
        0: WeiboDeepseekWrapper,            # 商用接口
        99: SelfModelDeepseekWrapper,       # 自建新模型
    }
    return business_clouds.get(cloud_id, WeiboDeepseekWrapper)


def get_deepseek_r1_model_from_weibo_sid(sid: str):
    """通过sid属性获取deepseek-r1模型, 默认商用接口模型"""
    # sid为dispatch_dsv_offline时走自建离线新接口
    cloud_id = 99 if sid == "dispatch_dsv_offline" else 0
    return get_deepseek_r1_model_from_id(cloud_id)


class QWEN3_30B_ModelGaoKaoWrapper(ModelQwen):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        self.model_name = "virtuoso-small-v2"
        self.url = "http://10.85.96.165:8080/v1"
        self.stream_url = "http://10.85.96.165:8080/v1"
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        """stream_qwen_72b_api"""
        async def async_stream_call_inner():

            self.weibo['basemodel'] = 'qwen3-30b'
            url = "http://qwen3-30b-a3b-0512.preview.search.weibo.com/v2/models/llm/generate_stream"
            data = {
                "temperature": temperature,
                "stream": True,
                "max_tokens": 2000,
                "id": "123",
                "messages": ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt + "/no_think"]
            }
            headers = {
                'Content-Type': 'application/json'
            }
            api_name = "STREAM_QWEN_72B"
            begin = time.time()
            first_time = None
            result = None

            content_text = ""
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.post(url, json=data, headers=headers) as response:
                        if response.status == 200:
                            # 逐块处理流式响应
                            data = bytearray()
                            async for chunk in response.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        result = dict_text
                                        content_text += dict_text['text']
                                        dict_text['text'] = content_text
                                        yield dict_text
                            if result:
                                data = {'prompt': prompt, 'content': content_text, 'completion_tokens': result.get("completion_tokens"),
                                        'prompt_tokens': result.get("prompt_tokens"), 'text': content_text}
                                self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                                json_data = count_tokens(self.weibo, data, "qwen3-30b_stream", begin, self.llm_call_stage,
                                                         first_time)
                                self.logger.info(
                                    self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                        else:
                            print(f"Request failed with status code: {response.status}")
                except aiohttp.ClientError as e:
                    print(f"An error occurred during the request: {e}")
        return async_stream_call_inner()

    async def async_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
        api_name = "qwen3-30b"
        async def async_call_inner(prompt, schema_index=None, max_tokens=2000, temperature=0.1, timeout=200, retry=1):
            url = "http://qwen3-30b-a3b-0512.preview.search.weibo.com/v2/models/llm/generate"
            datas = {
                "temperature": temperature,
                "stream": False,
                "max_tokens": 2000,
                "id": "123",
                "messages": ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt + "/no_think"]
            }
            if schema_index is not None:
                datas.update({"schema_idx": schema_index})

            return await self.async_post(url, api_name, datas, timeout=timeout, retry=retry)

        begin = time.time()
        result = await async_call_inner(prompt, schema_index, max_tokens, temperature, timeout, retry)
        if result:
            content_text = result.get("text", "")
            data = {'prompt': prompt, 'content': content_text, 'completion_tokens': result.get("completion_tokens"),
                    'prompt_tokens': result.get("prompt_tokens"), 'text': content_text}
            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
            json_data = count_tokens(self.weibo, data, "qwen3-30b", begin, self.llm_call_stage)
            self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
        return result


class GaoKaoIntentionWrapper(QWEN3_30B_ModelGaoKaoWrapper):
    """高考志愿模型封装"""

    async def async_call(self, prompt):
        """高考志愿结果协程获取"""
        result = await super().async_call(prompt)
        return result
    
class Mid2QueryModifyWrapper(QWEN3_30B_ModelGaoKaoWrapper):

    async def async_call(self, user_prompt='', system_prompt='', retry=3) -> dict:
        api_name = "qwen3-30b"
        url = "http://qwen3-30b-a3b-0512.preview.search.weibo.com/v2/models/llm/generate"
        datas = {
            "temperature": 0.1,
            "stream": False,
            "max_tokens": 2000,
            "id": "123",
            "messages": ["system", system_prompt, "user", user_prompt + "/no_think"]
        }

        begin = time.time()
        result = await self.async_post(url, api_name, datas, timeout=200, retry=retry)
        if result:
            content_text = result.get("text", "")
            data = {'prompt': system_prompt + user_prompt, 'content': content_text, 'completion_tokens': result.get("completion_tokens"),
                    'prompt_tokens': result.get("prompt_tokens"), 'text': content_text}
            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
            json_data = count_tokens(self.weibo, data, "mid2querymodify", begin, self.llm_call_stage)
            self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
            return result
        else:
            return {}

class UsersShowBatchWrapper(BaseApi):

    def group_list(self, text_list, batch_size=50):
        """
        按 batch_size 个元素分组，每组用英文逗号分隔
        :param text_list: 只有文本元素的列表
        :param batch_size: 每组大小，默认50
        :return: 分组后的字符串列表
        """
        n = len(text_list)
        num_groups = (n - 1) // batch_size + 1  # 计算需要的组数
        base_size = n // num_groups
        remainder = n % num_groups

        grouped = []
        start = 0
        for i in range(num_groups):
            size = base_size + (1 if i < remainder else 0)
            group = text_list[start:start + size]
            grouped.append(",".join(group))
            start += size
        return grouped

    @staticmethod
    async def async_process_res(res):
        """返回数据处理，便于打印信息，默认打印文本"""
        data = await res.json()
        users = data.get("users", [])
        result = {}
        for u in users:
            user_name = u.get("screen_name", "")
            uid = u.get("id", "")
            if uid and user_name:
                result[user_name] = {"uid": uid}
        return result

    async def async_call(self, user_name_list):
        url = "http://i2.api.weibo.com/users/show_batch.json"
        headers = get_tauth_token(7867080892)
        # 只有用户昵称，没有用户id
        user_name_list = list(set(user_name_list))
        grouped_user_name = self.group_list(user_name_list)
        api_name = "Get-Users-Show-Batch"
        tasks = []
        for group in grouped_user_name:
            params = {
                "trim_status": 1,
                "screen_name": group
            }
            task = asyncio.create_task(self.async_get(url, api_name, params=params, headers=headers, timeout=1))
            tasks.append(task)
        res_list = await asyncio.gather(*tasks)
        result = {}
        for res in res_list:
            if res:
                result.update(res)
        return result
class QWEN3_235B_ModelWrapper(BaseApi):
    """
    copied from first_page_online[preview]
    """
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage="", is_yulan=False):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage
        self.is_yulan = is_yulan

    def make_params(self, prompt, stream=False, sys_prompt="", enable_thinking=False):
        params = {
            "appkey": "2165752702",
            "type": "dashscope",
            "model_id": 'qwen-turbo',
            "smart_schedule": 1,
            "message": '你好',
            "use_ext_first": 1,

        }
        if stream:
            params.update({"stream": "true"})
        
        messages = [{"role": "user", "content": prompt}] if not sys_prompt \
            else [{"role": "system", "content": sys_prompt}, {"role": "user", "content": prompt}]

        model_ext = {
            "input": {
                "messages": messages,
            },
            "parameters": {
                'enable_thinking': enable_thinking,
                "result_format": "message",
                "incremental_output": stream
            }
        }
        api_ext = {
            "X-DashScope-DataInspection": {
                "input": "disable",
                "output": "disable"
            }
        }
        data = json.dumps({
            "model_ext": model_ext,
            "api_ext": api_ext
        }, ensure_ascii=False)

        return params, data

    async def async_post2(self, url, api_name, params, data, headers=None, timeout=200, retry=1):
        """协程发送post请求，并记录日志"""
        start = time.time()
        if headers is None:
            headers = self.default_headers
        error_info = ""
        error_code = 0
        response = None
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url=url, params=params, data=data, headers=headers) as r:
                        content_type = r.headers.get('Content-Type', '')
                        error_code = r.status
                        if r.status == 200:
                            if 'application/json' in content_type:
                                res = await r.json()
                            else:
                                res = await r.text()
                                res = json.loads(res)

                            if isinstance(res, dict):
                                model_ext = res.get('request_params', {}).get('model_ext', {})
                                model_ext.pop('messages', None)

                            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{i + 1}\tcost_time:{time.time() - start}\t"
                                        f"json:{data}\theaders:{headers}\ttimeout:{timeout}\tresponse:{res}")
                            return res
                        response = r
            except Exception as e:
                error_info = str(e)
        self.logger.error(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                           f"cost_time:{time.time() - start}\tjson:{data}\theaders:{headers}\t"
                                           f"timeout:{timeout}\terror_info:{error_info}\tresponse:{error_code}\tmsg:{response}")
        return self.default_get_res

    async def async_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200, retry=1, sys_prompt="", enable_thinking=False):
        begin = time.time()
        api_name = "WEIBO_DEEPSEEK_R1"
        self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
        params, data = self.make_params(prompt, sys_prompt=sys_prompt, enable_thinking=enable_thinking)
        headers = get_tauth_token(7867080892)
        response = await self.async_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers=headers, retry=retry, timeout=300)
        if response:
            result = response.get('response_data', {})
            choices = result.get('output', {}).get('choices', [])
            if not choices:
                self.logger.error(self.pre_log_msg + f"response error no choices: {response}")
                return None

            content = choices[0]['message'].get('content', "")

            # content = f"<think>\n{reasoning_content}\n</think>\n{content}"
            if content:
                data = {'prompt': prompt, 'completion_tokens': result.get('usage', {}).get('output_tokens', 0),
                        'prompt_tokens': result.get('usage', {}).get('input_tokens', 0), 'text': content}
                # self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                json_data = count_tokens(self.weibo, data, "qwen-turbo", begin, self.llm_call_stage)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                return data

        self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")
        return None

    async def async_stream_post2(self, url, api_name, params, data, headers=None, timeout=None, retry=2):
        start = time.time()
        prompt = data
        content_str = ""
        reasoning_content_str = ""
        final_result = None
        error_info = ""
        result = ""
        merge_result = ""
        first_result = None
        error_code = 0
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url, headers=headers, params=params, data=prompt) as res:
                        first_result = res
                        error_code = res.status
                        if res.status == 200:
                            data = bytearray()
                            async for chunk in res.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        final_result = dict_text

                                        result = final_result.get('response_data', {})
                                        choices = result.get('output').get("choices", [])
                                        content_str += choices[0].get('message', {}).get('content', "") or ""
                                        reasoning_content_str += choices[0].get('message', {}).get('reasoning_content',
                                                                                                   "") or ""
                                        if content_str:
                                            merge_result = f"<think>\n{reasoning_content_str}\n</think>\n{content_str}"
                                        else:
                                            merge_result = f"<think>\n{reasoning_content_str}"
                                        if result:
                                            usage = result.get('usage', {}) or {}
                                            yield {
                                                'prompt': prompt, 'text': merge_result,
                                                'completion_tokens': usage.get("output_tokens", 0),
                                                'prompt_tokens': usage.get("input_tokens", 0)
                                            }
                            if data:
                                try:
                                    last_event = data.decode("utf-8")
                                    last_dict = json.loads(last_event)
                                    self.logger.info(self.pre_log_msg + f"处理最终事件: {last_dict}")
                                    real_type = last_dict.get('real_type', "")
                                except json.JSONDecodeError:
                                    self.logger.info(f"无法解析最终数据: {data.decode('utf-8', errors='replace')}")
                                except Exception as e:
                                    self.logger.info(f"处理最终事件失败: {e}")


            except Exception as e:
                error_info = str(e)
            if not result:
                self.logger.error(self.pre_log_msg + f"llm error, result is empty : {first_result}")
                continue
            break
        self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                            f"cost_time:{time.time() - start}\tjson:{prompt}\theaders:{headers}\t"
                                            f"timeout:{timeout}\terror_info:{error_info}\terror_code:{error_code}\t"
                                            f"res:{result}\tfirst:{first_result}\tfinal:{json.dumps(merge_result, ensure_ascii=False)}")

    async def async_stream_call(self, prompt, schema_index=None, max_tokens=2000, temperature=0.6, timeout=200,
                                retry=1, sys_prompt="", enable_thinking=False):
        async def async_stream_call_inner():
            begin = time.time()
            api_name = "qwen3-235b-a22b"
            self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
            result = None
            first_time = None
            params, data = self.make_params(prompt, stream=True, sys_prompt=sys_prompt, enable_thinking=enable_thinking)
            headers = get_tauth_token(7867080892)
            stream_response = self.async_stream_post2(DEEPSEEK_AIGC_URL, api_name, params, data, headers)
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                yield result

            if result:
                json_data = count_tokens(self.weibo, result, "qwen-turbo", begin, self.llm_call_stage,
                                         first_time)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")

            self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")

        return async_stream_call_inner()
class ModelPicWrapper(ModelQwen):
    def __init__(self, weibo, pid, pre_log_msg, llm_call_stage=""):
        self.weibo = weibo
        super().__init__(pid, pre_log_msg)
        self.llm_call_stage = llm_call_stage


    async def async_post2(self, url, api_name, params, data, headers=None, timeout=200, retry=1):
        """协程发送post请求，并记录日志"""
        start = time.time()
        if headers is None:
            headers = self.default_headers
        error_info = ""
        error_code = 0
        response = None
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url=url, params=params, data=data, headers=headers) as r:
                        content_type = r.headers.get('Content-Type', '')
                        error_code = r.status
                        if r.status == 200:
                            if 'application/json' in content_type:
                                res = await r.json()
                            else:
                                res = await r.text()
                                res = json.loads(res)

                            if isinstance(res, dict):
                                model_ext = res.get('request_params', {}).get('model_ext', {})
                                model_ext.pop('messages', None)

                            self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{i + 1}\tcost_time:{time.time() - start}\t"
                                        f"json:{data}\theaders:{headers}\ttimeout:{timeout}\tresponse:{res}")
                            return res
                        response = r
            except Exception as e:
                error_info = str(e)
        self.logger.error(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                           f"cost_time:{time.time() - start}\tjson:{data}\theaders:{headers}\t"
                                           f"timeout:{timeout}\terror_info:{error_info}\tresponse:{error_code}\tmsg:{response}")
        return self.default_get_res

    async def async_call(self, prompt, img_list=[]):
        
        url = 'http://i.aigc.weibo.com/completion'
        headers = get_tauth_token(7867080892)
        DEFAULT_APPKEY = '2165752702'
        params = {'message': '你好', 'appkey': DEFAULT_APPKEY, 'type': 'dashscope', 'use_ext_first': '1', 'model_id':'qwen-vl-max'}
        content = [{"text": prompt}]
        for u in img_list:
            content.append({"image": u})
        payload = json.dumps(
            {
                "api_ext": {
                    "request_compatible_mode": "dashscope"
                },
                "model_ext": {
                    "model": "qwen-vl-max",
                    "input": {
                        "messages": [
                            {
                                "role": "user",
                                "content": content,
                            }
                        ]
                    },
                    "parameters": {
                        "result_format":"message"
                    }
                }
        })
  
        begin = time.time()
        api_name = "WEIBO_DEEPSEEK_R1"
        self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
        # params, data = self.make_params(prompt, sys_prompt=sys_prompt, enable_thinking=enable_thinking)
        
        response = await self.async_post2(url, api_name, params, payload, headers=headers, retry=1, timeout=5000)
        if response:
            result = response.get('response_data', {})
            choices = result.get('output', {}).get('choices', [])
            if not choices:
                self.logger.error(self.pre_log_msg + f"response error no choices: {response}")
                return None

            content = choices[0]['message'].get('content', [{}])

            if content and isinstance(content, list):
                data = {'prompt': prompt, 'completion_tokens': result.get('usage', {}).get('output_tokens', 0),
                        'prompt_tokens': result.get('usage', {}).get('input_tokens', 0), 'text': content[0].get('text', "")}
                # self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
                json_data = count_tokens(self.weibo, data, "qwen-vl-max", begin, self.llm_call_stage)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
                return data

        self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")
        return None
    
    async def async_stream_post2(self, url, api_name, params, data, headers=None, timeout=None, retry=2):
        """协程发送post请求，并记录日志"""
        prompt = data
        start = time.time()
        if headers is None:
            headers = self.default_headers

        content_str = ""
        reasoning_content_str = ""
        merge_result = ""
        error_info = ""
        error_code = ""
        result = {}
        first_result = None
        final_result = None
        for i in range(int(retry)):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(timeout)) as session:
                    async with session.post(url, headers=headers, params=params, data=prompt) as res:
                        first_result = res
                        error_code = res.status
                        if res.status == 200:
                            data = bytearray()
                            async for chunk in res.content.iter_any():
                                if chunk:
                                    data.extend(chunk)
                                    split_symbol = b'\n\n'
                                    while split_symbol in data:
                                        index = data.find(split_symbol)
                                        split = data[0:index + 1]
                                        data = data[index + 1:]
                                        content = split.decode("utf-8")
                                        strip_text = content[:len(content) - 1]
                                        dict_text = json.loads(strip_text)
                                        final_result = dict_text

                                        result = final_result.get('response_data', {}).get("output", {})
                                        choices = result.get('choices', [])
                                        if not choices:
                                            final_result = {'prompt': prompt, 'text': content_str,
                                                            'completion_tokens': result['usage'].get("output_tokens", 0),
                                                            'prompt_tokens': result['usage'].get("input_tokens", 0)
                                                            }
                                            yield final_result
                                            break

                                        content_list = result['choices'][0].get('message', {}).get('content', [])
                                        if content_list:
                                            content_str = content_list[0].get("text")
                                        # reasoning_content_str += result['choices'][0].get('delta', {}).get('reasoning_content', "") or ""
                                        # finish_reason = result['choices'][0].get('finish_reason', "")
                                        # if finish_reason == 'content_filter':
                                        #     self.logger.error(self.pre_log_msg + f"response error:{dict_text}")
                                        #     self.weibo['finish_reason'] = finish_reason
                                        #     yield None
                                        #     break

                                        # elif content_str:
                                        #     merge_result = f"<think>\n{reasoning_content_str}\n</think>\n{content_str}"
                                        # else:
                                        #     merge_result = f"<think>\n{reasoning_content_str}"

                                        if result:
                                            usage = final_result.get("response_data", {}).get("usage", {})
                                            final_result = {'prompt': prompt, 'text': content_str,
                                                            'completion_tokens': usage.get("output_tokens", 0),
                                                            'prompt_tokens': usage.get("input_tokens", 0)
                                                            }
                                            yield final_result

                            if data:
                                try:
                                    last_event = data.decode("utf-8")
                                    last_dict = json.loads(last_event)
                                    last_dict.pop('request_params', None)
                                    self.logger.info(self.pre_log_msg + f"处理最终事件: {last_dict}")
                                except json.JSONDecodeError :
                                    self.logger.info(f"无法解析最终数据: {data.decode('utf-8', errors='replace')}")
                                except Exception as e :
                                    self.logger.info(f"处理最终事件失败: {e}")

            except Exception as e:
                error_info = str(e)

            if not result:
                self.logger.error(self.pre_log_msg + f"llm error, result is empty : {first_result}")
                continue
            break
        self.logger.info(self.pre_log_msg + f"api_name:{api_name}\ttry_times:{retry}\t"
                                                  f"cost_time:{time.time() - start}\tjson:{prompt}\theaders:{headers}\t"
                                                  f"timeout:{timeout}\terror_info:{error_info}\terror_code:{error_code}\t"
                                                  f"res:{result}\tfirst:{first_result}\tfinal:{json.dumps(merge_result,ensure_ascii=False)}")
        
    async def async_stream_call(self, prompt, img_list=[]):
        async def async_stream_call_inner():
            begin = time.time()
            api_name = "WEIBO_DEEPSEEK_R1"
            self.logger.info(self.pre_log_msg + f"api_name:{api_name} begin")
            result = None
            DEFAULT_APPKEY = '2165752702'
            first_time = None
            # params, data = self.make_params(prompt, stream=True, no_think=no_think)
            params = {'message': '你好', 'appkey': DEFAULT_APPKEY, 'type': 'dashscope', 'use_ext_first': '1', 'model_id':'qwen-vl-max', 'stream': 'true'}
            content = [{"text": prompt}]
            for u in img_list:
                content.append({"image": u})
            payload = json.dumps(
                    {
                        "api_ext": {
                            "request_compatible_mode": "dashscope"
                        },
                        "model_ext": {
                            "model": "qwen-vl-max",
                            "input": {
                                "messages": [
                                    {
                                        "role": "user",
                                        "content": content,
                                    }
                                ]
                            },
                            "parameters": {
                                "result_format":"message"
                            }
                        }
                })
  
            headers = get_tauth_token(7867080892)
            stream_response = self.async_stream_post2(DEEPSEEK_AIGC_URL, api_name, params, payload, headers)
            async for response in stream_response:
                if first_time is None:
                    first_time = time.time()
                result = response
                # print("stream_result: ", result)
                yield result

            if result:
                json_data = count_tokens(self.weibo, result, "deepseek_r1_stream", begin, self.llm_call_stage, first_time)
                self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")

            self.logger.info(self.pre_log_msg + f"api_name:{api_name} end")

        return async_stream_call_inner()

    
    # async def async_call(self, prompt, temperature=0.6, timeout=1000, img_list=[]):
    #     def process_content(content):
    #         # todo 解析大模型返回结果
    #         return content
    #     from openai import AsyncOpenAI
    #     content = [{"type": "text", "text": prompt}]
    #     for i in img_list:
    #         content.append({"type": "image_url", "image_url": {"url": await self.image_url_to_base64(i)}})
            
    #     prompt = json.dumps(content)
    #     async with AsyncOpenAI(base_url="http://llm-beixian.multimedia.wml.weibo.com/mm-wb-search/gemma-3-12b-it-weibo-search-zc-68a82dac/v2/models/llm", api_key="EMPTY", timeout=timeout) as client:
    #         response = await client.chat.completions.create(
    #             model="default",
    #             messages=[
    #                 {"role": "user", "content": prompt}
    #             ],
    #             temperature=temperature,
    #             max_tokens=2000,
    #         )

    #         # return content 的 string 
    #         content = response.choices[0].message.content
    #         result = response.usage
    #         if result:
    #             data = {"is_reco": True, "search_words": [], "name": process_content(content)}
    #             # data = {'prompt': prompt, 'content': content, 'completion_tokens': result.completion_tokens,
    #             #         'prompt_tokens': result.prompt_tokens, 'text': content}
    #             # self.logger.info(self.pre_log_msg + f"api_name:{api_name}\tjson:{data}\t")
    #             # json_data = count_tokens(self.weibo, data, "deepseek_r1", begin, self.llm_call_stage, first_time)
    #             # self.logger.info(self.pre_log_msg + f"count_tokens: {json.dumps(json_data, ensure_ascii=False)}")
    #             return data
    #     return None
