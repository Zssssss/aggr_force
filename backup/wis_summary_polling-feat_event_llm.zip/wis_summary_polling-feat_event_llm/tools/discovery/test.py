# -*- coding:utf-8 -*-

import dconf as discovery

sid_handlers_config = discovery.configget("wis_summary_service", "aaa")
print(sid_handlers_config)