import json
import time

import requests


def server_test(query):
    datas = {
        'query': query
    }
    headers = {'Content-Type': 'application/json'}
    start = time.time()
    r = requests.post("http://10.182.19.62:9099/v1/wis_summary", json=datas, headers=headers)
    end = time.time()
    print(r.text)
    print(end - start)
    print(r.status_code)


if __name__ == "__main__":
    for i in range(20):
        data = {'query': '郭富城{}'.format(i), 'trace_id': "12313",  'uid': '', 'llm_name': 'qwen72b', 'version': 'jl0020',  'query_question': '', 'query_category': '', 'ab_test': '0', 'high_level': 7, 'source': '99', 'in_time': 1734710397, 'in_time_ms': 1734710397.987, 'sens_words': '', 'self_account': 0, 'q_attr': '{"new_high_level":7,"async":1,"strategy_source":7,"orifid":"102803_ctg1_1780_-_ctg1_1780$$0","m_top5_status":1,"action_from":3011,"lfid":"100103type=1&t=3","m_top10_status":1,"m_top3_status":1,"m_top5_40diff_status":1,"qwen72b":1,"chatglm4":1,"mtop5_diff_num":2}', 'level2_uid': '1239246050', 'stream_output': 1}
        json_str = json.dumps(data)
        server_test(json_str)
