# -*- coding:utf-8 -*-
import asyncio
import copy
import json
import os
import random
import sys
import datetime
import time
import traceback
from asyncio import Semaphore
from concurrent.futures.thread import ThreadPoolExecutor

import aiohttp
import pymongo
import requests
import uvicorn
from fastapi import FastAPI, Body

from lib.base import Base
from lib.redis_utils import redis_connect
from lib.safe_logger import get_logger
from plugins.llm.llm import LLM
from plugins.llm.stream_llm import StreamLLM
from plugins.llm.whiteboard_llm import WhiteboardLLM, StreamWhiteboardLLM, WhiteboardDeepseekLLM, \
    StreamWhiteboardDeepseekLLM
from whiteboard.wis_summary_server_config import multi_server_config

base_dir = os.path.abspath('.')
llm_model_api_logger_filename = "log/" + "server.log"
logger = get_logger(llm_model_api_logger_filename, 'server', enqueue=True)


app = FastAPI()


class MongoOutput(Base):
    @staticmethod
    def callback_mongo(llm_res, llm_name, label, query, knowledge, content_list, version, prompt):
        # 流式思考态
        if not label:
            return
        mongo_cluster = ['10.2.32.49:27017', '10.2.32.50:27017', '10.2.32.51:27017']
        mongo_db = 'summary_llm_online'
        mongo_collection = 'summary_result_baiban'
        client = pymongo.MongoClient(mongo_cluster)
        db = client[mongo_db]
        mongo_cli = db[mongo_collection]
        if version.endswith('_master'):
            version = version.replace('_master', '')
            data = {"query": query, "llm_name": llm_name, "label": label, "llm_res_master": llm_res, 'prompt_master': prompt}
        else:
            data = {"query": query, "llm_name": llm_name, "label": label, "llm_res": llm_res, "version": version,
                    "knowledge": knowledge, "link_list": content_list, 'prompt': prompt}
        flt = {"query": query, "llm_name": llm_name, "label": label, "version": version}
        mongo_cli.update_one(flt, {"$set": data}, upsert=True)

    async def run(self, **kwargs):
        ready = kwargs.get('ready', "")
        content = kwargs.get('content', "")
        status_stage = kwargs.get('status_stage', "")
        weibo = kwargs.get("weibo", {})
        weibo['result'] = content
        self.weibo = weibo
        llm_res = weibo.get("result", "")
        llm_name = weibo.get("llm_name", "")
        label = weibo.get("label", "")
        knowledge = weibo.get("knowledge", "")
        baike_knowledge = '\n'.join([i.get('content') for i in weibo.get('baike_knowledge', [])])
        query = weibo.get("query", "")
        content_list = json.dumps(weibo.get("link_list", []))
        version = weibo.get("version", "")
        prompt = weibo.get("prompt", "")

        try:
            self.callback_mongo(llm_res, llm_name, label, query, knowledge + "\n" + baike_knowledge, content_list, version, prompt)
        except Exception as e:
            print(e)

        print('ee')


async def server_request(query, url):
    datas = {
        'query': query
    }
    status_code = 0
    headers = {'Content-Type': 'application/json'}
    start = time.time()
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=datas, headers=headers) as r:
            status_code = r.status
    end = time.time()
    logger.info("code:{}, cost:{}".format(status_code, end - start))


async def multi_server(weibo):
    tasks = []
    for name, server in multi_server_config:
        # 删除set
        input_weibo = {k: v for k, v in weibo.items() if not isinstance(v, set)}
        input_weibo['version'] = input_weibo['version'] + "_master"
        input_weibo['whiteboard_branch'] = 'master'
        input_weibo["ready_pid_dict"] = {}
        input_weibo_json = json.dumps(input_weibo)
        tasks.append(server_request(input_weibo_json, server))
    await asyncio.gather(*tasks)


async def main(weibo, pid):
    try:
        output = MongoOutput(pid)
        stream_output = weibo.get('stream_output', 0)
        model = weibo.get('llm_name', "qwen72b")
        if model == 'deepseek':
            llm = WhiteboardDeepseekLLM(weibo, output, pid)
        elif model == 'deepseek_stream':
            llm = StreamWhiteboardDeepseekLLM(weibo, output, pid)
        elif stream_output:
            llm = StreamWhiteboardLLM(weibo, output, pid)
        else:
            llm = WhiteboardLLM(weibo, output, pid)
        await llm.run()
        await multi_server(weibo)
    except Exception as e:
        logger.exception("summary exception: {}, msg: {}".format(e, traceback.format_exc()))

semaphore = Semaphore(50)


@app.post("/v1/wis_summary")
async def wis_response(payload: dict = Body(...)):
    async with semaphore:
        query = payload.get('query')
        weibo = json.loads(query)
        trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
        trace_id = weibo.get("trace_id", trace_id)
        weibo['trace_id'] = trace_id
        weibo['traceid'] = trace_id
        logger.info("query in:{}".format(weibo))
        asyncio.create_task(main(weibo, '888'))
        now = datetime.datetime.now()
        t = now.strftime("%Y-%m-%d %H:%M:%S")
        answer = {
            "status": 200,
            "time": t
        }
        return answer


if __name__ == '__main__':
    uvicorn.run(app='whiteboard.wis_summary_server:app', host='0.0.0.0', port=9099, workers=1)
