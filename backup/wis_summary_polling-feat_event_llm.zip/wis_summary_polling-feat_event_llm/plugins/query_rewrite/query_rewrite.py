"""query改写模块"""
# -*- coding:utf-8 -*-
import socket
import struct
import time
import random
import json
import traceback
import re
from functools import reduce
from lib.base import Base
from api.model_api import ModelApi
from plugins.query_rewrite.prompts import QUERY_REWRITE_PROMPT


class DaRequest:
    """Da请求，socket连接"""

    def __init__(self, host, port):
        self.sock = None
        self.host = host
        self.port = int(port)
        self.connect()
        self.seqid_iter = DaRequest.seqid_generator()

    @staticmethod
    def seqid_generator():
        seqid = random.randint(1, 10000000)
        while True:
            seqid = (seqid + 1) & 0xffffffff
            yield seqid

    @staticmethod
    def microtime():
        tm = time.time()
        now = int(tm * 1000)
        high = now >> 32
        low = now & 0xffffffff
        return low, high

    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.host, self.port))

    def request(self, msgs, logger, pre_log_msg):
        retry = 0
        while retry < 3:
            retry += 1
            try:
                if self.sock is None:
                    self.connect()
                self.send_msg(msgs)
                return self.recv_msg()
            except Exception as e:
                s = traceback.format_exc()
                logger.warning(pre_log_msg + s)
                logger.warning(pre_log_msg + "retry:%d Exception:%s" % (retry, str(e)))
                self.sock = None

        return None

    def send_msg(self, msgs):
        cmd = 2
        cmd_package = reduce(lambda x, y: x + y,
                             map(lambda msg: (struct.pack('II', cmd, len(msg)) + bytes(msg.encode('utf8'))), msgs))
        bodylen = len(cmd_package)
        seqid = next(self.seqid_iter)
        now = self.microtime()
        common_head = struct.pack("IIIIIIII", 2, seqid, 0, bodylen, now[0], now[1], 0xa3b9f14d, 0)
        msg_package = common_head + cmd_package
        ret = self.sock.send(msg_package)
        return ret

    def recv_msg(self):
        response = self.sock.recv(10240)
        if len(response) < 32:
            return []
        version_flag_cbit_pad, seqid, asyn_seqid, bodylen, timestamp0, timestamp1, magic, reserved = struct.unpack(
            "IIIIIIII", response[:32])
        totallen = bodylen + 32
        while len(response) < totallen:
            ret = self.sock.recv(10240)
            # if not ret:
            #    break
            response += ret

        cmd_package = response[32:]
        result = []
        while cmd_package:
            cmd, cmd_len = struct.unpack("II", cmd_package[:8])
            cmd_body_rest = cmd_package[8:]
            cmd_body = cmd_body_rest[:cmd_len]
            result.append(cmd_body)
            cmd_package = cmd_body_rest[cmd_len:]

        return result


class QueryRewrite(Base):
    """query改写的业务实现，可以打印日志"""

    async def run(self, weibo=None):
        """query改写业务逻辑"""
        if not weibo:
            return
        #if weibo.get("stream_output", 0) == 1:
        # 实时流式不需要query改写
        weibo["query_analysis"] = weibo['query']
        weibo["debug"]["query_analysis_get_time"] = time.time()
        return

        func_name = "QUERY_REWRITE"
        start = time.time()
        self.update_pre_log_msg(weibo)
        query = weibo.get("query", "")
        try:
            # 先获取前置及后置词
            words = self.get_query_before_after(query, int(time.time()))
            before_word = words["before"][0].split("_")[0] if words["before"] else ""
            after_word = words["after"][0].split("_")[0] if words["after"] else ""
            content = ""
            content_list = weibo.get("content_list", [])
            for j in range(min(len(content_list), 10)):
                content = content + str(j + 1) + "、" + content_list[j] + "\n"
            if content == "" and before_word == "" and after_word == "":
                res = ""
            else:
                # 调用大模型接口获取结果
                res = await self.query_analysis_v2(query, content, before_word, after_word)
            weibo["query_analysis"] = res
            weibo["debug"]["query_analysis_get_time"] = time.time()
            self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\tbefore_word:{before_word}\t"
                                   f"after_word:{after_word}\tquery_analysis:{res}\t")
            weibo["debug"]["time_analysis"][f"{func_name}_start"] = start
            weibo["debug"]["time_analysis"][f"{func_name}_end"] = time.time()
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")

    def get_query_before_after(self, query, start_time, start=0, num=0, time_length=60):
        """获取前置及后置词"""
        ip = 'subs.search.weibo.com'
        port = 9213
        req = {"type": 8, "search": query, 'start_time': int(start_time), "start": start, "num": num,
               "time_length": int(time_length)}
        req = json.dumps(req)
        res = {"before": [], "after": []}

        try:
            d_r = DaRequest(ip, port)
            response = d_r.request([req], self.logger, self.pre_log_msg)[0]
            result = json.loads(response)
            if result.get("query_ba", []):
                res = self.split_before_after(result["query_ba"][0])  # 只取一天的数据，后续可以扩展
            return res
        except:
            self.write_log(write_type="WARNING", message=f"get session log failed,error trace:{traceback.print_exc()}")
            return res

    @staticmethod
    def split_before_after(q_ba_object):
        """切分前置和后置词"""
        # {"bb38":"0;王俊凯_99;王俊凯偶遇张艺谋_18;王俊凯被陌生男子搂肩_17;王源厦门_11;王俊凯双标现场_8$1;王俊凯瑞士_31;王俊凯_25;王俊凯金鸡奖_23;王俊凯金鸡奖闭幕式_11;王源厦门_10"}
        b_str = ""
        a_str = ""
        ba_list = []
        for k, v in q_ba_object.items():
            ba_dict = {}
            if v[0:2] == "0;":
                ba_arr = v[2:].split("$1;")
                b_str = ba_arr[0]
                if len(ba_arr) > 1:
                    a_str = ba_arr[1]
            else:
                ba_arr = v[2:].split("$0;")
                a_str = ba_arr[0]
                if len(ba_arr) > 1:
                    b_str = ba_arr[1]
            b_arr = b_str.split(";")
            a_arr = a_str.split(";")
            if len(b_arr) > 0:
                b_arr = b_arr[0:min(5, len(b_arr))]
            if len(a_arr) > 0:
                a_arr = a_arr[0:min(5, len(a_arr))]
            ba_dict["before"] = b_arr
            ba_dict["after"] = a_arr
            ba_list.append(ba_dict)
        if ba_list:
            return ba_list[0]  # 只读取一列的数据，后续可以扩展
        return {"before": [], "after": []}

    async def query_analysis_v2(self, query, content, before_word, after_word):
        """通过大模型获取query改写结果"""
        fun_name = "CALL_QUERY_ANALYSIS"
        prompt = QUERY_REWRITE_PROMPT.format(query=query, content=content, prevword=before_word,
                                             nextword=after_word)
        try:
            res = await ModelGlm4Wrapper(weibo, pid, pre_log_msg, func_name).async_chatglm4_9b_api(prompt)

            res = res.get("text", "")
            match = re.search(r'\{(.*?)\}', res, re.DOTALL)
            res_answer = ""
            if match:
                json_str = match.group(1)  # 获取匹配的JSON字符串
                json_dict = json.loads('{' + json_str + '}')  # 将JSON字符串转换为字典
                res_answer = json_dict.get("回答", "")
        except:
            res_answer = ""
        return res_answer
