# -*- coding:utf-8 -*-
import json
import time

import aiohttp

from lib.base import Base
from api.model_api import count_tokens


class QueryModify(Base):
    def __init__(self, weibo, pid):
        super().__init__(pid)
        self.weibo = weibo

    async def glm4(self, query, session_infos, traceid='', seqid=''):
        modified_query = ""
        try:
            session_infos = json.loads(session_infos)
            if not session_infos:
                return query

            user_content = "\n".join([history.get("zs_data", "") for history in session_infos])
            if not user_content:
                return query

            url = 'http://mproxy.search.weibo.com/llm/generate'
            system_prompt = f"""<任务说明>
你是一个query改写助手,需要根据query和上下文summary信息，必要时改写query为可独立检索的完整query

<改写步骤>
1.检查query：首先检查用户给定的query是否存在指代不明或缺少必要背景信息的情况。
2.无需改写的情况：如果query已经明确且完整，没有指代不明或背景信息缺失的问题，那么直接输出原始query。例如，query='麦琳是如何减肥成功的'，由于它明确指出了人物和询问的内容，因此不需要进行改写。
3.需要改写的情况：如果query存在指代不明或缺少必要背景信息的问题，那么结合上下文summary信息，按照以下步骤进行改写：
    a. 阅读并理解输入：仔细阅读用户给定的query和上下文summary信息。
    b. 识别关键信息：在summary中识别出与query相关的关键信息，如人物名称、事件背景、时间地点等。
    c. 整合关键信息：将识别出的关键信息整合到query中，确保改写后的query完整、明确且独立。
    d. 检查并优化：检查改写后的query是否简洁明了，没有冗余或不必要的词汇。

示例：

示例1：
query：瘦身后不能补录的具体原因是什么?
summary：麦琳在直播中回应了关于《再见爱人》补录的争 议，表示自己作为一个普通的嘉宾，不可能让整个 节目组专门为她一个人补录。她强调自己瘦了很 多，甚至失去了双下巴，所以即使想补录也不可能 再恢复原来的样子。
改写后的query：麦琳因瘦身无法参与《再见爱人》补录的具体原因是什么?

示例2：
query：麦琳是如何减肥成功的?
summary：麦琳在直播中回应了关于《再见爱人》补录的争 议，表示自己作为一个普通的嘉宾，不可能让整个 节目组专门为她一个人补录。她强调自己瘦了很 多，甚至失去了双下巴，所以即使想补录也不可能 再恢复原来的样子。
改写后的query：麦琳是如何减肥成功的?

<注意事项>
1.在改写过程中，请确保只基于给定的query和summary进行修改，不引入任何外部信息。
2.改写后的query（如果需要改写的话）应该保持简洁明了，避免冗余或不必要的词汇。
        """

            user_prompt = f"""给定输入如下，请完成query改写任务，请直接给出改写后的query。不要给出其他标点符号和其他内容，严格按照要求来。
query：{query}
summary：{user_content}
改写后的query：..."""
            request_body = {
                "id": seqid,
                "temperature": 0.1,
                "max_tokens": 1500,
                "repetition_penalty": 1.15,
                "messages": ["system", system_prompt, "user", user_prompt],
                # "schema_idx": 0
            }

            data = {"payload": request_body, "sid": "smart_app_nknxw", "model": "glm4"}
            headers = {'Content-Type': 'application/json'}
            func_name = "CALL_GET_QUERY_MODIFY"
            begin = time.time()
            async with aiohttp.ClientSession() as session:
                async with session.post(url=url, json=data, headers=headers, timeout=2) as r:
                    if r.status == 200:
                        ret = await r.json()
                        modified_query = ret["data"]['text']
                        count_tokens(self.weibo, ret["data"], "chatglm4_2", begin, func_name)
        except Exception as e:
            self.logger.error("{} {} query modify error:{}".format(traceid, query, e))

        modified_query = modified_query.strip()
        return query if not modified_query else modified_query

    async def modified_function(self, query, last_content):
        user_content = [last_content]
        modified_query = ""
        model_url = "http://llm-yizhuang.multimedia.wml.weibo.com/mm-wb-search/qwen25-7b-instruct-weibo-search-zc-177055/v2/models/llm/generate"

        system_prompt = f"""
        现在你是一个query改写的助手。请你根据用户当前的 /query 与 /history 来改写 /query ，使得改写后的 /query 
        
        例子：
        
        query= 他最近有什么活动。
        history = 我喜欢 刘德华
        
        改写后的query= 刘德华 最近 活动
        
        只用输出改写后的query即可 不需要输出其他内容。请严格按照要求来。
        """

        user_prompt = f"请将下面query改写,以history为参考信息, query={query}, history={user_content} 改写query为更适合搜索引擎检索的query。请直接给出改写后的query。不要给出其他标点符号和其他内容，严格按照要求来。"
        payload = {
          "temperature": 0.1,
          "max_tokens": 8192,
          "messages": ["system",system_prompt,"user",user_prompt]
        }
        headers = {'Content-Type': 'application/json'}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url=model_url, json=payload, headers=headers, timeout=2) as r:
                    if r.status == 200:
                        ret = await r.json()
                        modified_query = ret["text"]
        except Exception as e:
            self.logger.error("{} query modify error:{}".format(query, e))

        modified_query = modified_query.strip()
        return query if not modified_query else modified_query

    async def run(self):
        session_infos = self.weibo.get('session_infos', [])
        trace_id = self.weibo.get('trace_id', "")
        ori_query = self.weibo['query']
        self.weibo['ori_query'] = ori_query

        weibo_client_query = ""
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                if json_data.get("flush_source", 0) == 1024 and ori_query.endswith("_sinanews"):
                    weibo_client_query = ori_query.split('_sinanews')[0]
            except Exception as e:
                self.logger.error(
                    "{} query modify {} q_attr:{}, error:{}".format(trace_id, ori_query, q_attr, e))

        if session_infos:
            start = time.time()
            # modify_query = await self.modified_function(ori_query, history)
            modify_query = await self.glm4(ori_query, session_infos, trace_id)
            self.logger.info("{} query modify {} -> {} cost:{}".format(trace_id, ori_query, modify_query, time.time() - start))
            self.weibo['query'] = modify_query
        elif weibo_client_query:
            self.logger.info("{} query modify {} -> {}".format(trace_id, ori_query, weibo_client_query))
            self.weibo['query'] = weibo_client_query








