tools = [
            {
                "type" : "function",
                "function" : {
                    "name" : "weibo_search",
                    "description" : "调用微博搜索引擎，搜索微博内容、用户和话题。输入由多个原子化query组成的“queries”数组，该工具将在一次调用中为每个query搜索相关结果。",
                    "parameters" : {
                        "type" : "object",
                        "properties" : {
                            "queries" : {
                                "type" : "array",
                                "description" : "queries数组，例如：['query1','query2','query3']",
                                "items" : {"type" : "string"}
                            }
                        },
                        "required" : ["queries"]
                    }
                }
            }
        ]