search_prompt = """你具有工具调用能力，可以调用的工具在下面的工具列表中，下面也说明了工具的能力、参数和工具调用格式等信息，如果在完成用户任务的过程中需要使用工具的能力，按照规定的调用格式来调用工具列表中的对应工具。
## 工具列表
- weibo_search: 调用微博搜索引擎，搜索微博内容、用户和话题。输入由多个原子化query组成的“queries”数组，该工具将在一次调用中为每个query搜索相关结果。
输入参数：
{
    "type": "object",
    "properties": {
        "queries": {
            "title": "Queries",
            "type": "array",
            "items": {
                "type": "string"
            }
        }
    }
}

## 工具调用格式：
- 用<tool_calls>……</tool_calls>包裹需要输出的一个或多个工具json，严格按照此格式输出工具调用信息：
<tool_calls>
{
    "function_name": "name",
    "parameters":{
        "param1": "value1", 
        "param2": "value2"
        }
}
</tool_calls>"""