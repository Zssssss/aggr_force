"""意图识别模块"""
# -*- coding:utf-8 -*-
import json
import traceback
from lib.base import Base
from plugins.llm.utils import is_stream_output


class Intention(Base):
    """意图识别的业务逻辑部分，需要打印日志"""

    def check_is_about_xi(self, q_attr):
        """判断是否敏感"""
        about_xi = 0
        try:
            if q_attr:
                attr_dict = json.loads(q_attr)
                about_xi = attr_dict.get("about_xi", 0)
        except:
            about_xi = 0
        return about_xi

    async def run(self, weibo=None):
        """意图识别业务逻辑"""
        if not weibo:
            return
        func_name = "INTENTION"
        self.update_pre_log_msg(weibo)
        hot_overview_override = weibo.get("hot_overview_override", "")
        robot_override = weibo.get("robot_override", "")
        source = weibo.get('source', "")
        q_attr = weibo.get('q_attr', "")
        label = 'ds'
        try:
            if not is_stream_output(weibo) and source == '99':
                if self.check_is_about_xi(q_attr) != 1:
                    label = 'risk_control'

            if hot_overview_override:
                label = hot_overview_override
            if robot_override:
                label = robot_override
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")

        weibo["label"] = label
        self.logger.info(self.pre_log_msg + f"label: {label}")

