# -*- coding:utf-8 -*-
import time
from contextlib import asynccontextmanager
from lib.base import Base
from lib.redis_utils import async_redis_client
from plugins.material.material_api import write_previous_result


class Recalculate(Base):
    """计算控制器：负责判断是否需要计算以及保存计算结果
    
    使用方式：
    async with Recalculate(pid).computing_context(weibo) as should_compute:
        if not should_compute:
            return
        # 执行计算逻辑
    """
    
    def __init__(self, pid):
        super().__init__(pid)
        self.redis_client = async_redis_client

    @asynccontextmanager
    async def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        need_compute = False
        try:
            need_compute = await self.acquire(weibo)
            yield need_compute
        finally:
            if need_compute:
                await self.release(weibo)

    async def acquire(self, weibo):
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        trace_id = weibo.get("trace_id", "")
        llm_name = weibo.get("llm_name", "")
        query_category = weibo.get("query_category", "")
        self_account = weibo.get("self_account", "")
        source = weibo.get('source', '0')
        restart = weibo.get("restart", "")
        hot_overview_override = weibo.get("hot_overview_override", "")
        robot_override = weibo.get("robot_override", "")
        cid = weibo.get("cid", "")
        conversation_id = weibo.get("ori_conversation_id", "")
        abtest = weibo.get("abtest", "")
        if robot_override:
            llm_name = robot_override
        if hot_overview_override:
            llm_name = hot_overview_override

        try:
            # 尝试获取锁
            lock_key = f"{query}{restart}{source}_{llm_name}_{self_account}{cid}{conversation_id}{abtest}_lock"
            redis_server = self.redis_client.get_redis_server(query)
            lock_time = self.get_lock_time(source, query_category)
            
            is_locked = await redis_server.set(
                lock_key,
                1,
                nx=True,
                ex=lock_time
            )
            
            if not is_locked:
                weibo["debug"]["reason_of_not_rerun"] = "no lock"
                return False

            return True
            
        except Exception as e:
            self.logger.error(f"Acquire calculation error,trace_id:{trace_id}  {str(e)}")
            return True

    async def release(self, weibo):
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        trace_id = weibo.get("trace_id", "")
        llm_name = weibo.get("llm_name", "")
        self_account = weibo.get("self_account", "")
        result = weibo.get("result", "")
        restart = weibo.get("restart", "")
        source = weibo.get('source', '0')
        hot_overview_override = weibo.get("hot_overview_override", "")
        robot_override = weibo.get("robot_override", "")
        cid = weibo.get("cid", "")
        conversation_id = weibo.get("ori_conversation_id", "")
        abtest = weibo.get("abtest", "")
        if hot_overview_override:
            llm_name = hot_overview_override
        if robot_override:
            llm_name = robot_override
        lock_key = f"{query}{restart}{source}_{llm_name}_{self_account}{cid}{conversation_id}{abtest}_lock"

        try:
            redis_server = self.redis_client.get_redis_server(query)
            if not result:
                # 结果为空，释放锁
                await redis_server.delete(lock_key)

        except Exception as e:
            self.logger.error(f"Release calculation error,trace_id:{trace_id} {str(e)}")

    def get_lock_time(self, source, query_category):
        """获取锁的过期时间"""
        if source == '3' or source == "99" or source == "999":
            return 3
        return 60


class StreamRecalculate(Recalculate):

    async def acquire(self, weibo):
        in_time_ms = weibo.get("in_time_ms", time.time())
        query_in_time = weibo.get('query_in_time', time.time())
        conversation_id = weibo.get("ori_conversation_id", "")

        # 对话来的继续计算
        if query_in_time - in_time_ms > 5 and not conversation_id:
            weibo["debug"]["reason_of_not_rerun"] = "timeout in queue"
            return False
        return await super().acquire(weibo)

    def get_lock_time(self, source, query_category):
        return 50


class ShortRecalculate(Recalculate):
    """计算控制器：负责判断是否需要计算以及保存计算结果

    使用方式：
    async with Recalculate(pid).computing_context(weibo) as should_compute:
        if not should_compute:
            return
        # 执行计算逻辑
    """

    @asynccontextmanager
    async def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        # if len(weibo["content_list"]) == 0:
        #     yield False
        yield True


class BriefRecalculate(Recalculate):
    """计算控制器：负责判断是否需要计算以及保存计算结果

    使用方式：
    async with Recalculate(pid).computing_context(weibo) as should_compute:
        if not should_compute:
            return
        # 执行计算逻辑
    """

    @asynccontextmanager
    async def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        # if len(weibo["hot_query_list"]) == 0:
        #     yield False
        yield True
