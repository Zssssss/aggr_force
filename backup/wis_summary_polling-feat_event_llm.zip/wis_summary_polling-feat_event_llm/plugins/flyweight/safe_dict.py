# -*- coding:utf-8 -*-
import asyncio


class AsyncSafeDict:
    def __init__(self):
        self._dict = {}
        self._lock = asyncio.Lock()

    async def set(self, key, value):
        async with self._lock:
            self._dict[key] = value

    async def get(self, key, default=None):
        async with self._lock:
            return self._dict.get(key, default)

    async def delete(self, key):
        async with self._lock:
            self._dict.pop(key, None)

    async def update(self, data: dict):
        async with self._lock:
            self._dict.update(data)

    async def clear(self):
        async with self._lock:
            self._dict.clear()

    async def items(self):
        async with self._lock:
            return dict(self._dict).items()

    async def snapshot(self):
        async with self._lock:
            return dict(self._dict)

    async def swap(self, new_data: dict) -> dict:
        async with self._lock:
            old_data = self._dict
            self._dict = dict(new_data)
            return old_data