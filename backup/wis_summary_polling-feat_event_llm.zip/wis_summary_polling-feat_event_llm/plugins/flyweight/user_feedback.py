# -*- coding:utf-8 -*-
import asyncio
import traceback
import time

from lib.base import Base
from lib.mongo_helper import AsyncMongoHelper
from plugins.flyweight.safe_dict import AsyncSafeDict

user_feedback_mongo = AsyncMongoHelper("user_feedback")
user_feedback_dict = AsyncSafeDict()

cove_content_mongo = AsyncMongoHelper("manual_setting")
black_mid_mongo = AsyncMongoHelper("manual_blackmid")
cove_manual_dict = AsyncSafeDict()

class UserFeedBackLoader(Base):

    async def run(self):
        start = time.time()
        feedback_dict = {}
        try:
            user_feedback_data = await user_feedback_mongo.read_any({}, {"_id": 0, 'query': 1, "result": 1})
            for item in user_feedback_data:
                query = item.get('query', "")
                result = item.get('result', {})
                if not query or not result:
                    continue

                feedbacks = []
                for val in result.values():
                    kx = val.get('KEXIN', False)
                    fkfm = val.get('FANKUIFUMIAN', False)
                    zsfm = val.get('ZHISOUFUMIAN', False)
                    query_cat = val.get('query_cat', "")
                    norm_feedback = val.get('norm_feedback', "")
                    feedback = val.get('feedback', "")

                    if query_cat == 'Ip':
                        if norm_feedback:
                            if kx is True and fkfm is False:
                                feedbacks.append(norm_feedback)
                            elif kx is False and zsfm is True:
                                feedbacks.append(norm_feedback)
                    else:
                        if feedback and kx is True:
                            feedbacks.append(feedback)

                if feedbacks:
                    feedback_dict[query] = "\n".join(feedbacks)

            await user_feedback_dict.swap(feedback_dict)
            self.logger.info(f"user feedback len: {len(feedback_dict)}")
        except Exception as e:
            self.logger.error(f"user feedback read mongo failed: {traceback.format_exc()}")

        self.logger.info(f"user feedback read mongo cost:{time.time() - start}")



class CoveMaterialLoader(Base):

    async def run(self):
        start = time.time()
        cove_dict = {}
        try:
            task1 = await cove_content_mongo.read_any({}, {"_id": 0, 'query': 1, "reality_overreview":1, "reality_ds": 1, "match_key": 1, "black_mid": 1})
            task2 = await black_mid_mongo.read_any({}, {"_id": 0, 'black_mid': 1})
            cove_dict['cove_content'] = task1
            cove_dict['cove_mid'] = task2

            self.logger.info(f"cove_content len: {len(task1)}, cove_mid len: {len(task2)}")
            await cove_manual_dict.swap(cove_dict)
        except Exception as e:
            self.logger.error(f"cove read mongo failed: {traceback.format_exc()}")

        self.logger.info(f"cove read mongo cost:{time.time() - start}")