import asyncio
import json
import time
import traceback

import aiohttp

from lib.base import Base
from lib.normalize import topic_normalize
from plugins.flyweight.safe_dict import AsyncSafeDict
import tools.discovery.dconf as discovery

hotsearch_bang_dict = AsyncSafeDict()
reliable_tips_dict = AsyncSafeDict()
guide_text_dict = AsyncSafeDict()
event_group_dict = AsyncSafeDict()
one_sentence_banned_dict = AsyncSafeDict()
sina_night_cove = AsyncSafeDict()
sina_night_prompt = AsyncSafeDict()

class HotSearchBangLoader(Base):

    async def business_query(self, trace_id):
        start = time.time()
        business_query_set = set()
        data = []
        url = f'http://admin.s.weibo.com/intfs/Commerce/adData?sid=ai_lead'
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(3)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        data = res.get("data", {}).get("list", [])
            for item in data:
                query = item.get("query", "")
                if query:
                    business_query_set.add(topic_normalize(query))
        except Exception as e:
            self.logger.error("{}  business query error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info(
            "{} business query: {}, cost: {}".format(trace_id, len(business_query_set), time.time() - start))
        return business_query_set


    async def get_category_query(self, trace_id, category):
        start = time.time()
        filter_query_set = set()
        data = []
        url = f'http://hotdepot.search.weibo.com/normal_hot_depot/interface/outer/normal?sid=v_zhisou_circulateword&is_circulating=1&category={category}'
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(3)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        data = res.get("data", [])
            for item in data:
                query = item.get("query", "")
                if query:
                    filter_query_set.add(topic_normalize(query))
        except Exception as e:
            self.logger.error("{}  {} query error: {}, msg: {}".format(trace_id, category, e, traceback.format_exc()))
        self.logger.info("{} {} query: {}, cost: {}".format(trace_id, category, len(filter_query_set), time.time() - start))
        return filter_query_set

    async def get_reliable_filter_query(self, trace_id):
        tasks = []
        categories = ["情感","幽默","休闲"]
        for category in categories:
            tasks.append(self.get_category_query(trace_id, category))

        results = await asyncio.gather(*tasks)
        queries = set()
        for result in results:
            queries.update(result)
        return queries


    async def get_guide_filter_query(self, trace_id):
        tasks = []
        categories = ["辟谣/通报","国内时政","国际时政","军事"]
        for category in categories:
            tasks.append(self.get_category_query(trace_id, category))

        results = await asyncio.gather(*tasks)
        queries = set()
        for result in results:
            queries.update(result)
        return queries


    async def get_hot_query(self, trace_id):
        start = time.time()
        hot_query_set = set()
        data = []
        url = f'http://hotdepot.search.weibo.com/normal_hot_depot/interface/commercial/ip_info?delicate_status=1&sid=v_zsfk'
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(2)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        data = res.get("data", [])
            for item in data:
                query = item.get("query", "")
                # is_in_realtime_hot_board = item.get("is_in_realtime_hot_board", "0")
                # is_in_subboard_entertainment = item.get("is_in_subboard_entertainment", "0")
                # if query and (is_in_subboard_entertainment == '1' or is_in_realtime_hot_board == '1'):
                if query:
                    hot_query_set.add(topic_normalize(query))
        except Exception as e:
            self.logger.error("{}  hot query error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info("{} hot query: {}, cost: {}".format(trace_id, len(hot_query_set), time.time() - start))
        return hot_query_set

    async def run(self):
        start = time.time()
        try:
            hot_query_set, filter_query_set, business_query_set, guide_filter_query_set = await asyncio.gather(
                self.get_hot_query(self.pid),
                self.get_reliable_filter_query(self.pid),
                self.business_query(self.pid),
                self.get_guide_filter_query(self.pid),
            )

            hot_bang = {query: 1 for query in hot_query_set}
            self.logger.info(f"hot search len: {len(hot_query_set)}, bang: {hot_query_set}")
            await hotsearch_bang_dict.swap(hot_bang)

            diff = hot_query_set - filter_query_set
            bang = {query: 1 for query in diff}
            self.logger.info(f"reliable_tips_dict len: {len(diff)}, reliable_tips_dict: {diff}")
            await reliable_tips_dict.swap(bang)

            diff = hot_query_set - business_query_set - guide_filter_query_set
            bang = {query: 1 for query in diff}
            self.logger.info(f"guide_text_dict len: {len(diff)}, guide_text_dict: {diff}")
            await guide_text_dict.swap(bang)

            diff = set()
            diff.update(business_query_set)
            diff.update(guide_filter_query_set)
            bang = {query: 1 for query in diff}
            self.logger.info(f"one_sentence_banned_dict len: {len(diff)}, one_sentence_banned_dict: {diff}")
            await one_sentence_banned_dict.swap(bang)

        except Exception as e:
            self.logger.error(f"hot search bang failed: {traceback.format_exc()}")

        self.logger.info(f"hot search bang cost:{time.time() - start}")



class EventGroupLoader(Base):

    async def event_group_query(self, trace_id):
        start = time.time()
        event_group_query_set = set()
        data = []
        url = f'http://hotdepot.search.weibo.com/normal_hot_depot/interface/light/event_group?sid=smart_search'
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(3)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        data = res.get("data", [])
            for item in data:
                query = item.get("major_query", "")
                category = item.get("category", "")
                if query and category not in ['国际时政', '国内时政', '军事活动']:
                    event_group_query_set.add(topic_normalize(query))
        except Exception as e:
            self.logger.error("{}  event_group_query_set query error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info(
            "{} event_group_query_set query: {}, cost: {}".format(trace_id, len(event_group_query_set), time.time() - start))
        return event_group_query_set


    async def run(self):
        start = time.time()
        try:
            event_group_query_set = await self.event_group_query(self.pid)
            event_group_queries = {query: 1 for query in event_group_query_set}
            self.logger.info(f"event_group_queries len: {len(event_group_query_set)}, bang: {event_group_query_set}")
            await event_group_dict.swap(event_group_queries)
        except Exception as e:
            self.logger.error(f"event_group_queries failed: {traceback.format_exc()}")

        self.logger.info(f"event_group_queries cost:{time.time() - start}")


class SinaNightLoader(Base):
    async def run(self, **kwargs):
        start = time.time()
        sina_night_cove_dict = dict()
        sina_night_prompt_dict = dict()
        try:
            config_value = discovery.configget("wis_summary_service", 'sina_night')
            if config_value:
                data = json.loads(config_value)
                for k, v in data.items():
                    sina_night_cove_dict[k] = v.strip()

            self.logger.info(f"sina_night_cove_dict len: {len(sina_night_cove_dict)}, bang: {sina_night_cove_dict}")
            await sina_night_cove.swap(sina_night_cove_dict)

            config_value = discovery.configget("wis_summary_service", 'sina_night_prompt')
            if config_value:
                data = json.loads(config_value)
                for k, v in data.items():
                    sina_night_prompt_dict[k] = v

            self.logger.info(f"sina_night_prompt_dict len: {len(sina_night_prompt_dict)}, bang: {sina_night_prompt_dict}")
            await sina_night_prompt.swap(sina_night_prompt_dict)

        except Exception as e:
            self.logger.error(self.pre_log_msg + f"SinaNightCoveMaterial failed: {traceback.format_exc()}")

        self.logger.info(self.pre_log_msg + "SinaNightCoveMaterial cost: {}".format(time.time() - start))
