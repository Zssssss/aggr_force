# -*- coding:utf-8 -*-
"""
公共常量定义
"""

# 自动干预，使用query事实改写的source标识
RECALCULATE_SOURCE = "999"

# 存储干预知识的redis key prefix
REDIS_INTERVENE_KNOWLEDGE_PREFIX = "wis_auto_intervene_knowledge_"