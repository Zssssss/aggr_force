# -*- coding:utf-8 -*-
import json
import os
import queue
import time
import traceback
from contextlib import contextmanager
import diskcache
from lib.base import Base


class QueryCache(Base):

    def __init__(self, pid, model):
        super().__init__(pid)
        self.model = model
        self.name = model
        self.cache = diskcache.Cache(os.path.join("data", self.name))
        self.queue = queue.Queue()
        self.load()

    @contextmanager
    def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        try:
            self.add(weibo)
            yield True
        finally:
            self.delete(weibo)

    def add(self, weibo):
        query = weibo.get('query', "")
        trace_id = weibo.get('traceid', "")
        try:
            start = time.time()
            res = self.cache.set(query, json.dumps(weibo, ensure_ascii=False), expire=100)
            self.logger.info("add: {}, res: {}, cost: {}".format(trace_id, res, time.time() - start))
        except Exception as e:
            self.logger.error("{} add error: {}".format(trace_id, e))

    def delete(self, weibo):
        query = weibo.get('query', "")
        trace_id = weibo.get('traceid', "")
        try:
            start = time.time()
            res = self.cache.delete(query)
            self.logger.info("delete: {}, res: {}, cost: {}".format(trace_id, res, time.time() - start))
        except Exception as e:
            self.logger.error("{} delete error: {}".format(trace_id, e))

    def load(self):
        try:
            all_keys = list(self.cache.iterkeys())
            self.logger.info("start load items: {}".format(len(all_keys)))
            for key in all_keys:
                item = self.cache.pop(key)
                self.logger.info("load item: {}".format(item))
                if item:
                    data = json.loads(item)
                    self.queue.put(data)
            self.cache.clear()
        except Exception as e:
            self.logger.error("load error: {}, msg:{}".format(e, traceback.format_exc()))

    def get(self):
        try:
            if self.queue.qsize():
                data = self.queue.get(False)
                if data:
                    in_time = time.time()
                    data['restart'] = 'restart'
                    data['in_time'] = int(in_time)
                    data['in_time_ms'] = in_time
                    data['query_in_time'] = in_time
                    self.logger.info("get item: {}".format(data))
                return data
        except Exception as e:
            self.logger.error("get error: {}, msg:{}".format(e, traceback.format_exc()))
        return None

