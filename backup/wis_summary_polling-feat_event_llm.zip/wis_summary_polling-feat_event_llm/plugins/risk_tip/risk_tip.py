# -*- coding:utf-8 -*-
import time
import json
import traceback

from lib.base import Base
from plugins.llm.utils import count_tokens
from plugins.prompt.risk_tip import risk_tip_factory
from api.model_api import get_deepseek_r1_model_from_weibo_sid


class RiskTip(Base):
    async def run(self, weibo):
        self.update_pre_log_msg(weibo)
        ori_all_result = weibo.get('ori_result', "")
        content = weibo.get('content', "")
        query = weibo.get('query', "")
        sid = weibo.get('sid', "")

        if "</think>" not in ori_all_result:
            raise Exception('no think')
        try:
            begin = time.time()
            prompt = risk_tip_factory(weibo)
            llm = get_deepseek_r1_model_from_weibo_sid(sid)(weibo, self.pid, self.pre_log_msg, "风险提示生成")
            prompt_content = prompt.prompt()
            weibo['risk_tip_prompt'] = prompt_content
            if not prompt_content:
                self.logger.info(self.pre_log_msg + "no ref")
                return ori_all_result

            response = await llm.async_call(prompt_content)
            await count_tokens(weibo, response, begin)

            risk_result = response.get("text", "")
            weibo['risk_tip_result'] = risk_result
            add_risk_result = prompt.post_process(risk_result)
            self.logger.info(self.pre_log_msg + "add risk result:{}".format(json.dumps(add_risk_result, ensure_ascii=False)))
            return add_risk_result
        except Exception as e:
            self.logger.error(self.pre_log_msg + "risk tip error:{}\tmsg:{}".format(e, traceback.format_exc()))
        return ori_all_result
