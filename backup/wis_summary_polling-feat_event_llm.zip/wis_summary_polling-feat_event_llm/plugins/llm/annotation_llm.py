# -*- coding:utf-8 -*-
import asyncio
import json
import re
import time

import aiohttp

from api.model_api import get_deepseek_r1_model_from_weibo_sid
from lib.split_markdown import split_markdown_by_headings
from lib.trie import MidTrie
from plugins.llm.mid_llm import MidLLM
from plugins.material.material import SummaryResultMaterial, ShowBatchMaterial
from plugins.prompt.annotation import AnnotationPrompt, TitlePrompt, AnnotationIntention

trie1 = MidTrie(["求证", "核实", "可信", "验证", "核查", "真实性", "确认"])
trie2 = MidTrie(["交叉验证", "经核查", "经核实", "经查证"])


def matches_pattern(text, include_heading_in_content=False):
    try:
        temp_txt = text.strip()
        temp_pos = 0
        txt_with_title, txt_not_with_title = "", text
        while temp_pos < len(temp_txt):
            ch = temp_txt[temp_pos]
            if ch == '#':
                txt_with_title = temp_txt[temp_pos:]
                txt_not_with_title = temp_txt[:temp_pos]
                break
            temp_pos += 1

        if txt_not_with_title and trie2.contains_any_keyword(txt_not_with_title):
            return True, txt_not_with_title

        secs = split_markdown_by_headings(txt_with_title, include_heading_in_content=include_heading_in_content)
        temp_res = ""
        pre_level = -1
        for sec in secs:
            if (trie1.contains_any_keyword(sec.title) or trie2.contains_any_keyword(
                    sec.content)) and sec.level >= pre_level:
                temp_res = sec.content
                pre_level = sec.level
        if not temp_res:
            return False, temp_res
        return True, temp_res
    except Exception :
        print("matches_pattern error:" + text)
        return False, ""

def markdown_to_plain(text: str) -> str:
    # 去掉 markdown 的加粗/斜体符号 * 或 _
    # text = re.sub(r'(\*{1,3}|_{1,3})(.*?)\1', r'\2', text)
    pattern = re.compile(r'(\*{1,3}|_{1,3})(.*?)\1')
    while pattern.search(text):
        text = pattern.sub(r'\2', text)
        
    # 去掉各级标题标记（开头的 # 及后面的空格）
    text = re.sub(r'^\s*#{1,6}\s*', '', text, flags=re.MULTILINE)
    
    # 处理换行符 \n
    text = text.replace("\\n", "\n")
    
    # 去掉多余的转义符号
    text = text.replace("\\", "")

    # \n转化为空格
    text = text.replace("\n", " ")

    text = re.sub(r' ', '', text) ###去掉所有空格变紧凑

    return text.strip()

def trim_tail_after_colon(text):
    try:
        text = text.strip().rstrip("-").strip()
        # 如果末尾有冒号（可能前面还有空格），才处理
        if text.rstrip().endswith('：'):
            # 从末尾开始，找到最后一个句号/问号/感叹号的位置
            match = re.search(r'[。！？](?!.*[。！？])', text)
            if match:
                text = text[:match.end()]
        text = markdown_to_plain(text)
        return text.strip()
    except Exception:
        print("trim_tail_after_colon error:" + text)
        return ""

class AnnotationLLM(MidLLM):

    async def fetch_material(self):
        await asyncio.gather(
            super().fetch_material(),
            SummaryResultMaterial(self.pid).run(weibo=self.weibo),
            ShowBatchMaterial(self.pid).run(weibo=self.weibo)
        )

    def make_prompt(self):
        prompt = AnnotationPrompt(self.weibo)
        return prompt

    async def output_result(self, trace_id, version, query, llm_name, result, page_id, source, scene, exclusion, note_page_id, is_review=0):
        data = {"query": query, "model": "verification_note", "annotation": result, "version": version, "page_id": page_id,
                'source': source, 'prompt_scene': scene, 'exclusion': exclusion, "not_page_id": note_page_id}

        if is_review == 1:
            data.update({"is_review": 0})

        url = 'http://admin.ai.s.weibo.com/api/annotations/push.json'
        headers = {'Content-Type': 'application/json'}
        start = time.time()
        timeout = 2
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as session:
                async with session.post(url=url, json=data, headers=headers, timeout=timeout) as response:
                    response.raise_for_status()
                    response_json = await response.json()
                    self.logger.info("traceid:{}\tquery:{}\tanno_response:{}\tdata:{}\tcost:{}".format(
                        trace_id, query, response_json, json.dumps(data, ensure_ascii=False), time.time() - start))
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} write to fronted error data:{}, cost:{}".format(
                    query, str(e), trace_id, json.dumps(data, ensure_ascii=False), time.time() - start))

    async def generate_title(self, trace_id, sid, query):

        begin = time.time()
        try:
            mid_uid = self.weibo.get("mid_uid", "")
            if not query or not mid_uid:
                self.logger.error(
                    "query:{}, traceid:{} generate_title mid_uid not found".format(query, trace_id))
                return

            prompt = TitlePrompt(self.weibo)
            llm = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "标题生成")
            prompt_content = prompt.prompt()
            response = await llm.async_call(prompt_content)
            await self.count_tokens(response, begin)
            title_result = response.get("text", "")
            result = prompt.post_process(title_result)
            self.weibo['title_prompt'] = json.dumps(prompt_content, ensure_ascii=False)
            self.weibo['title_result'] = json.dumps(title_result, ensure_ascii=False)
            self.weibo['title'] = result
            if not result.strip():
                self.logger.error(
                    "query:{}, traceid:{} result is empty".format(query, trace_id))
                return

            # 回传格式"admin.ai.s.weibo.com/api/qingjing/create.json?mid=5201660014232907&query=求证马谡是否出错&user=1885429940"
            data = {"mid": query, "query": result, "user": mid_uid}
            if not self.weibo.get('is_verification_title', False):
                data.update({"mode" : "recall", "source" : "smartq_content"})
            url = 'http://admin.ai.s.weibo.com/api/qingjing/create.json'
            headers = {'Content-Type': 'application/json'}
            start = time.time()
            timeout = 2
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as session:
                    async with session.post(url=url, json=data, headers=headers, timeout=timeout) as response:
                        response.raise_for_status()
                        response_json = await response.json()
                        self.logger.info("traceid:{}\tquery:{}\ttitle_response:{}\tdata:{}\tcost:{}".format(
                            trace_id, query, response_json, json.dumps(data, ensure_ascii=False), time.time() - start))
            except Exception as e:
                self.logger.error(
                    "query:{},error:{},traceid:{} write to fronted error data:{}, cost:{}".format(
                        query, str(e), trace_id, json.dumps(data, ensure_ascii=False), time.time() - start))
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} llm error: {}, cost:{}".format(
                    query, str(e), trace_id, e, time.time() - begin))

    def is_over_three_days(self, mid):
        try:
            cur_time = int(time.time())
            tmp_time = (int(mid) >> 22) + 515483463
            return (cur_time - tmp_time) > 259200
        except:
            pass
        return True



    async def annotation(self):
        try:
            begin = time.time()
            sid = self.weibo.get('sid', "")
            modify_query = self.weibo.get("query", "")
            query = self.weibo.get("ori_query", modify_query)
            llm_name = self.weibo.get("llm_name", "")
            trace_id = self.weibo.get("trace_id", "")
            ori_result = self.weibo.get("ori_result", "")
            # version = self.weibo.get("verification_note_version", "")
            version = trace_id
            page_id = self.weibo.get("verification_note_page_id", "")
            is_ad = self.weibo.get("is_ad", False)
            is_forward = self.weibo.get("is_forward", 0)
            is_star = self.weibo.get("is_star", False)
            is_organization = self.weibo.get("is_organization", False)
            prompt_scene = self.weibo.get("prompt_scene", "")
            source = self.weibo.get("source", 0)
            note_page_id = self.weibo.get("note_page_id", "")

            if not ori_result:
                self.logger.info(self.pre_log_msg + "no result")
                return "", 0

            is_over_time = self.is_over_three_days(query)
            if is_ad or is_forward or is_over_time or is_star or is_organization:
                self.logger.info(self.pre_log_msg + f"is_ad: {is_ad}, is_forward: {is_forward}, is_over_3days: {is_over_time}, "
                                                    f"is_star: {is_star}, is_organization: {is_organization}")
                return "", 0

            flag, exclusion = matches_pattern(ori_result)
            exclusion = trim_tail_after_colon(exclusion)

            if source == '87':
                await self.output_result(trace_id, version, query, llm_name, "", page_id, source, prompt_scene,
                                         exclusion, note_page_id)
                return "", 1

            if not flag:
                self.logger.info(self.pre_log_msg + "result no matches")
                return "", 0

            llm = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "附注生成")

            # 判断是否求证
            prompt = AnnotationIntention(self.weibo)
            annotation_intention_prompt = prompt.prompt()
            response = await llm.async_call(annotation_intention_prompt)
            await self.count_tokens(response, begin)
            annotation_intention_result = response.get("text", "")
            is_verification = prompt.post_process(annotation_intention_result)
            self.weibo['annotation_intention_prompt'] = json.dumps(annotation_intention_prompt, ensure_ascii=False)
            self.weibo['annotation_intention_result'] = json.dumps(annotation_intention_result, ensure_ascii=False)
            self.weibo['annotation_intention'] = is_verification
            self.logger.info(self.pre_log_msg + f"intention: {is_verification}")
            if not is_verification:
                self.logger.info(
                    self.pre_log_msg + f"verification: {is_verification}, result: {json.dumps(annotation_intention_result, ensure_ascii=False)}")
                return "", 0
            # 意图为求证就生成标题
            self.weibo['is_verification_title'] = True
            await self.generate_title(trace_id, sid, query)

            # 生成附注
            prompt = AnnotationPrompt(self.weibo)
            annotation_prompt = prompt.prompt()
            response = await llm.async_call(annotation_prompt)
            await self.count_tokens(response, begin)
            annotation_result = response.get("text", "")
            result, value = prompt.post_process(annotation_result)
            self.weibo['annotation_prompt'] = json.dumps(annotation_prompt, ensure_ascii=False)
            self.weibo['annotation_result'] = json.dumps(annotation_result, ensure_ascii=False)
            self.weibo['annotation'] = result
            self.logger.info(self.pre_log_msg + f"result:{result}\tis_verified: {value}")

            if value:
                await self.output_result(trace_id, version, query, llm_name, result, page_id, source, prompt_scene, exclusion, note_page_id)
            return result, value
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"annotation error: {e}")

        return "", 0

    async def call_llm(self, prompt):
        sid = self.weibo.get('sid', "")
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        trace_id = self.weibo.get("trace_id", "")
        ori_result = self.weibo.get("ori_result", "")
        url_marked = self.weibo.get("url_marked", False)
        llm_name = self.weibo.get("llm_name", "")
        version = trace_id
        page_id = self.weibo.get("verification_note_page_id", "")
        prompt_scene = self.weibo.get("prompt_scene", "")
        source = self.weibo.get("source", 0)
        note_page_id = self.weibo.get("note_page_id", "")

        if url_marked:
            self.logger.info(self.pre_log_msg + f"mid：{query} is url_marked")
            return ""

        content, val = await self.annotation()
        if not val:
            await self.output_result(trace_id, version, query, llm_name, "", page_id, source, prompt_scene, "", note_page_id,  1)

        await self.send_response(ready='yes' if content else 'error', content=content, status_stage=4)
        # 如果没有生成求证标题，则计算通用标题
        is_verification_title = self.weibo.get('is_verification_title', False)
        if not is_verification_title and ori_result and source != '87':
            await self.generate_title(trace_id, sid, query)

        content = self.weibo.get('title', "")
        return content