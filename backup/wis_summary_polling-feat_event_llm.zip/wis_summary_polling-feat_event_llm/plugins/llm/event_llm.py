# -*- coding:utf-8 -*-
import asyncio
import copy
import json
import re
import time
from datetime import datetime
from typing import List, Dict, Any, Tuple

import traceback
from jinja2 import Template

from api.model_api import WeiboDeepseekWrapper
from plugins.llm.deepseek import DeepSeekLLM
from plugins.material.multiq_runner import MultiQueryMaterialRunner
from plugins.post_process.deep_resarch import merge_and_map_link_lists, merge_weibo_multi_modal_info, update_quote_position
from plugins.prompt.event import get_planner_prompt, get_researcher_prompt, get_reporter_prompt
from plugins.prompt.json_utils import parse_json


class EventLLM(DeepSeekLLM):

    async def generate_risk_tips(self):
        # 不计算可信标签
        ori_result = self.weibo.get("ori_result", "")
        return ori_result

    async def fetch_multiq_material(self, query_list: list[str]) -> dict[str, any]:
        # backup
        weibo_bak = copy.deepcopy(self.weibo)
        weibo_new_data = {}
        try:
            self.logger.info(self.pre_log_msg + f"fetch_multiq_material with query_list: {query_list}")
            multi_q_runner = MultiQueryMaterialRunner(self.pid)
            await multi_q_runner.run(weibo=self.weibo, query_list=query_list, query_weight=[1] * (len(query_list) + 1))
            await self.confine_material_length()
            weibo_new_data = copy.deepcopy(self.weibo)
        except Exception:
            self.logger.error(self.pre_log_msg + f"fetch_and_struct_material error: {traceback.format_exc()}")
        finally:
            self.weibo.update(weibo_bak)
        return weibo_new_data

    async def generate_planner(self, query, mats):
        prompt = get_planner_prompt(query, mats)
        llm = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, "事件组词计算")
        for attempt in range(2):
            try:
                begin = time.time()
                response = await llm.async_call(prompt)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                data = parse_json(result)
                return data
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"planner error：{e}")
        return {}

    async def generate_researcher_one(self, prompt):
        llm = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, "事件组词计算")
        for attempt in range(2):
            try:
                begin = time.time()
                response = await llm.async_call(prompt)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                return result
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"researche error：{e}")
        return ""

    async def generate_researcher(self, query, planner_result):
        tasks = []
        link_list_all = []
        weibo_new_data_all = []
        ds_struct_material_all = []
        for plan_it in planner_result.get("steps", []):
            heading = plan_it.get("heading", "")
            for plan_subit in plan_it.get("subheadings", []):
                subheading = plan_subit.get("subheading", "")
                subtitle = f"{heading}-{subheading}"
                search_queries = plan_subit.get("search_queries", [])
                if search_queries:
                    weibo_new_data = await self.fetch_multiq_material(search_queries)
                else:
                    weibo_new_data = await self.fetch_multiq_material([subtitle])
                prompt = get_researcher_prompt(query, subtitle, weibo_new_data.get('ds_struct_material', []))
                task = self.generate_researcher_one(prompt)
                tasks.append(task)
                link_list_all.append(weibo_new_data.get('link_list', []))
                weibo_new_data_all.append(weibo_new_data)
                ds_struct_material_all.append(weibo_new_data.get('ds_struct_material', []))
        result = await asyncio.gather(*tasks)
        # 合并引文
        merged_links, position_mappings = merge_and_map_link_lists(link_list_all)
        # 引文替换
        for index in range(len(result)):
            result[index] = update_quote_position(result[index], position_mappings[index])
        # 合并多模态信息
        merged_multi_modal_info = merge_weibo_multi_modal_info(weibo_new_data_all)
        # 更新weibo
        self.weibo.update(merged_multi_modal_info)
        self.weibo.update({"link_list" : merged_links})
        return result


    async def generate_reporter(self, query, planner_result, researcher_result):
        support_data = ""
        k = 0
        for i, plan_it in enumerate(planner_result.get("steps", [])):
            heading = plan_it.get("heading", "")
            support_data += "# " + heading + "\n---\n"
            for j, plan_subit in enumerate(plan_it.get("subheadings", [])):
                subtitle = plan_subit.get("subheading", "")
                if subtitle and k < len(researcher_result):
                    support_data += "## " + subtitle + "\n" + researcher_result[k] + "\n"
                    k+=1

        prompt = get_reporter_prompt(query, support_data.strip())
        llm = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, "事件组词计算")
        for attempt in range(2):
            try:
                begin = time.time()
                response = await llm.async_call(prompt)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                return result
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"planner error：{e}")
        return ""

    async def generate_content(self, llm_model, prompt):
        query = self.weibo.get("query", "")
        self.weibo["event_deep_research"] = True
        weibo_new_data = await self.fetch_multiq_material([query])
        planner_result = await self.generate_planner(query, '\n'.join(weibo_new_data.get('ds_struct_material', [])))
        self.logger.info(self.pre_log_msg + f"planner_result: {json.dumps(planner_result, ensure_ascii=False)}")
        researcher_result = await self.generate_researcher(query, planner_result)
        self.logger.info(self.pre_log_msg + f"researcher_result: {json.dumps(researcher_result, ensure_ascii=False)}")
        reporter_result = await self.generate_reporter(query, planner_result, researcher_result)
        self.logger.info(self.pre_log_msg + f"reporter_result: {json.dumps(researcher_result, ensure_ascii=False)}")
        return reporter_result