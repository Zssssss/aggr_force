# -*- coding:utf-8 -*-
import asyncio
import json
import re
import time
import traceback

from alarm.alarm import alarm
from api.model_api import WeiboDeepseekWrapper
from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.hot_overview import hv_cove_factory


class HotOverviewLLM(DeepSeekLLM):

    async def call_cove(self, result):
        func_name = "CALL-HOTOVERVIEWLLM-COVE"
        start = time.time()
        cove_query = self.weibo.get('cove_query', False)
        knowledge = self.weibo.get('knowledge', "")
        if result and cove_query and knowledge:
            self.weibo["claim1"] = result
            cove_prompt = hv_cove_factory(self.weibo)
            llm_qwen72b = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
            prompt_content = cove_prompt.prompt()
            begin = time.time()
            response = await llm_qwen72b.async_call(prompt_content)
            await self.count_tokens(response, begin)
            cove_result = response.get("text", "")
            result = cove_prompt.post_process(cove_result)
            self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\t"
                                                f"result:{json.dumps(result, ensure_ascii=False)}")
        return result
    
    """继承deepseek， 增加log输出"""
    async def call_llm(self, prompt):
        traceid = self.weibo.get("traceid", "")
        query = self.weibo.get("query", "")
        use_zhisou = self.weibo.get("use_zhisou", False)
        llm_name = self.weibo.get('llm_name', "")
        func_name = "热点概况生成"
        start = time.time()
        llm_qwen72b = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_content = prompt.prompt()
        self.weibo['prompt'] = prompt_content
        retry = 2
        content = ""
        error_name = ""
        for i in range(retry):
            try:
                schema_index = None if i == 0 else prompt.schema_index()
                for i in range(4):
                    begin = time.time()
                    response = await llm_qwen72b.async_call(prompt_content, schema_index)
                    await self.count_tokens(response, begin)
                    result = response.get("text", "")
                    result = prompt.post_process(result)
                    self.weibo["debug"]["time_analysis"][f"call_cove{i}_start"] = time.time()
                    result = await self.call_cove(result)
                    self.weibo["debug"]["time_analysis"][f"call_cove{i}_end"] = time.time()
                    if len(result) >= 40 or len(result) <= 60:
                        break
                    self.logger.info(self.pre_log_msg + f"length of result is not in range[40, 60]: {len(result)}")

                self.weibo["output_all_ready"] = True
                # error_name, no_error = await self.check_result(result)
                # if no_error and result:
                # self.weibo["debug"]["call_llm_times"] = i + 1
                # self.weibo["debug"]["time_analysis"]["call_llm_with_result_end"] = time.time()
                json_result = self.weibo.get("json_result", {})
                self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\ttimes:{i + 1}\t"
                                    f"label:{self.weibo.get('label', '')}\t"
                                    f"query_category:{self.weibo.get('query_category', '')}\t"
                                    f"result:{json.dumps(result, ensure_ascii=False)}\t"
                                    f"json_result:{json.dumps(json_result, ensure_ascii=False)}\t")
                content = result
                    # await self.calc_question(content)
                break
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        self.write_log(message=f"{func_name} get no result, cost_time:{time.time() - start}")
        self.weibo["debug"]["call_llm_times"] = retry
        self.weibo["debug"]["time_analysis"]["call_llm_no_result_end"] = time.time()
        self.weibo["debug"]['end_process'] = time.time()
        await self.send_response(ready='yes' if content else 'error', content=content)
        # if use_zhisou and error_name:
        #     alarm("{} {} {} format error: {}".format(llm_name, traceid, query, error_name))
        return content
