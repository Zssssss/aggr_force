"""高考相关处理"""
# -*- coding:utf-8 -*-
import time
import json
import asyncio
import traceback

from api.model_api import ZJZWThirdModelWrapper, QWEN3_30B_ModelGaoKaoWrapper as QWEN3_GaoKao, WeiboDeepseekWrapper
from plugins.llm.deepseek import DeepSeekLLM, StreamDeepSeekLLM
from plugins.material.material import CollegeMaterial
from plugins.prompt.college import colege_factory, colege_check_factory, third_text_process_new as third_text_process


class CollegeLLM(DeepSeekLLM):

    def third_text_process(self, text):
        return third_text_process(text)

    async def fetch_material(self):
        await asyncio.gather(
            super().fetch_material(),
            CollegeMaterial(self.pid).run(weibo=self.weibo)
        )

    async def call_third_party(self):
        """第三方接口调用"""
        start = time.time()
        func_name = "CALL-THIRD-PARTY"
        query = self.weibo.get("query", "")
        if not query:
            return ""
        # 1.调用第三方接口
        llm_model = ZJZWThirdModelWrapper(self.pid, self.pre_log_msg)
        # 2.处理返回结果
        result = ""
        is_available = True
        try:
            stream_response = await llm_model.async_stream_call(query)
            async for response in stream_response:
                is_available = response.get("is_available", True)
                if not is_available:
                    result = ""
                    break
                result = response.get("text", "")
                result = result.strip('\n')
            result, end_content = self.third_text_process(result)
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{e}")
            result = ""
            end_content = ""

        self.weibo['zjzw_result'] = f"{result}\n{end_content}".strip()
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time: {time.time() - start}, is_available: {is_available}, result: {json.dumps(result, ensure_ascii=False)}")
        return result, end_content

    async def call_public_experience_check_llm(self):
        """判断是否需要获取大众经验"""
        start = time.time()
        func_name = "CALL-PUBLIC-EXPERIENCE-CHECK-LLM"
        llm_qwen3 = QWEN3_GaoKao(self.weibo, self.pid, self.pre_log_msg)
        prompt = colege_check_factory(self.weibo)
        prompt_content = prompt.prompt()
        retry = 2
        content = ""
        for i in range(retry) :
            try :
                schema_index = None if i == 0 else prompt.schema_index()
                response = await llm_qwen3.async_call(prompt_content, schema_index)
                await self.count_tokens(response, start)
                ori_result = response.get("text", "")
                result = prompt.post_process(ori_result)
                content = result
                break
            except Exception as e :
                self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time: {time.time() - start}, result: {json.dumps(content, ensure_ascii=False)}")
        return content

    async def call_public_experience_text_llm(self, prompt, third_text, end_content):
        """大众经验的结果"""
        start = time.time()
        func_name = "CALL-PUBLIC-EXPERIENCE-TEXT-LLM"
        llm_model = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg)
        
        prompt_content = prompt.prompt()
        self.weibo['prompt'] = prompt_content
        result = ""
        try:
            response = await llm_model.async_call(prompt_content)
            result = response.get("text", "")
            await self.count_tokens(response, start)
            if "</think>" in result:
                result = result.split("</think>")[1]
            result = result.strip('\n')
            result = prompt.post_process(result)
            result = "\n\n".join([third_text, result, end_content])
            await self.output.run(weibo=self.weibo, ready='yes' if result else 'nodata', content=result, status_stage=4)
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{e}")
            result = "\n".join([third_text, end_content])
            await self.output.run(weibo=self.weibo, ready='yes' if result else 'nodata', content=result, status_stage=4)
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time: {time.time() - start}, result: {json.dumps(result, ensure_ascii=False)}")
        return result

    async def call_public_experience_check_llm_new(self):
        return True

    async def call_llm(self, prompt):
        """重写大模型调用流程"""
        is_need_third = self.weibo.get("is_called_third_party", True)
        gaokao_intention = self.weibo.get("gaokao_intention", "")
        if not is_need_third or gaokao_intention == "只使用智搜模式":
            self.logger.info(self.pre_log_msg + "\t只使用智搜模式")
            return await super().call_llm(prompt)
        tasks = [
            self.call_third_party(),
            self.call_public_experience_check_llm_new()
        ]
        (third_result, end_content), check = await asyncio.gather(*tasks)
        if not third_result:
            self.logger.info(self.pre_log_msg + "\t只使用智搜模式")
            return await super().call_llm(prompt)
        if not check or gaokao_intention == "只使用掌上高考模式":
            self.logger.info(self.pre_log_msg + "\t只使用掌上高考模式")
            third_result = "\n".join([third_result, end_content])
            await self.output.run(weibo=self.weibo, ready='yes' if third_result else 'nodata', content=third_result, status_stage=4)
            return third_result
        cur_prompt = colege_factory(self.weibo)
        self.logger.info(self.pre_log_msg + "\t拼接模式")
        return await self.call_public_experience_text_llm(cur_prompt, third_result, end_content)


class StreamCollegeLLM(StreamDeepSeekLLM):

    def third_text_process(self, text):
        return third_text_process(text)

    async def fetch_material(self):
        await asyncio.gather(
            super().fetch_material(),
            CollegeMaterial(self.pid).run(weibo=self.weibo)
        )

    async def call_llm_end(self, token_info, prompt, result, pre_result="", after_content="", check_think=True):
        """最终结果处理"""
        self.weibo['prompt'] = prompt.prompt()
        self.weibo["debug"]["time_analysis"]["stream_answer_end"] = time.time()
        self.weibo["debug"]['end_process'] = time.time()
        if token_info:
            final_result = token_info.get("final_result", {})
            begin = token_info.get("begin", 0)
            first_time = token_info.get("first_time", 0)
            await self.count_tokens(final_result, begin, first_time)
        self.weibo["output_all_ready"] = True
        self.weibo['ori_result'] = result
        result = prompt.post_process(result)
        result = "\n\n".join([pre_result, result, after_content])
        result = result.strip("\n")
        if check_think and "</think>" not in result:
            self.logger.error(self.pre_log_msg + f"no think result:{json.dumps(result, ensure_ascii=False)}\t")
            result = ""
        await self.output.run(weibo=self.weibo, ready='yes' if result else 'nodata', content=result, status_stage=4)
        error_name, no_error = await self.check_result(result)
        if no_error and result:
            await asyncio.gather(
                self.calc_question(result),
                self.calc_query_monitor()
            )
        return result
    async def call_third_party(self, common_dict):
        """第三方接口调用"""
        start = time.time()
        func_name = "CALL-THIRD-PARTY"
        query = self.weibo.get("query", "")
        if not query:
            return ""
        # 1.调用第三方接口
        llm_model = ZJZWThirdModelWrapper(self.pid, self.pre_log_msg)
        # 2.处理返回结果
        first = True
        stream_window = 10
        result = ""
        last_result = ""
        is_available = True
        try:
            stream_response = await llm_model.async_stream_call(query)
            async for response in stream_response:
                is_available = response.get("is_available", True)
                if not is_available:
                    result = ""
                    break
                if first:
                    first_time = time.time()
                    self.weibo["debug"]["time_analysis"]["stream_fist_answer"] = first_time
                    self.weibo["debug"]['first_answer'] = first_time
                    first = False
                result = response.get("text", "")
                result = result.strip('\n')
                if len(result) - len(last_result) > stream_window:
                    if stream_window < 20:
                        stream_window += 2
                    result_new, end_content = self.third_text_process(result)
                    common_dict["end_content"] = end_content
                    await self.output.run(weibo=self.weibo, ready='no', content=result_new, status_stage=4)
                    last_result = result
            result, end_content = self.third_text_process(result)
            common_dict["end_content"] = end_content
            if result:
                await self.output.run(weibo=self.weibo, ready='no', content=result, status_stage=4)
            self.logger.info(self.pre_log_msg + f"{func_name}, think_test, cur_time: {time.time()}, cost_time: {time.time() - start}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{e}")
            result = ""
            end_content = ""
        if result:
            common_dict["third_end"] = True
            common_dict["third_text"] = result
            common_dict["end_content"] = end_content
        else:
            common_dict["is_available"] = False
            end_content = ""

        self.weibo['zjzw_result'] = f"{result}\n{end_content}".strip()
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time: {time.time() - start}, is_available: {is_available}, result: {json.dumps(result, ensure_ascii=False)}, end_content: {json.dumps(end_content, ensure_ascii=False)}")
        return result

    async def call_public_experience_check_llm(self):
        """判断是否需要获取大众经验"""
        start = time.time()
        func_name = "CALL-PUBLIC-EXPERIENCE-CHECK-LLM"
        llm_qwen3 = QWEN3_GaoKao(self.weibo, self.pid, self.pre_log_msg)
        prompt = colege_check_factory(self.weibo)
        prompt_content = prompt.prompt()
        retry = 2
        content = ""
        for i in range(retry) :
            try :
                schema_index = None if i == 0 else prompt.schema_index()
                response = await llm_qwen3.async_call(prompt_content, schema_index)
                ori_result = response.get("text", "")
                result = prompt.post_process(ori_result)
                content = result
                break
            except Exception as e :
                self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time: {time.time() - start}, result: {json.dumps(content, ensure_ascii=False)}")
        return content

    async def call_public_experience_text_llm(self, prompt, common_dict):
        """大众经验的结果"""
        start = time.time()
        func_name = "CALL-PUBLIC-EXPERIENCE-TEXT-LLM"
        llm_model = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg)
        
        prompt_content = prompt.prompt()
        final_result = None
        result = ""
        last_result = ""
        stream_window = 10
        first = True
        first_time = 0
        think_fisrt = True
        try:
            begin = time.time()
            stream_response = await llm_model.async_stream_call(prompt_content)
            
            async for response in stream_response:
                if not common_dict["is_available"]:
                    break
                if first:
                    first_time = time.time()
                    first = False
                final_result = response
                result = response.get("text", "")
                if len(result) < 10 or ("<think>" in result and "</think>" not in result):
                    continue
                if "</think>" in result:
                    if think_fisrt:
                        self.logger.info(self.pre_log_msg + f"{func_name}, think_test, think_fisrt, cur_time: {time.time()}, cost_time: {time.time() - start}")
                        think_fisrt = False
                    result = result.split("</think>")[1]
                result = result.strip('\n')
                if common_dict.get("third_end") and len(result) - len(last_result) > stream_window:
                    if stream_window < 20:
                        stream_window += 2
                    result_new = prompt.post_process(result)
                    third_text = common_dict.get("third_text", "")
                    result_new = "\n\n".join([third_text, result_new])
                    await self.output.run(weibo=self.weibo, ready='no', content=result_new, status_stage=4)
                    last_result = result
            if final_result:
                common_dict["college_token_info"] = {"final_result": final_result, "begin": begin, "first_time": first_time}
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{e}")
            result = ""
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time: {time.time() - start}, result: {json.dumps(result, ensure_ascii=False)}")
        return result

    async def call_public_experience_total_llm(self, prompt, common_dict):
        """大众经验获取流程"""
        start = time.time()
        func_name = "CALL-PUBLIC-EXPERIENCE-TOTAL-LLM"
        if common_dict.get("cur_intention", "") == "只使用掌上高考模式":
            check = False
        else:
            check = True
        if not check or not common_dict["is_available"]:
            result = ""
        else:
            result = await self.call_public_experience_text_llm(prompt, common_dict)
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time: {time.time() - start}, check: {check}, result: {json.dumps(result, ensure_ascii=False)}")
        return result

    async def call_college_llm(self, common_dict):
        """高考流程"""
        prompt = colege_factory(self.weibo)
        tasks = [
            self.call_third_party(common_dict),
            self.call_public_experience_total_llm(prompt, common_dict)
        ]
        third_result, model_result = await asyncio.gather(*tasks)
        if not common_dict["is_available"]:
            return ""
        common_dict["used_third"] = True
        if third_result and model_result:
            self.logger.info(self.pre_log_msg + "\t拼接模式")
        elif third_result:
            self.logger.info(self.pre_log_msg + "\只使用掌上高考模式")
        return await self.call_llm_end(common_dict["college_token_info"], prompt, model_result, third_result, after_content=common_dict["end_content"], check_think=False)

    async def call_ori_llm(self, prompt, common_dict):
        """重写原始大模型调用流程"""
        func_name = "高考相关内容生成"
        start = time.time()
        llm_qwen72b = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_content = prompt.prompt()
        try:
            begin = time.time()
            stream_response = await llm_qwen72b.async_stream_call(prompt_content)
            final_result = None
            first = True
            first_time = 0
            result = ""
            last_result = ""
            stream_window = 10
            async for response in stream_response:
                final_result = response
                result = response.get("text", "")
                result = result.strip('\n')
                if common_dict["used_third"]:
                    break
                if common_dict["is_available"]:
                    continue
                if first:
                    first_time = time.time()
                    self.weibo["debug"]["time_analysis"]["stream_fist_answer"] = first_time
                    self.weibo["debug"]['first_answer'] = first_time
                    first = False
                if len(result) - len(last_result) > stream_window:
                    if stream_window < 20:
                        stream_window += 2
                    result_new = prompt.post_process(result)
                    await self.output.run(weibo=self.weibo, ready='no', content=result_new, status_stage=4)
                    last_result = result
            if final_result:
                common_dict["r1_token_info"] = {"final_result": final_result, "begin": begin, "first_time": first_time}
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"{e}")
            result = ""
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time:{time.time() - start}, result: {json.dumps(result, ensure_ascii=False)}")
        return result

    async def call_college_total(self, prompt, cur_intention):
        """高考整体大模型流程"""
        start = time.time()
        func_name = "CALL-COLLEGE-TOTAL"
        common_dict = {"third_end": False, "third_text": "", "is_available": True, "used_third": False, "cur_intention": cur_intention, "end_content": "",
            "college_token_info": {}, "r1_token_info": {}}
        tasks = [
            self.call_college_llm(common_dict),
            self.call_ori_llm(prompt, common_dict)
        ]
        college_result, ori_result = await asyncio.gather(*tasks)
        if college_result:
            result = college_result
        else:
            self.logger.info(self.pre_log_msg + "\t只使用智搜模式")
            result = await self.call_llm_end(common_dict["r1_token_info"], prompt, ori_result)
        common_dict_keys = ["third_end", "is_available", "used_third"]
        common_dict_log = {key: common_dict[key] for key in common_dict_keys}
        self.logger.info(self.pre_log_msg + f"{func_name}, cost_time:{time.time() - start}, common_dict: {common_dict_log}, result: {json.dumps(result, ensure_ascii=False)}")
        return result

    async def call_llm(self, prompt):
        """重写大模型调用流程"""
        is_need_third = self.weibo.get("is_called_third_party", True)
        gaokao_intention = self.weibo.get("gaokao_intention", "")
        if not is_need_third or gaokao_intention == "只使用智搜模式":
            self.logger.info(self.pre_log_msg + "\t只使用智搜模式")
            return await super().call_llm(prompt)
        return await self.call_college_total(prompt, gaokao_intention)
