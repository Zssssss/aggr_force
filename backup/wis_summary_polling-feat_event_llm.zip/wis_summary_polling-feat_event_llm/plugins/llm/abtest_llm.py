# -*- coding:utf-8 -*-
import asyncio
import copy
import json
import os
import pickle
import traceback

from lib.aiomcq import mcq_cli
from plugins.llm.deepseek import DeepSeekLLM, StreamDeepSeekLLM
from plugins.llm.intervene_llm import InterveneLLM
from plugins.llm.multi_llm import MultiInterveneLLM, MultiDeepseekLLM, MultiInterveneLLMLab1, MultiInterveneLLMLab2, \
    MultiDeepseekLLMLab1, MultiDeepseekLLMLab2

# os.environ['SEARCH_ENV_IP'] = "10.133.168.176"
rollback_queue = mcq_cli(domain="queue.search.weibo.com", port=11233)
SEARCH_ENV_IP = os.environ.get('SEARCH_ENV_IP', "")
SEARCH_ENV_IP_SUFFIX = SEARCH_ENV_IP.split(".")[-1]
ROLLBACK_KEY = "wis_summary_rollback_{}".format(SEARCH_ENV_IP_SUFFIX)
ROLLBACK_DATA = "../rollback_data"
print("SEARCH_ENV_IP: {}, KEY: {}".format(SEARCH_ENV_IP, ROLLBACK_KEY))

def abtest_factory(llm_class, multi_class=None, multi_class_lab_1=None, multi_class_lab_2=None,):
    class ABTester(llm_class):
        def __init__(self, weibo, output, pid, storages):
            super().__init__(weibo, output, pid)
            self.storages = storages
            # 需重新实验组
            self.special_keys = ["lab_h5","lab_h6","lab_h7"]
            self.multi_keys = ['lab_h', 'lab_b']
            self.material_keys = ['lab_m1']
            self.abtests = self.make_abtests()

        def select_llm_class(self, k):
            if multi_class and k == 'lab_h':
                return multi_class
            elif multi_class_lab_1 and k == 'lab_b':
                return multi_class_lab_1
            elif multi_class_lab_2 and k == 'lab_d':
                return multi_class_lab_2
            return llm_class

        def make_abtests(self):
            self.update_pre_log_msg(self.weibo)
            abtest_str = self.weibo.get("abtests")
            sid = self.weibo.get("sid", "")
            abtests = {}
            if abtest_str and sid != 'ab_test_push':
                try:
                    abtest_dict = json.loads(abtest_str)
                    for k, v in abtest_dict.items():
                        abtests[k] = {
                            'abtest': k,
                            'version': v.get("version"),
                            'llm': self.select_llm_class(k)(self.weibo, self.output, self.pid)
                        }
                except Exception as e:
                    self.logger.error(self.pre_log_msg + f"abtest error: {e}")

            self.logger.info(self.pre_log_msg + f"abtest count: {len(abtests)}")
            return abtests

        async def send_response(self, ready, content='', status_stage='', special_tips=""):

            # 对照组
            await super().send_response(ready, content, status_stage, special_tips)

            for key in self.special_keys:
                try:
                    if key in self.abtests:
                        v = self.abtests[key]
                        snapshot = {**self.weibo}
                        snapshot['abtest'] = key
                        snapshot['version'] = v.get("version")
                        snapshot['is_llm_called'] = False
                        llm = v.get("llm")
                        llm.reset(snapshot)
                        await llm.send_response(ready, content, status_stage, special_tips)
                        del snapshot
                except Exception as e:
                    self.logger.error(self.pre_log_msg + f"abtest lab {key} error: {traceback.format_exc()}")

            # 分叉了
            is_forked = self.weibo.get('is_forked', False)
            if is_forked:
                return

            # 实验组
            for k, v in self.abtests.items():
                if k in self.special_keys:
                    continue
                if k in self.material_keys:
                    continue
                snapshot = copy.deepcopy(self.weibo)
                snapshot['abtest'] = k
                snapshot['version'] = v.get("version")
                llm = v.get("llm")
                llm.reset(snapshot)
                await llm.send_response(ready, content, status_stage, special_tips)
                del snapshot

        async def abtest_call_llm(self, ab_name, ab_value):
            # if ab_name == 'lab_zz':
            #     try:
            #         trace_id = self.weibo.get("trace_id", "")
            #         origin_input = self.weibo.get("origin_input", {})
            #         file_path = os.path.join(ROLLBACK_DATA, "{}".format(trace_id))
            #         with open(file_path, 'wb') as f:
            #             pickle.dump(self.weibo, f)
            #
            #         await rollback_queue.set(ROLLBACK_KEY, json.dumps(origin_input))
            #         self.logger.info(self.pre_log_msg + f"abtest lab_zz enqueue")
            #     except Exception as e:
            #         self.logger.error(self.pre_log_msg + f"abtest lab_zz error: {e}")
            #     return ""

            snapshot = copy.deepcopy(self.weibo)
            snapshot['abtest'] = ab_name
            snapshot['version'] = ab_value.get("version")
            llm = ab_value.get("llm")
            llm.reset(snapshot)
            prompt = llm.make_prompt()
            result = await llm.call_llm(prompt)
            if snapshot is not llm.weibo:
                snapshot.update(llm.weibo)
            snapshot['result'] = result
            llm.post_process()
            await asyncio.gather(*[storage.run(weibo=snapshot) for storage in self.storages])
            del snapshot
            return result

        async def call_llm(self, prompt):
            self.weibo['is_forked'] = True

            # 对照组
            tasks = [super().call_llm(prompt)]

            # 实验组
            for k, v in self.abtests.items():
                if k in self.special_keys:
                    continue
                if k in self.material_keys:
                    continue
                tasks.append(self.abtest_call_llm(k, v))
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for idx, r in enumerate(results[1:], start=1):
                if isinstance(r, Exception):
                    self.logger.error(self.pre_log_msg + f"abtest task {idx} error: {r}")
            return results[0]

        async def abtest_run(self, ab_name, ab_value):
            snapshot = copy.deepcopy(self.weibo)
            snapshot['abtest'] = ab_name
            snapshot['version'] = ab_value.get("version")
            llm = ab_value.get("llm")
            llm.reset(snapshot)
            await llm.run()
            await asyncio.gather(*[storage.run(weibo=snapshot) for storage in self.storages])
            return snapshot

        async def run(self, **kwargs):
            # 对照组
            tasks = [super().run()]

            # 实验组
            for k, v in self.abtests.items():
                if k in self.material_keys:
                    tasks.append(self.abtest_run(k, v))
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for idx, r in enumerate(results):
                if isinstance(r, Exception):
                    self.logger.error(f"{self.pre_log_msg} abtest task {idx} error: {r}")


    return ABTester

ABTestInterveneLLM = abtest_factory(InterveneLLM, MultiInterveneLLM, MultiInterveneLLMLab1, MultiInterveneLLMLab2)
ABTestDeepSeekLLM = abtest_factory(DeepSeekLLM, MultiDeepseekLLM, MultiDeepseekLLMLab1, MultiDeepseekLLMLab2)
ABTestStreamDeepSeekLLM = abtest_factory(StreamDeepSeekLLM)
