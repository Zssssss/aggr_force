# -*- coding:utf-8 -*-
import asyncio
import copy
import json
import time
import re
import hashlib
import traceback
from typing import Any

from lib.redis_utils import async_redis_client
from api.model_api import get_deepseek_r1_model_from_weibo_sid, QWEN3_235B_ModelWrapper, QWEN3_30B_XiaoYiWrapper
from plugins.llm.mid_llm import MidLLM
from plugins.prompt.shortcomment import (
                                            ShortCommentBlogProcQuestionPrompt,
                                            ShortCommentBlogProcSummaryPrompt,
                                            ShortCommentBlogProcPrompt,
                                            ShortCommentActivePrompt,
                                            ShortCommentQueryCheckPrompt,
                                            ShortCommentQueryModifyPrompt,
                                            ShortCommentIntentionPrompt,
                                            ShortCommentPrompt,
                                            render_short_comment_system_prompt,
                                            SHORT_COMMENT_QUERY_CHECK_SYSTEM_PROMPT
                                        )
from plugins.material.material import (
                                        MidMaterial,
                                        MidContentAnalysisMaterial,
                                        SummaryMaterial, 
                                        KnowledgeMaterial, 
                                        CoveMaterial, 
                                        PreviousMaterial, 
                                        StockMaterial, 
                                        RiskControlMaterial,
                                        HotquerySql,
                                        GaoKaoAgentMaterial,
                                       )
from plugins.material.multiq_runner import MultiQueryMaterialRunner
# from plugins.material.query_search import SCKeywordTrie


# SCKWT_FILTER = SCKeywordTrie()

def clean_text(content, remove_url=True, remove_sina=True, weibo_at=True,
               remove_emoji=True, weibo_topic=True, remove_space=True,
               remove_puncts=True):
    '''
    去除话题词，链接，@用户，图标，emoji，标点符号，空白符

    :param text: 输入文本
    :param remove_url: （默认使用）是否去除网址链接
    :param remove_sina: （默认使用）是否去除sina链接
    :param weibo_at: （默认不使用）是否去除\@相关文本
    :param remove_emoji: （默认不使用）去除\[\]包围的文本，一般是表情符号
    :param weibo_topic: （默认不使用）去除##包围的文本，一般是话题
    :param remove_puncts: （默认不使用）移除所有标点符号
    :param remove_space: （默认不使用）移除空白符

    :return: 清洗后的文本
    '''

    query = content.replace("\xe2\x80\x8b", "")
    query = re.sub(r'<[^>]+>', '', query)
    if weibo_topic:
        query = re.sub(u"#[^#]*?#", "", query)
    if weibo_at:
        query = re.sub(u"@[^ ]*", "", query)
    if remove_sina:
        query = re.sub(u"<sina.*?>", "", query)
    if remove_url:
        try:
            URL_REGEX = re.compile(
                u'(?i)http[s]?://(?:[a-zA-Z]|[0-9]|[#$%*-;=?&@~.&+]|[!*,])+',
                re.IGNORECASE)
            query = re.sub(URL_REGEX, "", query)
        except:
            # sometimes lead to "catastrophic backtracking"
            zh_puncts1 = u"，；、。！？（）《》【】"
            URL_REGEX = re.compile(
                u'(?i)((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>' + zh_puncts1 + u']+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’' + zh_puncts1 + u']))',
                re.IGNORECASE)
            query = re.sub(URL_REGEX, "", query)
    if remove_emoji:
        # 去除图标 表情
        query = re.sub(u"\[\S+?\]", "", query)
        # 去除真,图标式emoji
        emoji_pattern = re.compile("["
                                   u"\U0001F600-\U0001F64F"  # emoticons
                                   u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                                   u"\U0001F680-\U0001F6FF"  # transport & map symbols
                                   u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                                   u"\U00002702-\U000027B0"
                                   u"\u2600-\u2B55" u"\U00010000-\U0010ffff"
                                   "]+", flags=re.UNICODE)
        query = emoji_pattern.sub('', query)

    query = query.replace("【", "").replace("】", "").replace('\u200b', '').replace("\n", "").replace('\t', '').replace(
        '&nbsp;', '')
    return query.strip()

class ShortCommentLLM(MidLLM):

    def update_pre_log_msg(self, weibo=None):
        super().update_pre_log_msg(weibo)
        prompt_scene = self.weibo.get('prompt_scene', '')
        if prompt_scene:
            self.pre_log_msg = f"{self.pre_log_msg}prompt_scene:{prompt_scene}\t"

    async def fetch_comment_material(self):
        try:
            material_providers = [
                MidContentAnalysisMaterial(self.pid),
                MidMaterial(pid=self.pid),
                SummaryMaterial(pid=self.pid), 
                KnowledgeMaterial(pid=self.pid), 
                CoveMaterial(pid=self.pid), 
                # PreviousMaterial(pid=self.pid),
                StockMaterial(pid=self.pid), 
                RiskControlMaterial(pid=self.pid),
                HotquerySql(pid=self.pid),
                GaoKaoAgentMaterial(pid=self.pid),
            ]
            tasks = [provider.run(weibo=self.weibo) for provider in material_providers]
            await asyncio.gather(*tasks)
            # 结构化
            await SummaryMaterial(self.pid).struct_material(weibo=self.weibo)
            # 截断
            self.logger.info(f"short comment material in commetn_material size: 25000*1.6")
            await self.confine_material_length(base_length=25000*1.6)
        except Exception:
            self.logger.error(f"error fetch comment material: {traceback.format_exc()}")

    async def call_qwen235b_llm(self, usr_prompt_str: str, sys_prompt_str: str='', enable_thinking=False):
        llm_cls = QWEN3_235B_ModelWrapper(self.weibo, pid=self.pid, pre_log_msg=self.pre_log_msg, llm_call_stage="判断用户@微博智搜是否属于闲聊")
        llm_result = {}
        for _ in range(2):
            try:
                llm_result = await llm_cls.async_call(prompt=usr_prompt_str, sys_prompt=sys_prompt_str, enable_thinking=enable_thinking)
                if llm_result:
                    break
            except Exception:
                self.logger.warning(f"retry call qwen235b llm: {traceback.format_exc()}")
        if not llm_result:
            self.logger.error(self.pre_log_msg + "short comment query modify qwen235b call fail, query: %s" % usr_prompt_str)
        
        return llm_result
    
    async def call_qwen30b_llm(self, usr_prompt_str: str, llm_call_stage: str):
        llm_cls = QWEN3_30B_XiaoYiWrapper(self.weibo, pid=self.pid, pre_log_msg=self.pre_log_msg, llm_call_stage=llm_call_stage)
        llm_result = {}
        for _ in range(2):
            try:
                llm_result = await llm_cls.async_call(prompt=usr_prompt_str)
                if llm_result:
                    break
            except Exception:
                self.logger.warning(f"retry call qwen30b llm: {traceback.format_exc()}")
        if not llm_result:
            self.logger.error(self.pre_log_msg + "short comment query modify qwen30b call fail, query: %s" % usr_prompt_str)
        
        return llm_result
    
    async def process_query_modify_with_llm(self):
        try:
            self.weibo["debug"]["time_analysis"][f"proc_query_modify_sc_start"] = time.time()
            user_prompt_cls = ShortCommentQueryModifyPrompt(self.weibo)
            user_prompt = user_prompt_cls.prompt()
            
            self.weibo['query_modify_usr_prompt'] = user_prompt
            llm_result = await self.call_qwen30b_llm(usr_prompt_str=user_prompt, llm_call_stage="用户问题拆解")
            
            self.weibo['query_modify_llm_res'] = llm_result.get('text', '')
            query_list = user_prompt_cls.post_process(llm_result.get('text', ''))
            if isinstance(query_list, list):
                
                self.weibo['query_modify_query_list'] = query_list
                self.weibo['mid2modify_list'] = query_list[:3]
                self.logger.info(self.pre_log_msg + f"short comment query modify(30b) llm query list(after query_modify): {query_list}")
            self.weibo["debug"]["time_analysis"][f"proc_query_modify_sc_end"] = time.time()
        except Exception:
            self.logger.error(f"error process query modify with llm: {traceback.format_exc()}")

    async def process_query_check_with_llm(self):
        try:
            self.weibo["debug"]["time_analysis"][f"proc_query_check_sc_start"] = time.time()
            user_prompt_cls = ShortCommentQueryCheckPrompt(self.weibo)
            user_prompt = user_prompt_cls.prompt()
            
            self.weibo['query_check_usr_prompt'] = user_prompt
            llm_result = await self.call_qwen235b_llm(usr_prompt_str=user_prompt, sys_prompt_str=SHORT_COMMENT_QUERY_CHECK_SYSTEM_PROMPT, enable_thinking=True)
            
            self.weibo['query_check_llm_res'] = llm_result.get('text', '')
            is_chat = user_prompt_cls.post_process(llm_result.get('text', ''))
                
            self.weibo['is_chat'] = is_chat
            self.logger.info(self.pre_log_msg + f"short comment query check(235b) llm is_chat: {is_chat}")
            self.weibo["debug"]["time_analysis"][f"proc_query_check_sc_end"] = time.time()
        except Exception:
            self.logger.error(f"error process query check with llm: {traceback.format_exc()}")

    async def process_active_cmt_with_llm(self):
        normal_reply_flag = False
        try:
            if self.get_comment_type() != 'active_comment':
                return
            self.weibo["debug"]["time_analysis"][f"proc_active_cmt_sc_start"] = time.time()
            user_prompt_cls = ShortCommentActivePrompt(self.weibo)
            user_prompt = user_prompt_cls.prompt()
            llm_res_1 = await self.call_qwen30b_llm(usr_prompt_str=user_prompt, llm_call_stage="用户问题分类")
            if isinstance(llm_res_1, dict) and llm_res_1.get('text', ''):
                label = user_prompt_cls.post_process(llm_res_1.get('text', ''))
                self.logger.info(self.pre_log_msg + f"short comment active cmt 30b label: {label}")
                if label == '信息获取、求证类':
                    # 继续R1
                    llm_call = get_deepseek_r1_model_from_weibo_sid(self.weibo.get("sid", ""))(self.weibo, self.pid, self.pre_log_msg, "评论回复_前置判断")
                    llm_res_2 = await llm_call.async_call(prompt=user_prompt)
                    if isinstance(llm_res_2, dict) and llm_res_2.get('text', ''):
                        label = user_prompt_cls.post_process(llm_res_2.get('text', ''))
                        self.logger.info(self.pre_log_msg + f"short comment active cmt r1 label: {label}")
                        if label == '信息获取、求证类':
                            normal_reply_flag = True
                            self.logger.warning(self.pre_log_msg + f"short comment active not reply with cmt r1 label: {label}")
                            self.weibo['sc_normal_reply_flag'] = normal_reply_flag

        except Exception:
            self.logger.error(self.pre_log_msg + f"error process active cmt with llm: {traceback.format_exc()}")
            self.weibo["debug"]["time_analysis"][f"proc_active_cmt_sc_end"] = time.time()
        
        self.weibo['sc_normal_reply_flag'] = normal_reply_flag
        self.logger.info(self.pre_log_msg + f"short comment active cmt normal_reply_flag: {normal_reply_flag}")

    async def process_blog_with_llm(self):
        """判断是否需要生成回复
        问答：
        总结：
        """
        normal_reply_flag = False
        try:
            if self.weibo.get('prompt_scene') != 'direct_comment':
                return
            mid_from_type = self.get_blog_type()
            blog_content = self.weibo.get('sc_mid_ori_content', '')
            self.weibo["debug"]["time_analysis"][f"proc_blog_sc_start"] = time.time()
            if mid_from_type == 'summary':
                user_prompt_cls = ShortCommentBlogProcSummaryPrompt(self.weibo)
            else:
                if "@微博智搜" in blog_content:
                    normal_reply_flag = True
                    self.logger.info(self.pre_log_msg + f"short comment blog proc {mid_from_type} 30b label: @微博智搜问答\tnormal_reply_flag: {normal_reply_flag}")
                    self.weibo['sc_blog_normal_reply_flag'] = normal_reply_flag
                    self.weibo["debug"]["time_analysis"][f"proc_blog_sc_end"] = time.time()
                    return
                user_prompt_cls = ShortCommentBlogProcQuestionPrompt(self.weibo)
            user_prompt = user_prompt_cls.prompt()
            llm_res = await self.call_qwen30b_llm(usr_prompt_str=user_prompt, llm_call_stage="判断博文是否适合回复")
            if isinstance(llm_res, dict) and llm_res.get('text', ''):
                label = user_prompt_cls.post_process(llm_res.get('text', ''))
                if mid_from_type == 'summary' and label == '适合总结':
                    normal_reply_flag = True
                if mid_from_type == 'question' and label == '是':
                    normal_reply_flag = True
                self.logger.info(self.pre_log_msg + f"short comment blog proc {mid_from_type} 30b label: {label}\tnormal_reply_flag: {normal_reply_flag}")

        except Exception:
            self.logger.error(self.pre_log_msg + f"error process active cmt with llm: {traceback.format_exc()}")

        self.weibo["debug"]["time_analysis"][f"proc_blog_sc_end"] = time.time()
        
        self.weibo['sc_blog_normal_reply_flag'] = normal_reply_flag
        self.logger.info(self.pre_log_msg + f"short comment blog_sc normal_reply_flag: {normal_reply_flag}")
    
    def get_comment_type(self) -> str:
        try:
            q_attr = self.weibo.get('q_attr', '{}')
            q_attr_dict = json.loads(q_attr)
            comment_from_type = q_attr_dict.get('comment_from_type', '')
            return comment_from_type
        except Exception:
            self.logger.error(f"error get comment type: {traceback.format_exc()}")
            return ''
    def get_blog_type(self) -> str:
        """
        reply_type: 
                2 -> summary
                1 -> question
        mid_from_type:
        分两类，商业带b_前缀
        """
        try:
            q_attr = self.weibo.get('q_attr', '{}')
            q_attr_dict = json.loads(q_attr)
            # mid_from_type = q_attr_dict.get('mid_from_type', '')
            # return mid_from_type
            reply_type = q_attr_dict.get('reply_type', 0)
            if not isinstance(reply_type, int):
                raise TypeError(f"reply_type is not int: {type(reply_type)}:{reply_type}")
            return 'question' if reply_type == 1 else 'summary'

        except Exception:
            self.logger.error(f"error get blog reply type: {traceback.format_exc()}")
            return ''
    
    def is_active_cmt_normal(self) -> bool:
        """
        0. 判断是否是评论流程
        1. 判断是否是主动评论
        2. 判断是否是'信息获取、求证类'
        1满足2满足 -> True(回复)
        """
        prompt_scene = self.weibo.get('prompt_scene')
        if prompt_scene != "verification_comment" :
            # 不属于评论流程，直接返回True，不进行判断
            return True
        comment_from_type = self.get_comment_type()
        if comment_from_type != 'active_comment':
            # 不属于主动评论，直接返回True，不进行判断
            return True
        if self.weibo.get('comment_uid', '') in ['5762999670', '5606716867']:
            self.logger.info(self.pre_log_msg + f"short comment active cmt hit black uid: {self.weibo.get('comment_uid', '')}")
            return False
        res = self.weibo.get('sc_normal_reply_flag', False)
        if not res:
            self.logger.info(self.pre_log_msg + f"short comment [active cmt] not reply with sc_normal_reply_flag: {res}")
        return res

    def check_material_length(self) -> bool:
        """
        1. 判断midmaterial是否存在， mid_content, nick_name
        """
        mid_content = self.weibo.get('mid_content', '')
        sc_mid_ori_content = self.weibo.get('sc_mid_ori_content', '')
        if len(mid_content) < 7:
            self.logger.warning(self.pre_log_msg + f"short comment material check mid_content < 7 return False: {mid_content}")
            return False
        if not sc_mid_ori_content:
            self.logger.warning(self.pre_log_msg + f"short comment material check sc_mid_ori_content < 1 return False: {sc_mid_ori_content}")
            return False
        
        return True
        
    
    def is_blog_normal(self) -> bool:
        """
        1. 判断是否是发博源
        2. 判断是否需要回复
        1满足2满足 -> True(回复)
        """
        prompt_scene = self.weibo.get('prompt_scene', '')
        if prompt_scene != 'direct_comment':
            # 不属于发博源，直接返回True，不进行判断
            return True
        res=  self.weibo.get('sc_blog_normal_reply_flag', False)
        if not res:
            self.logger.info(self.pre_log_msg + f"short comment [blog] not reply with sc_blog_normal_reply_flag: {res}")
        return res

    async def query_modify(self):
        """意图改写 -> 3"""
        try: 
            self.weibo["debug"]["time_analysis"][f"fetch_comment_m_sc_start"] = time.time()
            await self.fetch_comment_material()
            self.weibo["debug"]["time_analysis"][f"fetch_comment_m_sc_end"] = time.time()
            # if self.is_blog_not_reply_by_filter():
            prompt_scene = self.weibo.get('prompt_scene')
            if not self.check_material_length():
                return
            if prompt_scene == "verification_comment" :
            
                await self.process_active_cmt_with_llm()
                if not self.is_active_cmt_normal():
                    return
                
            elif prompt_scene == "direct_comment":
                await self.process_blog_with_llm()
                if not self.is_blog_normal():
                    return
            await self.process_query_modify_with_llm()
        except Exception:
            self.logger.error(f"error query_modify: {traceback.format_exc()}")
    
    async def fetch_material(self):
        try:
            # if self.is_blog_not_reply_by_filter():
            #     return
            if not self.check_material_length():
                return
            if not self.is_active_cmt_normal():
                return
            if not self.is_blog_normal():
                return
            
            await self.fetch_merge_struct_material()
        except:
            self.logger.exception(f"error fetch material: {traceback.format_exc()}")
    
    async def struct_material(self):
        pass

    async def fetch_merge_struct_material(self):
        query_list = self.weibo.get("mid2modify_list", [])
        multi_q_runner = MultiQueryMaterialRunner(self.pid)
        await multi_q_runner.run(self.weibo, query_list)
        
    def make_prompt(self):
        # if self.is_blog_not_reply_by_filter():
        #     return
        if not self.check_material_length():
            return
        if not self.is_active_cmt_normal():
            return
        if not self.is_blog_normal():
            return
        prompt = ShortCommentPrompt(self.weibo)
        return prompt

    # async def intention(self, llm_call):
    #     if self.is_blog_not_reply_by_filter():
    #         return
    #     if not self.is_active_cmt_normal():
    #         return
    #     if not self.is_blog_normal():
    #         return
        
    #     all_begin = time.time()
    #     prompt = ShortCommentIntentionPrompt(self.weibo)
    #     retry = 2
    #     for i in range(retry):
    #         try:
    #             begin = time.time()
    #             response = await llm_call.async_call(prompt.prompt())
    #             await self.count_tokens(response, begin)
    #             ori_result = response.get("text", "")
    #             if not ori_result:
    #                 self.logger.warning(self.pre_log_msg + f"comment intention llm returned empty")
    #                 continue
    #             result = prompt.post_process(ori_result)
    #             self.logger.info(
    #                 self.pre_log_msg + f"comment intention ori:{json.dumps(ori_result, ensure_ascii=False)}, "
    #                                    f"result: {json.dumps(result, ensure_ascii=False)} cost:{time.time() - begin}")
    #             return result
    #         except Exception as e:
    #             self.logger.error(
    #                 self.pre_log_msg + f"comment intention error: {e} cost: {time.time() - all_begin}, retry: {i}")
    #     return '其他'
    
    async def call_llm(self, prompt):
        def _precheck() -> tuple[bool, int]:
            """False代表跳过, 提前返回, 仅在物料不足时，需要发送前端信号‘无需回复-原博无内容’"""
            if not self.check_material_length():
                return False, 0
            if not self.is_active_cmt_normal():
                return False, 1
            if not self.is_blog_normal():
                self.logger.info(self.pre_log_msg + f"blog not reply by proc")
                return False, 2
            return True, -1
        try:
            # if self.is_blog_not_reply_by_filter():
            #     self.weibo['zs_not_reply'] = 3
            #     await self.output.run(weibo=self.weibo, ready='yes', content='风控命中，不回复', status_stage=4)
            #     return
            need_call_llm, err_code = _precheck()
            content = ''
            if need_call_llm:
                # results = await asyncio.gather(
                #     self.process_query_check_with_llm(),
                #     self._call_llm4comment(prompt),
                #     return_exceptions=True
                # )
                # if isinstance(results[1], Exception):
                #     self.logger.error(self.pre_log_msg + f"error call llm: {traceback.format_exc()}")
                # elif isinstance(results[1], str):
                #     content = results[1]
                content = await self._call_llm4comment(prompt)
                await self.calc_question(content)
            else:
                if err_code == 0:
                    content = '无需回复-原博无内容'
                    self.weibo['zs_not_reply'] = 2
                    await self.output.run(weibo=self.weibo, ready='yes' if content else 'error', content=content, status_stage=4)
                    self.logger.warning(self.pre_log_msg + f"comment not reply because error code: {err_code}")
            return content
        except Exception:
            self.logger.error(f"error call llm: {traceback.format_exc()}")
        return ''
        
    async def save_res(self, result: str):
        try:
            # redis 2day过期
            mid = self.weibo.get('mid', '')
            cid = self.weibo.get('cid', '')
            comment_str = self.weibo.get('comment', '')
            # mid + comment_str = key
            if len(comment_str) <= 15:
                return
            _hash = hashlib.md5(f"{mid}_{comment_str}".encode()).hexdigest()
            key = f"{mid}:{_hash}"
            cli = async_redis_client.get_redis_server(key)
            count = await cli.incr(key)
            if count == 1:
                await cli.expire(key, 2 * 24 * 60 * 60)
            self.logger.info(self.pre_log_msg + f"save count: {count}")
        except Exception:
            self.logger.error(f"error save res: {traceback.format_exc()}")
        
    async def is_repeat_cmt(self) -> bool:
        # 同一条微博下的3条相同评论不再回复
        try:
            mid = self.weibo.get('mid', '')
            comment_str = self.weibo.get('comment', '')
            # mid + comment_str = key
            # 评论内容为@微博智搜时，不保存
            if len(comment_str) <= 15:
                return False
            _hash = hashlib.md5(f"{mid}_{comment_str}".encode()).hexdigest()
            key = f"{mid}:{_hash}"
            cli = async_redis_client.get_redis_server(key)
            count = await cli.get(key)
            if count is None:
                count = 0
            else:
                count = int(count)
            if count >= 3:
                self.logger.info(self.pre_log_msg + f"repeat cmt count: {count}, cmt: {comment_str}, key: {key}, return True")
                return True
        except Exception:
            self.logger.error(f"error is repeat cmt: {traceback.format_exc()}")
        return False
        

    async def _call_llm4comment(self, prompt):
        begin = time.time()
        sid = self.weibo.get("sid", "")
        content = ""
        comment = self.weibo.get("comment", "").strip()
        prompt_scene = self.weibo.get("prompt_scene", "")
        comment_from_type = self.get_comment_type()
        no_think = False
        # 评论+非主动评论-> deepseek-v3.1-terminus
        if prompt_scene == 'verification_comment' and comment_from_type != 'active_comment':
            self.weibo['use_model'] = 'deepseek-v3.1-terminus'
            no_think = True
            self.logger.info(self.pre_log_msg + f"use model: {self.weibo['use_model']}")
        llm_call = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "评论回复")
        # self.weibo["debug"]["time_analysis"][f"intention_start"] = time.time()
        # if comment == '@微博智搜':
        #     intention = '求证'
        # else:
        #     intention = await self.intention(llm_call)
        # self.weibo["debug"]["time_analysis"][f"intention_end"] = time.time()
        self.weibo["debug"]["time_analysis"][f"verification_start"] = time.time()
        # self.weibo['type'] = intention
        self.weibo['type'] = '求证'
        # if intention == '求证':
        for i in range(3):
            try:
                prompt_content = prompt.prompt()
                sys_prompt_content = render_short_comment_system_prompt(self.weibo)
                response = await llm_call.async_call(prompt_content, system_prompt=sys_prompt_content, no_think=no_think)
                await self.count_tokens(response, begin)
                if not isinstance(response, dict):
                    self.logger.warning(self.pre_log_msg + f"comment llm returned not dict: {response}")
                    continue
                ori_result = response.get("text", "")
                if not ori_result:
                    self.logger.warning(self.pre_log_msg + f"comment llm returned empty")
                    continue
                self.weibo['ori_result'] = ori_result
                
                self.weibo['ori_prompt'] = response.get('prompt', '')
                result = prompt.post_process(ori_result)
                self.logger.info(self.pre_log_msg + "result: {}".format(json.dumps(result, ensure_ascii=False)))
                if len(result) > 400 or len(result) < 1:
                    self.logger.warning(self.pre_log_msg + f"result: {json.dumps(result, ensure_ascii=False)}, too short / too long")
                    content = result
                    self.weibo['too_long'] = True
                    continue
                if '无需回复' in result:
                    self.logger.info(self.pre_log_msg + f"comment: {comment}\tresult: {json.dumps(result, ensure_ascii=False)}, not reply & direct return")
                    self.weibo['zs_not_reply'] = 1
                content = result
                await self.save_res(result)
                # if SCKWT_FILTER.search(result):
                #     self.logger.info(self.pre_log_msg + f"llm result hit zs_not_reply_3: {result}, not reply & direct return")
                #     self.weibo['zs_not_reply'] = 3
                #     content = '风控命中，不回复'
                break
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"short comment error:{e}, msg:{traceback.format_exc()}")

        self.weibo["debug"]["time_analysis"][f"verification_end"] = time.time()
        await self.output.run(weibo=self.weibo, ready='yes' if content else 'error', content=content, status_stage=4)
        return content
    
    # def is_blog_not_reply_by_filter(self) -> bool:
    #     """
    #     根据过滤器判断是否不回复
    #     """
    #     if self.weibo.get('blog_not_reply_by_filter', False):
    #         return True
    #     # 博文内容
    #     blog_content = self.weibo.get('mid_content', '')
    #     # 评论内容
    #     comment_content = self.weibo.get('comment', '')

    #     if SCKWT_FILTER.search(blog_content) or SCKWT_FILTER.search(comment_content):
    #         self.logger.info(self.pre_log_msg + f"blog_content: {blog_content}, comment_content: {comment_content}, not reply with 3 & direct return")
    #         self.weibo['blog_not_reply_by_filter'] = True
    #         return True
    #     return False

    
    async def run(self, **kwargs):
        repeat_cmt_flag = await self.is_repeat_cmt()
        if repeat_cmt_flag:
            self.weibo['zs_not_reply'] = 2
            await self.output.run(weibo=self.weibo, ready='yes', content='重复评论', status_stage=4)
            return
        comment_str = self.weibo.get('comment', '')
        cleaned_text = clean_text(comment_str)
        if not cleaned_text:
            self.weibo['zs_not_reply'] = 2
            await self.output.run(weibo=self.weibo, ready='yes', content='无实质评论', status_stage=4)
            return
        
        await super().run(**kwargs)
