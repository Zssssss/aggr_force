import asyncio
import copy
import traceback
import json
from typing import Any
import time

from plugins.llm.deepseek import DeepSeekLLM, StreamDeepSeekLLM
from plugins.prompt.mid import mid_factory
from plugins.material.material import (
                                        MidMaterial,
                                        MidContentAnalysisMaterial,
                                        SummaryMaterial, 
                                        KnowledgeMaterial, 
                                        CoveMaterial, 
                                        PreviousMaterial, 
                                        StockMaterial, 
                                        RiskControlMaterial,
                                        HotquerySql,
                                        URLSINAMaterial
                                       )
from plugins.prompt.annotation import AnnotationPrompt, AnnotationIntention
from plugins.prompt.annotation import TitlePrompt
from api.model_api import get_deepseek_r1_model_from_weibo_sid
from plugins.llm.annotation_llm import matches_pattern


class UrlLLM(DeepSeekLLM):

    async def fetch_material(self):
        try:
            await URLSINAMaterial(self.pid).run(weibo=self.weibo)
            url_sina_content_dict = self.weibo.get('url_sina_content', {})
            if url_sina_content_dict:
                await self.fetch_merge_struct_material(list(url_sina_content_dict.values()))
            else:
                raise Exception("no url_sina_content")

        except:
            self.logger.exception(f"error fetch material: {traceback.format_exc()}")

    async def struct_material(self):
        pass

    def make_prompt(self):
        return mid_factory(self.weibo)
    
    async def generate_news_title(self):
        begin = time.time()
        sid = self.weibo.get('sid', "")
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        trace_id = self.weibo.get("trace_id", "")
        try:
            prompt = TitlePrompt(self.weibo)
            llm = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "标题生成")
            prompt_content = prompt.prompt()
            response = await llm.async_call(prompt_content)
            await self.count_tokens(response, begin)
            title_result = response.get("text", "")
            result = prompt.post_process(title_result)
            self.weibo['news_title'] = result
            if not result.strip():
                self.logger.error(
                    "query:{}, traceid:{} result is empty".format(query, trace_id))
                return
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} llm error: {}, cost:{}".format(
                    query, str(e), trace_id, e, time.time() - begin))
    
    async def generate_verification_flag(self):
        begin = time.time()
        sid = self.weibo.get('sid', "")
        ori_result = self.weibo.get("ori_result", "")
        is_verification, exclusion = matches_pattern(ori_result)
        self.weibo['news_analyze_flag'] = is_verification # 是否求证
        if not is_verification:
            self.logger.info(
                self.pre_log_msg + f"news_analyze_flag: {is_verification}, exclusion: {exclusion}")
            return
        
        # 判断是否求证
        llm = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "求证判断")
        prompt = AnnotationIntention(self.weibo)
        annotation_intention_prompt = prompt.prompt()
        response = await llm.async_call(annotation_intention_prompt)
        await self.count_tokens(response, begin)
        annotation_intention_result = response.get("text", "")
        is_verification = prompt.post_process(annotation_intention_result)
        self.weibo['news_analyze_flag'] = is_verification
        self.logger.info(self.pre_log_msg + f"news intention: {is_verification}")
        if not is_verification:
            self.logger.info(
                self.pre_log_msg + f"news verification: {is_verification}, result: {json.dumps(annotation_intention_result, ensure_ascii=False)}")
            return
            
    async def generate_abstract(self):
        begin = time.time()
        sid = self.weibo.get('sid', "")
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        trace_id = self.weibo.get("trace_id", "")
        try:
            prompt = AnnotationPrompt(self.weibo)
            llm = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "求证生成")
            response = await llm.async_call(prompt.prompt())
            await self.count_tokens(response, begin)
            annotation_result = response.get("text", "")
            result, value = prompt.post_process(annotation_result)
            self.weibo['news_analyze_category'] = result # 分析类别
            self.logger.info(
                self.pre_log_msg + f"news_analyze_category: {result}")
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} llm error: {}, cost:{}".format(
                    query, str(e), trace_id, e, time.time() - begin))

    async def call_generate_extra_info(self):
        self.weibo["mid_content"] = self.weibo.get("url_sina_content", {}).get("content")
        await asyncio.gather(
            self.generate_news_title(),
            self.generate_abstract(),
            self.generate_verification_flag()
        )

    def rerank_weibo(self, weibo_list: list[list[dict[str, Any]]]) -> tuple[list[dict[str, Any]], list[str]]:
        top_weibo_list, other_weibo_list = [], []
        top_mid_list, other_mid_list = [], []
        for weibo in weibo_list:
            struct_content_list = weibo.get('struct_content_list', [])
            mid_list = weibo.get('mid_list', [])
            for mid, item in zip(mid_list, struct_content_list):
                if item.get("is_good", 0) >= 1:
                    if mid not in top_mid_list: 
                        top_weibo_list.append(item)
                        top_mid_list.append(mid)
                else:
                    if mid not in other_mid_list:
                        other_weibo_list.append(item)
                        other_mid_list.append(mid)
        return top_weibo_list + other_weibo_list, top_mid_list + other_mid_list
    
    def merge_material_list(self, m_group: list[list[dict[str, Any]]]) -> list[dict[str, Any]]:
        """去重"""
        res = []
        seen = set()
        for m_list in m_group:
            for m in m_list:
                key = json.dumps(m, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    res.append(m)
        return res

    def merge_material_bool(self, m_group: list[bool]) -> bool:
        return any(m_group)
    
    def merge_material_dict(self, m_group: list[dict[Any, Any]]) -> dict[Any, Any]:
        res = {}
        for m_dict in m_group:
            res.update(m_dict)
        return res

    def merge_material_str_list(self, m_group: list[list[str]]) -> list[str]:
        seen = set()
        res = []
        for m_list in m_group:
            for item in m_list:
                if item not in seen:
                    seen.add(item)
                    res.append(item)
        return res

    async def fetch_merge_struct_material(self, query_list: list[str]):
        weibo_list = [copy.deepcopy(self.weibo) for _ in range(len(query_list))]
        for idx, item in enumerate(query_list):
            weibo_list[idx]['query'] = item

        m_providers = [
            SummaryMaterial(self.pid), 
            KnowledgeMaterial(self.pid),
            CoveMaterial(self.pid),
            # PreviousMaterial(self.pid),
            StockMaterial(self.pid),
            RiskControlMaterial(self.pid),
            HotquerySql(self.pid)
        ]
        async def _fetch_once(weibo: dict):
            await asyncio.gather(*[provider.run(weibo=weibo) for provider in m_providers])
            await SummaryMaterial(self.pid).struct_material(weibo=weibo)

        tasks = [_fetch_once(w) for w in weibo_list]
        await asyncio.gather(*tasks)

        main_weibo, *other_weibo_list = weibo_list
        # 文章数量
        if 'sina_article_data' in main_weibo:
            main_weibo['sina_article_data'] = main_weibo['sina_article_data'][:3]
        for o_weibo in other_weibo_list:
            if 'sina_article_data' in o_weibo:
                o_weibo['sina_article_data'] = o_weibo['sina_article_data'][:1]
        # weibo 按照top排序
        merged_weibo = self.weibo
        try:
            struct_content_list, mid_list = self.rerank_weibo(weibo_list)
            merged_weibo["struct_content_list"] = struct_content_list
            merged_weibo["mid_list"] = mid_list
        except Exception:
            self.logger.error(f"rerank & merge weibo error: {traceback.format_exc()}")

        for key in ['sina_article_data', 'baike_knowledge', 'history_hot_res',
                    'gaokao_agent_result', 'star_ip_result', 'current_hot_res',
                    'stock_info', 'hot_query_res', 'zs_knowledge', 'user_search_res',
                    'video_mid_list']:
            try:
                merged_weibo[key] = self.merge_material_list([weibo.get(key, []) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge list {key} error: {traceback.format_exc()}")

        for key in ['ready_pid_dict', 'pid_dup_dic', 'pic_info_dict_all', 'video_mid_dict',
                    'mid_feature_dict']:
            try:
                merged_weibo[key] = self.merge_material_dict([weibo.get(key, {}) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge dict {key} error: {traceback.format_exc()}")
        
        for key in ['blog_analysis_flag']:
            try:
                merged_weibo[key] = self.merge_material_bool([weibo.get(key, False) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge bool {key} error: {traceback.format_exc()}")
        
        try:
            merged_cove_material_list = self.merge_material_str_list([weibo.get('cove_material', []) for weibo in weibo_list])
            merged_weibo['knowledge'] = '\n'.join(merged_cove_material_list).strip()
        except Exception:
            self.logger.error(f"merge list 'cove_material' error: {traceback.format_exc()}")

class StreamUrlLLM(StreamDeepSeekLLM):

    async def fetch_material(self):
        try:
            await asyncio.gather(
                super().create_status_task(1),
                URLSINAMaterial(self.pid).run(weibo=self.weibo)
            )
            url_sina_content_dict = self.weibo.get('url_sina_content', {})
            if url_sina_content_dict:
                await self.fetch_merge_struct_material(list(url_sina_content_dict.values()))
            else:
                raise Exception("no url_sina_content")

        except:
            self.logger.exception(f"error fetch material: {traceback.format_exc()}")

    async def struct_material(self):
        await super().create_status_task(2)
        pass

    def make_prompt(self):
        return mid_factory(self.weibo)

    def rerank_weibo(self, weibo_list: list[list[dict[str, Any]]]) -> tuple[list[dict[str, Any]], list[str]]:
        top_weibo_list, other_weibo_list = [], []
        top_mid_list, other_mid_list = [], []
        for weibo in weibo_list:
            struct_content_list = weibo.get('struct_content_list', [])
            mid_list = weibo.get('mid_list', [])
            for mid, item in zip(mid_list, struct_content_list):
                if item.get("is_good", 0) >= 1:
                    if mid not in top_mid_list: 
                        top_weibo_list.append(item)
                        top_mid_list.append(mid)
                else:
                    if mid not in other_mid_list:
                        other_weibo_list.append(item)
                        other_mid_list.append(mid)
        return top_weibo_list + other_weibo_list, top_mid_list + other_mid_list
    
    def merge_material_list(self, m_group: list[list[dict[str, Any]]]) -> list[dict[str, Any]]:
        """去重"""
        res = []
        seen = set()
        for m_list in m_group:
            for m in m_list:
                key = json.dumps(m, sort_keys=True)
                if key not in seen:
                    seen.add(key)
                    res.append(m)
        return res

    def merge_material_bool(self, m_group: list[bool]) -> bool:
        return any(m_group)
    
    def merge_material_dict(self, m_group: list[dict[Any, Any]]) -> dict[Any, Any]:
        res = {}
        for m_dict in m_group:
            res.update(m_dict)
        return res

    def merge_material_str_list(self, m_group: list[list[str]]) -> list[str]:
        seen = set()
        res = []
        for m_list in m_group:
            for item in m_list:
                if item not in seen:
                    seen.add(item)
                    res.append(item)
        return res

    async def fetch_merge_struct_material(self, query_list: list[str]):
        weibo_list = [copy.deepcopy(self.weibo) for _ in range(len(query_list))]
        for idx, item in enumerate(query_list):
            weibo_list[idx]['query'] = item

        m_providers = [
            SummaryMaterial(self.pid), 
            KnowledgeMaterial(self.pid),
            CoveMaterial(self.pid),
            # PreviousMaterial(self.pid),
            StockMaterial(self.pid),
            RiskControlMaterial(self.pid),
            HotquerySql(self.pid)
        ]
        async def _fetch_once(weibo: dict):
            await asyncio.gather(*[provider.run(weibo=weibo) for provider in m_providers])
            await SummaryMaterial(self.pid).struct_material(weibo=weibo)

        tasks = [_fetch_once(w) for w in weibo_list]
        await asyncio.gather(*tasks)

        main_weibo, *other_weibo_list = weibo_list
        # 文章数量
        if 'sina_article_data' in main_weibo:
            main_weibo['sina_article_data'] = main_weibo['sina_article_data'][:3]
        for o_weibo in other_weibo_list:
            if 'sina_article_data' in o_weibo:
                o_weibo['sina_article_data'] = o_weibo['sina_article_data'][:1]
        # weibo 按照top排序
        merged_weibo = self.weibo
        try:
            struct_content_list, mid_list = self.rerank_weibo(weibo_list)
            merged_weibo["struct_content_list"] = struct_content_list
            merged_weibo["mid_list"] = mid_list
        except Exception:
            self.logger.error(f"rerank & merge weibo error: {traceback.format_exc()}")

        for key in ['sina_article_data', 'baike_knowledge', 'history_hot_res',
                    'gaokao_agent_result', 'star_ip_result', 'current_hot_res',
                    'stock_info', 'hot_query_res', 'zs_knowledge', 'user_search_res',
                    'video_mid_list']:
            try:
                merged_weibo[key] = self.merge_material_list([weibo.get(key, []) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge list {key} error: {traceback.format_exc()}")

        for key in ['ready_pid_dict', 'pid_dup_dic', 'pic_info_dict_all', 'video_mid_dict',
                    'mid_feature_dict']:
            try:
                merged_weibo[key] = self.merge_material_dict([weibo.get(key, {}) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge dict {key} error: {traceback.format_exc()}")
        
        for key in ['blog_analysis_flag']:
            try:
                merged_weibo[key] = self.merge_material_bool([weibo.get(key, False) for weibo in weibo_list])
            except Exception:
                self.logger.error(f"merge bool {key} error: {traceback.format_exc()}")
        
        try:
            merged_cove_material_list = self.merge_material_str_list([weibo.get('cove_material', []) for weibo in weibo_list])
            merged_weibo['knowledge'] = '\n'.join(merged_cove_material_list).strip()
        except Exception:
            self.logger.error(f"merge list 'cove_material' error: {traceback.format_exc()}")
