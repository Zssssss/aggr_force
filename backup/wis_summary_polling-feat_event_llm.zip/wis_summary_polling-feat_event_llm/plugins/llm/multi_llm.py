# -*- coding:utf-8 -*-
import asyncio
import copy
import json

import aiohttp
from aiohttp import ClientTimeout

from plugins.llm.deepseek import DeepSeekLLM
from plugins.llm.intervene_llm import InterveneLLM



def multi_factory(llm_class, lab):
    class MultiLLM(llm_class):
        def __init__(self, weibo, output, pid):
            super().__init__(weibo, output, pid)
            self.llms = [llm_class(weibo, output, pid) for _ in range(5)]

        async def calc_ctr_score(self, query, content):
            url = "http://10.133.169.246:5057/predict"
            headers = {'Content-Type': 'application/json'}
            data = {
                "content": content,
                "query": query
            }

            timeout_obj = ClientTimeout(total=2)
            try:
                async with aiohttp.ClientSession(timeout=timeout_obj) as session:
                    async with session.post(url, json=data, headers=headers) as response:
                        if response.status == 200:
                            result = await response.json()
                            self.logger.info(self.pre_log_msg + f"{json.dumps(content, ensure_ascii=False)} ctr score {result}")
                            return result[0]
            except asyncio.TimeoutError:
                self.logger.error(self.pre_log_msg + f"ctr timeout error")
            except aiohttp.ClientError as e:
                self.logger.error(self.pre_log_msg + f"ctr ClientError error: {e}")
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"ctr exception error: {e}")
            return 0

        async def multi_call_llm_impl(self, llm):
            query = self.weibo.get("query", "")
            snapshot = copy.deepcopy(self.weibo)
            llm.reset(snapshot)
            result = await llm.call_llm_impl()
            score = await self.calc_ctr_score(query, result)

            # pattern = r'<media-block>(.*?)</media-block>'
            # media_block_size = re.findall(pattern, result)
            all_ready_list = llm.weibo.get("ready_pid_dict", {}).get("all_ready_list", [])

            return llm.weibo, result, score, len(all_ready_list)

        def result_sorted(self, results):
            # greater_than_3 = [t for t in results if t[3] >= 2]
            # if len(greater_than_3):
            #     sorted_results = sorted(greater_than_3, key=lambda x: x[2], reverse=True)
            #     return sorted_results

            sorted_results = sorted(results, key=lambda x: x[2], reverse=True)
            return sorted_results

        async def call_llm_impl(self):
            tasks = [self.multi_call_llm_impl(llm) for llm in self.llms]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            sorted_results = self.result_sorted(results)
            weibo, result, score, media_block_size = sorted_results[0]
            self.reset(weibo)
            return result

    class MultiLLMLab1(MultiLLM):

        async def calc_ctr_score(self, query, content):
            url = "http://10.133.169.246:5056/predict"
            headers = {'Content-Type': 'application/json'}
            data = {
                "content": content,
                "query": query
            }

            timeout_obj = ClientTimeout(total=2)
            try:
                async with aiohttp.ClientSession(timeout=timeout_obj) as session:
                    async with session.post(url, json=data, headers=headers) as response:
                        if response.status == 200:
                            result = await response.json()
                            self.logger.info(self.pre_log_msg + f"{json.dumps(content, ensure_ascii=False)} ctr score {result}")
                            return result[0][0]
            except asyncio.TimeoutError:
                self.logger.error(self.pre_log_msg + f"timeout error")
            except aiohttp.ClientError as e:
                self.logger.error(self.pre_log_msg + f"ClientError error: {e}")
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"exception error: {e}")
            return 0

    class MultiLLMLab2(MultiLLM):

        async def calc_ctr_score(self, query, content):
            url = "http://10.133.168.176:8000/score"
            headers = {'Content-Type': 'application/json'}
            data = {
                "content": content,
                "query": query
            }

            timeout_obj = ClientTimeout(total=2)
            try:
                async with aiohttp.ClientSession(timeout=timeout_obj) as session:
                    async with session.post(url, json=data, headers=headers) as response:
                        if response.status == 200:
                            result = await response.text()
                            self.logger.info(self.pre_log_msg + f"ctr score {result}")
                            return float(result)
            except asyncio.TimeoutError:
                self.logger.error(self.pre_log_msg + f"timeout error")
            except aiohttp.ClientError as e:
                self.logger.error(self.pre_log_msg + f"ClientError error: {e}")
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"exception error: {e}")
            return 0

    if lab == 1:
        return MultiLLMLab1
    elif lab == 2:
        return MultiLLMLab2
    else:
        return MultiLLM

MultiDeepseekLLM = multi_factory(DeepSeekLLM, 0)
MultiInterveneLLM = multi_factory(InterveneLLM, 0)
MultiDeepseekLLMLab1 = multi_factory(DeepSeekLLM, 1)
MultiInterveneLLMLab1 = multi_factory(InterveneLLM, 1)
MultiDeepseekLLMLab2 = multi_factory(DeepSeekLLM, 2)
MultiInterveneLLMLab2 = multi_factory(InterveneLLM, 2)


