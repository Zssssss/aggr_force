# -*- coding:utf-8 -*-
import asyncio
import time
import json
import aiohttp

from alarm.alarm import alarm
from api.model_api import ModelQwen, ModelQwenWrapper
from plugins.llm.llm import LLM
from plugins.material.material import SummaryMaterial, ShortTvMaterial, AccountMaterial, SummaryMaterialNoType, \
    PreviousMaterial, StockMaterial, StreamSummaryMaterial
from plugins.recalculate.recalculate import StreamRecalculate


class StreamLLM(LLM):
    async def fetch_material(self):
        func_name = "STREAM-FETCH_MATERIAL"
        start = time.time()
        status_task = self.send_response(ready='no', content="", status_stage=1)
        materials = [
            StreamSummaryMaterial(self.pid),
            AccountMaterial(self.pid),
            ShortTvMaterial(self.pid),
            SummaryMaterialNoType(self.pid),
            # PreviousMaterial(self.pid),
            StockMaterial(self.pid),
        ]

        tasks = [material.run(weibo=self.weibo) for material in materials]
        tasks.append(status_task)
        await asyncio.gather(*tasks)
        self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}")

    def should_recalculate(self):
        recalculate = StreamRecalculate(self.pid)
        return recalculate

    def check_material(self):
        """检查物料是否发生变化"""
        query_category = self.weibo.get("query_category", "")
        mid_list = self.weibo.get('mid_list', [])
        account_mid_list = self.weibo.get('account_mid_list', [])
        all_mid_list = mid_list + account_mid_list

        previous_result = self.weibo.get("previous_result", {})
        previous_update = float(previous_result.get("update", '0'))  # 大于一天就重算
        if not previous_result or time.time() - previous_update > 24 * 60 * 60:
            self.weibo['recalc_status'] = 'nodata'
            return bool(len(mid_list) or query_category == 'Account_Nor')

        previous_mid = previous_result.get("mid_list", "")
        previous_mid_list = previous_mid.split(',') if previous_mid else []
        previous_account_mid = previous_result.get("account_mid_list", "")
        previous_account_mid_list = previous_account_mid.split(',') if previous_account_mid else []
        previous_all_mid_list = previous_mid_list + previous_account_mid_list

        # 流式不用更新时间
        # self.weibo['recalc_status'] = 'is_have_material_diff'
        # 根据不同类型判断是否需要重新计算
        if query_category == 'Account_Nor':
            # 账户前三条完全变化才重算
            return (bool(account_mid_list or previous_account_mid_list) and
                    not set(account_mid_list[:3]) & set(previous_account_mid_list[:3]))
        elif query_category == 'kol':
            # 所有物料有变化就重算
            return set(all_mid_list) != set(previous_all_mid_list)

        # 普通情况下比较 mid_list
        return set(mid_list) != set(previous_mid_list)

    async def struct_material(self):
        await asyncio.gather(
            self.send_response(ready='no', content="", status_stage=2),
            super().struct_material()
        )

    async def query_intention_and_rewrite(self):
        await asyncio.gather(
            self.send_response(ready='no', content="", status_stage=3),
            super().query_intention_and_rewrite()
        )

    async def calc_query(self, trace, query, q_attr):
        res = ""
        try:
            url = "http://admin.ai.s.weibo.com/intfs/llm/refreshSummary"
            # 3 截断或者特殊符号
            data = {"query": query, "model": "qwen72b", "op_type": 3, "q_attr": q_attr}

            async with aiohttp.ClientSession() as session:
                async with session.post(url=url, data=data, timeout=3) as r:
                    return r.status == 200
        except Exception as e:
            self.logger.info("[{}] query:{} res:{} msg:{}".format(trace, query, res, e))
            return False

    async def call_llm(self, prompt):
        func_name = "总结生成"
        start = time.time()
        llm_qwen72b = ModelQwenWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_content = prompt.prompt()
        self.weibo['prompt'] = prompt_content
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("query", "")
        q_attr = self.weibo.get("q_attr", "")
        use_zhisou = self.weibo.get("use_zhisou", False)
        error_name = ""

        try:
            begin = time.time()
            stream_response = await llm_qwen72b.async_stream_call(prompt_content)
            final_result = {}
            first = True
            first_time = 0
            result = ""
            last_result = ""
            async for response in stream_response:
                if first:
                    first_time = time.time()
                    self.weibo["debug"]["time_analysis"]["stream_fist_answer"] = first_time
                    self.weibo["debug"]['first_answer'] = first_time
                    first = False
                final_result = response
                result = response.get("text", "")
                result = result.strip('\n')
                if len(result) - len(last_result) > 10:
                    await self.send_response(ready='no', content=result, status_stage=4),
                    last_result = result
            self.weibo["debug"]["time_analysis"]["stream_answer_end"] = time.time()
            self.weibo["debug"]['end_process'] = time.time()
            await self.count_tokens(final_result, begin, first_time)
            await self.send_response(ready='yes', content=result, status_stage=4)
            error_name, no_error = await self.check_result(result)
            if no_error:
                self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time() - start}\t"
                                                    f"result:{json.dumps(result, ensure_ascii=False)}")
                await self.calc_question(result)
                return result
            res = await self.calc_query(trace_id, query, q_attr)
            self.logger.info(self.pre_log_msg + f"{func_name} calc query res: {res}")
        except Exception as e:
            self.logger.exception(e)
            self.weibo["debug"]['end_process'] = time.time()
            await self.send_response(ready='nodata', content="", status_stage=4)

        if use_zhisou and error_name:
            alarm("qwen_stream {} {} format error: {}".format(trace_id, query, error_name))
        self.logger.info(self.pre_log_msg + f"{func_name} get no data, cost_time:{time.time() - start}\t")
        return ""
