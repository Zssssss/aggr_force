# -*- coding:utf-8 -*-
import asyncio
import json
import re
import time
from datetime import datetime
from typing import List, Dict, Any, Tuple

import traceback
from jinja2 import Template
from plugins.material.material import HotQueryListMaterial
from plugins.material.multiq_runner import MultiQueryMaterialRunner
from api.model_api import WeiboDeepseekWrapper, WeiboDeepseekV31Wrapper
from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.award_er import get_award_generate_prompt as get_award_generate_prompt_er
from plugins.prompt.award_star import get_award_generate_prompt as get_award_generate_prompt_star
from plugins.prompt.award_game import get_award_generate_prompt as get_award_generate_prompt_game

from plugins.prompt.award_er import get_final_summary_prompt as get_final_summary_prompt_er
from plugins.prompt.award_star import get_final_summary_prompt as get_final_summary_prompt_star
from plugins.prompt.award_game import get_final_summary_prompt as get_final_summary_prompt_game

from plugins.prompt.award_er import get_final_intent as get_final_intent_er
from plugins.prompt.award_star import get_final_intent as get_final_intent_star
from plugins.prompt.award_game import get_final_intent as get_final_intent_game

from plugins.prompt.award_er import get_final_verify as get_final_verify_er
from plugins.prompt.award_star import get_final_verify as get_final_verify_star
from plugins.prompt.award_game import get_final_verify as get_final_verify_game


# 全局常量
CLEAN_SUMMARY_PATTERN = re.compile(r'^### 关键信息汇总\n?', flags=re.MULTILINE)
INVALID_RESPONSE_KEYWORDS = {"无法回答", "无相关信息", "没有找到", "无法提供", "暂无数据", "无需回复"}
MAX_RETRY_TIMES = 2  # 完整流程最大重试次数
GLOBAL_CONCURRENCY = 10  # 全局query并发数（根据API并发限制调整）


class AwardLLM(DeepSeekLLM):
    """颁奖词"""

    def get_intent(self):
        da_intention = self.weibo.get("da_intention", "")
        if da_intention in ['二次元', '电竞']:
            return da_intention
        return "明星"

    def get_prompt(self, step):
        category = self.get_intent()

        # 定义提示词映射表
        prompt_map = {
            1: {
                '二次元': get_award_generate_prompt_er,
                '电竞': get_award_generate_prompt_game,
                'default': get_award_generate_prompt_star
            },
            2: {
                '二次元': get_final_summary_prompt_er,
                '电竞': get_final_summary_prompt_game,
                'default': get_final_summary_prompt_star
            },
            3: {
                '二次元': get_final_intent_er,
                '电竞': get_final_intent_game,
                'default': get_final_intent_star
            },
            4: {
                '二次元': get_final_verify_er,
                '电竞': get_final_verify_game,
                'default': get_final_verify_star
            }
        }

        step_config = prompt_map.get(step)
        return step_config.get(category, step_config['default'])
    
    # 去重
    def merge_re_duplicate_by_link(self, link_groups: list[list[str]], txt_groups: list[list[str]], topn: int) -> tuple[list[str], list[str]]:
        """
        合并去重
        :topn: 每组取最多的topn个
        """
        res_txt_list = []
        res_link_list = []
        seen = set()
        for link_list, txt_list in zip(link_groups, txt_groups):
            link_list = link_list[:topn]
            txt_list = txt_list[:topn]
            for link, txt in zip(link_list, txt_list):
                if link not in seen:
                    res_link_list.append(link)
                    res_txt_list.append(txt)
                    seen.add(link)
        return res_link_list, res_txt_list

    async def fetch_and_struct_material(self, query: str = None) -> tuple[list[str], list[str]]:
        # backup
        weibo_query = self.weibo.get('query', '')
        query_list = []
        try:
            # 只使用站内物料
            for k in ['baike_knowledge', 'history_hot_res']:
                self.weibo[k] = []
            if query and weibo_query != query:
                self.logger.info(self.pre_log_msg + f"ori query {weibo_query} replaceed with: {query}")
                self.weibo['query'] = query
            await HotQueryListMaterial(self.pid).run(weibo=self.weibo)
            query_list = self.weibo.get('hot_query_list', [])
            self.logger.info(self.pre_log_msg + f"use query [{self.weibo['query']}] to get hot_query_list: {query_list}")
            if weibo_query != query and not query_list:
                # 退化使用原始query获取词条
                self.weibo['query'] = weibo_query
                await HotQueryListMaterial(self.pid).run(weibo=self.weibo)
                query_list = self.weibo.get('hot_query_list', [])
                self.logger.info(self.pre_log_msg + f"use ori query [{self.weibo['query']}] to get hot_query_list: {query_list}")
                self.weibo['query'] = query
            if not query_list:
                self.logger.info(self.pre_log_msg + "hot_query_list is empty")
                return self.weibo.get('link_list', []),  self.weibo.get('ds_struct_material', [])
            multi_q_runner = MultiQueryMaterialRunner(self.pid)
            await multi_q_runner.run(weibo=self.weibo, query_list=query_list, query_weight=[0] * (len(query_list) + 1), used_materials=['zs_knowledge'], refresh_main=(weibo_query != query))
            await self.confine_material_length()
            return self.weibo.get('link_list', []),  self.weibo.get('ds_struct_material', [])
        except Exception:
            self.logger.error(self.pre_log_msg + f"fetch_and_struct_material error: {traceback.format_exc()}")
            return self.weibo.get('link_list', []),  self.weibo.get('ds_struct_material', [])
        finally:
            # recover
            self.weibo['query'] = weibo_query

    @staticmethod
    def _extract_fields(result) -> Tuple[str, str]:
        """
        安全解析 think / content 字段。字段缺失时返回空串。
        兼容不同返回结构，尽量不抛异常。
        """
        try:
            pattern = r'<think>(?P<think>.*?)</think>(?P<content>.*?)$'
            match = re.search(pattern, result, flags=re.DOTALL)
            if match:
                thk = match.group('think')
                ret = match.group('content')
                return thk, ret
        except Exception:
            pass
        return "", ""

    async def generate_award_one(self, query, mat, sem, max_retries=1):
        async with sem:
            llm = WeiboDeepseekV31Wrapper(self.weibo, self.pid, self.pre_log_msg, "年终颁奖词")
            get_award_generate_prompt = self.get_prompt(1)
            award_generate_prompt_base, award_generate_prompt_optim = get_award_generate_prompt(query, mat)
            for attempt in range(max_retries):
                try:
                    begin = time.time()
                    response = await llm.async_call(award_generate_prompt_base)
                    await self.count_tokens(response, begin)
                    result = response.get("text", "")
                    think, ret = self._extract_fields(result)
                    clean_ret = CLEAN_SUMMARY_PATTERN.sub("", ret)
                    return {
                        "query": query,
                        "prompt": award_generate_prompt_base,
                        "think": think,
                        "result": clean_ret,
                        "length": len(clean_ret),
                        "error": ""
                    }
                except Exception as e:
                    error_msg = f"{type(e).__name__}: {e}"
                    self.logger.error(self.pre_log_msg + f"⚠️  单条任务重试 {attempt}/{max_retries}，错误：{error_msg}")
            return {
                "query": query,
                "think": "",
                "result": "",
                "length": 0,
                "error": error_msg
            }

    async def generate_award(self, query, mats, concurrency=8):
        step = 20
        mats_sliced = [mats[i:i + step] for i in range(0, len(mats), step)]
        sub_mat_list = ['\n'.join(mat_slice) for mat_slice in mats_sliced]
        sem = asyncio.Semaphore(concurrency)
        tasks = [
            self.generate_award_one(query, mat, sem=sem, max_retries=2)
            for mat in sub_mat_list
        ]
        award_result = []
        results = await asyncio.gather(*tasks)
        for i, result in enumerate(results):
            think = result.get("think", "")
            content = result.get("result", "")
            if think and content:
                award_result.append({"think": think, "content": content})
        return award_result

    async def generate_summary(self, query, award_result: [List]):
        # 3. 合并颁奖词结果
        award_list = []
        for i, result in enumerate(award_result):
            content = result.get("content", "")
            if content:
                ret_formatted = f'[结果 {i + 1} begin]\n{content}\n[结果 {i + 1} end]'
                award_list.append(ret_formatted)

        llm = WeiboDeepseekV31Wrapper(self.weibo, self.pid, self.pre_log_msg, "年终颁奖词")
        get_final_summary_prompt = self.get_prompt(2)
        summary_prompt_base, summary_prompt_optim = get_final_summary_prompt(query, award_list)
        for attempt in range(2):
            try:
                begin = time.time()
                response = await llm.async_call(summary_prompt_base)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                _, ret = self._extract_fields(result)
                return ret
            except Exception as e:
                error_msg = f"{type(e).__name__}: {e}"
                self.logger.error(self.pre_log_msg + f"⚠️  总结摘要，错误：{error_msg}")
        return ""

    async def generate_intent_mats(self, query, award_intent):
        # 提取<search>标签内的补充搜索内容
        pattern = r'<search>(.*?)</search>'
        search_contents = re.findall(pattern, award_intent, re.DOTALL)
        mat_supplement = ''
        link_groups, ds_struct_material_groups = [], []
        for idx, content in enumerate(search_contents, 1):
            if content:
                link_list, ds_struct_material_list = await self.fetch_and_struct_material(content)
                link_groups.append(link_list)
                ds_struct_material_groups.append(ds_struct_material_list)

        # 提取topn后去重
        link_list, ds_struct_material_list = self.merge_re_duplicate_by_link(link_groups, ds_struct_material_groups, topn=5)
        mat_supplement += f"\n[补充材料]\n" + "\n".join(ds_struct_material_list) # 每个补充内容取前5条
        return mat_supplement

    async def generate_intent(self, query, summary):
        llm = WeiboDeepseekV31Wrapper(self.weibo, self.pid, self.pre_log_msg, "年终颁奖词")
        get_final_intent = self.get_prompt(3)
        verify_prompt_base, verify_prompt_optim = get_final_intent(query, summary)
        for attempt in range(2):
            try:
                begin = time.time()
                response = await llm.async_call(verify_prompt_base)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                _, ret = self._extract_fields(result)
                return ret
            except Exception as e:
                error_msg = f"{type(e).__name__}: {e}"
                self.logger.error(self.pre_log_msg + f"⚠️  意图验证，错误：{error_msg}")
        return ""

    # 拿物料
    async def generate_result(self, query, award_summary, award_intent, award_intent_mats):
        get_final_verify = self.get_prompt(4)
        verify_final_prompt_base, verify_final_prompt_optim = get_final_verify(
            query, award_summary, award_intent_mats, award_intent
        )
        llm = WeiboDeepseekV31Wrapper(self.weibo, self.pid, self.pre_log_msg, "年终颁奖词")
        for attempt in range(2):
            try:
                begin = time.time()
                response = await llm.async_call(verify_final_prompt_base)
                await self.count_tokens(response, begin)
                result = response.get("text", "")
                _, ret = self._extract_fields(result)
                return ret.strip()
            except Exception as e:
                error_msg = f"{type(e).__name__}: {e}"
                self.logger.error(self.pre_log_msg + f"⚠️  幻觉修复，错误：{error_msg}")
        return ""

    def award_valid(self, award_result):
        """
        判断响应是否有效：非空 + 不包含无效关键词
        """
        if not award_result or not award_result.strip():
            return False
        for keyword in INVALID_RESPONSE_KEYWORDS:
            if keyword in award_result:
                return False
        return True

    async def call_llm(self, prompt):
        try:
            query = self.weibo.get("query", "")
            query_category = self.weibo.get("query_category", "")
            da_intention = self.weibo.get("da_intention", "")
            self.logger.info(self.pre_log_msg + f"start query_category: {query_category}, da_intention: {da_intention}")
            link_list, ds_struct_material = await self.fetch_and_struct_material()
            award_result = await self.generate_award(query, ds_struct_material)
            self.logger.info(self.pre_log_msg + f"award_result: {json.dumps(award_result, ensure_ascii=False)}")
            award_summary = await self.generate_summary(query, award_result)
            self.logger.info(self.pre_log_msg + f"award_summary: {json.dumps(award_summary, ensure_ascii=False)}")
            award_intent = await self.generate_intent(query, award_summary)
            self.logger.info(self.pre_log_msg + f"award_intent: {json.dumps(award_intent, ensure_ascii=False)}")
            award_intent_mats = await self.generate_intent_mats(query, award_intent)
            self.logger.info(self.pre_log_msg + f"award_intent_mats: {json.dumps(award_intent_mats, ensure_ascii=False)}")
            final_result = await self.generate_result(query, award_summary, award_intent, award_intent_mats)
            self.logger.info(self.pre_log_msg + f"final_result: {json.dumps(final_result, ensure_ascii=False)}")
            is_valid = self.award_valid(final_result)
            content = final_result if is_valid else ""
            await self.send_response(ready='yes' if content else 'error', content=content, status_stage=4)
            return content
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error {e}")
            await self.send_response(ready='error', content="", status_stage=4)
        return ""
