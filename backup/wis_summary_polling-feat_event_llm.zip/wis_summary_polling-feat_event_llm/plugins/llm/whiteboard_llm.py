# -*- coding:utf-8 -*-
from contextlib import asynccontextmanager

from plugins.llm.deepseek import DeepSeekLLM, StreamDeepSeekLLM
from plugins.llm.llm import LLM
from plugins.llm.stream_llm import StreamLLM
from plugins.recalculate.recalculate import Recalculate


class WhiteboardLLM(LLM):
    async def fetch_material(self):
        whiteboard_branch = self.weibo.get('whiteboard_branch', "")
        if whiteboard_branch != 'master':
            return await super().fetch_material()

    def should_recalculate(self):
        class WhiteboardRecalculate(Recalculate):
            @asynccontextmanager
            async def run(self, **kwargs):
                yield True

        recalculate = WhiteboardRecalculate(self.pid)
        return recalculate


class StreamWhiteboardLLM(StreamLLM):
    async def fetch_material(self):
        whiteboard_branch = self.weibo.get('whiteboard_branch', "")
        if whiteboard_branch != 'master':
            return await super().fetch_material()

    def should_recalculate(self):
        class WhiteboardRecalculate(Recalculate):
            @asynccontextmanager
            async def run(self, **kwargs):
                yield True

        recalculate = WhiteboardRecalculate(self.pid)
        return recalculate


class WhiteboardDeepseekLLM(DeepSeekLLM):
    async def fetch_material(self):
        whiteboard_branch = self.weibo.get('whiteboard_branch', "")
        if whiteboard_branch != 'master':
            return await super().fetch_material()

    def should_recalculate(self):
        class WhiteboardRecalculate(Recalculate):
            @asynccontextmanager
            async def run(self, **kwargs):
                yield True

        recalculate = WhiteboardRecalculate(self.pid)
        return recalculate


class StreamWhiteboardDeepseekLLM(StreamDeepSeekLLM):
    async def fetch_material(self):
        whiteboard_branch = self.weibo.get('whiteboard_branch', "")
        if whiteboard_branch != 'master':
            return await super().fetch_material()

    def should_recalculate(self):
        class WhiteboardRecalculate(Recalculate):
            @asynccontextmanager
            async def run(self, **kwargs):
                yield True

        recalculate = WhiteboardRecalculate(self.pid)
        return recalculate
