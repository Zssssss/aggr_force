# -*- coding:utf-8 -*-
import json
import time
from aiomcache import Client
from lib.memq import MEMQ
from lib.redis_utils import async_redis_client

# q = MEMQ("llm_tokens_list@fe.queue.search.weibo.com:11233")

key = "llm_tokens_list"
# q = Client("fe.queue.search.weibo.com", 11233, pool_minsize=1, pool_size=2)

from lib.aiomcq import mcq_cli
# mcq_client = mcq_cli(domain="fe.queue.search.weibo.com", port=11233)

async def count_tokens(weibo, response, begin, first_stream=0):
    query = weibo.get("query", "")
    traceid = weibo.get("version", "")
    label = weibo.get('label', "")
    input_token = response.get("prompt_tokens", 0)
    output_token = response.get("completion_tokens", 0)
    llm_name = weibo.get("llm_name", "")
    hot_overview_override = weibo.get("hot_overview_override", "")
    robot_override = weibo.get("robot_override", "")
    verification_comment = weibo.get("verification_comment", "")
    verification_note = weibo.get("verification_note", "")
    if hot_overview_override:
        llm_name = hot_overview_override
    if robot_override:
        llm_name = robot_override
    if verification_comment:
        llm_name = verification_comment
    if verification_note:
        llm_name = verification_note
    json_data = {
        "scene": "综述_" + label,
        "input_tokens": input_token,
        "output_tokens": output_token,
        "model": llm_name,
        "time": int(time.time()),
        "all_cost_time": int((time.time() - begin) * 1000),
        "version": traceid,
        "query": query
    }
    if first_stream:
        json_data["first_cost_time"] = int((first_stream - begin) * 1000)
    weibo["debug"]["tokens_list"].append(json_data)
    # await q.set(key.encode('utf8'), json.dumps(json_data).encode('utf8'))

    # await mcq_client.set(key, json.dumps(json_data))
    # q.set(json.dumps(json_data))


def is_stream_output(weibo):
    llm_name = weibo.get("llm_name", "")
    stream_output = weibo.get("stream_output", 0)

    # ds
    if llm_name == 'deepseek_stream':
        return True

    # 求证
    if llm_name == 'deepseek_verification' and stream_output == 1:
        return True

    return False

def is_hot_query(source, q_attr):
    """判断是否为热点问题"""
    try:
        attr_dict = json.loads(q_attr)
        flush_source = attr_dict.get("flush_source", "")
    except:
        flush_source = ""
    if source == "3" and flush_source == "1":
        return True
    return False


# 人工触发ab实验流程
import tools.discovery.dconf as discovery


def get_abtest(weibo):
    manual_abtest = weibo.get("manual_abtest", "")
    abtest = weibo.get("abtest", manual_abtest)
    return abtest

def discovery_get_json(config, key, default):
    try:
        config_value = discovery.configget(config, key)
        if config_value:
            return json.loads(config_value)
    except Exception as e:
        print("discovery_get error")
    return default

def gn_to_letter(g_str):
    try:
        if g_str.startswith('g') or  g_str.startswith('G'):
            num_str = g_str[1:]
            if num_str.isdigit():
                num = int(num_str)
                if 1 <= num <= 26:  # 确保在字母表范围内
                    return chr(ord('a') + num)
    except Exception as e:
        print("gn_to_letter error: ".format(e))
    return g_str

def ab_to_lab(config, ab_id, ab_ver, query_category):
    try:
        for key, val in config.items():
            abid = val.get("abid")
            if abid == ab_id:
                lab = val.get("abval", {}).get(ab_ver, {}).get("suff", "")
                category = val.get("query", {}).get('intention_two', [])
                if 'Star_ExactMatch' in category:
                    query_category = '明星'
                return lab, query_category
    except Exception as e:
        print("ab_to_lab error: ".format(e))
    return "", query_category

def query_to_lab(query, query_category):
    try:
        fields = query.split('_ab_')
        if len(fields) == 2:
            ab_fields = fields[1].split('_')
            if len(ab_fields) == 2:
                ab_id = ab_fields[0]
                ab_ver = gn_to_letter(ab_fields[1])
                config = discovery_get_json("admin_ai", "llm_ab_lab", {})
                lab, query_category = ab_to_lab(config, ab_id, ab_ver, query_category)
                if lab:
                    return fields[0], lab, query_category
    except Exception as e:
        print("query_to_lab error: ".format(e))
    return query, "", query_category

try:
    config = discovery_get_json("admin_ai", "llm_ab_lab", {})
    print('load discovery: {}'.format(json.dumps(config, ensure_ascii=False)))
except Exception as e:
    print('discovery_get_json error')


async def read_ab_query(query):
    try:
        client = async_redis_client.get_redis_server(query)
        key = f"wis_last_time_abtest_{query}"
        val = await client.get(key)
        if val:
            return val.decode('utf-8')
    except Exception as e:
        print(f"❌ 读取Redis时出错: {e}")
    return None

async def write_ab_query(query):
    try:
        client = async_redis_client.get_redis_server(query)
        key = f"wis_last_time_abtest_{query}"
        current_time = int(time.time())
        await client.set(key, current_time, ex=3*60*60)
        return True
    except Exception as e:
        print(f"❌ 存储到Redis时出错: {e}")
    return False




class McqUtils:
    mcq_obj = mcq_cli(domain="queue.search.weibo.com", port=11233)
    @staticmethod
    async def send_mcq(data):
        json_str = json.dumps(data)
        res = await McqUtils.mcq_obj.set("wis_auto_monitor", json_str)
        return res

    @staticmethod
    async def get_mcq():
        res = await McqUtils.mcq_obj.get("wis_auto_monitor")
        if not res:
            return None
        data = json.loads(res)
        return data