import asyncio
import time
import traceback

from api.model_api import get_deepseek_r1_model_from_weibo_sid, QWEN3_235B_ModelWrapper
from lib.base import Base
from plugins.llm.deepseek import DeepSeekLLM
from plugins.llm.utils import count_tokens
from plugins.material.material import URLSINAMaterial
from plugins.prompt.articlecomment import ArticleCommentPrompt, ARTICLE_COMMENT_SYSTEM_PROMPT


class ArticleCommentLLM(Base):

    def __init__(self, weibo, output, pid):
        super().__init__(pid)
        self.weibo = weibo
        self.output = output
        self.weibo['pid'] = pid

    async def fetch_material(self):
        try:
            await URLSINAMaterial(self.pid).run(weibo=self.weibo)
            url_sina_content_dict = self.weibo.get('url_sina_content', {})
            title = url_sina_content_dict.get("title", "")
            content = url_sina_content_dict.get("content", "")
            if title and content:
                self.weibo['title'] = title
                self.weibo['content'] = content
                return True
        except:
            self.logger.exception(f"error fetch material: {traceback.format_exc()}")

        self.logger.error(self.pre_log_msg + "no url_sina_content")
        return False
    async def call_llm(self):
        begin = time.time()
        result = ""
        sid = self.weibo.get("sid", "")
        prompt = ArticleCommentPrompt(self.weibo)
        llm_call = get_deepseek_r1_model_from_weibo_sid(sid)(self.weibo, self.pid, self.pre_log_msg, "文章总结")
        self.weibo["debug"]["time_analysis"][f"article_comment_begin"] = time.time()
        try:
            prompt_content = prompt.prompt()
            response = await llm_call.async_call(prompt_content, system_prompt=ARTICLE_COMMENT_SYSTEM_PROMPT)
            await count_tokens(self.weibo, response, begin, first_stream=0)
            ori_result = response.get("text", "")
            result = prompt.post_process(ori_result)
        except Exception as e:
            self.logger.exception(f"article comment error: {traceback.format_exc()}")

        self.weibo['result'] = result
        self.weibo["debug"]["time_analysis"][f"article_comment_end"] = time.time()
        await self.output.run(weibo=self.weibo, ready='nodata' if not result else "yes", content=result, status_stage=4)

    async def run(self, **kwargs):
        start = time.time()
        self.weibo["llm_trace_info"] = []
        self.weibo["debug"] = {
            "llm_name": self.weibo.get("llm_name", ""),
            "time_analysis": {
                "all_start": start,
                "input_end": time.time(),
                'add_query_info_ts_start': self.weibo.get('add_query_info_ts_start', time.time()),
                'add_query_info_ts_end': self.weibo.get('add_query_info_ts_end', time.time()),
            },
            'in_time_ms': self.weibo.get("in_time_ms", time.time()),
            'in_time': self.weibo.get('in_time', int(time.time())),
            'user_request_time_ms': self.weibo.get('user_request_time_ms', time.time()),
            'server_request_time_ms': self.weibo.get('server_request_time_ms', time.time()),
            'query_in_time': self.weibo.get('query_in_time', time.time()),
            "tokens_list": [],
        }
        self.update_pre_log_msg(self.weibo)
        await self.output.run(weibo=self.weibo, ready='begin')
        self.weibo["debug"]["time_analysis"]["fetch_material_start"] = time.time()
        has_material = await self.fetch_material()
        self.weibo["debug"]["time_analysis"]["fetch_material_end"] = time.time()
        if has_material:
            self.weibo["debug"]["time_analysis"]["call_llm_start"] = time.time()
            await self.call_llm()
            self.weibo["debug"]["time_analysis"]['end_process'] = time.time()
        else:
            await self.output.run(weibo=self.weibo, ready='nodata', content="", status_stage=4)



class StreamArticleCommentLLM(ArticleCommentLLM):
    async def call_llm(self):
        result = ""
        self.weibo['sina_stream'] = True
        prompt = ArticleCommentPrompt(self.weibo)
        llm_qwen3 = QWEN3_235B_ModelWrapper(self.weibo, self.pid, self.pre_log_msg, '文章总结')
        prompt_content = prompt.prompt()
        self.weibo["debug"]["time_analysis"][f"article_comment_begin"] = time.time()
        try:
            begin = time.time()
            stream_response = await llm_qwen3.async_stream_call(prompt_content, sys_prompt=ARTICLE_COMMENT_SYSTEM_PROMPT, enable_thinking=False)
            final_result = {}
            first = True
            first_time = 0
            last_result = ""
            async for response in stream_response:
                final_result = response
                result = response.get("text", "")
                result = result.strip('\n')
                process_result = prompt.post_process(result)
                if first:
                    first_time = time.time()
                    self.weibo["debug"]["time_analysis"]["stream_fist_answer"] = first_time
                    self.weibo["debug"]['first_answer'] = first_time
                    self.weibo["debug"]["first_update"] = 1
                    if not self.weibo["debug"].get("first_return_time", 0):
                        self.weibo["debug"]["first_return_time"] = time.time()
                    await self.output.run(weibo=self.weibo, ready='no', content=process_result, status_stage=4)
                    if not self.weibo["debug"].get("first_return_time_behind", 0):
                        self.weibo["debug"]["first_return_time_behind"] = time.time()
                    user_request_time_ms = self.weibo.get('user_request_time_ms', 0)
                    server_request_time_ms = self.weibo.get('server_request_time_ms', 0)
                    if not self.weibo["debug"].get("user_request_time_ms", 0):
                        self.weibo["debug"]["user_request_time_ms"] = user_request_time_ms
                    if not self.weibo["debug"].get("server_request_time_ms", 0):
                        self.weibo["debug"]["server_request_time_ms"] = server_request_time_ms
                    last_result = result
                    first = False

                if len(result) - len(last_result) > 10:
                    if not self.weibo["debug"].get("first_return_time", 0):
                        self.weibo["debug"]["first_return_time"] = time.time()
                    await self.output.run(weibo=self.weibo, ready='no', content=process_result, status_stage=4)
                    last_result = result
            self.weibo["debug"]["time_analysis"]["stream_answer_end"] = time.time()
            await count_tokens(self.weibo, final_result, begin, first_time)
            result = prompt.post_process(result)
        except Exception as e:
            result = ""
            self.logger.exception(f"article comment error: {traceback.format_exc()}")

        self.weibo['result'] = result
        self.weibo["debug"]["time_analysis"][f"article_comment_end"] = time.time()
        await self.output.run(weibo=self.weibo, ready='nodata' if not result else "yes", content=result, status_stage=4)


