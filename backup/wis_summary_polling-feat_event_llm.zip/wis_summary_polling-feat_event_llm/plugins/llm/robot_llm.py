# -*- coding:utf-8 -*-
import asyncio
import json
import re
import time
from datetime import datetime
import traceback
import aiohttp

from alarm.alarm import alarm
from api.model_api import ModelDeepseekWrapper, WeiboDeepseekWrapper, QWEN3_30B_XiaoYiWrapper
from lib.base import Base
from plugins.llm.deepseek import DeepSeekLLM
from plugins.prompt.cove import cove_factory
from plugins.recalculate.recalculate import StreamRecalculate
from plugins.regression.regression import DeepseekRegression
from plugins.risk_tip.risk_tip import RiskTip


class RobotLLM(DeepSeekLLM):
    """继承deepseek， 增加log输出"""

    async def call_cove(self, result):
        return result

    async def get_robot_result(self):
        tasks = [RiskTip(self.pid).run(self.weibo), Verification(self.pid).get_verify_result(self.weibo)]
        ori_result, _ = await asyncio.gather(*tasks)
        return ori_result

    async def call_llm(self, prompt):
        traceid = self.weibo.get("traceid", "")
        query = self.weibo.get("query", "")
        use_zhisou = self.weibo.get("use_zhisou", False)
        llm_name = self.weibo.get('llm_name', "")
        func_name = "罗伯特回复生成"
        start = time.time()
        llm_qwen72b = WeiboDeepseekWrapper(self.weibo, self.pid, self.pre_log_msg, func_name)
        prompt_content = prompt.prompt()
        self.weibo['prompt'] = prompt_content
        retry = 4
        content = ""
        error_name = ""
        for i in range(retry):
            try:
                schema_index = None if i == 0 else prompt.schema_index()
                begin = time.time()
                response = await llm_qwen72b.async_call(prompt_content, schema_index)
                await self.count_tokens(response, begin)
                ori_result = response.get("text", "")
                self.weibo["ori_result"] = ori_result
                ori_result = await self.get_robot_result()
                result = prompt.post_process(ori_result)
                if len(result) > 200:
                    self.logger.info(self.pre_log_msg + f"[robot] result length is too long: {len(result)}")
                    continue

                self.weibo["output_all_ready"] = True
                self.weibo["debug"]["time_analysis"][f"call_cove{i}_start"] = time.time()
                result = await self.call_cove(result)
                self.weibo["debug"]["time_analysis"][f"call_cove{i}_end"] = time.time()
                error_name, no_error = await self.check_result(result)
                if no_error and result:
                    self.weibo["debug"]["call_llm_times"] = i + 1
                    self.weibo["debug"]["time_analysis"]["call_llm_with_result_end"] = time.time()
                    json_result = self.weibo.get("json_result", {})
                    self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\ttimes:{i + 1}\t"
                                        f"label:{self.weibo.get('label', '')}\t"
                                        f"query_category:{self.weibo.get('query_category', '')}\t"
                                        f"result:{json.dumps(result, ensure_ascii=False)}\t"
                                        f"json_result:{json.dumps(json_result, ensure_ascii=False)}\t")
                    content = result
                    # await self.calc_question(content)
                    break
            except Exception as e:
                self.logger.error(self.pre_log_msg + f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        self.write_log(message=f"{func_name} get no result, cost_time:{time.time() - start}")
        self.weibo["debug"]["call_llm_times"] = retry
        self.weibo["debug"]["time_analysis"]["call_llm_no_result_end"] = time.time()
        self.weibo["debug"]['end_process'] = time.time()
        await self.output.run(weibo=self.weibo, ready='yes' if content else 'error', content=content)
        return content


class Verification(Base):

    def process_res_judge(self, ret):
        reason = ""
        result = False
        judge_dict = {
            '是': True,
            '(是)': True,
            '（是）': True,
            '否': False,
            '(否)': False,
            '（否）': False
        }
        try:
            for item in ret.strip().split("\n"):
                if item.startswith("是否满足"):
                    judge = re.split(r":|：", item)[-1].strip()
                    if judge in judge_dict:
                        result = judge_dict[judge]
                if item.startswith("理由"):
                    reason = re.split(r":|：", item)[-1].strip()
        except:
            self.logger.error(self.pre_log_msg + f"parse res_type error:{traceback.format_exc()}")
        return result, reason

    @staticmethod
    
    def get_judge_resp_prompt(query, resp):
        prompt = f"""
输入：
用户查询：{query}
回答结果：{resp}

请你仔细阅读用户查询与回答结果，然后判断结果是否回答用户查询：
(是)：回答结果能够回答或部分回答用户查询。
(否)：回答结果完全不能回答用户查询。

输出：
理由: ...
是否满足：(是/否)
"""
        return prompt

    async def qwen7b(self, prompt, seqid):
        url = 'http://mproxy.search.weibo.com/llm/generate'
        request_body = {
            "id": seqid,
            "temperature": 0.1,
            "max_tokens": 100,
            "repetition_penalty": 1.15,
            "messages": prompt,
        }
        data = {
            "payload": request_body,
            "sid": "smart_app_nknxw",
            "model": "qwen257b"
        }
        request_body = data
        for _ in range(2):
            try:
                timeout = aiohttp.ClientTimeout(
                    connect=10,  # 连接超时
                    total=200        # 总超时（含连接+读取）
                )
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.post(url=url, json=request_body) as r:
                        # print(r)
                        r.raise_for_status()
                        response_data = await r.json()
                        text = response_data["data"]['text']
                        r.close()
                        return text
            except:
                self.logger.error(self.pre_log_msg + f"call llm error:{traceback.format_exc()}")
        return ""

    async def call_llm(self, prompt, weibo, seqid='11111111'):
        """
        Call LLM
        :param prompt:
        :param seqid:
        :return:
        """
        try:
            llm_qwen3_30b = QWEN3_30B_XiaoYiWrapper(weibo, self.pid, self.pre_log_msg, "判断结果是否回答用户查询")
            # prompt = [
            #     {'role': 'system', 'content': datetime.now().strftime('当前日期是 %Y-%m-%d.')},
            #     {'role': 'user', 'content': prompt}
            # ]
            # prompt_format = []
            # for p in prompt:
            #     prompt_format.append(p['role'])
            #     prompt_format.append(p['content'])
            #
            # result = await self.qwen7b(prompt_format, seqid)
            result = await llm_qwen3_30b.async_call(prompt)
            return result.get('text', "")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"[verify] error: {traceback.format_exc()}")
        return ""

    async def get_verify_result(self, weibo):
        self.update_pre_log_msg(weibo)
        query = weibo.get('query', "")
        resp = weibo.get('ori_result', "")
        self.logger.info(self.pre_log_msg + f"[verify] query:{query}\t ori_result:{resp}")
        prompt = self.get_judge_resp_prompt(query, resp)
        self.logger.info(self.pre_log_msg + f"[verify] prompt:{prompt}")
        ret = await self.call_llm(prompt, weibo)
        self.logger.info(self.pre_log_msg + f"[verify] ret:{ret}")
        judge, reason = self.process_res_judge(ret)
        weibo['verify_judge'] = judge
        weibo['verify_reason'] = reason
        self.logger.info(self.pre_log_msg + f"verify_judge: {judge}\t verify_reason:{reason}")
