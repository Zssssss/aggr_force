# -*- coding:utf-8 -*-
import asyncio
import datetime
import json
import time

from aiomcache import Client

from lib.aiomcq import mcq_cli
from lib.base import Base
from lib.memq import MEMQ


class MemqStorage(Base):

    def __init__(self, pid):
        super().__init__(pid)
        # self.memq_cli_prod = MEMQ("wis_zhisou_output_forward@searchlogqueue.search.weibo.com:11233")
        self.key = "wis_zhisou_output_forward".encode('utf8')
        self.queue = Client("searchlogqueue.search.weibo.com", 11233, pool_minsize=1, pool_size=2)
        # 历史热点触发
        self.his_key = "wis_analysis_del_hot_query".encode('utf8')
        # debug
        # self.memq_cli_prod = MEMQ("wis_zhisou_output_forward_debug@searchlogqueue.search.weibo.com:11233")
    
    def make_mid_uid_mapping(self, raw_material_list):
        res = {}
        try:
            for item in raw_material_list:
                mid = item.get("mid")
                uid = item.get("uid")
                if mid and uid:
                    res[mid] = uid
        except:
            self.logger.error("make_mid_uid_mapping error, raw_material_list:{}".format(raw_material_list))
        return res
    
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        tid = weibo.get("tid", "")
        trace_id = weibo.get("trace_id", "")
        llm_result = weibo.get("result", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        llm_name = weibo.get("llm_name", "")
        content_list = weibo.get("content_list", [])
        mid_list = weibo.get("mid_list", [])
        account_mid_list = weibo.get("account_mid_list", [])
        query_category = weibo.get("query_category", "")
        account_content_list = weibo.get("account_content_list", [])
        zhisou_content = weibo.get("zhisou_content", "")
        knowledge = weibo.get("knowledge", "")
        self_account = weibo.get("self_account", "")
        query_grade = weibo.get("query_grade", "")
        raw_time_grade = weibo.get("raw_time_grade", "")
        label = weibo.get("label", "")
        cove_material = weibo.get("cove_material", [])
        struct_content_list = weibo.get("struct_content_list", [])
        struct_account_content_list = weibo.get("struct_account_content_list", [])
        source = weibo.get("source", "")
        q_attr = weibo.get("q_attr", "")
        output_forward_zj_link = weibo.get("output_forward_zj_link", "")
        ready_img_dict = weibo.get("ready_pid_dict", {}).get("img_ready", {})
        raw_material_list = weibo.get("raw_material_list", [])
        mid_uid_mapping = self.make_mid_uid_mapping(raw_material_list)
        his_need_refresh_list = weibo.get('his_need_refresh_list', [])
        # 发送到转发队列
        data = {"traceid": trace_id,
                "mid_uid_mapping": json.dumps(mid_uid_mapping, ensure_ascii=False),
                "query_category": query_category,
                'query_grade': query_grade,
                'llm_result': llm_result,
                'modify_query': modify_query,
                "query": query, "tid": tid,
                "update": str(time.time()),
                "output_forward_zj_link": output_forward_zj_link}
        if llm_result:
            try:
                # 发送到转发队列
                # await asyncio.to_thread(self.memq_cli_prod.set, json.dumps(data))
                for i in range(3):
                    try:
                        await self.queue.set(self.key, json.dumps(data).encode('utf8'))
                        self.logger.info("query:{},traceid:{} write to forward queue success".format(query, trace_id))
                        break
                    except:
                        if i == 2:
                            self.logger.error("query:{},traceid:{} write to forward queue error data:{}".format(query, trace_id, data))
                        else:
                            self.logger.warning("query:{},traceid:{} write to forward queue error, retry...".format(query, trace_id))
            except Exception as e:
                self.logger.error("query:{},error:{},traceid:{} write to forward queue error data:{}".format(query, str(e), trace_id, json.dumps(data, ensure_ascii=False)))

        if his_need_refresh_list:
            try:
                data_list = [{
                    'query': q,
                    'time': ts
                } for q, ts in his_need_refresh_list]
                tasks = []
                for item in data_list:
                    tasks.append(self.queue.set(self.his_key, json.dumps(item).encode('utf8')))
                await asyncio.gather(*tasks)
                self.logger.info(f"trace_id: {trace_id}\t write success to his queue: {len(data_list)}")
            except Exception as e:
                self.logger.error("query:{},error:{},traceid:{} write to his queue error data:{}".format(query, str(e), trace_id, json.dumps(data_list, ensure_ascii=False)))

    async def close(self):
        pass


class ShortCommentStorage(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.mcq_obj = mcq_cli(domain="fe.queue.search.weibo.com", port=11233)

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        content = weibo.get('result', "")
        result_type = '其他' if not content else weibo.get('type', '其他')
        zs_not_reply = weibo.get("zs_not_reply", 0)
        is_chat = weibo.get('is_chat', 1)
        data = {
            'content': content,
            'type': result_type,
            "cid": weibo.get('cid', ""),  # 评论ID
            "comment_uid": weibo.get("comment_uid", ""),  # 评论人uid
            "mid": weibo.get("mid", ""),  # 微博mid
            "comment": weibo.get("comment", ""),  # 评论内容
            "uid": weibo.get("uid", ""),  # 发博人用户id
            "page_id": weibo.get("page_id", ""),  # 智搜结果id
            "zs_not_reply": zs_not_reply,
            "is_chat": is_chat
        }

        try:
            await self.mcq_obj.set("zs_zhijie_reply_task", json.dumps(data))
            self.logger.info("query:{},traceid:{} write:{}".format(query, trace_id, json.dumps(data, ensure_ascii=False)))
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} write to forward queue error data:{}".format(
                    query, str(e), trace_id, json.dumps(data, ensure_ascii=False)))

    async def close(self):
        pass

