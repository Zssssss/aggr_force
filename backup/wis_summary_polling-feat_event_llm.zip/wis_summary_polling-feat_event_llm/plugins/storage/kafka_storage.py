# -*- coding:utf-8 -*-
import datetime
import json
import time
import logging
import traceback

from lib.base import Base
from aiokafka import AIOKafkaProducer

# 关闭kafka的日志输出
kafka_logger  = logging.getLogger("aiokafka.conn")
kafka_logger.setLevel(logging.CRITICAL)

# 输出到kafka
class KafkaStorage(Base):
    def __init__(self, pid):
        super().__init__(pid)
        self.producer = None

    async def get_producer(self):
        if self.producer is None:
            self.producer = AIOKafkaProducer(
                bootstrap_servers=["kfk26.c9.al.sina.com.cn:9110",
                                   "kfk08.c9.al.sina.com.cn:9110",
                                   "kfk23.c9.al.sina.com.cn:9110",
                                   "kfk02.c9.al.sina.com.cn:9110",
                                   "kfk01.c9.al.sina.com.cn:9110"],
                sasl_plain_username="weiboSearch",
                sasl_plain_password="0d57008f1a611f866fd6e7c04ebb51a2",
                security_protocol="SASL_PLAINTEXT",
                sasl_mechanism="PLAIN",
                value_serializer=lambda m: json.dumps(m).encode('ascii')
            )
            await self.producer.start()
        return self.producer
    
    async def kafka_send_one(self, data: dict):
        kafka_producer = AIOKafkaProducer(
                bootstrap_servers=["kafka-center-endpoint.sina.com.cn:9110"],
                sasl_plain_username="weiboSearch",
                sasl_plain_password="0d57008f1a611f866fd6e7c04ebb51a2",
                security_protocol="SASL_PLAINTEXT",
                sasl_mechanism="PLAIN",
                compression_type='snappy',
                value_serializer=lambda m: json.dumps(m).encode('ascii'),
                max_request_size=5*1024*1024
            )
        await kafka_producer.start()
        try:
            # Produce message
            await kafka_producer.send_and_wait("search_zs_model_detail", value=data)
        except Exception as e:
            self.logger.error(f"kafka send failed: {traceback.format_exc()}")
        finally:
            # Wait for all pending messages to be delivered or expire.
            await kafka_producer.stop()

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        version = weibo.get("version", "")
        llm_result = weibo.get("result", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        prompt_scene = weibo.get("prompt_scene", "")
        llm_name = weibo.get("llm_name", "")
        hot_overview_override = weibo.get("hot_overview_override", "")
        robot_override = weibo.get("robot_override", "")
        verification_comment = weibo.get("verification_comment", "")
        verification_note = weibo.get("verification_note", "")
        content_list = weibo.get("content_list", [])
        mid_list = weibo.get("mid_list", [])
        query_category = weibo.get("query_category", "")
        account_content_list = weibo.get("account_content_list", [])
        zhisou_content = weibo.get("zhisou_content", "")
        knowledge = weibo.get("knowledge", "")
        cove_query = weibo.get("cove_query", False)
        start = time.time()
        prompt = weibo.get("prompt", "")
        llm_trace_info = weibo.get("llm_trace_info", [])
        risk_tip_prompt = weibo.get("risk_tip_prompt", "")
        risk_tip_result = weibo.get("risk_tip_result", "")
        stream_output = weibo.get("stream_output", 0)
        summary_filterd_june_mid_list = weibo.get("summary_filterd_june_mid_list_v2", "")
        account_filterd_june_mid_list = weibo.get("account_filterd_june_mid_list_v2", "")
        zjzw_result = weibo.get("zjzw_result", "")
        gaokao_intention_little = weibo.get("gaokao_intention_little", "")
        annotation_prompt = weibo.get("annotation_prompt", "")
        annotation_result = weibo.get("annotation_result", "")
        annotation = weibo.get("annotation", "")
        annotation_intention_prompt = weibo.get("annotation_intention_prompt", "")
        annotation_intention_result = weibo.get("annotation_intention_result", "")
        annotation_intention = weibo.get("annotation_intention", "")
        first_prompt = weibo.get("first_prompt", "")
        first_result = weibo.get("first_result", "")
        first_link_list = weibo.get("first_link_list", "")
        verification_prompt = weibo.get("verification_prompt", "")
        verification_result = weibo.get("verification_result", "")
        verification_link_list = weibo.get("verification_link_list", "")
        intervene_prompt = weibo.get("intervene_prompt", "")
        intervene_result = weibo.get("intervene_result", "")
        intervene_link_list = weibo.get("intervene_link_list", "")
        verification_note_version = weibo.get("verification_note_version", "")
        verification_note_page_id = weibo.get("verification_note_page_id", "")
        debug = weibo.get('debug', {})
        abtests = weibo.get("abtests", "")
        abtest = weibo.get("abtest", "")
        ori_prompt = weibo.get("ori_prompt", "")
        finish_reason = weibo.get("finish_reason", "")
        query_filter_reason = weibo.get("query_filter_reason", "")
        # 热搜事件进展
        hotsearch_abstract = weibo.get('hotsearch_abstract', '')
        hotsearch_abstract_prompt = weibo.get('hotsearch_abstract_prompt', '')
        hotsearch_report_linklist = weibo.get("hotsearch_report", {}).get("hotsearch_summary_linklist", [])
        # 博文分析
        mid_has_pic = 1 if weibo.get("reco_pic_list", []) else 0
        mid_voice = weibo.get('mid_voice', '')
        mid_ocr = weibo.get('mid_ocr', '')
        mid_video_abs = weibo.get('mid_video_abs', '')
        mid_pic_list = weibo.get("reco_pic_list", [])
        mid_has_video = 1 if weibo.get("have_video", 0)  else 0
        mid_tag3_extra_part = weibo.get("mid_tag3_extra_part", False)
        use_model = weibo.get("use_model", "")
        ori_reliable_result = weibo.get("ori_reliable_result", "")
        # 商业物料引用记录
        mid_business_quote_list = weibo.get("mid_business_quote_list", [])

        if robot_override:
            llm_name = robot_override
        if hot_overview_override:
            llm_name = hot_overview_override
        if verification_comment:
            llm_name = verification_comment
        if verification_note:
            llm_name = verification_note

        data_from = 'wis_comment' if 'comment' in prompt_scene else "wis_summary"
        json_data = {
            "log_type": "zs_summary",
            "data_type": "zs_generate",
            "data_from": data_from,
            "ori_content": llm_result,
            "front_content": weibo.get("front_content", ""),
            "query": query,
            # "content_list": content_list,
            "link_list": weibo.get("link_list", []),
            "model": prompt_scene,
            "mid_list": mid_list,
            "query_category": query_category,
            "kol_content_list": account_content_list,
            "zhisou_content": zhisou_content,
            "knowledge": knowledge,
            "prompt": prompt,
            "end_process": time.time(),
            "in_time_ms": weibo.get("in_time_ms", time.time()),
            "trace_id": trace_id,
            "version": version,
            "time": int(time.time()),
            "log_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "prompt_length": len(prompt),
            "reasoning_cost_time": time.time() - start,
            "all_mids_num": weibo.get("all_mids_num", 0),
            "use_content_mid_len": weibo.get('use_content_mid_len', 0),
            "use_account_mid_len": weibo.get('use_account_mid_len', 0),
            "source": weibo.get('source', ""),
            "high_level": weibo.get("high_level", ""),
            "q_attr": weibo.get("q_attr", ""),
            "diff_10": weibo.get("diff_10", ""),
            "diff_5": weibo.get("diff_5", ""),
            "cove": cove_query,
            "modify_query": modify_query,
            "label": weibo.get("label", ""),
            "llm_trace_info": llm_trace_info,
            "risk_tip_prompt": risk_tip_prompt,
            "risk_tip_result": risk_tip_result,
            "stream_output": stream_output,
            "summary_filterd_june_mid_list_v2": summary_filterd_june_mid_list,
            "account_filterd_june_mid_list_v2": account_filterd_june_mid_list,
            "zjzw_result": zjzw_result,
            "gaokao_intention_little": gaokao_intention_little,
            "annotation_prompt": annotation_prompt,
            "annotation_result": annotation_result,
            "annotation": annotation,
            "annotation_intention_prompt": annotation_intention_prompt,
            "annotation_intention_result": annotation_intention_result,
            "annotation_intention": annotation_intention,
            "title_prompt": weibo.get("title_prompt", ""),
            "title_result": weibo.get("title_result", ""),
            "title": weibo.get("title", ""),
            "hotsearch_abstract" : hotsearch_abstract,
            "hotsearch_abstract_prompt" : hotsearch_abstract_prompt,
            "hotsearch_report_linklist" : hotsearch_report_linklist,
            "news_title": weibo.get("news_title", ""),
            "news_analyze_category": weibo.get("news_analyze_category", ""),
            "news_analyze_flag" : weibo.get("news_analyze_flag", False),
            "sid" : weibo.get("sid", ""),
            "first_prompt": first_prompt,
            "first_result": first_result,
            "first_link_list": first_link_list,
            "verification_prompt": verification_prompt,
            "verification_result": verification_result,
            "verification_link_list": verification_link_list,
            "intervene_prompt": intervene_prompt,
            "intervene_result": intervene_result,
            "intervene_link_list": intervene_link_list,
            "verification_note_version": verification_note_version,
            "verification_note_page_id": verification_note_page_id,
            "debug": json.dumps(debug, ensure_ascii=False),
            "abtests": abtests,
            "abtest": abtest,
            "ori_prompt": ori_prompt,
            "model_filter": finish_reason,
            "query_filter_reason": query_filter_reason,
            "mid_has_pic": mid_has_pic,
            "mid_voice": mid_voice,
            "mid_ocr": mid_ocr,
            "mid_video_abs": mid_video_abs,
            "mid_pic_list": mid_pic_list,
            "mid_has_video": mid_has_video,
            "mid_tag3_extra_part": mid_tag3_extra_part,
            "use_model": use_model,
            "ori_reliable_result": ori_reliable_result,
            "mid_business_quote_list": mid_business_quote_list
        }
        kafka_begin = time.time()
        try:
            # producer = await self.get_producer()
            # await producer.send("search_zs_mirror", value=json_data)
            await self.kafka_send_one(json_data)
        except Exception as e:
            kafka_end = time.time()
            self.logger.error(f"write to kafka failed: query:{query}\ttraaceid:{trace_id}\t{traceback.format_exc()}")
            self.logger.error("write to kafka,query:{}\ttraaceid:{}\tpost_data:{}\ttime_cost:{}".format(
                query, trace_id, json_data, kafka_end - kafka_begin))
        self.logger.info("write to kafka,query:{}\ttraceid:{}\ttime_cost:{}".format(query, trace_id, time.time() - kafka_begin))

    async def close(self):
        if self.producer:
            await self.producer.stop()



class ChatVerificationKafkaStorage(Base):
    def __init__(self, pid):
        super().__init__(pid)
        self.producer = None

    async def kafka_send_one(self, data: dict):
        kafka_producer = AIOKafkaProducer(
                bootstrap_servers=["kafka-center-endpoint.sina.com.cn:9110"],
                sasl_plain_username="weiboSearch",
                sasl_plain_password="0d57008f1a611f866fd6e7c04ebb51a2",
                security_protocol="SASL_PLAINTEXT",
                sasl_mechanism="PLAIN",
                compression_type='snappy',
                value_serializer=lambda m: json.dumps(m).encode('ascii')
            )
        await kafka_producer.start()
        try:
            # Produce message
            await kafka_producer.send_and_wait("search_zs_model_detail", value=data)
        except Exception as e:
            self.logger.error(f"kafka send failed: {traceback.format_exc()}")
        finally:
            # Wait for all pending messages to be delivered or expire.
            await kafka_producer.stop()

    async def run(self, weibo):
        trace_id = weibo.get('trace_id', "")
        query = weibo.get('query', "")
        content = weibo.get('content', "")
        question = weibo.get('ori_question', "")
        model = weibo.get('model', "deepseek")
        version = weibo.get('version', "")
        session_id = weibo.get('session_id', "")
        conversation_id = weibo.get('ori_conversation_id', "")
        uid = weibo.get('user_id', "")
        q_attr = weibo.get('q_attr', "")
        prompt_scene = weibo.get('prompt_scene', "")
        status_stage = weibo.get('update_output', {}).get("status_stage", 1)
        chat_type = weibo.get('update_output', {}).get("chat_type", 0)
        link_list = weibo.get('update_output', {}).get("link_list", [])
        llm_trace_info = weibo.get("llm_trace_info", [])

        json_data = {
            "log_type": "wis_dialogue",
            "data_type": "zs_generate",
            "data_from": "wis_dialogue",
            'content': content,
            "question": question,
            "model": model,
            "version": version,
            "session_id": session_id,
            "conversation_id": conversation_id,
            "user_id": uid,
            "q_attr": q_attr,
            "prompt_scene": prompt_scene,
            "status_stage": status_stage,
            "chat_type": chat_type,
            "link_list": link_list,
            "llm_trace_info": llm_trace_info,
        }

        kafka_begin = time.time()
        try:
            await self.kafka_send_one(json_data)
        except Exception as e:
            kafka_end = time.time()
            self.logger.error(
                f"write to kafka failed: query:{query}\ttraaceid:{trace_id}\t{traceback.format_exc()}")
            self.logger.error("write to kafka,query:{}\ttraaceid:{}\tpost_data:{}\ttime_cost:{}".format(
                query, trace_id, json.dumps(json_data, ensure_ascii=False), kafka_end - kafka_begin))
        self.logger.info(
            "write to kafka,query:{}\ttraceid:{}\ttime_cost:{}".format(query, trace_id, time.time() - kafka_begin))

    async def close(self):
        pass