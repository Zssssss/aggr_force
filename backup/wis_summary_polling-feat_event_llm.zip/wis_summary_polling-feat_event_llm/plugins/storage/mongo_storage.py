# -*- coding:utf-8 -*-
import json
import time
import traceback

from lib.base import Base
from lib.mongo_helper import AsyncMongoHelper

risk_tip_mongo = AsyncMongoHelper('risk_tip')
robot_mongo = AsyncMongoHelper('robot')
business_mongo = AsyncMongoHelper('business')


class MongoStorage(Base):
    def __init__(self, pid):
        super().__init__(pid)

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        llm_result = weibo.get("result", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        risk_tip_prompt = weibo.get("risk_tip_prompt", "")
        risk_tip_result = weibo.get("risk_tip_result", "")
        risk_tips_result_list = weibo.get("risk_tips_result_list", [])
        risk_tips_dict = weibo.get("risk_tips_dict", [])
        mid_business_quote_list = weibo.get("mid_business_quote_list", [])

        json_data = {
            "query": query,
            "risk_tip_prompt": risk_tip_prompt,
            "risk_tip_result": risk_tip_result,
            "risk_tips_result_list": json.dumps(risk_tips_result_list, ensure_ascii=False),
            "risk_tips_dict": json.dumps(risk_tips_dict, ensure_ascii=False)
        }

        if len(risk_tips_dict):
        # if True:
            start = time.time()
            try:
                await risk_tip_mongo.write_any({'query': query, 'trace_id': trace_id}, json_data)
            except Exception as e:
                self.logger.error(
                    f"write to mongo failed: query:{query}\ttraceid:{trace_id}\t{traceback.format_exc()}")
            self.logger.info(
                f"write to mongo query:{query}\ttraceid:{trace_id}\tcost:{time.time() - start}")
            
        if mid_business_quote_list:
            start = time.time()
            try:
                json_data = {
                    "query": query,
                    "version": trace_id,
                    "mid_business_quote_list": mid_business_quote_list
                }
                await business_mongo.write_any({'query': query, 'trace_id': trace_id}, json_data)
            except Exception as e:
                self.logger.error(
                    f"write to mongo failed: query:{query}\ttraceid:{trace_id}\t{traceback.format_exc()}")
            self.logger.info(
                f"write to mongo query:{query}\ttraceid:{trace_id}\tcost:{time.time() - start}")

    async def close(self):
        pass


class RobotMongoStorage(Base):
    def __init__(self, pid):
        super().__init__(pid)

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        content = weibo.get("front_content", "")
        q_attr = weibo.get("q_attr", "")
        query = weibo.get("query", "")
        llm_name = weibo.get('llm_name', "")
        model = weibo.get('robot_override', llm_name)

        start = time.time()
        try:
            q_attr_dict = json.loads(q_attr)
            if q_attr_dict:
                query_mid = q_attr_dict.get("mid", "")
                await robot_mongo.write_any({'trace_id': trace_id},
                                                     {'model': model, 'query_mid': query_mid, "content": content, 'query': query})
        except Exception as e:
            self.logger.error(
                f"write to mongo failed\ttraceid:{trace_id}\t{traceback.format_exc()}")
        self.logger.info(f"write to mongo traceid:{trace_id}\tcost:{time.time() - start}")

    async def close(self):
        pass
