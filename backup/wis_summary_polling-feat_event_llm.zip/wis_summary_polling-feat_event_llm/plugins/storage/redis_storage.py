# -*- coding:utf-8 -*-
import asyncio
import datetime
import json
import time

import hashlib
import urllib.parse
import aiohttp  
from lib.redis_utils import async_redis_client
from lib.base import Base
from plugins.llm.utils import write_ab_query
from plugins.material.material_api import write_previous_result


class RedisStorage(Base):

    async def cove_query_record(self, query, llm_name, content):
        if not content:
            return

        try:
            prefix = "qwen72b_match_query_"
            now = datetime.datetime.now()
            now_str = now.strftime("%Y%m%d")
            key = prefix + now_str

            redis_server = async_redis_client.get_redis_server(query)
            await redis_server.hset(key, query, "\n".join(content))
            ttl = await redis_server.ttl(key)
            if ttl == -1:
                await redis_server.expire(key, 7 * 24 * 3600)
        except Exception as e:
            self.logger.error("cove_query_record \t{}\t{}".format(query, e))

    async def daily_query_record(self, query, llm_name):

        try:
            prefix = "qwen72b_record_"
            now = datetime.datetime.now()
            now_str = now.strftime("%Y%m%d")
            key = prefix + now_str
            value = now.strftime("%Y%m%d-%H:%M:%S")

            redis_server = async_redis_client.get_redis_server(query)
            await redis_server.hset(key, query, value)
            ttl = await redis_server.ttl(key)
            if ttl == -1:
                await redis_server.expire(key, 7 * 24 * 3600)
        except Exception as e:
            self.logger.error("daily_query_record \t{}\t{}".format(query, e))

    @staticmethod
    async def storage_pic_to_redis(query, llm_name, source, q_attr, ready_img_dict):
        """存储微博图片到redis"""
        if "deepseek" not in llm_name:
            return
        try:
            attr_dict = json.loads(q_attr)
            flush_source = attr_dict.get("flush_source", "")
        except Exception as e:
            flush_source = ""
        if source == "3" and flush_source == "1":
            is_hot_query = True
        else:
            is_hot_query = False

        tasks = []
        for _, img_item in ready_img_dict.items():
            img_pid = img_item.get("pid", "")
            flag = img_item.get("flag", False)
            if not flag:
                continue
            cur_data = {"is_hot_query": is_hot_query, "data_time": time.time()}
            tasks.append(RedisPicture().storage_data(img_pid, query, cur_data))
        await asyncio.gather(*tasks)

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        llm_result = weibo.get("result", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        llm_name = weibo.get("llm_name", "")
        hot_overview_override = weibo.get("hot_overview_override", "")
        robot_override = weibo.get("robot_override", "")
        content_list = weibo.get("content_list", [])
        mid_list = weibo.get("mid_list", [])
        account_mid_list = weibo.get("account_mid_list", [])
        query_category = weibo.get("query_category", "")
        account_content_list = weibo.get("account_content_list", [])
        zhisou_content = weibo.get("zhisou_content", "")
        knowledge = weibo.get("knowledge", "")
        self_account = weibo.get("self_account", "")
        query_grade = weibo.get("query_grade", "")
        raw_time_grade = weibo.get("raw_time_grade", "")
        label = weibo.get("label", "")
        cove_material = weibo.get("cove_material", [])
        struct_content_list = weibo.get("struct_content_list", [])
        struct_account_content_list = weibo.get("struct_account_content_list", [])
        source = weibo.get("source", "")
        q_attr = weibo.get("q_attr", "")
        ready_img_dict = weibo.get("ready_pid_dict", {}).get("img_ready", {})
        prompt = weibo.get("prompt", "")
        data = {"ready": "no", "content": llm_result, "mid_list": ",".join(mid_list), "traceid": trace_id,
                "query_category": query_category, 'query_grade': query_grade, 'raw_time_grade': raw_time_grade,
                "content_list": "\n".join(content_list), "knowledge": knowledge, "label": label,
                "zhisou_content": "\n".join(zhisou_content), "account_mid_list": ",".join(account_mid_list),
                "account_content_list": "\n".join(account_content_list),
                "struct_content_list": str(struct_content_list),
                "struct_account_content_list": str(struct_account_content_list), 'llm_result': llm_result,
                'modify_query': modify_query, "prompt": prompt,
                "update": str(time.time())}
        if llm_result:
            if robot_override:
                llm_name = robot_override
            elif hot_overview_override:
                llm_name = hot_overview_override
            start = time.time()
            await asyncio.gather(
                # write_previous_result(query, llm_name, self_account, trace_id, data, self.logger),
                self.cove_query_record(query, llm_name, cove_material),
                self.daily_query_record(query, llm_name),
                self.storage_pic_to_redis(query, llm_name, source, q_attr, ready_img_dict),
            )
            #self.logger.info("write to redis,query:{}\ttraaceid:{}\tpost_data:{}\ttime_cost:{}".format(
            #    query, trace_id, json.dumps(data, ensure_ascii=False), time.time() - start))

    async def close(self):
        pass


class RedisBusinessCompress(object):
    """
    用来处理redis业务压缩数据的类
    """

    def __init__(self):
        self.suffix = '_compress'
        self.redis_client = async_redis_client
        self.days = 10  # 过期时间为10天

    def get_query_name(self, query: str, query_category: str):
        """
        获取查询语句的名称
        :param query: 查询语句
        :param query_category: 查询类别
        :return: 查询语句的名称
        """
        return f'{query}_{query_category}' + self.suffix

    async def storage_data(self, query: str, query_category: str, opinion: list, reality: list, mids: list):
        """
        存储数据到redis
        :param query: 查询语句
        :param query_category: 查询类别
        :param opinion: 观点数据
        :param reality: 真实数据
        :param mids: 物料id列表
        :return: None
        """
        query = self.get_query_name(query, query_category)
        redis_client = self.redis_client.get_redis_server(query)
        data = {'opinion': json.dumps(opinion), 'reality': json.dumps(reality),
                'mids': json.dumps(mids), 'time': time.time()}
        tasks = []
        for key, value in data.items():
            tasks.append(redis_client.hset(query, key, value))
        await asyncio.gather(*tasks)
        await redis_client.expire(query, self.days * 24 * 60 * 60)

    async def get_data(self, query: str, query_category: str):
        """
        从redis中获取数据
        :param query: 查询语句
        :param query_category: 查询类别
        :return:
        """
        query = self.get_query_name(query, query_category)
        redis_client = self.redis_client.get_redis_server(query)
        reslut = await redis_client.hgetall(query)
        if not reslut:
            return None
        converted_reslut = {}
        for key, value in reslut.items():
            converted_reslut[key.decode("utf-8")] = value.decode("utf-8")
        opinion = json.loads(converted_reslut.get('opinion', '[]'))
        reality = json.loads(converted_reslut.get('reality', '[]'))
        return opinion, reality

class RedisImageVector(object):
    """
    用来处理redis图片向量数据的类
    """
    def __init__(self):
        self.suffix = '_vector'
        self.redis_client = async_redis_client
        self.days = 10  # 过期时间为10天
        
    def get_mauth(self,payload, secret):
        # 对字典按键进行排序
        sorted_payload = sorted(payload.items())
        
        # 拼接字符串
        builder = []
        for k, v in sorted_payload:
            builder.append(f"{urllib.parse.quote(str(k))}={urllib.parse.quote(str(v))}")
        
        # 将 secret 添加到末尾
        builder.append(secret)
        
        # 拼接成字符串并进行替换
        res = "&".join(builder).replace("+", "%20").replace("*", "%2A").replace("%7E", "~")
        
        # 计算 MD5 值
        return hashlib.md5(res.encode('utf-8')).hexdigest()
    
    async def embedding_image(self, mids_set, pid_dic):    
        # 请求的 URL
        url = "http://public.api.admin.weibo.com/hot_search/mblog/get_img_vector"

        timestamp = int(time.time() * 1000)
        
        mids = ",".join(mids_set)
        
        params = {
            'mids': mids,
            'appid': '4620130809',
            "timestamp": timestamp
        }
        
        app_secret = 'bdqq1dd68r1vrkbmnl89tjb3b2ujuk0j'  
        
        signature = self.get_mauth(params, app_secret)
        
        # 构造请求头
        headers = {
            'Authorization': f'MAuth {signature}',
            'timestamp': str(timestamp)
        }
        
        try:
            # 创建一个 aiohttp 会话
            async with aiohttp.ClientSession() as session:
                # 发送 GET 请求
                async with session.get(url, headers=headers, params=params) as response:
                    # 解析 JSON 响应
                    response_json = await response.json()
                    n = len(response_json['data'])
                    pid_list = []
                    for i in range(n):
                        pid_list.append(response_json['data'][i]['pids'])
                    
                    pid_list = [item for sublist in pid_list for item in sublist]
        except Exception as e:
            pid_list = []
            pass

        res = {}
        
        for pid_dic in pid_list:
            pid_info = pid_dic.get("pid", "")
            vector = pid_dic.get("vector", 0)

            res[pid_info] = vector
        return res
    
    async def save_image_vector(self, pid, vector):
        redis_client = self.redis_client.get_redis_server(pid)
        await redis_client.hset(pid, 'vector', json.dumps(vector))
        await redis_client.expire(pid, self.days * 24 * 60 * 60)


    async def get_image_vector(self, pid):
        redis_client = self.redis_client.get_redis_server(pid)
        result = await redis_client.hget(pid, "vector")
        if not result:
            return None
        vector = json.loads(result)
        return vector


class RedisPicture(object):
    """
    用来处理redis图片数据的类
    """
    def __init__(self):
        self.suffix = '_picture_id'
        self.redis_client = async_redis_client
        self.days = 7  # 过期时间为7天

    async def storage_data(self, picture_id: str, query: str, pic_info: dict):
        """
        存储数据到redis
        """
        key = f'{picture_id}' + self.suffix + f'_{datetime.datetime.now().strftime("%Y-%m-%d")}'
        value = json.dumps(pic_info)
        redis_client = self.redis_client.get_redis_server(key)
        try:
            await redis_client.hset(key, query, value)
            await redis_client.expire(key, self.days * 24 * 60 * 60)
        except:
            pass

    async def get_data(self, picture_id: str, date_today: str):
        """
        从redis中获取数据
        """
        key = f'{picture_id}' + self.suffix + f'_{date_today}'
        redis_client = self.redis_client.get_redis_server(key)
        result = await redis_client.hgetall(key)
        if not result:
            return None
        converted_result = {}
        for key, value in result.items():
            converted_result[key.decode("utf-8")] = json.loads(value.decode("utf-8"))
        return converted_result

class RedisStarIp(Base):
    def __init__(self, pid):
        super().__init__(pid)
        self.redis_client = async_redis_client
        self.days = 2  # 过期时间为2天

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        used_mid_list = weibo.get("mid_list", [])
        link_list = weibo.get("link_list", [])
        account_mid_list = weibo.get("account_mid_list", [])
        used_baike_list = weibo.get('urls_used_baike', [])
        used_article_list = weibo.get('urls_used_article', [])
        trace_id = weibo.get("trace_id", "")
        # list[dict[str, str]]
        llm_res = weibo.get("result", "")
        query = weibo.get("query", "")

        key = f'{query}_star_ip'
        redis_client = self.redis_client.get_redis_server(key)

        value = {
            "llm_res": json.dumps(llm_res, ensure_ascii=False),
            "ref_meta": json.dumps({
                "mid_list": used_mid_list,
                "link_list": link_list,
                "account_mid_list": account_mid_list,
                "urls_used_baike": used_baike_list,
                "urls_used_article": used_article_list
            }, ensure_ascii=False),
            "query": query,
            "create_time": str(time.time())
        }
        try:
            for k, v in value.items():
                await redis_client.hset(key, k, v)
            await redis_client.expire(key, self.days * 24 * 60 * 60)

            await asyncio.sleep(0.01)
            redis_result = await redis_client.hgetall(key)
            if not redis_result:
                self.logger.error(f"trace_id:{trace_id}\tquery:{query}\tredis_star_ip_key:{key} is empty")
            self.logger.info(f"trace_id:{trace_id}\tquery:{query}\tredis_star_ip_key:{key}\tllm_result:{llm_res}")
        except Exception as e:
            self.logger.error(f"trace_id:{trace_id}\tquery:{query}\tredis_star_ip_key:{key}\terror:{e}")
    
    async def close(self):
        pass


class AnnotationRedisStore(Base):
    def __init__(self, pid):
        super().__init__(pid)
        self.redis_client = async_redis_client
        self.days = 3*365

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        query = weibo.get("query", "")
        result = weibo.get("result", "")
        annotation = weibo.get("annotation", "")
        comment = weibo.get("annotation_comment", "")
        if result and (annotation == "谣言类" or annotation == "信息不实类"):
            try:
                name = f'zhisou_annotation_{query}'
                redis_client = self.redis_client.get_redis_server(name)
                data = {'result': json.dumps(result, ensure_ascii=False), 'annotation': annotation, 'comment': comment, 'trace_id': trace_id}
                tasks = []
                for key, value in data.items():
                    tasks.append(redis_client.hset(name, key, value))
                await asyncio.gather(*tasks)
                await redis_client.expire(name, self.days * 24 * 60 * 60)
                self.logger.info(f"trace_id:{trace_id}\tquery:{query}\tannotation:{annotation}")
            except Exception as e:
                self.logger.error(f"trace_id:{trace_id}\tquery:{query}\tannotation:{annotation}\terror:{e}")

    async def close(self):
        pass


class NotifyPendingRedisStorage(Base):
    """消息通知剩余任务-完成"""
    def __init__(self, pid):
        super().__init__(pid)
        self.redis_client = async_redis_client

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        query = weibo.get("query", "")
        notify_has_res = weibo.get('notify_has_res', False)
        q_attr = weibo.get("q_attr", '')
        q_attr = json.loads(q_attr)
        q_4msg_type = q_attr.get('q_4msg_type', 'star')
        q_4msg_label = q_attr.get('q_4msg_label', '')

        # 兼容旧格式
        key_res = 'star_finished_set:prod'
        key = 'star_pending_set:prod'
        if q_4msg_type == 'ip':
            key_res = 'ip_finished_set:prod'
            key = 'ip_pending_set:prod'
        elif q_4msg_type == 'game_star':
            # game star
            key_res = 'game_star_finished_set:prod'
            key = 'game_star_pending_set:prod'
        elif q_4msg_type == 'game_ip':
            # game ip
            key_res = 'game_ip_finished_set:prod'
            key = 'game_ip_pending_set:prod'

        try:
            redis_client = self.redis_client.get_redis_server(key)
            res_len = await redis_client.srem(key, query)
            self.logger.info(self.pre_log_msg + f"remove task from redis: {key}, res_len: {res_len}")
            if notify_has_res:
                redis_client = self.redis_client.get_redis_server(key_res)
                f_len = await redis_client.sadd(key_res, query)
                self.logger.info(self.pre_log_msg + f"set finished task to redis: {key_res}, res_len:{f_len}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"remove task from redis error: {e}")

from pydantic import BaseModel, Field
from typing import List, Any


class MaterialModel(BaseModel):

    # 保存物料
    mid_list: List[str] = Field(default_factory=list, description="链接列表")
    sina_article_data: List[Any] = Field(default_factory=list, description="链接列表")
    baike_knowledge: List[Any] = Field(default_factory=list, description="链接列表")
    history_hot_res: List[Any] = Field(default_factory=list, description="链接列表")
    zs_knowledge: List[Any] = Field(default_factory=list, description="链接列表")
    user_search_res: List[Any] = Field(default_factory=list, description="用户搜索结果")


class RedisComparisonStorage(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.redis_client = async_redis_client
        self.days = 7

    def make_mid_from(self, raw_material_list):
        mid_from_dict = {}
        for item in raw_material_list:
            mid = item.get('mid', '')
            frm = item.get('from', '')
            if mid:
                mid_from_dict[mid] = frm
        return mid_from_dict

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        query = weibo.get("query", "")
        result = weibo.get("ori_result", "")
        source = weibo.get("source", "")
        q_attr = weibo.get("q_attr", "")
        llm_name = weibo.get("llm_name", "")
        version = weibo.get("version", "")
        prompt_scene = weibo.get("prompt_scene", "")
        prompt = weibo.get("prompt", "")
        link_list = weibo.get("link_list", [])
        raw_material_list = weibo.get("raw_material_list", [])

        if source != '12':
            return

        if source:
            try:
                mid_from = self.make_mid_from(raw_material_list)
                material_data = MaterialModel(**weibo)
                all_material = json.dumps(material_data.model_dump(), ensure_ascii=False)

                json_data = {
                    'content': result,
                    "query": query,
                    "model": llm_name,
                    "version": version,
                    "q_attr": q_attr,
                    "prompt_scene": prompt_scene,
                    "prompt": prompt,
                    "all_material": all_material,
                    "link_list": json.dumps(link_list, ensure_ascii=False),
                    "mid_from": json.dumps(mid_from, ensure_ascii=False)
                }

                start = time.time()
                key = f'wis_summary_compare_{query}'
                redis_client = self.redis_client.get_redis_server(key)
                try:
                    for k, v in json_data.items():
                        await redis_client.hset(key, k, v)
                    await redis_client.expire(key, self.days * 24 * 60 * 60)
                    self.logger.info(
                        f"trace_id:{trace_id}\tquery:{query}\t redis write success cost: {time.time() - start}")
                except Exception as e:
                    self.logger.error(f"trace_id:{trace_id}\tquery:{query}\t error:{e}")

                self.logger.info(f"trace_id:{trace_id}\tquery:{query}\t")
            except Exception as e:
                self.logger.error(f"trace_id:{trace_id}\tquery:{query}\terror:{e}")

    async def close(self):
        pass


class RedisABTestQueryStorage(Base):

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        trace_id = weibo.get("trace_id", "")
        query = weibo.get("query", "")
        llm_result = weibo.get("result", "")
        abtests = weibo.get("abtests", "")
        is_lab_filter = weibo.get("is_lab_filter", False)
        if llm_result and 'lab_xx' in abtests and is_lab_filter == False:
            try:
                await write_ab_query(query)
                self.logger.info(f"trace_id:{trace_id}\tquery:{query}\t")
            except Exception as e:
                self.logger.error(f"trace_id:{trace_id}\tquery:{query}\terror:{e}")

    async def close(self):
        pass