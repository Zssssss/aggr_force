# -*- coding: utf-8 -*-
"""
用户类型判断

@Author: qiuhong
@CreateDate: 2025-06-12
@LastModified: 2025-06-12
"""

def is_redv_user(verified_type, verified_type_ext):
    """
    判断用户是否为红V用户
    :param verified_type: 认证类型
    :param verified_type_ext: 扩展认证类型
    :return: bool
    """
    return (int(verified_type) == 3 and int(verified_type_ext) == 53)