# -*- coding:utf-8 -*-
import asyncio
import json
import random
import re
from datetime import datetime, timedelta
from collections import Counter
from collections import defaultdict
import time
import traceback
import itertools
import aiohttp

from api.model_api import GaoKaoIntentionWrapper, get_deepseek_r1_model_from_weibo_sid
from conf.config import RISK_CONTROL_3_6_SWITCH

from conf.config import RISK_CONTROL_3_6_SWITCH, DICT_GAOKAO_KW
from lib.base import Base
from lib.safe_convert import convert_to_float, convert_to_int
from lib.mongo_helper import MongoHelper, AsyncMongoHelper
from lib.redis_utils import async_redis_client, async_old_redis_client, jing_xuan_async_redis_client
from lib.weibo_interface import checkQualifiedOcrText, get_voice, get_user_info, get_url_marked, get_pid_info
from plugins.flyweight.hotsearch_bang import hotsearch_bang_dict, reliable_tips_dict, guide_text_dict, event_group_dict, \
    sina_night_cove, sina_night_prompt
from plugins.flyweight.user_feedback import user_feedback_dict, cove_manual_dict, CoveMaterialLoader
from plugins.llm.utils import count_tokens, is_stream_output, is_hot_query, read_ab_query
from plugins.user.user_type import is_redv_user
from plugins.common.intervene_common import REDIS_INTERVENE_KNOWLEDGE_PREFIX
from plugins.material.filter import (
    MaterialContentFilter, BlackMidFilter, SelfMidFilter,
    CategoryFilter, RiskLevelFilter, FilterChain, RiskLevel,
    SafeTagFilter, FILTERED_KEYWORDS, TimeRangeFilter, ReliableUIDFilter
)
from plugins.material.material_api import (
    get_summary_material,
    get_account_material,
    get_trend_summary_material,
    get_zongshu_contents,
    get_query_cate_list, get_pic_url, extract_material, structure_material, get_knowledge_api,
    get_zhisou, get_query_type, get_zhisou_new, get_zhisou_emotion_res, read_search_knowledge, read_starip_result,
    read_previous_result, fmt_stock_info, clean_text, material_filter, get_weibo_year, repl_time_year, get_weibo_time,
    # get_baike_knowledge,
    get_search_material,
    get_tm_dict,
    shorttv_material_filter, media_material_filter, replace_emoji, change_material_save_top1_topic, ht_hashtag_rewrite,
    get_query_time_grade,
    get_article,
    get_refute_material,
    get_size_from_pid,
    compatible_mat,
    extract_history_struct_data,
    call_query_extend,
    get_content_user_name,
    struct_cur_hot,
    fetch_stock_via_api,
    build_stock_content,
    get_gaokao_agent_material, mid_clean,
    read_ctr_res_via_redis,
    struct_ctr_result,
    read_sina_news_via_http,
    read_broadsocial_res_res_via_redis,
    read_weibo_click4hotstar,
    get_hot_brief_material,
    get_query_version_list_via_http,
    read_r1_res_via_http,
    get_hot_query_list_90d,
    get_hot_query_list_full_year,
    read_and_struct_his_s_summary,
    make_event_deep_research_his_summary
)
from plugins.material.query_search import (
    QueryTrie,
    StockDict,
    get_media_uids,
    get_medical_uids,
    get_consulate_uids,
    get_credible_media_uids,
    get_risk_filter_uids,
    HotQueryLlm,
    get_credible_uids,
    get_displayed_uids,
    get_star_black_uids,
    get_star_white_uids
)
from plugins.prompt.college import college_intention_factory
from plugins.storage.redis_storage import RedisImageVector
from lib.timeit import timeit
from lib.redis_utils import async_redis_client
from plugins.material.utils import Utils as MaterialUtils

from collections import defaultdict
from lib.weibo_interface import http_get_json_with_c_token, async_http_get_json_with_c_token

import tools.discovery.dconf as discovery

stock_dict = StockDict()
async_mongo_shorttv = AsyncMongoHelper("manual_shorttv")
async_mongo_cove_content = AsyncMongoHelper("manual_setting")
async_mongo_black_mid = AsyncMongoHelper("manual_blackmid")
MEDIA_UIDS,DA_V_UIDS,_ = get_credible_uids()
CONSULATE_UIDS = get_consulate_uids()
CREDIBLE_MEDIA_UIDS = get_credible_media_uids()
RISK_FILTER_UIDS = get_risk_filter_uids()
MEDICAL_UIDS = get_medical_uids()
DISPLAYED_UIDS = get_displayed_uids()
STAR_BLACK_UID_DICT = get_star_black_uids()
STAR_WHITE_UIDS = get_star_white_uids()
global STAR_LIST
with open("data/star.json", "r", encoding="utf-8") as f:
    STAR_LIST = json.load(f)
query_trie = QueryTrie(STAR_LIST)


class SummaryMaterial(Base):
    abtest: bool = False

    def check_is_about_xi(self, weibo):
        """判断是否敏感"""
        about_xi = 0
        q_attr = weibo.get("q_attr", "")
        try:
            if q_attr:
                attr_dict = json.loads(q_attr)
                about_xi = attr_dict.get("about_xi", 0)
        except:
            about_xi = 0
        return about_xi

    def set_url(self):
        url = "http://i.huati.search.weibo.com/llm/zongshu_material.json"
        d3_limit = 100
        return url, d3_limit

    def grade_to_days(self, raw_time_grade):
        return 3 if raw_time_grade == "strong" else 30

    async def fetch(self, trace_id, query, query_category, llm_name, stream_output):
        post_url, d3_limit = self.set_url()
        res_list, raw_time_grade = await get_summary_material(
            trace_id=trace_id, query=query, query_category=query_category, llm_name=llm_name,
            stream_output=stream_output, post_url=post_url, d3_limit=d3_limit, logger=self.logger, source=self.raw_source)
        return res_list, raw_time_grade


    def merge_ext_query_res(self, main_res_list, ext_results):
        res_list = list()
        if not ext_results.get('extends_querys'):
            return main_res_list, ext_results
        tmp_dict = ext_results['extends_querys']
        baike_knowledge = ext_results.get('baike_res', [])
        if not isinstance(baike_knowledge, list):
            baike_knowledge = list()
        sina_article_data = ext_results.get('article_res', [])
        if not isinstance(sina_article_data, list):
            sina_article_data = list()
        history_hot_res = ext_results.get('history_hot_res', [])
        if not isinstance(history_hot_res, list):
            history_hot_res = list()
        res_list.extend(main_res_list)
        exist_mids = set([i.get('mid') for i in res_list])
        exist_articles_urls = set([i.get('19') for i in sina_article_data if isinstance(i, dict) and i.get('77') and i.get('19')])
        self.logger.info(self.pre_log_msg + f"merge before ext_querys\tres_list:{len(res_list)}\tbaike_knowledge:{len(baike_knowledge)}\tsina_article_data:{len(sina_article_data)}\thistory_hot_res:{len(history_hot_res)}")
        ext_articles = list()
        ext_weibos = list()
        for ext_query, other_ext_mats in tmp_dict.items():
            if isinstance(other_ext_mats.get('weibo', {}), dict):
                ext_weibos.append(other_ext_mats.get('weibo', {}).get('list', []))
            other_article = other_ext_mats.get('article', [])
            if isinstance(other_article, list):
                ext_articles.extend(other_article[:1])
        ext_weibos = [i for i in itertools.chain.from_iterable(itertools.zip_longest(*ext_weibos, fillvalue=[])) if i]
        for i in ext_weibos:
            if i.get('mid') not in exist_mids and int(i.get('category', 0)) not in [31, 1005]:
                new_i = compatible_mat(i)
                # 添加from_ext
                new_i['from_ext'] = True
                res_list.append(new_i)
                exist_mids.add(new_i.get('mid'))
        for i in ext_articles:
            if isinstance(i, dict) and i.get('19') and i.get('77') and i.get('19') not in exist_articles_urls:
                sina_article_data.append(i)
                exist_articles_urls.add(i.get('19'))
        self.logger.info(self.pre_log_msg + f"merge after ext_querys\tres_list:{len(res_list)}\tbaike_knowledge:{len(baike_knowledge)}\tsina_article_data:{len(sina_article_data)}\thistory_hot_res:{len(history_hot_res)}")
        self.logger.info(self.pre_log_msg + f"after merge_ext_query_res all mid list: {[i.get('mid') for i in res_list]}\tall_category_list:{[i.get('category') for i in res_list]}")
        return res_list, {'baike_res': baike_knowledge, 'article_res': sina_article_data, 'history_hot_res': history_hot_res, 'user_search_res': ext_results.get('user_search_res', []), 'current_hot_res': ext_results.get('current_hot_res', []), 'account_mats': ext_results.get('account_mats', []), 'gaokao_mats': ext_results.get('gaokao_mats', []), 'zs_knowledge': ext_results.get('zs_knowledge', []), "first_grid_doc_num": ext_results.get('first_grid_doc_num', 0)}

    def struct_gaokao_mats(self, gaokao_mats):
        struct_gaokao_list = list()
        if not isinstance(gaokao_mats, list):
            return struct_gaokao_list
        for gk in gaokao_mats:
            gaokao_inp = list()
            if isinstance(gk, dict):
                title = gk.get('77', '')
                if title:
                    gaokao_inp.append(f'标题:{title}')
                url = gk.get('19', '')
                pub_time = gk.get('4', '')
                contents = gk.get('87')
                if contents:
                    js_content = json.loads(contents)
                    for k, v in js_content.items():
                        chinese_k = DICT_GAOKAO_KW.get(k, k)
                        if chinese_k and v:
                            gaokao_inp.append(f'{chinese_k}:{v}')
                inp = {'内容': '\n'.join(gaokao_inp), '内容来源': '高考物料', '内容类型': '高考物料', 'url': url, '发布时间': pub_time}
                struct_gaokao_list.append(inp)
        return struct_gaokao_list

    def struct_zs_knowledge(self, zs_knowledge_list: list) -> list:
        struct_zs_knowledge_list = []
        if not isinstance(zs_knowledge_list, list):
            self.logger.error(self.pre_log_msg + f"type of (zs_knowledge) is not list:{type(zs_knowledge_list)}")
            return []
        try:
            for item in zs_knowledge_list:
                pub_time_ts = int(item.get('doc_rank', ''))
                pub_time = datetime.fromtimestamp(pub_time_ts).strftime('%Y年%m月%d日')
                content = item.get('text', '')
                url = item.get('78', '')
                struct_zs_knowledge_list.append({
                    '内容': content,
                    '内容来源': '微博',
                    '内容类型': '智搜知识库',
                    'url': url,
                    '发布时间': pub_time,
                    # '发布账号名': '微博智搜',
                    '发布账号类型': '媒体账号'
                })
            return struct_zs_knowledge_list
        except:
            self.logger.error(self.pre_log_msg + f"zs_knowledge_list struct error: {traceback.format_exc()}")
        return []
            


    def struct_account_info(self, query, account_info_list):
        struct_account_list = list()
        if not isinstance(account_info_list, list):
            return struct_account_list
        for ac_info in account_info_list:
            screen_name = ac_info.get('screen_name', '')
            if screen_name.lower() != query.lower():
                continue
            uid = ac_info.get('idstr', '')
            verified = ac_info.get('verified', False)
            verified_type = ac_info.get('verified_type', -1)
            verified_type_ext = ac_info.get('verified_type_ext', -1)
            avatar_large = ac_info.get("avatar_large", "")
            mbtype = ac_info.get('mbtype', -1)
            if uid:
                acc_inp = {'微博昵称': screen_name,
                        '微博认证信息': ac_info.get('verified_reason', ''),
                        '微博简介': ac_info.get('description', ''),
                        '微博粉丝量': ac_info.get('followers_count', ''),
                        }
                inp = {'内容': acc_inp, '内容来源': '微博账号个人主页', '内容类型': '个人主页', 'url': f'sinaweibo://userinfo?uid={uid}',
                        "verified": verified, "verified_type": verified_type, "verified_type_ext": verified_type_ext, "avatar_large": avatar_large, "mbtype": mbtype, '用户uid': uid}
                if uid in MEDIA_UIDS:
                    inp["发布账号类型"] = "媒体账号"
                # elif (int(verified_type) == 0 and int(verified_type_ext) in [1, 2]) or (int(verified_type) == 3 and int(verified_type_ext) == 53):
                elif uid in DA_V_UIDS:
                    inp["发布账号类型"] = "大V账号"
                elif (int(verified_type) >= 0 and int(verified_type) <= 7):
                    inp["发布账号类型"] = "认证账号"
                else:
                    inp["发布账号类型"] = "普通账号"
                struct_account_list.append(inp)
        return struct_account_list[:1]

    def baike_rank_filter(self, baike_list):
        """根据title返回同名百科"""
        if not isinstance(baike_list, list):
            return baike_list
        if not baike_list:
            return baike_list
        res = [baike_list[0]] # 默认返回1条
        for item in baike_list[1:]:
            if item.get('title') != res[0].get('title'):
                # 按照排序，如果title不同，则中断筛选
                break
            res.append(item)
        # 限制条数 -> 1条
        res = res[:1]
        url_list = [i.get('url') for i in res]
        self.logger.info(self.pre_log_msg + f"baike_rank_filter ori get\turl_list:{url_list}")
        return res


    def proc_account_mats(self, res_list, weibo):
        func_name = "ACCOUNT-MATERIAL"
        try:
            content_list, pic_ids_list, video_abs_list, mid_list, tag_list, verified_type_list, name_list, from_list = extract_material(res_list)
            struct_content_list, struct_mid_list, tag3_list = structure_material(
                content_list, mid_list, tag_list, verified_type_list, name_list)
            weibo['account_raw_material_list'] = res_list
            weibo['account_content_list'] = content_list
            weibo['account_video_abs_list'] = video_abs_list
            weibo['account_mid_list'] = mid_list
            weibo['account_struct_content_list'] = struct_content_list
            weibo['account_struct_mid_list'] = struct_mid_list
            weibo['account_tag3_list'] = tag3_list
            weibo['account_verified_type_list'] = verified_type_list
            weibo['account_name_list'] = name_list
            weibo['account_from_list'] = from_list
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")

    def make_from_zhisou_quote_dict(self, raw_weibo_list: list) -> dict:
        if not isinstance(raw_weibo_list, list):
            return {}
        if not raw_weibo_list:
            return {}
        zhisou_quote_dict = {}
        for raw_weibo in raw_weibo_list:
            url_objects = raw_weibo.get('trans_objects', [])
            mid = raw_weibo.get('mid', "")
            uid = raw_weibo.get('uid', "")
            if isinstance(url_objects, list):
                for url_object in url_objects:
                    url_object = url_object.get('object', {})
                    object_type = url_object.get('object_type', "")
                    if object_type == "ai_summary":
                        zhisou_quote_dict[mid] = {
                            "is_quote": False,
                            "uid": uid,
                        }

        return zhisou_quote_dict

    def filter_weibo_by_black_uids(self, weibo_list: list, query: str, query_category: str) -> list:
        try:
            blockd_mids = []
            res_list = []
            if query_category != '明星':
                return weibo_list
            if not isinstance(weibo_list, list):
                return weibo_list
            if not weibo_list:
                return weibo_list
            black_star_uids = STAR_BLACK_UID_DICT.get(query, [])
            for item in weibo_list:
                mid = item.get('mid', '')
                uid = item.get('uid', '')
                if str(uid) in black_star_uids:
                    blockd_mids.append(mid)
                    continue
                res_list.append(item)
            self.logger.info(self.pre_log_msg + f"after black_uid4star filter: {len(res_list)}\tblockd_mids: {blockd_mids}")
            return res_list
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"filter_weibo_by_black_uids error:{e}, msg:{traceback.format_exc()}")

    def get_mid_business_list(self, raw_list: list[dict]) -> list:
        mid_business_list = []
        for raw in raw_list:
            mid = raw.get('mid', '')
            is_ads = raw.get('is_ads', False)
            if is_ads:
                mid_business_list.append(mid)
        return mid_business_list

    def make_mid_attrs_mapping(self, raw_material_list: list[dict]) -> dict:
        res = {}
        if not isinstance(raw_material_list, list):
            return res
        try:
            for item in raw_material_list:
                if not isinstance(item, dict):
                    continue
                mid = item.get("mid")
                # uid
                doc_domain = item.get("uid")
                a_features = item.get("authoritative_features")
                if a_features:
                    try:
                        feature_dict = json.loads(a_features)
                    except:
                        feature_dict = eval(a_features)
            
                    # 质量分
                    final_qi_score = feature_dict.get("final_qi_score")
                    # 有效互动
                    doc_valid_num = feature_dict.get("doc_valid_num")
                    # 权威分
                    authority_score = feature_dict.get("authority_score")
                    # 相关性分
                    hit_score_final = feature_dict.get("hit_score_final")

                    if mid:
                        res[mid] = {
                            "doc_domain": str(doc_domain),
                            "final_qi_score": str(final_qi_score),
                            "doc_valid_num": str(doc_valid_num),
                            "authority_score": str(authority_score),
                            "hit_score_final": str(hit_score_final),
                        }
        except:
            self.logger.error("make_mid_attrs_mapping error:{}".format(traceback.format_exc()))
        return res


    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        start = time.time()
        func_name = "SUMMARY-MATERIAL"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("traceid", "")
        ori_query = weibo.get("ori_query", "")
        query = weibo.get("query", "")
        llm_name = weibo.get("llm_name", "")
        event_deep_research_flag = weibo.get('event_deep_research', False)
        self.llm_name = llm_name
        stream_output = weibo.get("stream_output", 0)
        query_category = weibo.get("query_category", "")
        self.raw_source = weibo.get("source", "")
        self.abtest = ('lab_m1' == weibo.get('abtest', ''))
        self.new_format = False
        self.about_xi = self.check_is_about_xi(weibo)
        self.query_raw_time_grade = weibo.get("query_raw_time_grade", "")
        self.query_field = weibo.get("query_field", -1)
        self.time_analysis_dict = weibo.get('debug', {}).get('time_analysis',{})
        self.logger.info(self.pre_log_msg + (
            f"query_field: {self.query_field}\t"
            f"query_raw_time_grade: {self.query_raw_time_grade}\t"
            f"query_category: {query_category}\t"
            f"about_xi: {self.about_xi}\t"
            f"llm_name: {llm_name}"
            ))
        try:
            res_list, raw_time_grade, ext_mats,query_field = await self.fetch_refactor(trace_id, query, query_category, llm_name, stream_output)
            res_list, ext_mats = self.merge_ext_query_res(res_list, ext_mats)
            # 过滤黑名单
            res_list = self.filter_weibo_by_black_uids(res_list, query, query_category)
            content_list,pic_ids_list, video_abs_list, mid_list, tag_list, verified_type_list, name_list,from_list = extract_material(res_list)
            query_grade = self.grade_to_days(raw_time_grade)
            struct_content_list, struct_mid_list, tag3_list = structure_material(
                content_list, mid_list, tag_list, verified_type_list, name_list)
            mid_business_list = self.get_mid_business_list(res_list)
            self.logger.info(self.pre_log_msg + f"add mid_business_list: {mid_business_list}")
            weibo['mid_business_list'] = mid_business_list
            weibo['raw_material_list'] = res_list
            weibo['content_list'] = content_list
            weibo['pic_ids_list'] = pic_ids_list
            weibo['video_abs_list'] = video_abs_list
            weibo['mid_list'] = mid_list
            weibo['struct_content_list'] = struct_content_list
            weibo['struct_mid_list'] = struct_mid_list
            weibo['query_grade'] = query_grade
            weibo['raw_time_grade'] = raw_time_grade
            weibo["query_field"] = query_field
            weibo['tag3_list'] = tag3_list
            weibo['verified_type_list'] = verified_type_list
            weibo['name_list'] = name_list
            weibo['from_list'] = from_list
            weibo['from_zhisou_quote_dict'] = self.make_from_zhisou_quote_dict(res_list)
            weibo['uid_attrs_mapping'] = self.make_mid_attrs_mapping(res_list)
            weibo['first_grid_doc_num'] = ext_mats.get('first_grid_doc_num', 0)
            weibo['m_use_new_format'] = self.new_format

            baike_knowledge = [{'content':i.get('77'), 'url': i.get('19'), 'title': i.get('30')} for i in ext_mats.get('baike_res', []) if isinstance(i, dict) and i.get('77') and i.get('19')]
            weibo['baike_knowledge'] = self.baike_rank_filter(baike_knowledge)
            sina_article_data = [
                                    {
                                        "content": i.get("mainText"),
                                        "url": i.get("url"),
                                        "final_qi_score": i.get("final_qi_score", "0"),
                                        "pub_ts": i.get("doc_rank"),
                                        "doc_id": i.get("doc_id"),
                                        "from_web": i.get("from_web", "0"),
                                        "hit_score_final": i.get("hit_score_final", "0"),
                                        "is_credible": i.get("is_credible", "0"),
                                        "is_kuake": i.get("is_kuake", 0),
                                        **({"ps_idx": i["ps_idx"]} if "ps_idx" in i else {}),
                                        **({"vs_idx": i["vs_idx"]} if "vs_idx" in i else {}),
                                        **({"ext_idx": i["ext_idx"]} if "ext_idx" in i else {}),
                                    }
                                    for i in ext_mats.get("article_res", [])
                                    if isinstance(i, dict) and i.get("mainText") and i.get("url")
                            ]
            self.logger.info(self.pre_log_msg + f"all_sina_article_data:{[item.get('url', '') for item in sina_article_data]}\tall_is_kuake:{[int(item.get('is_kuake', 0)) or int(item.get('from_web', '0')) for item in sina_article_data]}")
            if sina_article_data:
                if not self.new_format:
                    weibo['sina_article_data'] = sina_article_data[:10]
                else:
                    weibo['sina_article_data'] = sina_article_data
            history_hot_res, history_hot_ref_q_ts_list = extract_history_struct_data(ext_mats.get('history_hot_res', []), self.logger)
            # 历史热点精简限定人物
            if weibo.get('famous_person_intention', {}).get('is_exact_match', '') == '1' or weibo.get('da_intention_exact_match', '') == '1' or event_deep_research_flag:
                his_hot_s_list, his_need_refresh_list = await read_and_struct_his_s_summary(history_hot_ref_q_ts_list, self.logger, self.pre_log_msg, event_deep_research_flag)
                if his_hot_s_list:
                    if event_deep_research_flag:
                        res = make_event_deep_research_his_summary(query, his_hot_s_list, self.logger, self.pre_log_msg)
                        if res:
                            history_hot_res = [res] + history_hot_res

                    weibo['his_hot_s_list'] = his_hot_s_list
                    self.logger.info(self.pre_log_msg + f"add his_hot_s_list: {len(his_hot_s_list)}")
                if his_need_refresh_list:
                    weibo['his_need_refresh_list'] = his_need_refresh_list
                    self.logger.info(self.pre_log_msg + f"add his_need_refresh_list: {his_need_refresh_list}")
            weibo['history_hot_res'] = history_hot_res[:3] if history_hot_res else []
            user_search_res = self.struct_account_info(query, ext_mats.get('user_search_res', []))
            if user_search_res :
                weibo["exact_account_query"] = 1
            if ori_query.endswith("_zhanghao") or query_category in ['Account_Nor', 'kol']:
                weibo['user_search_res'] = user_search_res
            current_hot_res = await struct_cur_hot(ext_mats.get('current_hot_res', []), self.logger, self.pre_log_msg)
            if current_hot_res:
                weibo['current_hot_res'] = current_hot_res
            account_mats = ext_mats.get('account_mats', [])
            gaokao_mats = self.struct_gaokao_mats(ext_mats.get('gaokao_mats', []))
            if gaokao_mats:
                weibo['gaokao_mats'] = gaokao_mats
                weibo['history_hot_res'] = gaokao_mats + weibo.get('history_hot_res', [])
            zs_knowledge = self.struct_zs_knowledge(ext_mats.get('zs_knowledge', []))
            if zs_knowledge:
                weibo['zs_knowledge'] = zs_knowledge
            self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time()-start}\t"
                                                f"content_list_len:{len(content_list)}\t"
                                                f"baike_list_len:{len(baike_knowledge)}\t"
                                                f"sina_article_list_len:{len(sina_article_data)}\t"
                                                f"history_hot_res_len:{len(history_hot_res)}\t"
                                                f"current_hot_res_len:{len(current_hot_res)}\t"
                                                f"gaokao_mats_len:{len(gaokao_mats)}\t"
                                                f"account_mats_len:{len(account_mats)}\t"
                                                f"zs_knowledge_len:{len(zs_knowledge)}\t"
                                                f"raw_time_grade:{raw_time_grade}")
            self.proc_account_mats(account_mats, weibo)
            weibo["debug"]["time_analysis"][f"{func_name}_start"] = start
            weibo["debug"]["time_analysis"][f"{func_name}_end"] = time.time()
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")

    @staticmethod
    def get_original_material(weibo):
        """获取原始的物料数据"""
        keys = ["category", "stream_output", "content_list", "pic_ids_list", "video_abs_list", "mid_list", "struct_content_list", "struct_mid_list",
                "tag3_list", "verified_type_list", "name_list","query_category","from_list", "raw_material_list", "limit_degree", "user_v_type", "material_time_range", "limit_material", "limit_degree_reliable_uids"]
        result = {}
        for key in keys:
            result[key] = weibo.get(key, [])
        return result

    @staticmethod
    def update_weibo(weibo, result):
        """更新weibo数据"""
        for key, value in result.items():
            weibo[key] = value

    @staticmethod
    def get_pic_tags_from_hbase(data_list):
        for i in data_list:
            tmp_dict = dict()
            tmp_dict_finger = dict()
            pic_ids = i.get('pic_ids', [])
            pic_tags = i.get('pic_tags', '')
            pic_info = i.get('pic_info', [])
            pic_finger = i.get('picture', '')
            try:
                pic_waic = json.loads(i.get('pics_waic'))
            except:
                pic_waic = dict()
            if pic_info:
                for pic in pic_info:
                    pic_id = pic.get("pic_id", "")
                    if pic_id in pic_waic:
                        fea_1174 = pic_waic[pic_id].get('1174', -1)
                        pic.update({'fea_1174': fea_1174})
            fetchdata_ext = i.get('fetchdata_ext', {})
            try:
                photo_sub_type = json.loads(fetchdata_ext).get('pic', {}).get('photo_sub_type', '')
            except:
                photo_sub_type = ''
            if photo_sub_type and pic_info and pic_ids:
                photo_sub_type_list = photo_sub_type.split(',')
                if len(photo_sub_type_list) == len(pic_ids):
                    tmp_dict_type = dict(zip(pic_ids, photo_sub_type_list))
                    for pic in pic_info:
                        pic_id = pic.get("pic_id", "")
                        if pic_id in tmp_dict_type:
                            pic.update({'photo_sub_type': tmp_dict_type[pic_id]})
            if pic_finger:
                pic_finger = pic_finger.split(',')
            else:
                pic_finger = []
            if pic_finger and pic_ids and len(pic_finger) == len(pic_ids) and pic_info:
                tmp_dict_finger = dict(zip(pic_ids, pic_finger))
                for pic in pic_info:
                    pic_id = pic.get("pic_id", "")
                    if pic_id in tmp_dict_finger:
                        pfinger = tmp_dict_finger[pic_id]
                        pic.update({'pic_finger': pfinger})
            if pic_tags:
                pic_tags = pic_tags.split(',')

            mix_media_ids = i.get('mix_media_ids', [])
            if mix_media_ids and pic_info:
                for pic in pic_info:
                    pic_id = pic.get('pic_id', '')
                    if pic_id in mix_media_ids:
                        pic_idx = mix_media_ids.index(pic_id)
                        pic.update({'mix_media_id': pic_idx})
            if pic_ids and pic_tags and pic_info:
                if len(pic_tags) == len(pic_ids):
                    tmp_dict = dict(zip(pic_ids, pic_tags))
                    for pic in pic_info:
                        pic_id = pic["pic_id"]
                        if pic_id in tmp_dict:
                            ptag = tmp_dict[pic_id]
                            pic.update({'ptag': ptag})
        return data_list


    @staticmethod
    def get_pic_list(raw_material, material_dict, pic_info_list, text, name, mid, i,
                verified_type, is_blue, is_gold_orange, threshold, unify, mid_pid_dic, is_media_user, pid_dup_dic, ocr_limit, pid_set, mid_set):
        """处理采编图片"""
        pic_list = []
        pic_info = raw_material.get("pic_info", [])
        # 图片筛选
        def is_valid_picture(pic, is_blue, threshold, ocr_len, h, w, is_media_user, ocr_limit):
            return True
            # if  h * w <= 118 * 118:
            #     return False
            # if is_media_user:
            #     return True
            # if pic.get("ptag", "0") != "0":
            #     return False
            # if pic.get("score", 0) <= 0.366:
            #     return False
            # if ocr_len >= 10 or ocr_len < 0:
            #     return False
            # return h / w < 2

        if pic_info:
            for pic in pic_info:
                ocr_len = pic.get("ocr_len", -2)
                h, w = get_size_from_pid(pic.get("pic_id", ""))
                if is_valid_picture(pic, is_blue, threshold, ocr_len, h, w, is_media_user, ocr_limit):
                    pic_id = pic.get("pic_id", "")
                    pic_list.append(pic_id)
                    pid_set.add(pic_id)
                    mid_set.add(mid)
                    if pic_id not in mid_pid_dic:
                        mid_pid_dic[pic_id] = mid

                    if pic_id not in pid_dup_dic:
                        pid_dup_dic[pic_id] = pic.get("dup_group", -1)

                    pic_info_list.setdefault(mid, dict()).setdefault(pic_id, dict())
                    pic_info_list[mid][pic_id]["category"] = raw_material.get("category", "")
                    pic_info_list[mid][pic_id]["score"] = pic.get("score", 0)
                    pic_info_list[mid][pic_id]["ocr_len"] = ocr_len
                    pic_info_list[mid][pic_id]["ocr"] = pic.get("ocr", "")
                    pic_info_list[mid][pic_id]["dup_group"] = pic.get("dup_group", -1)
                    pic_info_list[mid][pic_id]["unify"] = unify
                    pic_info_list[mid][pic_id]["type"] = pic.get("type", '')
                    pic_info_list[mid][pic_id]["h"] = h
                    pic_info_list[mid][pic_id]["w"] = w
                    pic_info_list[mid][pic_id]["pic_tags"] = pic.get("ptag", "0")
                    pic_info_list[mid][pic_id]["name"] = name
                    pic_info_list[mid][pic_id]["verified_type"] = verified_type
                    pic_info_list[mid][pic_id]["is_gold_orange"] = is_gold_orange
                    pic_info_list[mid][pic_id]["threshold"] = threshold
                    pic_info_list[mid][pic_id]["material_sequence"] = i
                    pic_info_list[mid][pic_id]["is_media_user"] = is_media_user
                    pic_info_list[mid][pic_id]["is_top_up"] = raw_material.get("category", 0) == 306
                    pic_info_list[mid][pic_id]["doc_valid_num"] = raw_material.get('a_feature', {}).get("doc_valid_num", 0)
                    pic_info_list[mid][pic_id]["fea_1174"] = pic.get("fea_1174", -1)
                    if pic.get("pic_finger"):
                        pic_info_list[mid][pic_id]["pic_finger"] = pic.get("pic_finger")
                    if pic.get("mix_media_id"):
                        pic_info_list[mid][pic_id]["mix_media_id"] = pic.get("mix_media_id")
                    if pic.get("photo_sub_type"):
                        pic_info_list[mid][pic_id]["photo_sub_type"] = pic.get("photo_sub_type")

        return pic_list, pic_info_list

    @staticmethod
    async def get_result_from_material_dict(query, ori_query, black_mids, material_dict, mid_is_medical=False, **kwargs):
        """通过原始的物料数据结构化"""
        result = {"mid_list": [], "content_list": [], "struct_content_list": [], "blue_v": [], "list_tag3": [],
                  "text_url_dict": [], "pid_dup_dic":{}, "vector_dict":{}, "video_mid_list": [],
                  "filter_reasons": ""}
        query_category = material_dict["query_category"]
        query_risk_level = material_dict.get("limit_degree", "")
        user_v_type = material_dict.get("user_v_type", [])
        # material_time_range = material_dict.get("material_time_range", {}) # 为空则不进行by时间的物料过滤
        limit_degree_reliable_uids = material_dict.get("limit_degree_reliable_uids", []) # 为空则不进行by uid的物料过滤
        limit_material = material_dict.get("limit_material", False)
        first_grid_doc_num = kwargs.get('first_grid_doc_num', 0)
        m_use_new_format = kwargs.get('m_use_new_format', False)
        prompt_scene = kwargs.get('prompt_scene', '')
        dup_group_list = set()
        video_mid_dict = dict()
        mid_feature_dict = dict()
        user_feature_dict = dict()
        pic_info_list= {"use_ocr":False}
        video_info_list= {"query":query,"use_voice":False}
        pic_info_list["query"] = query
        mid_pid_dic = defaultdict(list)
        # 六月风控专项过滤
        filterd_june_mid_list = defaultdict(list)
        # 过滤原因+mid
        filterd_reason_dict = {
            'deepseek_last': [],
            'consulate_uid': [],
            'by_time': [],
            'by_time_kol': []
        }

        # raw_material_list = material_dict['raw_material_list']
        # 是否命中by时间过滤物料关键词
        is_filtered_by_time = False
        for kwd in FILTERED_KEYWORDS:
            if kwd in query:
                is_filtered_by_time = True
                break
        
        img_vector = RedisImageVector()
        pid_dup_dic = defaultdict(list)

        raw_material_list = material_dict['raw_material_list']
        raw_material_list = SummaryMaterial.get_pic_tags_from_hbase(raw_material_list)

        # 分层prompt渲染
        extra_info_q_tag_set = set()
        if not m_use_new_format:
            for item in raw_material_list[:first_grid_doc_num]:
                item['doc_level_top'] = '1'
        mid_set = set()
        pid_set = set()
        for i in range(len(material_dict["content_list"])):
            struct_data = {"内容": "", "图片url_list":"", "发布时间": "", "内容来源": "微博", "内容类型": "", "发布账号类型": "", "内容可信分级": ""}
            text_url_dic = {"text":"", "url_list":""}
            extra_info_tag_set = set()
            #if not ori_query.endswith("_zhanghao") and query_category not in ['Account_Nor', 'kol']:
            #    if f'@{query.lower()}' in material_dict["content_list"][i].lower() or query.lower() == raw_material_list[i].get("name","").lower() :
            #        continue
            abs_info = raw_material_list[i].get("abs_info", {})
            user_attr1 = abs_info.get("user_attr1", "")
            if prompt_scene == 'deepseek_last' and user_attr1 not in ['组织号', '明星']:
                filterd_reason_dict['deepseek_last'].append(raw_material_list[i].get("mid", ""))
                continue
            
            all_user_name = get_content_user_name(material_dict["content_list"][i])
            for user_name in all_user_name:
                user_feature_dict.setdefault(user_name, dict())
            text = clean_text(material_dict["content_list"][i],remove_emoji=True)
            # text = change_material_save_top1_topic(query, text)
            # 开头结尾话题词改写
            text = ht_hashtag_rewrite(text)
            # text = replace_emoji(text)
            # video_abs字段不为空，改写视频博文文本内容 [曾昆仑:视频摘要每天就几千条]
            # video_voice 和video_abs同时存在，只使用video_abs字段
            # 六月风控专项过滤
            url_objects = raw_material_list[i].get('trans_objects', [])
            video_voice_risk_flag = True # 有风险时为False
            if isinstance(url_objects, list):
                for url_object in url_objects:
                    url_object = url_object.get('object', {})
                    object_type = url_object.get('object_type', "")
                    url = url_object.get('object', {}).get("url", "")
                    if object_type == 'video' and url:
                        obj_item = url_object.get('object', {})
                        monitor_state = str(obj_item.get('monitor_state', ''))
                        if monitor_state != '1':
                            video_voice_risk_flag = False
                            break
            video_abs = raw_material_list[i].get("video_abs","")
            video_voice = raw_material_list[i].get("video_voice","")
            text_vv = ""
            if video_abs:
                text_vv = "【正文内容】\n{}\n【视频内容】\n{}".format(text, video_abs)
                struct_data['use_video_abs'] = True
            elif video_voice:
                text_vv = "【正文内容】\n{}\n【视频内容】\n{}".format(text, video_voice)
                struct_data['use_video_voice'] = True
                video_info_list["use_voice"] = True
            if not RISK_CONTROL_3_6_SWITCH and text_vv:
                # 关闭
                text = text_vv
            else:
                # 开启
                if video_voice_risk_flag and text_vv:
                    text = text_vv

            pic_ocr = raw_material_list[i].get("pic_ocr", "")
            if pic_ocr:
                if "【视频内容】" in text:
                    text = "{}\n【图片内容】\n{}".format(text, pic_ocr)
                else:
                    text = "【正文内容】{}\n【图片内容】\n{}".format(text, pic_ocr)

                pic_info_list["use_ocr"] = True
                struct_data['use_pic_ocr'] = True

            mid = material_dict["mid_list"][i]
            name = material_dict["name_list"][i]
            topic_role = raw_material_list[i].get("topic_role", "")
            if topic_role:
                extra_info_tag_set.add(topic_role)
                extra_info_q_tag_set.add(topic_role)

            #蓝标
            verified_type = material_dict["verified_type_list"][i]
            if verified_type == "" or verified_type is None:
                verified_type = 999
            verified_type_ext = raw_material_list[i].get("verified_type_ext", -999)
            if verified_type_ext == "" or verified_type_ext is None:
                verified_type_ext = 999

            is_blue = 1<= verified_type <=7
            #金橙标
            is_gold_orange = raw_material_list[i].get("is_gold_orange", 0)
            # 权威媒体
            uid = str(raw_material_list[i].get("uid", ""))
            for level_ in DISPLAYED_UIDS:
                if uid in DISPLAYED_UIDS[level_]:
                    is_media_user = convert_to_int(level_)
                    break
            else:
                is_media_user = 0
            # 可信媒体
            is_credible_media_user = uid in CREDIBLE_MEDIA_UIDS
            # 相关度阈值
            threshold = 0.31 if is_media_user else 0.366
            ocr_limit = 100 if is_media_user else 10
            # 热门来源
            unify = raw_material_list[i].get("from", '')

            pic_list, updated_pic_info_list = SummaryMaterial.get_pic_list(
                raw_material_list[i], material_dict, pic_info_list, text, name, mid, i,
                verified_type, is_blue, is_gold_orange, threshold, unify, mid_pid_dic, is_media_user, pid_dup_dic, ocr_limit, pid_set, mid_set
            )
            pic_info_list.update(updated_pic_info_list)

            url_list = [get_pic_url(pid) for pid in pic_list]

            #每个物料最多选3张
            # url_list = url_list[:3]

            pic_url_list = url_list



            if len(url_list) > 0 and i < 20:
                text_url_dic["text"] =  text
                text_url_dic["url_list"] = [f"![]({url})" for url in url_list]
            else:
                text_url_dic["text"] = ""
                text_url_dic["url_list"] = ""

            # add date
            pub_time = raw_material_list[i].get("pub_time", 0)
            ts = 0
            if isinstance(pub_time, str):
                # 处理 'Mon Feb 24 13:38:18 +0800 2025'
                try:
                    ts = int(time.mktime(time.strptime(pub_time, '%a %b %d %H:%M:%S %z %Y')))
                except Exception as e:
                    ts = int(time.time())
            else:
                try:
                    ts = int(raw_material_list[i].get("pub_time", 0))
                except Exception as e:
                    ts = int(time.time())

            tag_parse = material_dict["tag3_list"][i]
            from_ = ''
            if len(material_dict["from_list"]) > i:
                from_ = material_dict["from_list"][i]
            #tag_parse[2]是你要的数据，格式是：{"r1": {}, "r2": {}, "r3": {}, "m1": {}, "m2": {}, "m3": {}}里面的格式是{'电视剧':0.85}
            all_tag= tag_parse[2]

            uid = str(raw_material_list[i].get("uid", ""))
            # 使用过滤器链进行过滤
            filter_chain = FilterChain(
                MaterialContentFilter(query, text),
                BlackMidFilter(mid, black_mids),
                SelfMidFilter(mid, query),
                CategoryFilter(from_, query_category, all_tag),
                RiskLevelFilter(
                    query_risk_level, verified_type, verified_type_ext, user_v_type, limit_material
                ),
                SafeTagFilter(
                    safe_tags=raw_material_list[i].get("safe_tags", ""),
                    uid=uid,
                    utype=raw_material_list[i].get("user", {}).get("type", 0),
                ),
                # TimeRangeFilter(ts, material_time_range, limit_material),
                ReliableUIDFilter(uid, limit_degree_reliable_uids, limit_material)
            )
            if (filter_reason := filter_chain.apply()):
                result["filter_reasons"] = f"{mid}:R{filter_reason.value}" if not result.get("filter_reasons") \
                    else f"{result['filter_reasons']},{mid}:R{filter_reason.value}"
                continue

            try:
                format_str = get_weibo_time(mid)
            except Exception as e:
                format_str = ""

            struct_data['mid'] = mid
            struct_data["内容"] = text
            struct_data["图片url_list"] = pic_url_list
            struct_data["发布时间"] = format_str
            struct_data["发布账号名"] = name
            struct_data["url"] = f'sinaweibo://detail?mblogid={mid}'
            if uid in CONSULATE_UIDS:
                filterd_june_mid_list["consulate_uid"].append(mid)
                filterd_reason_dict['consulate_uid'].append(mid)
                continue
            
            # try:
                # user_type = raw_material_list[i].get('user_type', 0)
                # urisk = int(raw_material_list[i].get('urisk', '0'))
    #             if user_type in [6, 7, 8, 9, 11, 12, 1201, 13, 14, 15, 16, 17, 19,
    # 701, 801, 1301, 1302, 1303, 1304, 1701] or user_type >= 10000:
    #                 filterd_june_mid_list["user_type_limit"].append({
    #                     'uid': uid,
    #                     'mid': mid,
    #                     'user_type': user_type,
    #                 })
                    # if RISK_CONTROL_3_6_SWITCH:
                    #     continue
            #     urisk_flag = False
            #     for k in [5, 6, 8, 1, 4, 29, 30]:
            #         if urisk & (1 << (k - 1)) != 0:
            #             urisk_flag = True
            #             filterd_june_mid_list["urisk_limit"].append({
            #                 'mid':  mid,
            #                 'uid': uid,
            #                 'urisk': k,
            #             })
            #             break
            #     if urisk_flag:
            #         continue
            # except:
            #     pass
            if uid in MEDIA_UIDS:
                struct_data["发布账号类型"] = "媒体账号"
                struct_data["内容可信分级"] = "权威可信"
            # elif (int(is_gold_orange) == 1) or (int(verified_type) == 0 and int(verified_type_ext) in [1, 2]) or (int(verified_type) == 3 and int(verified_type_ext) == 53):
            elif uid in DA_V_UIDS:
                struct_data["发布账号类型"] = "大V账号"
                struct_data["内容可信分级"] = "权威可信"
            elif (int(verified_type) >= 0 and int(verified_type) <= 7):
                struct_data["发布账号类型"] = "认证账号"
                struct_data["内容可信分级"] = "权威可信"
                # if prompt_scene == 'deepseek_annual_message':
                #     continue
            else:
                struct_data["发布账号类型"] = "普通账号"
                struct_data["内容可信分级"] = "一般可信"
                if prompt_scene == 'deepseek_annual_message':
                    continue
            is_crucial = raw_material_list[i].get("is_crucial", False)
            a_feature = raw_material_list[i].get('a_feature', {}) or {}
            if query_category == 'Medical' or mid_is_medical:
                if uid in MEDICAL_UIDS:
                    struct_data["发布账号类型"] = "医生"
                    struct_data["内容可信分级"] = "权威可信"
                else:
                    struct_data["发布账号类型"] = ""
            if query_category == '明星' and mid in STAR_WHITE_UIDS:
                struct_data["发布账号类型"] = "媒体账号"

            final_qi_score = convert_to_float(a_feature.get('final_qi_score', '0'))
            hit_score_new = convert_to_float(a_feature.get('hit_score_new', '0'))
            hit_score_final = convert_to_float(a_feature.get('hit_score_final', '0'))
            is_good = 1 if (final_qi_score >= 76 and hit_score_final >= 60) or is_crucial else 0
            struct_data["is_good"] = is_good
            struct_data["from"] = unify
            struct_data["uid"] = uid
            if ts <  datetime.strptime('2023年1月1日', '%Y年%m月%d日').timestamp():
                filterd_june_mid_list["time_limit"].append(mid)
                if RISK_CONTROL_3_6_SWITCH:
                    continue
            # 如果24h内发布 & is_good
            now = int(time.time())
            if now - ts < 3600 * 24 and is_good:
                extra_info_q_tag_set.add('当天发布')
            # 根据doc_level添加tag
            # doc_level = a_feature.get('doc_level', '0')
            doc_level_top = a_feature.get('doc_level', '0') if m_use_new_format else raw_material_list[i].get('doc_level_top', '0')
            if doc_level_top == '1':
                struct_data['value_tag'] = '优质搜索结果'
                struct_data["is_good"] = 1
            value_tag = raw_material_list[i].get('value_tag', '')
            if value_tag:
                struct_data['value_tag'] = value_tag
            # 根据query是否命中关键词，by时间过滤物料，后续优化统一放到filter里(仅在D级别下生效)
            if query_risk_level == RiskLevel.D.value and ts >  datetime.strptime('2025年8月18日', '%Y年%m月%d日').timestamp() and is_filtered_by_time:
                filterd_reason_dict['by_time'].append(mid)
                continue
            
            if query_category in ['Account_Nor', 'kol'] and int(time.time()) - ts > 3600 * 24 * 365:
                filterd_reason_dict['by_time_kol'].append(mid)
                continue
            struct_data["发布时间"] = datetime.fromtimestamp(ts).strftime("%Y年%m月%d日")

            # 添加实验组物料
            extra_info_tag= "、".join(list(extra_info_tag_set))
            struct_data["extra_info_tag"] = extra_info_tag

            if tag_parse[0]:
                struct_data["内容标签词"] = tag_parse[0]
            if tag_parse[1]:
                result["list_tag3"] += tag_parse[1]
            if 'ps_idx' in raw_material_list[i]:
                struct_data["ps_idx"] = raw_material_list[i]['ps_idx']
            elif 'vs_idx' in raw_material_list[i]:
                struct_data["vs_idx"] = raw_material_list[i]['vs_idx']
            elif 'ext_idx' in raw_material_list[i]:
                struct_data["ext_idx"] = raw_material_list[i]['ext_idx']
            filterd_june_mid_list["before_filter_mid_list"].append(mid)
            result["struct_content_list"].append(struct_data)
            result["blue_v"].append(verified_type)
            result["content_list"].append(text)
            result["mid_list"].append(mid)

            if text_url_dic["url_list"]:
                result["text_url_dict"].append(text_url_dic)

            # 视频信息
            material_node = raw_material_list[i]
            safe_tags = material_node.get('safe_tags', '')
            utype = material_node.get('user', {}).get('type', 0)
            res_safe = False
            if safe_tags:
                try:
                    safe_tags = int(float(safe_tags))
                except:
                    safe_tags = 0
                for j in [12, 15, 17, 40, 42, 43]:
                    if safe_tags & (1 << (j - 1)) != 0:
                        res_safe = True
                        filterd_june_mid_list["safe_tag"].append({
                            'uid': uid,
                            'mid': mid,
                            'verified_type': verified_type,
                            'utype': utype,
                            'safe_tag': j
                        })
                        break
                        
            cur_category = material_node.get("category", 0)
            # if cur_category == 659:
            #     url_objects = material_node.get('trans_objects', [])
            #     if len(url_objects):
            #         url_object = url_objects[0]
            #         object_type = url_object.get('object_type', "")
            #         url = url_object.get('object', {}).get("image", {}).get("url", "")
            #         if object_type == 'video' and url:
            #             result["video_mid_list"].append({"mid": mid, 'img_url': url})
            v_phash = material_node.get('v_phash', '')
            waic_video_dup_finger = material_node.get('waic_video_dup_finger', '')
            video_allinfo = material_node.get('video_allinfo', '{}')
            try:
                highest_quality_label = json.loads(video_allinfo).get(mid, {}).get('video_basic_info', {}).get('highest_quality_label')
            except:
                highest_quality_label = None
            try:
                avg = json.loads(video_allinfo).get(mid, {}).get('multi_dimision', {}).get('vqa_metaliq', {}).get('avg')
            except:
                avg = None
            video_voice_pinying = material_node.get('video_voice_pinying', '')
            if v_phash:
                v_phash = v_phash.split(',')
                v_phash = list(filter(lambda x: x!='0', v_phash))
            else:
                v_phash = []
            v_dhash = material_node.get('v_dhash', '')
            if v_dhash:
                v_dhash = v_dhash.split(',')
                v_dhash = list(filter(lambda x: x!='0', v_dhash))
            else:
                v_dhash = []
            high_quality_video = material_node.get('high_quality_video', '0')
            doc_score =  material_node.get('doc_score', '0')
            mix_media_ids = material_node.get('mix_media_ids', [])
            url_objects = material_node.get('trans_objects', [])
            if isinstance(url_objects, list):
                for url_object in url_objects:
                    url_object = url_object.get('object', {})
                    object_type = url_object.get('object_type', "")
                    url = url_object.get('object', {}).get("url", "")
                    if object_type == 'video' and url:
                        obj_item = url_object.get('object', {})
                        monitor_state = str(obj_item.get('monitor_state', ''))
                        if monitor_state != '1':
                            filterd_june_mid_list["video_limit"].append({
                                mid: url
                            })
                            if RISK_CONTROL_3_6_SWITCH:
                                continue
                        obj_item.update({'v_phash':v_phash, 'waic_video_dup_finger': waic_video_dup_finger, 'highest_quality_label':highest_quality_label, 'avg':avg, 'video_voice_pinying':video_voice_pinying ,'v_dhash':v_dhash, 'high_quality_video':high_quality_video, 'video_index':int(len(mix_media_ids) >0 and 'http:' not in mix_media_ids[0])})
                        video_mid_dict.setdefault(mid, list()).append(obj_item)
            avatar = material_node.get('user', {}).get('profile_image_url', '')
            doc_valid_num = convert_to_float(material_node.get('a_feature', {}).get("doc_valid_num", 0)) if material_node.get('a_feature', {}).get("doc_valid_num") else 0
            validfans = convert_to_float(material_node.get('a_feature', {}).get("validfans", 0)) if material_node.get('a_feature', {}).get("validfans") else 0
            qi_score = convert_to_float(material_node.get('a_feature', {}).get("qi_score", 400)) if material_node.get('a_feature', {}).get("qi_score") else 400
            if not is_crucial and (doc_valid_num < 10 and validfans < 50):
                res_safe = True
            relevance_info = {
                "mid_text": material_dict["content_list"][i],
                "abstract": material_node.get('comprehend_title', ''),
                "title": material_node.get('comprehend_abstract', ''),
                "keywords": material_node.get('comprehend_keywords', ''),
            }
            mid_feature_dict.setdefault(mid, dict()).update({"is_top_up": cur_category==306,
                "is_media_user":is_media_user, "is_gold_orange":is_gold_orange, "verified_type":verified_type, "source_from": unify,
                "mix_media_ids":mix_media_ids, "pic_info":material_node.get("pic_info", []), "qi_score": qi_score, "is_crediable_media": uid in MEDIA_UIDS,
                "pic_ids":material_node.get("pic_ids", []), "user_name":name, "user_avatar":avatar, "relevance_info": relevance_info,
                "doc_valid_num": doc_valid_num, "verified_type_ext": verified_type_ext, "is_credible_media_user": is_credible_media_user,
                "hit_score_new": hit_score_new, "hit_score_final": hit_score_final, "doc_score": doc_score, "filter_tag": res_safe})

        # vector_dict = await img_vector.embedding_image(mid_set, pid_set)
            user_feature_dict.setdefault(name, dict()).update(
                {
                    "uid": uid
                }
            )
        result["vector_dict"] = {}
        result["pid_dup_dic"] = pid_dup_dic
        result["pic_info_dict_all"] = pic_info_list
        result["video_mid_dict"] = video_mid_dict
        result["mid_feature_dict"] = mid_feature_dict
        result["user_feature_dict"] = user_feature_dict
        result['extra_info_q_tag'] = list(extra_info_q_tag_set)
        result['filterd_reason_dict'] = filterd_reason_dict
        return result, pic_info_list,video_info_list, filterd_june_mid_list

    def get_target_article(self, article_list):
        res_article = list()
        kuake_num = 0
        for item in article_list:
            try:
                longtext = item.get('content', '')
                is_kuake = int(item.get('is_kuake', '0'))
                from_web = int(item.get('from_web', '0'))
                from_kuake = 1 if from_web == 1 or is_kuake == 1 else 0
                final_qi_score = float(item.get('final_qi_score', '0'))
                hit_score_final = float(item.get('hit_score_final', '0'))
                pub_ts = item.get('pub_ts', '0')
                if pub_ts and pub_ts != '0':
                    pub_ts = datetime.fromtimestamp(int(pub_ts)).strftime('%Y年%m月%d日')
                else:
                    pub_ts = ""
                is_credible_account = '媒体账号' if str(item.get('is_credible', '0')) == '1' else ''
                is_good = 1 if final_qi_score >= 76 and hit_score_final >= 50 else 0
                if from_kuake:
                    kuake_num += 1
                if longtext.strip():
                    inp = {"内容": longtext.strip(), "内容来源": "微博", "内容类型": "文章",
                           "发布时间": pub_ts,
                           "发布账号类型": is_credible_account, "内容可信分级": "一般可信", "url": item.get('url', ''),
                           "is_good": is_good,"is_kuake":from_kuake}
                    if 'ps_idx' in item:
                        inp["ps_idx"] = item['ps_idx']
                    elif 'vs_idx' in item:
                        inp["vs_idx"] = item['vs_idx']
                    elif 'ext_idx' in item:
                        inp["ext_idx"] = item['ext_idx']
                    # input_str = "%s" % inp
                    res_article.append(inp)
            except Exception as e:
                self.logger.error(
                    self.pre_log_msg + f"get_target_article item: {json.dumps(item, ensure_ascii=False)} error: {e}")

        self.logger.info(self.pre_log_msg + f"fetched kuake_num: {kuake_num}")
        out = sorted(res_article, key=lambda i: i["is_good"], reverse=True)
        return out


    async def struct_material(self, weibo):
        """依赖于其他物料的结构化处理"""
        self.update_pre_log_msg(weibo)
        query = weibo.get("query", "")
        ori_query = weibo.get("ori_query", "")
        black_mids = weibo.get("black_mids", {})
        mid_is_medical = weibo.get("mid_is_medical", False)
        material_dict = self.get_original_material(weibo)
        first_grid_doc_num = weibo.get("first_grid_doc_num", 0)
        prompt_scene = weibo.get('prompt_scene', '')
        m_use_new_format = weibo.get('m_use_new_format', False)



        result, pic_info_list,video_info_list, filterd_june_mid_list = await self.get_result_from_material_dict(query, ori_query, black_mids, material_dict, mid_is_medical, first_grid_doc_num=first_grid_doc_num, prompt_scene=prompt_scene, m_use_new_format=m_use_new_format)
        # self.logger.info(self.pre_log_msg + f"summary_filterd_june_mid_list_v2:{filterd_june_mid_list}")
        weibo['summary_filterd_june_mid_list_v2'] = json.dumps(filterd_june_mid_list, ensure_ascii=False)
        # 微博特征
        struct_content_list = result.get('struct_content_list', [])
        MaterialUtils.log_weibo_mid_feature(struct_content_list, self.logger, self.pre_log_msg + "\tbefore_confine\t")
        # 过滤原因
        self.logger.info(self.pre_log_msg + "before_confine\t" + f"filterd_reason_dict:{result.get('filterd_reason_dict', {})}")
        #write info to  file
        # self.write_log(message=f'[pic_info_save]{pic_info_list}')
        # self.write_log(message=f'[video_info_save]{video_info_list}')
        self.write_log(message=f"[filter_reasons]{result.get('filter_reasons', '')}")
        self.write_log(message=f'[mid_feature_dict]{result["mid_feature_dict"]}')
        # self.write_log(message=f'[video_mid_dict]{result["video_mid_dict"]}')
        blog_analysis_flag = await self.add_analysis4struct_content_list(result.get('mid_list', []), result.get('struct_content_list', []))
        result["blog_analysis_flag"] = blog_analysis_flag
        self.update_weibo(weibo, result)
        if article_list := weibo.get('sina_article_data', []):
            weibo['sina_article_data'] = self.get_target_article(article_list)
            MaterialUtils.log_article_feature(weibo['sina_article_data'], self.logger, self.pre_log_msg + "before_confine\t")


    @timeit(logger_mode='self')
    async def add_analysis4struct_content_list(self, mid_list: list[str], struct_content_list: list[dict]) -> bool:
        """
        原地修改 struct_content_list
        """
        try:
            if not struct_content_list:
                return False
            blog_analysis_flag = False
            mid_key_list = [f"zhisou_annotation_{mid}" for mid in mid_list]
            redis_res = await async_redis_client.batch_get(mid_key_list)
            # redis_res = await async_redis_client.batch_get_hash_specific_fields(mid_key_list, fields=["comment"])
            self.logger.info(self.pre_log_msg + f"got comment keys:{redis_res.keys()}")
            for idx, item in enumerate(struct_content_list):
                key = mid_key_list[idx]
                if key in redis_res:
                    blog_analysis_flag = True
                    text = redis_res.get(key, {}).get("comment", "")
                    filtered_text = re.sub(r'原博|原博文|原始博文','该博文',text)
                    item.update({
                        "analysis_content": filtered_text
                    })
                    self.logger.info(self.pre_log_msg + f"add comment to struct content list: {len(item.get('analysis_content'))}")
            if blog_analysis_flag:
                self.logger.info(self.pre_log_msg + "ret_blog_analysis_flag -> true")
            return blog_analysis_flag
        except Exception:
            self.logger.error(self.pre_log_msg + f"add_analysis4weibo error:{traceback.format_exc()}")
        return False
                

        

    async def merge_article_mat(self, query, trace_id, data_list):
        article_data = {}
        async with aiohttp.ClientSession() as session:
            article_data = await get_article(session, query, use_trunk=1, threshold=0.5, traceid=trace_id, logger=self.logger)
        self.write_log(message=f"[debug res article], article_info:{article_data}")
        for i in data_list:
            text = i.get('text', "")
            mid = str(i.get("mid", ""))
            if mid in article_data:
                article = article_data.get(mid).get("text", "")
                if article:
                    self.write_log(message=f"[debug add article], mid:{mid}, info:{article_data.get(mid)}")
                    text += ";" + article
                    i['text'] = text
        return data_list

    async def get_trunk_res(self, dict_trunk, global_etime, trace_id, query, url, page=1, page_size=40):
        dict_res, tasks = dict(), list()
        diff_tm = 1 if len(dict_trunk) > 1 else 0
        for trunk_cate, stime in dict_trunk.items():
            latm_trunk_cate = int(trunk_cate)-1
            etime = dict_trunk.get(latm_trunk_cate, global_etime)
            tasks.append(get_search_material(
                trace_id=trace_id, query=query, post_url=url, stime=stime-diff_tm, etime=etime, logger=self.logger, page=page, page_size=page_size, source=self.raw_source, llm_name=self.llm_name, search_type='vs', abtest=self.abtest))
        results = await asyncio.gather(*tasks)
        for idx, res in enumerate(results, 1):
            dict_res[idx] = res[0]
        return dict_res

    def get_merge_list(self, support_list):
        res_list = list()
        for i in support_list:
            mid = i.get('mid')
            if not mid or mid in self.exists_mids:
                # self.write_log(message=f"[debug mid dup], mid:{mid}")
                continue
            res_list.append(i)
            self.exists_mids.add(mid)
        return res_list

    async def fetch_unify_res(self, trace_id, query, url, query_category):
        # 策略1
        new_format = False
        start_time = time.time()
        #综合实时接口合并到热门接口
        unify_res_list, is_less_old_res, ext_mats, weibo_article_data_list = await get_search_material(
            trace_id=trace_id, query=query, post_url=url, logger=self.logger, page=1, source=self.raw_source, llm_name=self.llm_name, query_category=query_category, abtest=self.abtest)
        unify_cost_time = time.time()
        self.time_analysis_dict['fetch_unify_res_start'] = start_time
        self.time_analysis_dict['fetch_unify_res_end'] = unify_cost_time
        # 普搜对齐格式后填充原有字段，crucial_res, article
        if weibo_article_data_list:
            new_format = True
            unify_res_list = []
            article_list = []
            weibo_list = []
            crucial_list = []
            category_list = []
            id_list = []
            droped_id_list = []
            for item in weibo_article_data_list:
                if 'mid' in item:
                    # 过滤mid == None和text为空的weibo
                    if item['mid'] and item['text']:
                        if item.get('is_crucial', False):
                            crucial_list.append(item)
                        else:
                            weibo_list.append(item)
                        id_list.append(item['mid'])
                        category_list.append(item.get('category', ''))
                    else:
                        droped_id_list.append(f"weibo: {item.get('ps_idx', -1)}")
                else:
                    url = item.get('url', '')
                    if url:
                        article_list.append(item)
                        id_list.append(url)
                        category_list.append(item.get('category', ''))
                    else:
                        droped_id_list.append(f"article: {item.get('ps_idx', -1)}")
            if crucial_list:
                ext_mats['crucial_res'] = crucial_list
            if weibo_list:
                unify_res_list.extend(weibo_list)
            if article_list:
                ext_mats['article_res'] = article_list
            self.logger.info(self.pre_log_msg + f"fetch_unify_with_new_format id_list: {id_list}\tcategory_list: {category_list}\tdroped_id_list: {droped_id_list}")

        self.write_log(message=f"[debug 1]\t" 
                            f"unify_cost_time:{unify_cost_time-start_time}\t"
                            f"is_less_old_res:{is_less_old_res}\t"
                               f"unify_res_list_len:{len(unify_res_list)}\t")
        return {'strategy_1': {'unify_res_list':unify_res_list, 'is_less_old_res':is_less_old_res, 'ext_mats':ext_mats, 'new_format': new_format}}

    async def fetch_vs_res(self, trace_id, query, raw_time_grade, unify_etime, url, stream_output):
        start_time = time.time()
        if raw_time_grade == 'strong':
            dict_tm = get_tm_dict(unify_etime, 1, 3)
        else:
            dict_tm = get_tm_dict(unify_etime, 1, 30)
        # 策略2 热门+语义 翻页将物料补充至1000条
        page_dict = {1: {'page': 1, 'limit': 40}, 0: {'page': 1, 'limit': 1000}}
        if self.about_xi == 0:
            dict_tm_vs_res = await self.get_trunk_res(dict_tm, unify_etime, trace_id, query, url, page=page_dict[0]['page'], page_size=page_dict[0]['limit'])
            raw_vs_dict_num = [(k, len(v)) for k, v in dict_tm_vs_res.items()]
            vs_cost_time = time.time()
            self.time_analysis_dict['fetch_vs_res_start'] = start_time
            self.time_analysis_dict['fetch_vs_res_end'] = vs_cost_time
            self.write_log(message=f"[debug 2]\t"
                        f"vs_cost_time:{vs_cost_time-start_time}\t"
                        f"raw_vs_dict_num:{raw_vs_dict_num}\t")
            return {'strategy_2': dict_tm_vs_res}
        else:
            return {}

    async def fetch_vs_sup_res(self, trace_id, query, raw_time_grade, unify_etime, url, stream_output):
        start_time = time.time()
        if raw_time_grade == 'weak' and self.about_xi == 0:
            # 最近2年内的物料中择优选择，最多将物料补充至30条
            dict_tm_weak = get_tm_dict(unify_etime, 1, 2*365)
            page_dict = {1: {'page': 1, 'limit': 30}, 0: {'page': 1, 'limit': 30}}
            dict_tm_vs_res_weak = await self.get_trunk_res(dict_tm_weak, unify_etime, trace_id, query, url, page=page_dict[0]['page'], page_size=page_dict[0]['limit'])
            raw_vs_weak_dict_num = [(k, len(v)) for k, v in dict_tm_vs_res_weak.items()]
            vs_cost_time_weak = time.time()
            self.time_analysis_dict['fetch_vs_sup_res_start'] = start_time
            self.time_analysis_dict['fetch_vs_sup_res_end'] = vs_cost_time_weak
            self.write_log(message=f"[debug weak]\t"
                           f"vs_cost_time_weak:{vs_cost_time_weak-start_time}\t"
                           f"dict_tm_vs_res_weak_len:{raw_vs_weak_dict_num}")
            return {'strategy_2_sup': dict_tm_vs_res_weak}
        else:
            return {}

    def filter_account_weibo(self, weibo_list, query):
        return weibo_list
        # return [i for i in weibo_list if f'@{query.lower()} ' in i.get('text', '').lower()]

    def make_ext_weibo_article_list(self, ext_list: dict, main_weibo: list, main_article: list) -> tuple[list, list]:
        res_list = []
        id_list = []
        res_weibo_list = []
        res_article_list = []
        try:
            exist_mids = set([item.get('mid', '') for item in main_weibo])
            # exist_urls = set([item.get('url', '')for item in main_article])
            for q, m in ext_list.items():
                data_list = m.get('weibo', {}).get('list', [])
                for item in data_list:
                    if 'mid' in item:
                        mid = item.get('mid', '')
                        if mid and mid not in exist_mids:
                            res_list.append(item)
                            exist_mids.add(mid)
                            id_list.append(mid)
                    # else:
                    #     url = item.get('url', '')
                    #     if url and url not in exist_urls:
                    #         res_list.append(item)
                    #         exist_urls.add(url)
                    #         id_list.append(url)
            for idx, item in enumerate(res_list):
                item['ext_idx'] = idx
                if 'mid' in item:
                    res_weibo_list.append(item)
                # else:
                #     res_article_list.append(item)
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"make_ext_weibo_article_list error: {e}")
        self.logger.info(self.pre_log_msg + f"make_ext_weibo_article_list add res_list: {id_list}")
        return res_weibo_list, res_article_list


    def make_weibo_list(self, fetch_dict: dict, query_time_grade: str) -> list[dict]:
        """新格式物料接口20251218"""
        res_list = list()
        crucial_res = fetch_dict.get('strategy_1', {}).get('ext_mats', {}).get('crucial_res', [])
        vs_dict = fetch_dict.get('strategy_2', {})
        vs_sup_dict = fetch_dict.get('strategy_2_sup', {})
        unify_res_list = fetch_dict.get('strategy_1', {}).get('unify_res_list', [])

        res_list.extend(self.get_merge_list(crucial_res))
        res_list.extend(self.get_merge_list(unify_res_list))
        for idx, vs_res in vs_dict.items():
            res_list.extend(self.get_merge_list(vs_res))
        if query_time_grade == 'weak':
            # 使用两年内的语义
            if len(res_list) < 30:
                self.logger.info(self.pre_log_msg + f"make_weibo_list use weak vs to add res_list before: {len(res_list)}")
                for idx, vs_res in vs_sup_dict.items():
                    res_list.extend(self.get_merge_list(vs_res))

        return res_list

    async def fetch_refactor(self, trace_id, query, query_category, llm_name, stream_output):
        res_list, high_list, low_list = list(), list(), list()
        self.exists_mids = set()
        start_time = time.time()
        unify_etime = int(start_time)
        # http://10.36.25.147/search/wis/material.json
        dict_url = {'unify':'http://i.search.weibo.com/search/wis/material.json',
                    'vs': 'http://i.search.weibo.com/search/wis/inner_material_light.json'}
        # raw_time_grade,query_field = await get_query_time_grade(trace_id, query, self.raw_source, self.logger)
        raw_time_grade, query_field = self.query_raw_time_grade, self.query_field
        time_grade_cost = time.time()
        self.write_log(message=f"[debug time_grade]\tstream_output:{stream_output}\t" 
                                f"time_grade_cost_time:{time_grade_cost-start_time}\t"
                                f"time_grade:{raw_time_grade}")
        if raw_time_grade == '':
            raw_time_grade = 'mid'

        dict_res_concurrent, tasks_concurrent = dict(), list()

        async def fetch_query_extend():
            start_time = time.time()
            res = await call_query_extend(trace_id, query, llm_name, self.logger)
            self.time_analysis_dict['fetch_query_extend_start'] = start_time
            self.time_analysis_dict['fetch_query_extend_end'] = time.time()
            return res

        tasks_concurrent = [self.fetch_unify_res(trace_id, query, dict_url.get('unify'), query_category),
                            self.fetch_vs_res(trace_id, query, 'mid' if query_category in ['Gossip', "LatestDevelopments"] else raw_time_grade, unify_etime, dict_url.get('vs'), stream_output),
                            self.fetch_vs_sup_res(trace_id, query, 'mid' if query_category in ['Gossip', "LatestDevelopments"] else raw_time_grade, unify_etime, dict_url.get('vs'), stream_output),
                            fetch_query_extend()
                            ]
        start_time = time.time()
        results = await asyncio.gather(*tasks_concurrent)
        self.time_analysis_dict['fetch_refactor_start'] = start_time
        self.time_analysis_dict['fetch_refactor_end'] = time.time()
        for sub_con_res in results:
            dict_res_concurrent.update(sub_con_res)
        self.write_log(message=f"[debug concurrent]\tstream_output:{stream_output}\t" 
                            f"concurrent_cost_time:{time.time()-time_grade_cost}\t")

        new_format = dict_res_concurrent.get('strategy_1', {}).get('new_format', False)
        self.new_format = new_format
        # 策略1
        unify_res_list = dict_res_concurrent.get('strategy_1', {}).get('unify_res_list', [])
        if self.about_xi == 0:
            ext_mats = dict_res_concurrent.get('strategy_1', {}).get('ext_mats', {})
        else:
            ext_mats = {'crucial_res': dict_res_concurrent.get('strategy_1', {}).get('ext_mats', {}).get('crucial_res', [])}
        
        if new_format:
            res_list = self.make_weibo_list(dict_res_concurrent, raw_time_grade)
            if self.about_xi == 1:
                res_list = [i for i in res_list if str(i.get('uid', '')) in RISK_FILTER_UIDS]
                self.logger.info(self.pre_log_msg +f"after about_xi uid filter, mid_list: {[item.get('mid', '') for item in res_list]}")
            self.logger.info(self.pre_log_msg +f'use new format to handle res_list len: {len(res_list)}')
            # 规划
            ext_querys = dict_res_concurrent.get('extends_querys', {})
            ext_query_weibo_list, ext_query_article_list = self.make_ext_weibo_article_list(ext_querys, res_list, ext_mats.get('article_res', []))
            if ext_query_weibo_list:
                res_list.extend(ext_query_weibo_list)
            if ext_query_article_list:
                ext_mats['article_res'] = ext_mats.get('article_res', []) + ext_query_article_list
            return res_list, raw_time_grade, ext_mats, query_field
        # filter account weibo
        # if query_category in ['Account_Nor', 'kol']:
        #     self.write_log(message=f"[debug filter account]\tstream_output:{stream_output}\t" 
        #                     f"raw_unify_res_list_len:{len(unify_res_list)}")
        #     unify_res_list = self.filter_account_weibo(unify_res_list, query)
        # is_less_old_res = dict_res_concurrent.get('strategy_1', {}).get('is_less_old_res', 0)
        #综合实时接口合并到热门接口
        res_list.extend(self.get_merge_list(ext_mats.get('crucial_res', [])))
        list_unify_realtime, list_unify_hot, list_good_weibo = list(), list(), list()
        for unify_res in unify_res_list:
            if unify_res.get('from', '') == 'unify_socialtime':
                if int(unify_res.get('category', 0)) == 1005:
                    list_good_weibo.append(unify_res)
                else:
                    list_unify_realtime.append(unify_res)
            elif unify_res.get('from', '') == 'unify_base':
                list_unify_hot.append(unify_res)
            else:
                # self.write_log(message=f"[debug wrong from], weibo_item:{unify_res}")
                list_unify_realtime.append(unify_res)
        res_list.extend(self.get_merge_list(list_unify_hot[:40]))
        """
        res_list.extend(self.get_merge_list(unify_res_list[:40]))
        """
        self.write_log(message=f"[debug 1]\tstream_output:{stream_output}\t" 
                               f"unify_res_list_len:{len(unify_res_list)}\t"
                               f"res_hotlist_len:{len(list_unify_hot)}\t"
                                   f"res_list_len:{len(res_list)}")
        if self.about_xi == 1:
            res_list = [i for i in res_list if str(i.get('uid', '')) in RISK_FILTER_UIDS]
            return res_list, raw_time_grade, ext_mats, query_field
        # 策略2 热门+语义
        dict_tm_vs_res = dict_res_concurrent.get('strategy_2', {})
        for idx, vs_res in dict_tm_vs_res.items():
            # filter account weibo
            # if query_category in ['Account_Nor', 'kol']:
            #     self.write_log(message=f"[debug filter account]\tstream_output:{stream_output}\t" 
            #                     f"raw_strategy_2_list_len:{len(vs_res)}")
            #     vs_res = self.filter_account_weibo(vs_res, query)
            #剩余物料不按热度---分2档（有效互动doc_valid_num大于等于30）
            low_list.extend(vs_res)

        #下线：优先选高热档位物料，高热档位选完后再选低热档位，同热度档位内择优（排序分doc_score值高）选择，最多将总物料条数补充至500
        # sorted_high_list = sorted(high_list, key=lambda x: x.get('doc_score', '0'), reverse=True)  
        # sorted_low_list = sorted(low_list, key=lambda x: x.get('doc_score', '0'), reverse=True)
        # res_list.extend(self.get_merge_list(sorted_high_list))
        res_list.extend(self.get_merge_list(low_list))
        self.write_log(message=f"[debug 2]\tstream_output:{stream_output}\t"
                       f"res_list_len:{len(res_list)}")

        if len(res_list) < 30 and raw_time_grade == 'weak':
            dict_tm_vs_res_weak = dict_res_concurrent.get('strategy_2_sup', {})
            tmp_total_list = list()
            for idx, vs_res in dict_tm_vs_res_weak.items():
                # filter account weibo
                # if query_category in ['Account_Nor', 'kol']:
                #     self.write_log(message=f"[debug filter account]\tstream_output:{stream_output}\t" 
                #                     f"raw_strategy_2_sup_len:{len(vs_res)}")
                #     vs_res = self.filter_account_weibo(vs_res, query)
                tmp_total_list.extend(vs_res)
            res_list.extend(self.get_merge_list(tmp_total_list))
            res_list = res_list[:30]
            self.write_log(message=f"[debug weak]\tstream_output:{stream_output}\t"
                          f"res_list_len:{len(res_list)}")

        # 策略3 实时物料
        if len(res_list) < 30:
            # 综合实时接口合并到热门接口
            res_list.extend(self.get_merge_list(list_unify_realtime))
            res_list = res_list[:30]
            self.write_log(message=f"[debug 3]\tstream_output:{stream_output}\t"
                           f"raw_realtime_num:{len(list_unify_realtime)}\t"
                           f"res_list_len:{len(res_list)}")
        if list_good_weibo:
            # 根据时效性过滤， 高->3，mid->30, weak->30,2years
            valid_good_realtime_weibo = []
            now_ts = time.time()
            valid_before_ts = now_ts
            if raw_time_grade == 'strong':
                valid_before_ts = now_ts - 3*24*3600
            elif raw_time_grade == 'mid':
                valid_before_ts = now_ts - 30*24*3600
            elif raw_time_grade == 'weak':
                if len(res_list) < 30:
                    valid_before_ts = now_ts - 2*365*24*3600
                else:
                    valid_before_ts = now_ts - 30*24*3600
            for item in list_good_weibo:
                mid_ts = (int(item.get('mid', '0')) >> 22) + 515483463
                if mid_ts >= valid_before_ts:
                    valid_good_realtime_weibo.append(item)
                
            res_list.extend(self.get_merge_list(valid_good_realtime_weibo))
            self.write_log(message=f"[debug good_weibo]\tstream_output:{stream_output}\t"
                           f"list_good_weibo_len:{len(list_good_weibo)}\t"
                        f"valid_good_realtime_weibo len:{len(valid_good_realtime_weibo)}")

        # if is_less_old_res == 1:
        #     res_list = await self.merge_article_mat(query, trace_id, res_list)

        self.write_log(message=f"[debug final]\tstream_output:{stream_output}\tsource:{self.raw_source}\t"
                       f"mids:{len(self.exists_mids)}\t"
                       f"res_list_len:{len(res_list)}\ttime_grade:{raw_time_grade}\ttotal_cost:{time.time()-start_time}")
        ext_mats['extends_querys'] = dict_res_concurrent.get('extends_querys', {})
        return res_list, raw_time_grade, ext_mats,query_field

class HotBriefSummaryMaterial(SummaryMaterial):
    """热搜速报物料"""

    async def fetch_refactor(self, query):
        fetchd_dict =  await get_hot_brief_material(query, self.pre_log_msg, self.logger)
        related_query_list = fetchd_dict.get('query_list', [])
        hot_weibo_list = fetchd_dict.get('hot_mid_info', [])
        fresh_weibo_list = fetchd_dict.get('fresh_mid_info', [])
        extra_weibo_list = fetchd_dict.get('all_mid_info', [])
        # 热门微博添加“优质搜索结果”标签
        for item in hot_weibo_list:
            item['value_tag'] = '优质搜索结果'

        # 最新微博添加“最新搜索结果”标签
        for item in fresh_weibo_list:
            item['value_tag'] = '最新搜索结果'

        # 去重
        seen = set()
        res_list = []
        for item in hot_weibo_list + fresh_weibo_list + extra_weibo_list:
            if item and isinstance(item, dict):
                mid = item.get('mid', '')
                text = item.get('text', '')
                if not text:
                    continue
                if mid in seen:
                    continue
                seen.add(mid)
                # 强制top_weibo
                item['is_good'] = 1
                res_list.append(item)

        return res_list, {}, related_query_list
    
    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        start = time.time()
        func_name = "SUMMARY-MATERIAL"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("traceid", "")
        ori_query = weibo.get("ori_query", "")
        query = weibo.get("query", "")
        llm_name = weibo.get("llm_name", "")
        self.llm_name = llm_name
        stream_output = weibo.get("stream_output", 0)
        query_category = weibo.get("query_category", "")
        self.raw_source = weibo.get("source", "")
        self.about_xi = self.check_is_about_xi(weibo)
        self.query_raw_time_grade = weibo.get("query_raw_time_grade", "")
        self.query_field = weibo.get("query_field", -1)
        self.time_analysis_dict = weibo.get('debug', {}).get('time_analysis',{})
        try:
            res_list, ext_mats, related_query_list = await self.fetch_refactor(query)
            res_list, ext_mats = self.merge_ext_query_res(res_list, ext_mats)
            # 过滤黑名单
            res_list = self.filter_weibo_by_black_uids(res_list, query, query_category)
            content_list,pic_ids_list, video_abs_list, mid_list, tag_list, verified_type_list, name_list,from_list = extract_material(res_list)
            # query_grade = self.grade_to_days(raw_time_grade)
            struct_content_list, struct_mid_list, tag3_list = structure_material(
                content_list, mid_list, tag_list, verified_type_list, name_list)
            weibo['raw_material_list'] = res_list
            weibo['content_list'] = content_list
            weibo['pic_ids_list'] = pic_ids_list
            weibo['video_abs_list'] = video_abs_list
            weibo['mid_list'] = mid_list
            weibo['struct_content_list'] = struct_content_list
            weibo['struct_mid_list'] = struct_mid_list
            # weibo['query_grade'] = query_grade
            # weibo['raw_time_grade'] = query_raw
            # weibo["query_field"] = query_field
            weibo['tag3_list'] = tag3_list
            weibo['verified_type_list'] = verified_type_list
            weibo['name_list'] = name_list
            weibo['from_list'] = from_list
            weibo['related_query_list'] = related_query_list
            weibo['from_zhisou_quote_dict'] = self.make_from_zhisou_quote_dict(res_list)
            weibo['first_grid_doc_num'] = ext_mats.get('first_grid_doc_num', 0)

  
            self.logger.info(self.pre_log_msg + f"{func_name} end, cost_time:{time.time()-start}\t"
                                                f"content_list_len:{len(content_list)}\t")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")

class SummaryMaterialNoType(Base):
    """辟谣账号的物料获取"""

    @staticmethod
    def check_is_need(weibo):
        def check_is_hot_query(source, q_attr):
            try:
                attr_dict = json.loads(q_attr)
                flush_source = attr_dict.get("flush_source", "")
            except:
                flush_source = ""
            if source == "3" and flush_source == "1":
                return True
            return False

        """判断当前的物料是否需要获取"""
        """判断是否需要风险提示"""
        q_attr = weibo.get("q_attr", "")
        source = weibo.get("source", "")
        model = weibo.get("llm_name", "")
        if source == '99':
            return False
        is_hot_query = check_is_hot_query(source, q_attr)
        if is_hot_query:
            return True

        if q_attr:
            try:
                json_data = json.loads(q_attr)
                if json_data.get("pv", 0) >= 50:
                    return True
            except Exception as e:
                pass
        return False

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        start = time.time()
        func_name = "SUMMARY-REFUTE"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("traceid", "")
        query = weibo.get("query", "")
        weibo["summary_material_refute"] = {}
        self.raw_source = weibo.get("source", "")
        formatted_list = list()
        try:
            if not self.check_is_need(weibo):
                self.write_log(message=f"{func_name} is not need, cost_time:{time.time() - start}\t")
                return
            res_list = await get_refute_material(trace_id, query, self.logger)
            # res_list = sorted(res_list, key=lambda i: i["mid"], reverse=True)
            # for idx, item in enumerate(res_list, 1):
            #     content = item.get('text')
            #     formatted_list.append(f"[辟谣信息{idx} begin]\n{content}\n[辟谣信息{idx} end]")
            weibo['refute_material_list'] = res_list
            # if formatted_list:
            #     formatted_str = '\n'.join(formatted_list)
            #     weibo['refute_material_outstr'] = formatted_str
            self.write_log(message=f"{func_name} end, cost_time:{time.time()-start}\t"
                                   f"refute_list_len:{len(res_list)}")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")

    @staticmethod
    def get_original_material(weibo):
        """获取原始的物料数据"""
        keys = ["content_list", "pic_ids_list", "video_abs_list", "mid_list", "struct_content_list", "struct_mid_list",
                "tag3_list", "verified_type_list", "name_list", "query_category","from_list", "raw_material_list"]
        result = {}
        for key in keys:
            result[key] = weibo.get("summary_material_no_type", {}).get(key, [])
        return result

    @staticmethod
    def update_weibo(weibo, result):
        """更新weibo数据,
        result = {"mid_list": [], "content_list": [], "struct_content_list": [], "blue_v": [], "list_tag3": []}"""
        weibo.setdefault("summary_material_no_type", {})
        for key, value in result.items():
            weibo["summary_material_no_type"][key] = value


    @staticmethod
    def get_date_time_from_mid(mid):
        try:
            time_time = (int(mid) >> 22) + 515483463
            formatted_date = datetime.fromtimestamp(time_time).strftime("%Y年%m月%d日")
            return formatted_date
        except Exception as e:
            return datetime.now().strftime('%Y年%m月%d日')

    @staticmethod
    def struct_material(weibo,logger):
        """辟谣账号根据mid取和原始物料有交集的部分"""
        raw_material_list = weibo.get("raw_material_list",[])
        raw_material_mid_dict = {}
        for mat in raw_material_list:
            if "mid" in mat:
                raw_material_mid_dict[mat['mid']] = 1
        refute_material_list = weibo.get('refute_material_list',[])
        res_list = sorted(refute_material_list, key=lambda i: i.get("mid", ""), reverse=True)
        formatted_list = []
        for idx, item in enumerate(res_list, 1):
            mid = item.get('mid',"")
            if mid in raw_material_mid_dict:
                formatted_list.append(item)
        final_list = []
        for idx, item in enumerate(formatted_list,1):
            content = item.get('text', "")
            mid = item.get('mid', "")
            # piyao_content = f"[辟谣信息{idx} begin]\n{content}\n[辟谣信息{idx} end]" 
            piyao_time = SummaryMaterialNoType.get_date_time_from_mid(mid)
            piyao_content = f"""[辟谣信息 {idx} begin]   
    [content begin]{content}[content end]
    [date begin]{piyao_time}[date end]
    [account type begin]官方辟谣账号[account type end]
[辟谣信息 {idx} end]"""
            final_list.append(piyao_content)
            weibo['refute_material_list_filter'] = final_list
        if len(final_list) > 0:
            formatted_str = '\n'.join(final_list)
            weibo['refute_material_outstr'] = formatted_str


class StreamSummaryMaterial(SummaryMaterial):

    def set_url(self):
        url = "http://admin.ai.s.weibo.com/api/llm/zongshu_material_speed.json"
        d3_limit = 40
        return url, d3_limit

    def grade_to_days(self, raw_time_grade):
        return 3


class TrendSummaryMaterial(SummaryMaterial):

    async def fetch_refactor(self, trace_id, query, query_category, llm_name, stream_output):
        res_list = await get_trend_summary_material(query, self.logger)
        return res_list, "", {},-1


class AccountMaterial(Base):
    async def run(self, **kwargs):
        start = time.time()
        func_name = "ACCOUNT-MATERIAL"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("traceid", "")
        query = weibo.get("query", "")
        query_category = weibo.get("query_category", "")
        self.raw_source = weibo.get("source", "")
        # if query_category != 'kol' and query_category != 'Account_Nor':
        #     return
        uid = weibo.get("level2_uid", "")
        if not uid:
            return

        try:
            res_list, verified_reason = await get_account_material(trace_id, query, query_category, uid, self.logger, self.raw_source)
            content_list, pic_ids_list, video_abs_list, mid_list, tag_list, verified_type_list, name_list, from_list = extract_material(res_list)
            struct_content_list, struct_mid_list, tag3_list = structure_material(
                content_list, mid_list, tag_list, verified_type_list, name_list)
            weibo['account_raw_material_list'] = res_list
            weibo['account_content_list'] = content_list
            weibo['account_video_abs_list'] = video_abs_list
            weibo['account_mid_list'] = mid_list
            weibo['account_struct_content_list'] = struct_content_list
            weibo['account_struct_mid_list'] = struct_mid_list
            weibo['account_tag3_list'] = tag3_list
            weibo['account_verified_type_list'] = verified_type_list
            weibo['account_name_list'] = name_list
            weibo['account_verified_reason'] = verified_reason
            weibo['account_from_list'] = from_list
            self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\t"
                                   f"account_content_list_len:{len(content_list)}")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")

    @staticmethod
    def get_original_material(weibo):
        """获取原始的物料数据"""
        keys = ["content_list", "pic_ids_list", "video_abs_list", "mid_list", "struct_content_list", "struct_mid_list",
                "tag3_list", "verified_type_list", "name_list", "query_category", "from_list", "raw_material_list"]
        result = {}
        for key in keys:
            result[key] = weibo.get("account_" + key, [])
        return result

    @staticmethod
    def update_weibo(weibo, result):
        """更新weibo数据,
        result = {"mid_list": [], "content_list": [], "struct_content_list": [], "blue_v": [], "list_tag3": []}"""
        verified_reason = weibo.get('account_verified_reason', "")
        weibo["account_mid_list"] = result["mid_list"]
        weibo["account_content_list"] = result["content_list"]
        weibo["account_struct_content_list"] = result["struct_content_list"]
        for value in weibo["account_struct_content_list"]:
            if verified_reason:
                value["发布账号认证"] = verified_reason

    async def struct_material(self, weibo):
        """依赖于其他物料的结构化处理"""
        query = weibo.get("query", "")
        ori_query = weibo.get("ori_query", "")
        black_mids = weibo.get("black_mids", {})
        mid_is_medical = weibo.get("mid_is_medical", False)
        material_dict = self.get_original_material(weibo)

        result, pic_info_list, video_info_list, filterd_june_mid_list = await SummaryMaterial.get_result_from_material_dict(query, ori_query, black_mids, material_dict, mid_is_medical)
        self.logger.info(self.pre_log_msg + f"account_filterd_june_mid_list_v2:{filterd_june_mid_list}")
        weibo['account_filterd_june_mid_list_v2'] = json.dumps(filterd_june_mid_list, ensure_ascii=False)
        self.update_weibo(weibo, result)


class BriefSummaryMaterial(Base):

    async def run(self, **kwargs):
        start = time.time()
        func_name = "BRIEF-MATERIAL"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("traceid", "")
        query_list = weibo.get("list", [])
        hot_query_list = []
        hit_query_list = []
        try:
            async with aiohttp.ClientSession() as session:
                async def get_summary(session, trace_id, query, logger):
                    task1 = get_zongshu_contents(session, trace_id, query, self.logger)
                    task2 = get_query_cate_list(session, trace_id, query, self.logger)
                    zongshu_content, query_cate_list = await asyncio.gather(*[task1, task2])
                    if zongshu_content == "" or query_cate_list == []:
                        return {}, query
                    data = {"query": query, "cate": query_cate_list, "summary": zongshu_content}
                    return data, query

                tasks = []
                for query in query_list:
                    tasks.append(get_summary(session, trace_id, query, self.logger))

                results = await asyncio.gather(*tasks)
                for data, query in results:
                    if data:
                        hot_query_list.append(data)
                        hit_query_list.append(query)

                weibo['hot_query_list'] = hot_query_list
                weibo['hit_query_list'] = hit_query_list
            self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\t"
                                   f"query_list_len:{len(query_list)}\thot_query_list_len:{len(hot_query_list)}\t"
                                   f"hit_query_list_len:{len(hit_query_list)}")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")


class ShortTvMaterial(Base):
    async def run(self, **kwargs):
        start = time.time()
        func_name = "SHORT-TV-MATERIAL"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("trace_id", "")
        query = weibo.get("query", "")

        temp = {}
        query_category = weibo.get("query_category", "")
        if query_category != 'ShortTv':
            return temp

        try:
            query = re.sub(r"^短剧|短剧$", "", query)
            #tgt_result = list(mongo_shorttv.find({'name': query}))
            tgt_result = list(await async_mongo_shorttv.find({'name': query}))
            keys = ['角色介绍', '剧情简介', '分集剧情', '剧集评价']
            for item in tgt_result:
                for key in keys:
                    if key in item and len(item[key]):
                        if key not in temp:
                            temp[key] = []
                        temp[key].append(item[key])
            weibo['short_tv_content'] = temp
            self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\t"
                                   f"tgt_result_len:{len(tgt_result)}")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        return temp


class KnowledgeMaterial(Base):

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("trace_id", "")
        try:
            star_ip_result = await read_starip_result(query, trace_id, self.logger)
            if star_ip_result:
                weibo['star_ip_result'] = star_ip_result
                self.write_log(message=f"star ip res success, query:{query}")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"star ip res error:{e}, msg:{traceback.format_exc()}")

class CTRMaterial(Base):
    """卡片头部内容优化 CTR优化 pv >= 1000, ctr >= 7.0"""

    def check_is_hot_query(self, source, q_attr):
        try:
            attr_dict = json.loads(q_attr)
            flush_source = attr_dict.get("flush_source", "")
        except:
            flush_source = ""
        if source == "3" and flush_source == "1":
            return True
        return False

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        source = weibo.get('source', '')
        q_attr = weibo.get('q_attr', '')
        self.update_pre_log_msg(weibo)
        if not self.check_is_hot_query(source, q_attr):
            return
        self.logger.info(self.pre_log_msg + f"use hot_query to get ctr material")
        try:
            ctr_res = await read_ctr_res_via_redis(query, self.pre_log_msg, self.logger)
            struct_ctr_res = await struct_ctr_result(query, ctr_res, self.pre_log_msg, self.logger)
            if struct_ctr_res:
                weibo['ctr_res_list'] = struct_ctr_res
                self.logger.info(self.pre_log_msg + f"add ctr_res_list len: {len(struct_ctr_res)}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error in ctr handle: {traceback.format_exc()}")

class HotClickMaterial(Base):
    """热点+star高点击物料"""
    def check_is_hot_query(self, source, q_attr):
        try:
            attr_dict = json.loads(q_attr)
            flush_source = attr_dict.get("flush_source", "")
        except:
            flush_source = ""
        if source == "3" and flush_source == "1":
            return True
        return False
        
    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        source = weibo.get('source', '')
        q_attr = weibo.get('q_attr', '')
        self.update_pre_log_msg(weibo)
        # if not self.check_is_hot_query(source, q_attr):
        #     return
        abtests = weibo.get('abtests', '')
        if 'lab_c' not in abtests:
            return
        self.logger.info(self.pre_log_msg + f"use hot_query to get hot click material(abtest)")
        try:
            # 获取当前时间
            now = datetime.now()

            # 生成前24小时的时间字符串列表
            hour_str_list = [(now - timedelta(hours=i)).strftime("%Y%m%d_%H") for i in range(1)]
            hot_weibo_click_dict = await read_weibo_click4hotstar(self.logger, self.pre_log_msg, query, hour_str_list, topn=20)

            if hot_weibo_click_dict:
                weibo['hot_weibo_click_dict'] = hot_weibo_click_dict
                self.logger.info(self.pre_log_msg + f"add hot_weibo_click_dict: {hot_weibo_click_dict}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error in hot click handle: {traceback.format_exc()}")

class BroadSocialMaterial(Base):
    """热搜 & 泛社会类"""

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        social_category = weibo.get('hot_social_category', 0)
        self.update_pre_log_msg(weibo)
        if not social_category:
            return
        self.logger.info(self.pre_log_msg + f"use hot_query to get broad social material")
        try:
            struct_broadsocial_res_res = await read_broadsocial_res_res_via_redis(query, self.pre_log_msg, self.logger)
            if struct_broadsocial_res_res:
                weibo['broadsocial_res_list'] = [struct_broadsocial_res_res]
                self.logger.info(self.pre_log_msg + f"add struct_broadsocial_res_res: {struct_broadsocial_res_res}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error in struct_broadsocial_res_res handle: {traceback.format_exc()}")

class URLSINAMaterial(Base):
    """SINANEWS物料"""

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        source = weibo.get('source', '')
        q_attr = weibo.get('q_attr', '')
        self.update_pre_log_msg(weibo)
        self.logger.info(self.pre_log_msg + f"use {query} to get url sina material")
        try:
            sina_res_dict = await read_sina_news_via_http(query, self.pre_log_msg, self.logger)
            if sina_res_dict:
                weibo['url_sina_content'] = sina_res_dict
                self.logger.info(self.pre_log_msg + f"add url_sina_title: {sina_res_dict.get('title', '')}\tconten len: {len(sina_res_dict.get('content', ''))}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error in sina news handle: {traceback.format_exc()}")

class GaoKaoAgentMaterial(Base):

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        query_category = weibo.get("query_category", "")
        if query_category != 'Education_Gaokao':
            return
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("trace_id", "")
        try:
            gaokao_agent_result = await get_gaokao_agent_material(query, trace_id, self.logger)
            if gaokao_agent_result:
                weibo['gaokao_agent_result'] = [gaokao_agent_result]
                self.logger.info(self.pre_log_msg + f"gaokao_agent_result:{gaokao_agent_result}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"gaokao_agent_result:{e}, msg:{traceback.format_exc()}")


class CoveMaterial(Base):

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        start = time.time()
        func_name = "COVE-MATERIAL"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get("trace_id", "")
        source = weibo.get("source", "")
        input_query = weibo.get("query", "")
        model = weibo.get('llm_name', "")
        hot_overview_override = weibo.get("hot_overview_override", "")
        realities = set()
        black_mids = set()

        if is_stream_output(weibo):
            return

        if source == '999':
            load = CoveMaterialLoader(self.pid)
            await load.run()

        try:
            queries = await cove_manual_dict.get('cove_content', [])
            global_black_mids = await cove_manual_dict.get('cove_mid', [])
            for item in global_black_mids:
                black_mid = item.get("black_mid", "")
                if black_mid:
                    black_mids.add(black_mid)

            for item in queries:
                reality_qwen = item.get('reality', [])
                reality_ds = item.get('reality_ds', [])
                reality_overview = item.get('reality_overreview', [])
                reality = reality_ds if 'deepseek' in model else reality_qwen
                if hot_overview_override:
                    reality = reality_overview

                query = item.get("query", "")
                match_key = item.get("match_key", "")
                black_mid = item.get("black_mid", "")
                query_set = {key.strip() for key in query.split('\n') if len(key.strip())}
                key_set = {key.strip() for key in match_key.split('\n') if len(key.strip())}
                black_mid_set = {mid.strip() for mid in black_mid.split('\n') if len(mid.strip())}

                if not reality and not black_mid_set:
                    continue

                # 命中query
                if input_query in query_set:
                    realities.update(reality)
                    black_mids.update(black_mid_set)

                # 命中key
                for key in key_set:
                    if key in input_query:
                        realities.update(reality)
                        black_mids.update(black_mid_set)

            # 用户反馈
            user_feedback = await user_feedback_dict.get(input_query, "")
            if user_feedback:
                self.logger.info(self.pre_log_msg + f"user_feedback:{json.dumps(user_feedback, ensure_ascii=False)}")
                realities.add(user_feedback)

            # 从redis里查当前query是否命中b级关键词事实，如果命中则拼到realities里
            intervene_knowledge = await self._get_intervene_knowledge_from_redis(input_query)
            if intervene_knowledge:
                realities.add(intervene_knowledge)
                self.logger.info(self.pre_log_msg + f"auto_intervene_knowledge:{intervene_knowledge}")
                weibo["is_auto_intervene_knowledge"] = True

            weibo["black_mids"] = black_mids
            if len(realities):
                weibo['cove_material'] = list(realities)
                weibo['cove_query'] = True
            self.write_log(message=f"{func_name} end, cost_time:{time.time() - start}\t"
                                   f"realities_len:{len(realities)}\tblack_mids_len:{len(black_mids)}")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}")

    async def _get_intervene_knowledge_from_redis(self, query: str) -> str:
        """从Redis中获取干预知识
        
        Args:
            query: 查询字符串
            
        Returns:
            str: 干预知识内容，如果没有找到则返回空字符串
        """
        try:
            key = f"{REDIS_INTERVENE_KNOWLEDGE_PREFIX}{query}"
            client = async_redis_client.get_redis_server(key)
            
            # 从Redis获取干预知识
            result = await client.get(key)
            if result:
                # 如果result是bytes类型，需要解码成字符串
                if isinstance(result, bytes):
                    return result.decode('utf-8')
                return result
                    
            return ""
            
        except Exception as e:
            return ""

class PreviousMaterial(Base):

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        llm_name = weibo.get("llm_name", "")
        hot_overview_override = weibo.get("hot_overview_override", "")
        robot_override = weibo.get("robot_override", "")
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        self_account = weibo.get("self_account", "")
        if robot_override:
            llm_name = robot_override
        if hot_overview_override:
            llm_name = hot_overview_override
        # previous_result = await read_previous_result(query, llm_name,
        #                                              self_account, trace_id, self.logger)
        # if previous_result:
        #     weibo['previous_result'] = previous_result


class WisAnalysisMaterial(Base):
    """Wis分析物料获取"""

    async def run(self, **kwargs):
        """启动函数"""
        start = time.time()
        func_name = "GET-WIS-MATERIAL"
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        if not weibo:
            return
        weibo["debug"]["zhisou_material_start_time"] = start
        self.update_pre_log_msg(weibo)
        query = weibo.get("query", "")
        stream_output = weibo.get("stream_output", 0)
        try:
            # 从Redis获取物料信息，格式{"24h": {}, "3d": {}, "30d": {}, "hot_tab": {}}，内部参考update_wis_dict函数
            task1 = get_zhisou(query, async_old_redis_client)
            # 从Redis获取category等信息
            task2 = get_query_type(query, async_old_redis_client)
            # 情感中间态观点物料获取
            redis_client_analysis = async_redis_client.get_redis_server(query)
            wis_material_dict, result2 = await asyncio.gather(*[task1, task2])
            category, up_billboard, hot_search = result2
            zhisou_emotion, star_json, emotion_dict = await self.get_emotion_wis_dict(query, category, stream_output, redis_client_analysis)
            self.logger.info(self.pre_log_msg + f"zhisou_emotion:{zhisou_emotion}\tstar_json:{star_json}")
            # 获取结果
            # 情感中间态观点更新物料信息
            self.update_wis_dict_with_emotion(wis_material_dict, emotion_dict)
            if stream_output != 1:
                weibo["zhisou_emotion"] = zhisou_emotion
                weibo["star_json"] = star_json
            if hot_search == "1":
                category = "9999"
            weibo["debug"]["zhisou_material_get_time"] = time.time()
            weibo["category"] = category
            weibo["up_billboard"] = up_billboard
            weibo["hot_search"] = hot_search
            weibo["wis_material_dict"] = wis_material_dict
            self.write_log(message=f"{func_name} end, cost_time:{time.time()-start}\t")
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")

    @staticmethod
    def struct_wis_material(weibo):
        """wis物料结构化，依赖于其他的物料信息，故在物料全部获取后处理"""
        wis_material_dict = weibo.get("wis_material_dict", {})
        raw_time_grade = weibo.get("raw_time_grade", "")
        query_category = weibo.get("query_category", "")
        # 更新默认值，
        WisAnalysisMaterial.update_wis_dict(wis_material_dict)
        # 物料清洗，置空不需要的物料
        WisAnalysisMaterial.clear_wis_strategy(wis_material_dict)
        # 合并物料
        merge_wis_dict = WisAnalysisMaterial.merge_wis_strategy(wis_material_dict, raw_time_grade, query_category)
        if not merge_wis_dict["content"]:
            weibo["use_zhisou"] = False
            weibo["zhisou_content"] = []
            weibo["zhisou_content_struct"] = []
            weibo["zhisou_mids_num"] = 0
        else:
            weibo["use_zhisou"] = True
            weibo["zhisou_content"] = merge_wis_dict["content"]
            weibo["zhisou_content_struct"] = merge_wis_dict["content_struct"]
            weibo["zhisou_mids_num"] = len(merge_wis_dict["zhisou_mids"])
            weibo["zhisou_mids"] = list(merge_wis_dict["zhisou_mids"])

    async def get_emotion_wis_dict(self, query, category, stream_output, redis_client_analysis):
        """获取情感中间态观点物料信息"""
        func_name = "EMOTION_WIS"
        zhisou_emotion = ""
        star_json = {}
        emotion_dict = {}
        try:
            if stream_output != 1:
                zhisou_emotion, star_json = await get_zhisou_emotion_res(self.pid, self.pre_log_msg, query)
            emotion_dict = await get_zhisou_new(query, redis_client_analysis, zhisou_emotion, category)
            return zhisou_emotion, star_json, emotion_dict
        except Exception as e:
            self.write_log(write_type="ERROR", message=f"{func_name} error:{e}, msg:{traceback.format_exc()}")
        return zhisou_emotion, star_json, emotion_dict

    @staticmethod
    def update_wis_dict_with_emotion(wis_material_dict, emotion_dict):
        """根据情感中间态观点物料更新wis物料"""
        for key, value in emotion_dict.items():
            if value.get("get_data_flag", False):
                wis_material_dict[key] = value
        wis_material_dict["3d"] = emotion_dict.get("3d", {})


    @staticmethod
    def update_wis_dict(wis_material_dict):
        """更新物料信息 {"24h": {}, "3d": {}, "30d": {}, "hot_tab": {}}"""
        keys = ["24h", "3d", "30d", "hot_tab"]
        for key in keys:
            wis_value = wis_material_dict.setdefault(key, {})
            wis_value["past_events"] = wis_value.get("past_events", [])
            wis_value["typical_viewpoint"] = wis_value.get("typical_viewpoint", [])
            wis_value["past_events_struct"] = wis_value.get("past_events_struct", [])
            wis_value["typical_viewpoint_struct"] = wis_value.get("typical_viewpoint_struct", [])
            wis_value["past_events_mids"] = wis_value.get("past_events_mids", [])
            wis_value["typical_viewpoint_mids"] = wis_value.get("typical_viewpoint_mids", [])
            wis_value["past_events_end_time"] = wis_value.get("past_events_end_time", 0)
            wis_value["typical_viewpoint_end_time"] = wis_value.get("typical_viewpoint_end_time", 0)
            wis_value["analysis_time"] = wis_value.get("analysis_time", 0)

    @staticmethod
    def clear_wis_list_data(wis_material_dict, wis_key):
        """不使用的wis物料置空"""
        material_type_list = ["past_events", "typical_viewpoint", "past_events_struct",
                         "typical_viewpoint_struct", "past_events_mids", "typical_viewpoint_mids"]
        for material_type in material_type_list:
            wis_material_dict[wis_key][material_type] = []
        wis_material_dict[wis_key]["analysis_time"] = 0

    @staticmethod
    def clear_wis_strategy(wis_material_dict):
        """本身逻辑清洗"""
        if not wis_material_dict["hot_tab"].get("analysis_time", 0):
            WisAnalysisMaterial.clear_wis_list_data(wis_material_dict, "hot_tab")
        tab_to_day = {"24h": 3, "3d": 3, "30d": 30}
        now = time.time()
        for tab, day in tab_to_day.items():
            if now - wis_material_dict[tab].get("analysis_time", 0) > day * 24 * 3600:
                WisAnalysisMaterial.clear_wis_list_data(wis_material_dict, tab)

    @staticmethod
    def merge_wis_strategy(wis_material_dict, raw_time_grade, query_category):
        """合并物料"""
        merge_wis_dict = {"content": [], "content_struct": [], "zhisou_mids": set()}
        if wis_material_dict["hot_tab"].get("analysis_time", 0):
            merge_wis_dict["content"].extend(wis_material_dict["hot_tab"]["past_events"])
            merge_wis_dict["content_struct"].extend(wis_material_dict["hot_tab"]["past_events_struct"])
            merge_wis_dict["zhisou_mids"] |= set(wis_material_dict["hot_tab"]["past_events_mids"])
        if raw_time_grade == 'strong' and query_category != "LatestDevelopments":
            if wis_material_dict["3d"].get("analysis_time", 0):
                WisAnalysisMaterial.merge_single_material(wis_material_dict, "3d", merge_wis_dict)
            else:
                WisAnalysisMaterial.merge_single_material(wis_material_dict, "24h", merge_wis_dict)
        else:
            WisAnalysisMaterial.merge_single_material(wis_material_dict, "30d", merge_wis_dict)
        # 去除空物料
        merge_wis_dict["content"] = [content.strip() for content in merge_wis_dict["content"] if content.strip()]
        return merge_wis_dict

    @staticmethod
    def merge_single_material(wis_material_dict, wis_key, merge_wis_dict):
        """合并 24h，3d，30d，hot_tab 其中的一项"""
        merge_wis_dict["content"].extend(wis_material_dict[wis_key]["past_events"])
        merge_wis_dict["content"].extend(wis_material_dict[wis_key]["typical_viewpoint"])
        merge_wis_dict["content_struct"].extend(wis_material_dict[wis_key]["past_events_struct"])
        merge_wis_dict["content_struct"].extend(wis_material_dict[wis_key]["typical_viewpoint_struct"])
        merge_wis_dict["zhisou_mids"] |= set(wis_material_dict[wis_key]["past_events_mids"])
        merge_wis_dict["zhisou_mids"] |= set(wis_material_dict[wis_key]["typical_viewpoint_mids"])


class StockMaterial(Base):
    """股票物料获取"""

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        start = time.time()
        self.update_pre_log_msg(weibo)

        # TODO: pre-compile the pattern for efficiency
        pattern = r"(?:股票|股价|市值|估值|走势|涨势|加仓|减仓|持仓)"
        flag = bool(re.search(pattern, query))
        self.logger.info(f"{self.pre_log_msg} {trace_id} stock flag: {flag}")

        jieba_url = 'http://10.133.168.176:9999/segment'
        data = {'query': query}
        headers = {'Content-Type': 'application/json'}

        if flag:
            try:
                # 白板统计
                weibo["m_type4wb"] = "股票财经"
                # Start the segment request asynchronously
                async with aiohttp.ClientSession() as session:
                    timeout = aiohttp.ClientTimeout(total=1)
                    async with session.post(jieba_url, json=data, headers=headers, timeout=timeout) as response:
                        response_data = await response.json()

                        # Handle the response and extract stock entity
                        search_query = response_data.get("entity", "")

                        self.logger.info(f"{self.pre_log_msg} {trace_id} stock jieba res: {search_query}")

                        if search_query:
                            stock_code_list = stock_dict.search(search_query)

                            # Proceed only if we have a valid stock code
                            if stock_code_list:

                                stock_info_list = await asyncio.gather(*[fetch_stock_via_api(oid=stock_code) for stock_code in stock_code_list])
                                struct_stock_info_list = build_stock_content(stock_info_list,
                                                                        logger=self.logger, pre_log_msg=self.pre_log_msg)

                                weibo['stock_info'] = struct_stock_info_list

                                # Log the info
                                self.logger.info(
                                    f"{self.pre_log_msg} {trace_id} stock info: {struct_stock_info_list}, cost: {time.time() - start}"
                                )

            except aiohttp.ClientError as e:
                self.logger.error(f"{self.pre_log_msg} Error in HTTP jieba server error: {str(e)}")
            except KeyError as e:
                self.logger.error(f"{self.pre_log_msg} Key error: {str(e)}")
            except Exception as e:
                self.logger.error(f"{self.pre_log_msg} Unexpected error: {traceback.format_exc()}")

class HotquerySql(Base):
    """通过大模型生成sql查询热点库"""
    def __init__(self, pid):
        super().__init__(pid)
        self.hot_query_llm = HotQueryLlm(pid)
        # with open("data/star.json", "r", encoding="utf-8") as f:
        #     star_list = json.load(f)
        self.star_trie = query_trie

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        query_risk_level = weibo.get("limit_degree", "")
        trace_id = weibo.get("trace_id", "")
        prompt_scene = weibo.get("prompt_scene", "")
        # s_list = weibo.get("start_list", "")
        # time_result = weibo.get("time_result", "")
        # keyword_conditions = weibo.get("keyword_conditions", "")
        # sql_list = weibo.get("sql_kwargs_list", [])
        pattern = r'(微博热搜榜|文娱榜|热榜|热点榜|热点榜单|热搜榜单|热搜简报|带货直播事件|热搜|热点|高频超话|高频话题)'
        flag = bool(re.search(pattern, query))
        if flag:
            try:
                # 白板统计
                weibo["m_type4wb"] = "榜单热点"

                if RISK_CONTROL_3_6_SWITCH or weibo.get("limit_material"):
                    return

                star_list = self.star_trie.search(query)
                t1 = time.time()
                #hot_query,  time_result_res, keyword_conditions_res, star_list_res, sql_kwargs_list_res = await self.hot_query_llm.run(query, star_list, trace_id)
                hot_query = await self.hot_query_llm.run(query, star_list, trace_id, prompt_scene=='deepseek_stream')
                t2 = time.time()
                self.logger.info("traceid: {}, agent_sql_time_cost: {}".format(trace_id, t2 - t1))
                if hot_query:
                    weibo["hot_query_res"] = hot_query
                # weibo["start_list"] = star_list_res
                # weibo["time_result"] = time_result_res
                # weibo["keyword_conditions"] = keyword_conditions_res
                # weibo["sql_kwargs_list"] = sql_kwargs_list_res
            except Exception as e:
                self.logger.error("{} hot query error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))


class RiskControlMaterial(Base):
    async def get_content(self, query, ori_content, version):
        url = f'http://admin.ai.s.weibo.com/api/wis/senstive.json'
        datas = {
            "content": ori_content,
            "version": version,
            "query": query
        }
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(2)) as session:
                async with session.post(url, json=datas) as r:
                    if r.status == 200:
                        res_json = await r.json()
                        return res_json.get("final_res", "")
        except Exception as e:
            self.logger.error("{} risk control get_content error: {}, msg: {}".format(version, e, traceback.format_exc()))
        return ""

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        source = weibo.get("source", "")
        llm_name = weibo.get("llm_name", "")
        start = time.time()
        data = {}
        url = f'http://admin.ai.s.weibo.com/api/llm/analysis_once_res.json?query={query}'
        if source == "99" and llm_name in ['deepseek', 'deepseek_verification']:
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(2)) as session:
                    async with session.get(url=url) as r:
                        if r.status == 200:
                            res = await r.json()
                            data = res.get("data", {}).get(llm_name, {})
                            if data:
                                content = data.get('content', "")
                                ori_content = data.get('ori_content', "")
                                sens_reason = data.get('sens_reason', "")

                                # 测试
                                # content = await self.get_content(query, ori_content, trace_id)
                                # data['content'] = content

                                if content and ori_content and sens_reason:
                                    weibo['risk_control'] = data
            except Exception as e:
                self.logger.error("{} risk control error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info("{} risk control: {}, cost: {}".format(trace_id, data, time.time() - start))


class MidMaterial(Base):

    async def get_art_content(self, trace_id, id):
        cleaned_text = ""
        url = "http://i2.api.weibo.com/2/entity/show.json?source=2842762591&object_id=1022:{}&with_object=1".format(id)

        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        content = res.get("entity", {}).get("content", "")
                        follow_to_read = int(res.get("entity", {}).get("follow_to_read", 1) or 1)
                        if follow_to_read == 1 or not content:
                            return ""
                        cleaned_text = re.sub(r'<[^>]+>', '', content)
        except Exception as e:
            self.logger.error(
                "{} get art content error:{}".format(trace_id, e))
        return cleaned_text

    async def get_weibo_article(self, trace_id, weibo):
        art_text = ""
        filter = int(weibo.get("FILTER", "0") or "0")
        if filter & 128 == 0:
            return art_text
        lurls = weibo.get("LURLS", "")
        art_id = ""
        for url in lurls.split(" "):
            if "ttarticle" in url:
                art_id = url.split("id=")[-1]
                break
        if art_id:
            art_text = await self.get_art_content(trace_id, art_id)
        return art_text

    def parse_all_tag_new(self, trace_id, all_tag_new):
        try:
            if not all_tag_new:
                return False

            all_tag_new_dict = json.loads(all_tag_new)
            m1 = all_tag_new_dict.get("m1", "")
            r1 = all_tag_new_dict.get("r1", "")
            if "医疗" in m1 or "医疗" in r1:
                return True
        except:
            self.logger.error(
                "{} all_tag_new parse error:{}".format(trace_id, all_tag_new))
        return False

    async def _req_via_hbase(self, query: str, retry: int = 2) -> dict:
        # url = f"http://hbaseapi.search.weibo.com/getdata/querydata2.php?condition={query}&mode=weibo&format=json&hbase=1"
        url = f"http://getdata.search.weibo.com/getdata/querydata.php?condition={query}&mode=weibo&format=json"
        for attempt in range(retry):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as session:
                    async with session.get(url) as resp:
                        text = await resp.text()
                        res = json.loads(text)
                        if isinstance(res, dict) and res:
                            self.logger.info(self.pre_log_msg + "hbase_ask_info")
                            return res
                        else:
                            self.logger.warning(self.pre_log_msg + f"HBASE INVALID RESPONSE {query} attempt {attempt + 1}/{retry} response: {text}")
            except asyncio.TimeoutError:
                self.logger.info("hbase_ask_timeout")
            except Exception as e:
                self.logger.warning(self.pre_log_msg + f"HBASE ERROR {query} attempt {attempt + 1}/{retry} error: {e}")
        return {}

    def process_all_tag_new(self, trace_id, all_tag_new):
        def process_tag_info(tag_str):
            tag_dict = {}
            for tag in tag_str.split("|"):
                tag_name, score_str = tag.split("@")
                tag_dict[tag_name] = float(score_str)
            return tag_dict

        tags = {"tag1": [], "tag2": [], "tag3": []}
        try:
            if not all_tag_new:
                return tags
            all_tag_new_dict = json.loads(all_tag_new)

            l1_tag_dict = {}
            r_flag = False
            if all_tag_new_dict.get("r1"):
                l1_tag_dict = process_tag_info(all_tag_new_dict["r1"])
                r_flag = True
            elif all_tag_new_dict.get("m1"):
                l1_tag_dict = process_tag_info(all_tag_new_dict["m1"])
            
            for tag, score in sorted(l1_tag_dict.items(), reverse=True):
                if r_flag:
                    if score > 0.7:
                        tags["tag1"].append(tag)
                else:
                    if tag in ["汽车", "美妆"]:
                        if score > 0.7:
                            tags["tag1"].append(tag)
                    else:
                        if score > 0.8:
                            tags["tag1"].append(tag)
                            
            l2_tag_dict = {}
            r_flag = False
            if all_tag_new_dict.get("r2"):
                l2_tag_dict = process_tag_info(all_tag_new_dict["r2"])
                r_flag = True
            elif all_tag_new_dict.get("m2"):
                l2_tag_dict = process_tag_info(all_tag_new_dict["m2"])
            
            for tag, score in sorted(l2_tag_dict.items(), reverse=True):
                if r_flag:
                    if score > 0.7:
                        tags["tag2"].append(tag)
                else:
                    if score > 0.8:
                        tags["tag2"].append(tag)
            
            l3_tag_dict = {}
            r_flag = False
            if all_tag_new_dict.get("r3"):
                l3_tag_dict = process_tag_info(all_tag_new_dict["r3"])
                r_flag = True
            elif all_tag_new_dict.get("m3"):
                l3_tag_dict = process_tag_info(all_tag_new_dict["m3"])
            
            for tag, score in sorted(l3_tag_dict.items(), reverse=True):
                if r_flag:
                    if score > 0.7:
                        tags["tag3"].append(tag)
                else:
                    if score > 0.8:
                        tags["tag3"].append(tag)
        except:
            self.logger.error("{} process_blog_all_tag error:{}".format(trace_id, all_tag_new))
        return tags

    def make_tag_extra_part(self, reco_tags: dict):
        if not reco_tags:
            return ""
        try:
            res_prefix = "- 这篇博文的内容"
            t1 = reco_tags.get("tag1", [])
            t2 = reco_tags.get("tag2", [])
            t3 = reco_tags.get("tag3", [])
            t1_str = ""
            t2_str = ""
            t3_str = ""
            res_list = []
            if t1:
                t1_str= f"属于{'、'.join(t1)}领域"
                res_list.append(t1_str)
            if t2:
                t2_str= f"可能涉及{'、'.join(t2)}等类型"
                res_list.append(t2_str)
            if t3:
                t3_str= f"内容与{'、'.join(t3)}相关"
                res_list.append(t3_str)
            res_str = "，".join(res_list)
            if res_str:
                return res_prefix + res_str + "。"
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"make_tag_extra_part error: {e}")
        return ""


    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        self.update_pre_log_msg(weibo)
        start = time.time()
        # 博文分析-求证
        mid_content = ""
        mid_voice = ""
        ocr_text = ""
        article_text = ""
        mid_uid = ""
        mid_type = ""
        nick_name = ""
        pub_time = ""
        root_name = ""
        root_txt = ""
        filter = False
        is_star = False
        is_ad = False
        mid_video_abs = ""
        mid_reco_tags = {}
        sc_mid_ori_content = ""
        blog_video_pic_comment = ""  # 博文视频或图片及评论内容概要
        video_whole_content = ""  # 视频整体内容摘要
        video_part_content = ""  # 视频分片内容摘要
        video_mention_keyword = ""  # 视频声音提及关键词
        video_reco_result = ""  # 视频声音识别结果
        blog_pic_content = ""  # 博文图片内容
        try:
            res = await self._req_via_hbase(query)
            try:
                blog_video_pic_comment = res.get("IDX_COMPREHEND_ABSTRACT", "").strip()
                video_whole_content = res.get("INDEX_VIDEO_AIABS_TOTAL", "").strip()
                video_part_content = res.get("INDEX_VIDEO_AIABSTRACT_NEW", "").strip()
                video_mention_keyword = res.get("IDX_VIDEO_VOICE_KEYWORD", "").strip()
                video_reco_result = res.get("IDX_VIDEO_VOICE", "").strip()
                blog_pic_content = await get_pid_info(res)
                mid_content = res.get("LONGTEXT", "") if res.get("ISLONG", "") == "1" else res.get("CONTENT", "")
                filter = int(res.get("FILTER", 0) or "0") & 4
                # if mid_content or filter:
                #     mid_content_str = f"- 博文正文：{mid_content}"
                #     sc_mid_ori_content = mid_content_str
                nick_name = res.get('NICK', "")
                pub_time = res.get('TIME')
                mid_video_abs = res.get('INDEX_VIDEO_AIABSTRACT', "").strip()
                if filter:
                    root_long_text = res.get("ROOT_LONGTEXT", "")
                    root_mid = res.get("ROOTMID", "")
                    root_name, root_uid, root_pub = await get_user_info(root_mid)
                    root_txt = root_long_text if root_long_text else res.get("TEXT", "")
                mid_voice = res.get("VIDEO_VOICE", "").strip()
                mid_uid = res.get('UID', "")
                is_ad = int(res.get('QI') or '0') % 2

                pic_feature = json.loads(res.get("PICS_FEATURE", "{}"))
                if pic_feature:
                    txt = "".join([item['ocr'] for item in pic_feature['res'] if 'ocr' in item])
                    # is_ocr = checkQualifiedOcrText(txt)
                    is_ocr = True
                    self.logger.info(
                        "{} ocr {} is_ocr:{}".format(trace_id, json.dumps(txt, ensure_ascii=False), is_ocr))
                    if is_ocr:
                        ocr_text = txt
                article_text = await self.get_weibo_article(trace_id, res)
                INNER_USER_INFO = json.loads(res.get("INNER_USER_INFO","{}"))
                users = INNER_USER_INFO.get("users", [])
                if users:
                    attr1 = users[0].get("flevel", {}).get("attr1", "")
                    if attr1 == "明星":
                        weibo['is_star'] = True
                        is_star = True
                    # if attr1 == "组织号":
                    #     weibo['is_organization'] = True
                    is_blue_v = int(users[0].get('vtype') or '0')
                    is_red_v = int(users[0].get('vtype_ext') or '0')
                    if is_blue_v == 1 or (is_blue_v == 3 and is_red_v == 53):
                        weibo['is_organization'] = True

                category_v2 = res.get("CATEGORY_V2")
                if category_v2:
                    weibo["mid_category_v2"] = int(category_v2) - 1

                total_pid_set = set()
                if res.get("PICS_INFO"):
                    pics_info = json.loads(res.get("PICS_INFO"))
                    total_pid_set.update(pics_info.keys())
                weibo["reco_pic_list"] = list(total_pid_set)

                total_video_pid_set = set()
                if res.get("VIDEO_INFO"):
                    video_info = json.loads(res.get("VIDEO_INFO", "{}"))
                    if video_info.get("api_res", {}) and isinstance(video_info["api_res"], dict):
                        total_video_pid_set.update(video_info["api_res"].keys())
                weibo["reco_video_pic_list"] = list(total_video_pid_set)
                weibo["have_video"] = int(res.get("HAVE_VIDEO", 0))

                all_tag_new = res.get("ALL_TAG_NEW", "")
                if self.parse_all_tag_new(trace_id, all_tag_new):
                    weibo["mid_is_medical"] = True
                
                mid_reco_tags = self.process_all_tag_new(trace_id, all_tag_new)
                weibo["reco_tags"] = mid_reco_tags
            except Exception as e:
                self.logger.warning(
                    "{} HBASE DATA PARSE ERROR {} error:{}".format(trace_id, query, e))

            if not mid_content:
                mid_content, mid_voice, mid_uid = await get_voice(query)

            if mid_uid in MEDIA_UIDS:
                mid_type = "媒体账号"
            elif is_star:
                mid_type = "明星"

            try:
                mid_content = re.sub(u'(?i)http[s]?://(?:[a-zA-Z]|[0-9]|[#$%*-;=?&@~.&+]|[!*,])+$', '', mid_content.strip())
                mid_content = re.sub(r'<sina.*?>$', '', mid_content)

                root_txt = re.sub(u'(?i)http[s]?://(?:[a-zA-Z]|[0-9]|[#$%*-;=?&@~.&+]|[!*,])+$', '', root_txt.strip())
                root_txt = re.sub(r'<sina.*?>$', '', root_txt)
            except:
                pass

            clean_content = mid_clean(mid_content, weibo_topic=False)
            clean_root_txt = mid_clean(root_txt, weibo_topic=False)
            all_content = clean_content + article_text + mid_voice + ocr_text + clean_root_txt
            if len(all_content) < 10:
                weibo['is_less_than_10'] = True
                self.logger.info("{} mid material is_less_than_10".format(trace_id))

            parts = []
            if mid_type:
                parts.append(f"- 原博的博主类型：{mid_type}")
            if mid_content or filter:
                mid_content_part = f"- 博文正文：{mid_content}"
                sc_mid_ori_content = mid_content
                if filter:
                    mid_content_part += f"//@{ root_name }：{ root_txt }"
                parts.append(mid_content_part)
            if article_text:
                parts.append(f"- 博文中的文章内容为：{article_text}")
            # if mid_voice:
            #     parts.append(f"- 博文中视频的声音识别结果为：{mid_voice}")
            # if ocr_text:
            #     parts.append(f"- 博文中图片的识别结果为：{ocr_text}")
            if mid_video_abs:
                parts.append(f"- 博文中视频内容为：{mid_video_abs}")
            new_parts = []
            if mid_reco_tags:
                part_str = self.make_tag_extra_part(mid_reco_tags)
                if part_str:
                    self.logger.info(self.pre_log_msg + f"add tag3_extra_part: {part_str}")
                    new_parts.append(part_str)
                    weibo['mid_tag3_extra_part'] = True
            if blog_video_pic_comment:
                if not blog_video_pic_comment.endswith("。"):
                    blog_video_pic_comment += "。"
                new_parts.append(f"- 博文视频或图片及评论内容概要是 {blog_video_pic_comment}")
            if video_whole_content:
                if not video_whole_content.endswith("。"):
                    video_whole_content += "。"
                new_parts.append(f"- 博文中视频整体内容摘要是 {video_whole_content}")
            if video_part_content:
                if not video_part_content.endswith("。"):
                    video_part_content += "。"
                new_parts.append(f"- 视频分片内容摘要分别是 {video_part_content}")
            if video_mention_keyword:
                if not video_mention_keyword.endswith("。"):
                    video_mention_keyword += "。"
                new_parts.append(f"- 视频声音中提及的关键词有 {video_mention_keyword}")
            if video_reco_result:
                if not video_reco_result.endswith("。"):
                    video_reco_result += "。"
                new_parts.append(f"- 视频的声音识别结果是 {video_reco_result}")
            if blog_pic_content:
                if not blog_pic_content.endswith("。"):
                    blog_pic_content += "相关。"
                else:
                    blog_pic_content += blog_pic_content[:-1] + "相关。"
                new_parts.append(f"- 博文中图片内容与 {blog_pic_content}")
            if ocr_text:
                if not ocr_text.endswith("。"):
                    ocr_text += "。"
                new_parts.append(f"- 图片的识别结果为{ocr_text}")
            if new_parts:
                new_parts = ["以下是博文相关内容的说明："] + new_parts
                parts += new_parts
            mid_content = '\n'.join(parts) if parts else ''
        except Exception as e:
            self.logger.error(
                "{} mid material {} error:{}".format(trace_id, query,e))

        weibo['sc_mid_ori_content'] = sc_mid_ori_content
        weibo['mid_content'] = mid_content
        weibo['mid_uid'] = mid_uid
        weibo['nick_name'] = nick_name
        weibo['pub_time'] = pub_time
        weibo['is_forward'] = filter
        weibo['is_ad'] = is_ad
        weibo['mid_voice'] = mid_voice
        weibo['mid_ocr'] = ocr_text
        weibo['mid_video_abs'] = mid_video_abs
        self.logger.info("{} mid_content: {}, cost: {}".format(trace_id, mid_content, time.time() - start))
        self.logger.info(self.pre_log_msg + (
            f"has_voice: {bool(mid_voice)}\t"
            f"has_ocr: {bool(ocr_text)}\t"
            f"has_video_abs: {bool(mid_video_abs)}\t"
            f"has_article: {bool(article_text)}\t"
            f"has_video: {bool(weibo.get('have_video', False))}"
        ))


class CollegeMaterial(Base):
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        tasks = [self.check_if_called_third_party(**kwargs),self.intention_recognition(**kwargs)]
        await asyncio.gather(*tasks)

    async def check_if_called_third_party(self,**kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        redis = async_redis_client.get_redis_server(query)
        key = "wis_summary_polling_gaokao" + query
        if await redis.exists(key):
            weibo["is_called_third_party"] = False
        else:
            weibo["is_called_third_party"] = True

        self.logger.info(self.pre_log_msg + f"is_called_third_party: {weibo.get('is_called_third_party', False)}")
        weibo["debug"]["time_analysis"]["check_if_called_third_party_start"] = start
        weibo["debug"]["time_analysis"]["check_if_called_third_party_end"] = time.time()

    async def intention_recognition(self,**kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        prompt = college_intention_factory(weibo)
        prompt_content = prompt.prompt()
        llm = GaoKaoIntentionWrapper(weibo, self.pid, self.pre_log_msg, "CALL_GAOKAO_INTENTION")
        response = await llm.async_call(prompt_content)
        text = response.get("text", "")
        if "</think>" in text:
            text = text.split("</think>")[1]
        resp = text.strip("\n")
        if resp in ["查高考真题", "查录取分数", "查询招生简章"]:
            text = '只使用掌上高考模式'
        elif resp in ["学校/专业选报建议", "查询学校/专业", "学校/专业就业情况", "相同学校不同专业对比", "相同专业不同学校对比"]:
            text = '拼接模式'
        elif resp in ["查高考作文", "其他"]:
            text = '只使用智搜模式'
        else:
            text = '只使用智搜模式'
            self.logger.info(f"{self.pre_log_msg}\tintention_recognition error\tquery:{weibo.get('ori_query', '')}\tresp:{resp}")

        weibo["gaokao_intention"] = text
        weibo['gaokao_intention_little'] = resp
        ori_query = weibo.get("ori_query", "")
        if ori_query.endswith("_gaokaosp"):
            weibo["gaokao_intention"] = "拼接模式"

        self.logger.info(self.pre_log_msg + f"gaokao_intention: {weibo.get('gaokao_intention', '')}\tresp: {json.dumps(resp, ensure_ascii=False)}\tori_query: {weibo.get('ori_query', '')}")
        weibo["debug"]["time_analysis"]["intention_recognition_start"] = start
        weibo["debug"]["time_analysis"]["intention_recognition_end"] = time.time()


class SummaryResultMaterial(Base):

    @staticmethod
    def clean_text(text):
        pattern = r'<think>.*?</think>'
        pattern1 = r'<media-block>.*?</media-block>'
        pattern2 = r'\[\^.*?\]'

        tq_pattern = r'```wbCustomBlock(\{.*?})```'
        text = re.sub(pattern, '', text, flags=re.DOTALL)
        text = re.sub(pattern1, '', text, flags=re.DOTALL)
        text = re.sub(pattern2, '', text, flags=re.DOTALL)
        text = re.sub(tq_pattern, '', text, flags=re.DOTALL)
        return text

    async def get_result(self, trace_id, query, version, model):
        url = "http://admin.ai.s.weibo.com/api/llm/get_redrocks.json?query={}&model={}&version={}&sid=annotations".format(query, model, version)
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        status = res.get("msg", "")
                        result = res.get("data", {}).get(model, {}).get("content", "").strip()
                        if "</think>" in result:
                            result = SummaryResultMaterial.clean_text(result.split("</think>")[1]).strip()
                        else:
                            result = ""
                        self.logger.info("{} get result status:{}, len:{}".format(trace_id, status, len(result)))
                        return result if status == "success" and result else ""
        except Exception as e:
            self.logger.error("{} get result error:{}".format(trace_id, e))
        return ""


    async def run(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get('trace_id', "")
        query = weibo.get('query', "")
        version = weibo.get('verification_note_version', "")
        result = await self.get_result(trace_id, query, version, "deepseek_verification")
        weibo['ori_result'] = result
        self.logger.info("{} cost:{}".format(trace_id, time.time() - start))

class MidContentAnalysisMaterial(Base):

    def clean_text(self, text):
        pattern = r'<think>.*?</think>'
        pattern1 = r'<media-block>.*?</media-block>'
        pattern2 = r'\[\^.*?\]'
        
        tq_pattern = r'```wbCustomBlock(\{.*?})```'
        text = re.sub(pattern, '', text, flags=re.DOTALL)
        text = re.sub(pattern1, '', text, flags=re.DOTALL)
        text = re.sub(pattern2, '', text, flags=re.DOTALL)
        text = re.sub(tq_pattern, '', text, flags=re.DOTALL)
        return text

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        start = time.time()
        data = {}
        url = f'http://admin.ai.s.weibo.com/api/llm/analysis_once_res.json?query={query}'
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(10)) as session:
                async with session.get(url=url) as r:
                    if r.status == 200:
                        res = await r.json()
                        data = res.get("data", {}).get('deepseek_verification', {})
                        if data:
                            content = data.get('content', "")
                            if content:
                                weibo['mid_content_analysis_res'] = self.clean_text(content)
        except Exception as e:
            self.logger.error("{} mid content analysis error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info("{} mid content analysis: {}, cost: {}".format(trace_id, data, time.time() - start))


class ShowBatchMaterial(Base):
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        start = time.time()
        url_marked = False
        try:
            url_marked = await get_url_marked(query)
            if url_marked:
                weibo['url_marked'] = True
        except Exception as e:
            self.logger.error("{} url_marked error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info("{} mid url_marked: {}, cost: {}".format(trace_id, url_marked, time.time() - start))


class HotSearchBoardMaterial(Base):

    def get_pv(self, trace_id, q_attr):
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                su_pv = int(json_data.get("su_pv", 0))
                return su_pv
            except Exception as e:
                self.logger.error("{} q_attr:{}, error:{}".format(trace_id, q_attr, e))
        return 0

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        source = weibo.get("source", "")
        q_attr = weibo.get("q_attr", "")
        llm_name = weibo.get("llm_name", "")
        prompt_scene = weibo.get("prompt_scene", "")
        start = time.time()

        try:
            if prompt_scene == 'deepseek':
                # 可信提示
                is_exist = await reliable_tips_dict.get(query, 0)
                pv = self.get_pv(trace_id, q_attr)
                if is_exist or pv >= 1000:
                    weibo['is_reliable'] = 1
                    self.logger.info("{}, {} is reliable".format(trace_id, query))

                # 引导语
                is_exist = await event_group_dict.get(query, 0)
                if is_exist:
                    weibo['is_guide'] = 1
                    self.logger.info("{}, {} is guide".format(trace_id, query))

        except Exception as e:
            self.logger.error("{} url_marked error: {}, msg: {}".format(trace_id, e, traceback.format_exc()))
        self.logger.info("{}, cost: {}".format(trace_id, time.time() - start))


class QueryVersionMaterial(Base):

    @staticmethod
    def filter_versions_within_range(
        versions: list[dict],
        start_ts: int,
        end_ts: int
    ) -> list[dict]:
        """
        从版本列表中过滤出 version_time 在最近 24 小时内的记录，并按 version_time 升序排序。

        Args:
            versions: 形如 [{'version_time': datetime(...), ...}, ...] 的列表
            now: 当前时间，不传则使用 datetime.now()

        Returns:
            过滤并排序后的列表
        """
        if not isinstance(versions, list):
            return []
        if not isinstance(start_ts, int) or not isinstance(end_ts, int):
            return []

        start_dt = datetime.fromtimestamp(start_ts)
        end_dt = datetime.fromtimestamp(end_ts)
        # 过滤 version_time 在 [threshold, now] 区间内的记录
        filtered = [
            item for item in versions
            if isinstance(item.get("version_time"), datetime)
            and start_dt <= item["version_time"] <= end_dt
        ]

        # 按 version_time 升序排序
        filtered.sort(key=lambda x: x["version_time"])
        return filtered

    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get('query', '')
        prompt_scene = weibo.get("prompt_scene", "")
        if prompt_scene != "deepseek_last":
            return
        self.update_pre_log_msg(weibo)

        try:
            now = datetime.now()
            today = now.strftime("%Y%m%d")
            q_attr = weibo.get('q_attr', '')
            q_attr = json.loads(q_attr)
            start_ts = q_attr.get('start_ts')
            end_ts = q_attr.get('end_ts')
            yesterday = (now - timedelta(days=1)).strftime("%Y%m%d")
            version_all_list = await get_query_version_list_via_http(query, yesterday, today, self.pre_log_msg, self.logger)
            sorted_version_list = QueryVersionMaterial.filter_versions_within_range(version_all_list, start_ts, end_ts)
            if len(sorted_version_list) > 1:
                start_version = sorted_version_list[0]['version']
                end_version = sorted_version_list[-1]['version']
                r1_res = await asyncio.gather(
                    read_r1_res_via_http(query, start_version, self.pre_log_msg, self.logger),
                    read_r1_res_via_http(query, end_version, self.pre_log_msg, self.logger)
                )
                start_r1_res = r1_res[0]
                end_r1_res = r1_res[1]
                if start_r1_res and end_r1_res:
                    weibo['q_r1_v_list'] = [start_version, end_version]
                    weibo['q_r1_res_list'] = [start_r1_res, end_r1_res]
                    self.logger.info(self.pre_log_msg + f"q_r1_v_list: {start_version}, {end_version}")
                else:
                    self.logger.warning(self.pre_log_msg + f"q_r1_res_list is empty: {len(start_r1_res)}, {len(end_r1_res)}")
            else:
                self.logger.warning(self.pre_log_msg + f"q_r1_v_list len is less than 2: {sorted_version_list}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"get query version list error: {e}")

class HotQueryListMaterial(Base):

    @timeit(logger_mode="self")
    async def run(self, **kwargs):
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        self.update_pre_log_msg(weibo)
        try:
            hot_query_list = []
            # 1. 优先从全年取12条
            related_month_q_dict = await get_hot_query_list_full_year(query, self.pre_log_msg, self.logger)
            if related_month_q_dict:
                self.logger.info(self.pre_log_msg + f"got related_month_q_dict len: {len(related_month_q_dict)}")
                sampled_queries = self.sample_queries_with_months(related_month_q_dict)
                hot_query_list = [item["query"] for item in sampled_queries]
                hot_query_list = hot_query_list[:12]
            else:
                hot_query_list = await get_hot_query_list_90d(query, self.pre_log_msg, self.logger)
                hot_query_list = hot_query_list[:10]
            
            weibo['hot_query_list'] = hot_query_list
            self.logger.info(self.pre_log_msg + f"add hot_query_list: {hot_query_list}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"error in hot_query_list handle: {traceback.format_exc()}")

    
    def sample_queries_with_months(
        self,
        data_dict: dict[str, list[str]],
        n_months: int = 3,
        forbid_consecutive: int = 1,
        max_total: int = 12
    ) -> list[dict[str, str]]:
        """抽样不连续月份的查询，若可用月份不足则提示"""
        if not data_dict or n_months <= 0:
            return []
        
        # 处理月份为整数并排序
        valid_months = sorted([int(month) for month in data_dict.keys()])
        total_available_months = len(valid_months)

        # 处理可用月份不足的情况
        if total_available_months < n_months:
            self.logger.info(self.pre_log_msg + f"提示：可用月份仅{total_available_months}个，少于请求的{n_months}个")
            sampled_month_nums = valid_months  # 直接使用所有可用月份
        else:
            # 抽样不连续的月份
            sampled_month_nums = []
            available = valid_months.copy()

            for _ in range(n_months):
                if not available:
                    break
                # 随机选择一个月份
                selected = random.choice(available)
                sampled_month_nums.append(selected)
                
                # 移除禁止范围内的月份
                forbidden_min = selected - forbid_consecutive
                forbidden_max = selected + forbid_consecutive
                available = [m for m in available if not (forbidden_min <= m <= forbidden_max)]
            
            # 处理抽样不足的情况
            if len(sampled_month_nums) < n_months:
                self.logger.info(self.pre_log_msg + f"警告：无法找到{n_months}个不连续的月份，实际返回{len(sampled_month_nums)}个")

        # 转换为两位月份字符串
        sampled_months = [f"{m:02d}" for m in sampled_month_nums]
        # 计算每个月的最大抽样数
        max_per_month = max(1, max_total // len(sampled_months))
        result = []

        # 抽取查询
        for month in sampled_months:
            queries = data_dict.get(month, [])
            if not queries:
                continue
            # 确定当前月抽样数量
            sample_num = min(max_per_month, len(queries))
            # 抽样并添加到结果
            sampled = random.sample(queries, sample_num)
            for q in sampled:
                result.append({"month": month, "query": q})
                # 达到总数量则提前终止
                if len(result) >= max_total:
                    return result

        return result

class QueryLastCalcTime(Base):

    async def run(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        trace_id = weibo.get('trace_id', "")
        version = weibo.get('version', "")
        query = weibo.get('query', "")
        hot_social_category = weibo.get("hot_social_category", 0)
        abtests = weibo.get("abtests", "")
        prompt_scene = weibo.get("prompt_scene", "")
        is_intervene = weibo.get("is_intervene", False)
        if prompt_scene in ['deepseek', 'deepseek_stream'] and not is_intervene and 'lab_xx' in abtests:
            calc_time = 0
            try:
                calc_time = await read_ab_query(query)
                if calc_time:
                    weibo['is_lab_filter'] = True
            except Exception as e:
                self.logger.error(self.pre_log_msg + "error: {}, cost:{}".format(e, time.time() - start))

            self.logger.info(self.pre_log_msg + "is_jingxuan_query: {} cost: {}".format(calc_time, time.time() - start))


class SinaNightCoveMaterial(Base):
    async def run(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)
        query = weibo.get('query', "")
        try:
            sina_night_knowledge = ""
            for k, v in await sina_night_cove.items():
                if k in query:
                    sina_night_knowledge += v.strip()
            if sina_night_knowledge:
                weibo['sina_night_knowledge'] = sina_night_knowledge
                self.logger.info(self.pre_log_msg + "sina_night_knowledge knowledge: {}".format(sina_night_knowledge))

            sina_night_tokens = []
            for k, v in await sina_night_prompt.items():
                keys = v.get("keys", [])
                vals = v.get("vals", [])
                for key in keys:
                    if key in query:
                        sina_night_tokens += vals
                        break

            if sina_night_tokens:
                tokens_str = ",".join([f"\"{token}\"" for token in list(set(sina_night_tokens))])
                sina_night_prompt_knowledge = f'- 回答内容中删除以下词汇表中词语：[{tokens_str}]'
                weibo['sina_night_prompt_knowledge'] = sina_night_prompt_knowledge
                self.logger.info(self.pre_log_msg + "sina_night_prompt_knowledge knowledge: {}".format(sina_night_prompt_knowledge))

        except Exception as e:
            self.logger.error(self.pre_log_msg + f"SinaNightCoveMaterial failed: {traceback.format_exc()}")

        self.logger.info(self.pre_log_msg + "SinaNightCoveMaterial cost: {}".format( time.time() - start))


class CredentialCheck(Base):
    """智搜封闭求证场景判断"""

    hit_words = [
        "是真的吗",
        "是假的吗",
        "是真是假",
        "真的假的",
        "是对的吗",
        "是错的吗",
        "是对是错",
        "求证",
        "求真",
    ]

    def check_is_credential(self, query: str):
        pattern = "|".join(re.escape(word) for word in self.hit_words)
        return bool(re.search(pattern, query))

    async def run(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        self.update_pre_log_msg(weibo)

        abtests = weibo.get("abtests", "")
        prompt_scene = weibo.get("prompt_scene", "")
        is_intervene = weibo.get("is_intervene", False)
        if ('lab_k8' in abtests) and prompt_scene == 'deepseek' and not is_intervene:
            try:
                query = weibo.get("query", "")
                # is_credential = self.check_is_credential(query)
                is_credential = True
                weibo["is_credential"] = is_credential
                self.logger.info(f"{self.pre_log_msg}CredentialCheck is_credential: {is_credential}")
            except Exception as e:
                self.logger.error(f"{self.pre_log_msg}CredentialCheck failed: {traceback.format_exc()}")
        self.logger.info(f"{self.pre_log_msg}CredentialCheck cost: {time.time() - start}")
