# -*- coding:utf-8 -*-
import asyncio
import json
import random
import traceback
from collections import defaultdict

import aiohttp
import requests
import datetime
import time
import re
import emoji
import binascii
from api.model_api import ModelEmotion
from lib.redis_utils import async_redis_client
from plugins.material.utils import Utils
import numpy as np
import binascii
import concurrent.futures
from lib.timeit import timeit
from plugins.post_process.utils import split_think_and_content


BLOG_TOPIC_MAPPING = {
    306: "置顶",
    569: "当事人",
    570: "当事方",
    571: "官方通报",
    # 26: "热源"
}

emb_u = Utils()
async def get_article(session, query, use_trunk=1, threshold=0.5, traceid="", logger=None):
    res_dict = dict()
    try:
        headers = {'Content-Type': 'application/json'}
        datas = {
            'query': query
        }
        data = {}
        async with session.post("http://summary.search.weibo.com/v1/search_article_weibo", json=datas,
                                headers=headers) as r:
            if r.status == 200:
                res_json = await r.json()
                data = res_json.get('statuses', {})
        if data:
            for mid, mid_item in data:
                score = mid_item.get('score', 0)
                text = mid_item.get('TEXT', '')
                if use_trunk:
                    chunk_start = int(mid_item.get('chunk_start', -1))
                    if chunk_start < 0:
                        chunk_start = 0
                    chunk_length = int(mid_item.get('chunk_length', -1))
                    if chunk_length < 0:
                        chunk_length = len(text)
                    text = text[chunk_start:chunk_start + chunk_length + 1]
                if not text:
                    continue
                if score >= threshold:
                    res_dict[mid] = {'text': text, 'score': score, 'article_id': mid_item.get('article_id', '')}
                    break
            return res_dict
    except Exception as e:
        if logger:
            logger.error(
                "query:{}\ttraceid:{}\terror:{}\t请求文章的函数发生了异常".format(query, traceid, e))
    return res_dict


async def get_summary_material(trace_id, query, query_category, llm_name, stream_output, post_url, d3_limit, logger, source=''):
    res_list = list()
    page = 1
    MAX_RETRY = 1
    retry = 0
    raw_time_grade = ""
    article_data = {}
    res_version = "2620240422000000" if query[0] == "#" else "1610240422000000"
    seqid = str(random.randrange(0, 999999, 1))
    while retry <= MAX_RETRY:
        post_data = {
            'query': query, "llm_name": llm_name, "stream_output": stream_output,
            'res_version': res_version, "query_category": query_category, 'page': page,
            "only_unify": 1, "test_mode": 1, "version": "2024060317220332020240604175203",
            "query_type": 1, 'page_size': 10, "limit_num": 1000,
            'low_score': 50, 'high_score': 65, "double_material": 2,
            "seqid": seqid, "source": source
        }
        post_data.update({"d3_limit": d3_limit})
        headers = {'Content-Type': 'application/json'}
        res = None
        try:
            data_list = []

            async with aiohttp.ClientSession() as session:
                async with session.get(url=post_url, params=post_data, headers=headers) as r:
                    if r.status == 200:
                        res = await r.json()
                        data_list = res.get('data').get('list', [])
                        raw_time_grade = res.get('data').get('get_time_grade', "")
                        is_less_old_res = int(res.get('data', {}).get('is_less_old_res', 0))
                        if is_less_old_res:
                            article_data = await get_article(session, query, use_trunk=0, threshold=0.5,
                                                             traceid=trace_id)
        except Exception as e:
            if logger:
                logger.error('query:{}, intf_res:{}, seqid:{}, error:{}'.format(query, res, seqid, e))
            data_list = []
        if not data_list:
            retry = retry + 1
            continue
        page += 1
        for i in data_list:
            text = i.get('text', "")
            mid = str(i.get("mid", ""))
            if mid in article_data:
                article = article_data.get(mid).get("text", "")
                if article:
                    text += ";" + article
                    i['text'] = text
            res_list.append(i)
        break
    return res_list, raw_time_grade


async def get_account_material(trace_id, query, query_category, uid, logger, source=''):
    MAX_RETRY = 3
    res_list = []
    retry = 1
    verified_reason = ""
    res = None
    while retry <= MAX_RETRY:
        try:
            params = {"page": 1, "page_size": 20, "mblog_screen_name": query, "query_category": query_category,
                      "mblog_uid": uid, "source": source}
            data_list = []
            async with aiohttp.ClientSession() as session:
                async with session.get(url="http://i.huati.search.weibo.com/llm/user_material.json",
                                       params=params) as r:
                    if r.status == 200:
                        res = await r.json()
                        data_list = res.get('data').get('list', [])
                        verified_reason = res.get('data').get("verified_reason", "")
        except Exception as e:
            if logger:
                logger.error('uid:{}, query:{}, traceid:{}, intf_res:{}, error:{}'.format(uid, query, trace_id, res, e))
            data_list = []
        if not data_list:
            retry = retry + 1
            continue
        for i in data_list:
            if i.get('text'):
                res_list.append(i)
        break
    return res_list, verified_reason


async def get_trend_summary_material(query, logger):
    res_list = list()
    url = "http://hotwbes.search.weibo.com:58881/landing_top"
    MAX_RETRY = 1
    retry = 0
    res = None
    while retry <= MAX_RETRY:
        params = {"keyword": query, "page": 1, "page_size": 20}
        data_list = []
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url=url, params=params) as r:
                    if r.status == 200:
                        res = await r.text()
                        data_list = eval(res)
        except Exception as e:
            if logger:
                logger.error('xiaojie_query:{}, intf_res:{}, error:{}'.format(query, res, e))
            data_list = []
        if not data_list:
            retry = retry + 1
            continue
        for i in data_list:
            if i.get('text'):
                res_list.append(i)
        break
    return res_list

def get_pic_url(pid, typ='large', https=False):
    """ 获取图片 URL
    Args:
      pid: A picture id provided by Imgbed.
      typ: picture typ.
      https: A Boolean flag, return https url or http url.
    Returns:
      A string of picture URL.
    """
    if pid[9] == 'y' and len(pid) >= 32:
        zone = (binascii.crc32(pid.encode('utf8')) & 0xffffffff & 0x03) + 1
        ext = 'jpg' if pid[21] == 'j' else 'gif'
        fmt = "https://wx{}.sinaimg.cn/{}/{}.{}" if https else \
            "http://wx{}.sinaimg.cn/{}/{}.{}"
        return fmt.format(zone, typ, pid, ext)

    elif pid[9] == 'w':
        zone = (binascii.crc32(pid.encode('utf8')) & 0xffffffff & 0x03) + 1
        ext = 'jpg' if pid[21] == 'j' else 'gif'
        fmt = "https://ww{}.sinaimg.cn/{}/{}.{}" if https else \
            "http://ww{}.sinaimg.cn/{}/{}.{}"
        return fmt.format(zone, typ, pid, ext)

def get_size_from_pid(pid):
    if len(pid) < 32 or pid[22] < "1":
        return 1, 1
    width = int(pid[23:26], 36)
    height = int(pid[26:29], 36)
    return height, width

def check_fake_imageurl(url):
    try:
        # 发送 HTTP HEAD 请求以获取响应头
        response = requests.head(url, allow_redirects=True, timeout=5)
        
        # 检查响应状态码是否为 200
        if response.status_code != 200:
            return False
        
        # 获取 Content-Type 并检查是否为图片类型
        content_type = response.headers.get('Content-Type', '')
        if content_type.startswith('image/'):
            return True
        else:
            return False
    except requests.RequestException:
        # 捕获请求异常，如超时、连接错误等
        return False

def extract_material(data_list):
    content_list = []
    pic_ids_list = []
    video_abs_list = []
    mid_list = []
    tag_list = []
    verified_type_list = []
    name_list = []
    from_list = []
    for i in data_list:
        name = i.get('name', "")
        text = i.get('text', "")
        pic_ids = i.get('pic_ids', "")
        video_abs = i.get('video_abs', "")
        mid = str(i.get("mid"))
        all_tag_new = i.get("all_tag_new", "")
        verified_type = i.get("verified_type", 999)
        if verified_type == "" or verified_type is None:
            verified_type = 999
        from_ = i.get("from", "")
        content_list.append(text)
        pic_ids_list.append(pic_ids)
        video_abs_list.append(video_abs)
        mid_list.append(mid)
        tag_list.append(all_tag_new)
        verified_type_list.append(verified_type)
        name_list.append(name)
        from_list.append(from_)
    return content_list, pic_ids_list, video_abs_list, mid_list, tag_list, verified_type_list, name_list, from_list


def parse_tags(all_tags):
    tag_score_dict = {"r1": {}, "r2": {}, "r3": {}, "m1": {}, "m2": {}, "m3": {}}
    try:
        if "r1" in all_tags:
            tag1 = list(set([i.split("@")[0] for i in all_tags.get("r1", "").split("|") if
                             len(i.split("@")) == 2 and float(i.split("@")[1]) >= 0.9]))
        else:
            tag1 = list(set([i.split("@")[0] for i in all_tags.get("m1", "").split("|") if
                             len(i.split("@")) == 2 and float(i.split("@")[1]) >= 0.9]))
        if "r3" in all_tags:
            tag3 = list(set([i.split("@")[0] for i in all_tags.get("r3", "").split("|") if
                             len(i.split("@")) == 2 and float(i.split("@")[1]) >= 0.9]))
        else:
            tag3 = list(set([i.split("@")[0] for i in all_tags.get("m3", "").split("|") if
                             len(i.split("@")) == 2 and float(i.split("@")[1]) >= 0.9]))
        for key, value in tag_score_dict.items():
            for tag_score_str in all_tags.get(key, "").split("|"):
                tag_score_list = tag_score_str.split("@")
                if len(tag_score_list) != 2:
                    continue
                value[tag_score_list[0]] = float(tag_score_list[1])
        return tag1, tag3, tag_score_dict
    except Exception as e:
        return [], [], tag_score_dict

def structure_material(content_list, mid_list, tag_list, verified_type_list, name_list):
    tag_parse_list = []
    for tag in tag_list:
        tag_score_dict = {"r1": {}, "r2": {}, "r3": {}, "m1": {}, "m2": {}, "m3": {}}
        if not tag:
            tag_parse_list.append(([], [], tag_score_dict))
            continue
        try:
            tag_dict = json.loads(tag)
        except:
            tag_dict = dict()
        tag1, tag3, tag_score_dict = parse_tags(tag_dict)
        tag_parse_list.append((tag1, tag3, tag_score_dict))
    return content_list, mid_list, tag_parse_list


async def get_zongshu_contents(session, traceid, query, logger=None):
    url = "http://admin.ai.s.weibo.com/api/llm/analysis_result.json"
    retry = 0
    while retry < 3:
        try:
            params = {"query": query, "sid": "wis_summary"}
            async with session.get(url=url, params=params, timeout=2) as r:
                if r.status == 200:
                    res = await r.json()
                    data = res["data"]
                    content = data["zongshu"]
                    content = content.replace("<br>", "\n")
                    return content
        except Exception as e:
            if logger:
                logger.error('query:{}, tracedid :{}, retry: {}, error:{}'.format(query, traceid, retry, e))
            retry += 1
    return ""


async def get_query_cate_list(session, traceid, query, logger):
    try:
        query = query.replace("#", "%23")
        url = "http://huati.search.weibo.com/topic/intention.json?query={}".format(query)
        cate_str = None
        for _ in range(5):
            try:
                async with session.get(url) as r:
                    if r.status == 200:
                        res = await r.json()
                        cate_str = res["res"]["field"]["field_vector"]
                        break
            except:
                continue

        def get_query_cate(s):
            if not s:
                return []
            categories = {
                "1": "娱乐明星", "2": "植物", "3": "电影", "4": "数码", "5": "汽车", "6": "情感", "7": "美食",
                "8": "旅游出行",
                "9": "音乐", "10": "读书作家", "11": "IT产业", "12": "财经", "13": "房地产", "14": "摄影拍照",
                "15": "设计",
                "16": "孕产", "17": "宗教", "18": "美女", "19": "育儿", "20": "体育", "21": "综艺", "22": "电视剧",
                "23": "交通服务", "24": "星座命理", "25": "家装家居", "26": "帅哥", "27": "职场", "28": "休闲娱乐",
                "29": "舞蹈", "30": "养生", "31": "婚庆", "32": "军事", "33": "国学", "34": "游戏", "35": "动漫",
                "36": "奢侈品", "37": "搞笑", "38": "时尚", "39": "小技巧", "40": "三农", "41": "民俗", "48": "美妆",
                "49": "教育", "50": "医疗", "51": "运动健身", "52": "人文艺术", "53": "动物", "54": "宠物",
                "55": "历史",
                "56": "科学科普", "57": "法律", "58": "收藏", "59": "政府政务", "60": "社会"
            }
            positions = [i + 1 for i, char in enumerate(s.split(',')) if
                         float(char) > 0]  # +1 because positions start from 1
            categories_for_ones = [categories[str(pos)] for pos in positions if str(pos) in categories]
            return categories_for_ones

        def get_key_from_value(input_value):
            cate_dict = {
                '社会': '社会,时政,政府政务',
                '文娱': '电视剧,电影,娱乐明星,音乐,综艺,舞蹈,时尚',
                '财经': '财经',
                '科技': 'IT产业,IT技术,数码,科学科普',
                '军事': '军事',
                '医疗': '医疗',
                '法律': '法律',
                '体育': '体育',
                '游戏': '游戏',
                '美妆': '美妆',
                '汽车': '汽车',
                '房地产': '房地产',
                '育儿': '孕产,育儿',
                '其他': '读书作家,美女,帅哥,历史,旅游出行,美食,摄影拍照,运动健身，婚庆,人文艺术,宗教,动物,宠物',
                '动漫': '动漫',
                '星座命理': '星座命理',

            }
            # Find the key corresponding to the input value
            for key, values in cate_dict.items():
                if input_value in values.split(','):
                    return key
            return "其他"

        categories_for_ones = get_query_cate(cate_str)
        cate_list, cate_set = list(), set()
        for cate_value in categories_for_ones:
            a = get_key_from_value(cate_value)
            if a in cate_set:
                continue
            cate_set.add(a)
            cate_list.append(a)
        if not cate_list:
            cate_list = ['其他']
    except Exception as e:
        if logger:
            logger.error("query:{}\ttraceid:{}\tget_query_cate_list failed: {}".format(query, traceid, e))
        return []
    return cate_list


async def get_knowledge_api(query, search_knowledge, logger=None, traceid="", threshold=60):
    # 接口异常返回flag=1
    try:
        headers = {'Content-Type': 'application/json'}
        datas = {
            'query': search_knowledge
        }
        data = {}
        async with aiohttp.ClientSession() as session:
            async with session.post("http://summary.search.weibo.com/v1/search", json=datas, headers=headers,
                                    timeout=5) as r:
                if r.status == 200:
                    res_json = await r.json()
                    data = res_json.get('statuses', {})
        if data:
            res = [[ii.get("TEXT", ""), ii.get("score", "")] for ii in data if
                   ii.get("TEXT", "").strip() and float(ii.get("score", 0)) >= threshold and ii.get("source", 0) == 2]
            text = [re.sub("\n\n+", "\n", i[0]) for i in res]
            score = [i[1] for i in res]
            return text, score, 0
        else:
            return [], [], 0
    except Exception as e:
        if logger:
            logger.error(
                "query:{}\tsearch_knowledge:{}\ttraceid:{}\terror:{}\t请求知识的函数发生了异常, 请检查知识接口以及代码".format(
                    query, search_knowledge, traceid, e))
        return [], [], 1


async def get_macro_knowledge_api(query, search_knowledge, logger=None, traceid="", threshold=60):
    # 接口异常返回flag=1
    try:
        headers = {'Content-Type': 'application/json'}
        datas = {
            'query': search_knowledge
        }
        data = {}
        async with aiohttp.ClientSession() as session:
            async with session.post("http://summary.search.weibo.com/v1/search_struct", json=datas, headers=headers,
                                    timeout=5) as r:
                if r.status == 200:
                    res_json = await r.json()
                    data = res_json.get('statuses', {})
        if data:
            res = [[ii.get("TEXT", ""), ii.get("score", "")] for ii in data if
                   ii.get("TEXT", "").strip() and float(ii.get("score", 0)) >= threshold and ii.get("source", 0) == 3]
            text = [re.sub("\n\n+", "\n", i[0]) for i in res]
            score = [i[1] for i in res]
            return text, score, 0
        else:
            return [], [], 0
    except Exception as e:
        if logger:
            logger.error(
                "query:{}\tsearch_knowledge:{}\ttraceid:{}\terror:{}\t请求知识的函数发生了异常, 请检查知识接口以及代码".format(
                    query, search_knowledge, traceid, e))
        return [], [], 1

def get_wis_emotion_res(star_name):
    star_name = star_name.strip("#").lower()
    for i in range(3):
        try:
            url = "http://admin.ai.s.weibo.com/api/llm/analysis_tab.json?query={}".format(star_name)
            emotion_res = ""
            url_res = requests.post(url)
            star_json = {}
            if url_res.status_code == 200:
                star_json = json.loads(url_res.text).get("data", {}).get("stars", {})
                #                 emotion_temp = json.loads(json.loads(url_res.text).get("data",{}).get("stars",{}).get("desc","[]"))
                emotion_temp = json.loads(star_json.get("desc", "[]"))
                emotion_label = []
                for num, i in enumerate(emotion_temp):
                    if (num < 3 and i["val"] > 0) or i["val"] >= 15:
                        emotion_label.append(i["name"])
                emotion_res = "，".join(emotion_label)
                # emotion_res = "，".join([i["name"] for i in emotion_temp[:3]])
            return emotion_res, star_json
        except:
            pass

    return "", {}

async def get_zhisou(query, redis_client):
    """通过Redis获取wis物料"""
    res = {"24h": {}, "30d": {}, "hot_tab": {}}
    try:
        if query == "":
            return res
        if query[0] == "#" and query[-1] == "#":
            query = query[1:-1]

        res["24h"]["redis_key"] = f"{query}_LLM_days_3"
        res["30d"]["redis_key"] = f"{query}_LLM_days_30"
        res["hot_tab"]["redis_key"] = f"{query}_LLM_timely"
        for _, res_value in res.items():
            try:
                redis_key = res_value["redis_key"]
                redis_res = await redis_client.hgetall(redis_key)
                all_result = {}
                for key, val in redis_res.items():
                    val = val.decode("utf-8")
                    key = key.decode("utf-8")
                    all_result[key] = val
                if not all_result:
                    res_value["past_events_struct"] = []
                    res_value["typical_viewpoint_struct"] = []
                    res_value["past_events_mids"] = []
                    res_value["typical_viewpoint_mids"] = []
                    res_value["typical_viewpoint"] = []
                    res_value["past_events"] = []
                    continue

                past_event = all_result.get("past_events", "").split("\n")
                typical_events = all_result.get("typical_viewpoint", "").split("\n")

                past_event_mid_list = all_result.get("past_events_mids", "").split(",")
                typical_viewpoint_mid_list = all_result.get("typical_viewpoint_mids", "").split(",")

                past_events_start_time = all_result.get("past_events_start_time", "0")
                past_events_end_time = all_result.get("past_events_end_time", "0")
                typical_events_start_time = all_result.get("typical_viewpoint_start_time", "0")
                typical_events_end_time = all_result.get("typical_viewpoint_end_time", "0")
                analysis_time = all_result.get("analysis_time", '0')

                past_event_start_time_str = datetime.datetime.fromtimestamp(int(past_events_start_time)).strftime(
                    '%Y-%m-%d %H:%M:%S')
                past_event_end_time_str = datetime.datetime.fromtimestamp(int(past_events_end_time)).strftime(
                    '%Y-%m-%d %H:%M:%S')
                typical_viewpoint_start_time_str = datetime.datetime.fromtimestamp(
                    int(typical_events_start_time)).strftime('%Y-%m-%d %H:%M:%S')
                typical_viewpoint_end_time_str = datetime.datetime.fromtimestamp(int(typical_events_end_time)).strftime(
                    '%Y-%m-%d %H:%M:%S')

                past_event_struct = []
                past_event_list = []
                for past_event_ele in past_event:
                    if past_event_ele.strip() == "":
                        continue
                    past_event_ele = re.sub("^\d+\.\s+", "", past_event_ele)
                    past_event_struct.append({"内容类型": "概况", "内容": past_event_ele,
                                              "内容分析周期": past_event_start_time_str + "~" + past_event_end_time_str})
                    past_event_list.append(past_event_ele)

                typical_viewpoint_struct = []
                typical_viewpoint_list = []
                for typical_viewpoint_ele in typical_events:
                    if typical_viewpoint_ele.strip() == "":
                        continue
                    typical_viewpoint_ele = re.sub("^\d+\.\s+", "", typical_viewpoint_ele)
                    typical_viewpoint_struct.append({"内容类型": "观点", "内容": typical_viewpoint_ele,
                                                     "内容分析周期": typical_viewpoint_start_time_str + "~" + typical_viewpoint_end_time_str})
                    typical_viewpoint_list.append(typical_viewpoint_ele)
                res_value["past_events_struct"] = past_event_struct
                res_value["typical_viewpoint_struct"] = typical_viewpoint_struct
                res_value["past_events_mids"] = past_event_mid_list
                res_value["typical_viewpoint_mids"] = typical_viewpoint_mid_list
                res_value["typical_viewpoint"] = typical_viewpoint_list
                res_value["past_events"] = past_event_list
                res_value['past_events_end_time'] = int(
                    past_events_end_time) if past_events_end_time and past_events_end_time.isdigit() else 0
                res_value['typical_viewpoint_end_time'] = int(
                    typical_events_end_time) if typical_events_end_time and typical_events_end_time.isdigit() else 0
                res_value["analysis_time"] = int(analysis_time)
            except Exception as e:
                continue
    except Exception as e:
        pass
    return res


def get_start_end_time(version):
    if version:
        start_time_str = version[:14]
        end_time_str = version[-14:]
        start_time = datetime.datetime.strptime(start_time_str, '%Y%m%d%H%M%S')
        end_time = datetime.datetime.strptime(end_time_str, '%Y%m%d%H%M%S')

        # 格式化输出
        formatted_start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
        formatted_end_time = end_time.strftime('%Y-%m-%d %H:%M:%S')
        timestamp = end_time.timestamp()
        return formatted_start_time,formatted_end_time,timestamp
    else:
        return "","",0


async def get_zhisou_new(query, redis_client, zhisou_emotion, category):
    get_data_flag = False
    res = {"24h": {}, "3d": {}, "30d": {}, "hot_tab": {}}
    try:
        if query == "":
            return res
        if query[0] == "#" and query[-1] == "#":
            query = query[1:-1]
        emotion_label_dict = {'生气': 'angry', '讨厌': 'annoying', '恐惧': 'fear', '开心': 'happy', '悲伤': 'sad',
                              '惊讶': 'surprised', '喜欢': 'like', '平和': 'usual', '感动': 'moved',
                              '失望': 'disappointed', '期待': 'expected', '疑惑': 'doubtful'}
        if zhisou_emotion:
            motion_label = [emotion_label_dict[emotion] for emotion in zhisou_emotion.split("，")]
        else:
            motion_label = []
        redis_key_24_h = "wis_middle_res_{}_h_24".format(query)
        redis_key_3_d = "wis_middle_res_{}_days_3".format(query)
        redis_key_30_d = "wis_middle_res_{}_days_30".format(query)
        redis_key_timely = "wis_middle_res_{}_timely".format(query)

        redis_key_list = [redis_key_24_h, redis_key_3_d, redis_key_30_d, redis_key_timely]
        for redis_key in redis_key_list:
            try:
                if "_h_24" in redis_key:
                    res_key = "24h"
                elif "_days_3" in redis_key:
                    res_key = "3d"
                elif "_days_30" in redis_key:
                    res_key = "30d"
                elif "_timely" in redis_key:
                    res_key = "hot_tab"
                res[res_key] = {}
                redis_res = await redis_client.hgetall(redis_key)
                past_events_res = json.loads(redis_res.get("past_events", "{}"))
                typical_viewpoint_res = json.loads(redis_res.get("typical_viewpoint", "{}"))
                past_event = list(past_events_res.get("model_full_res", {}).keys())
                past_event_mid_list = past_events_res.get("mids", [])
                typical_viewpoint = []
                for key, value in typical_viewpoint_res.get("model_middle_res", {}).items():
                    key = key.split("_")[0]
                    if key in motion_label and category == '101':
                        for tmp_content, _ in value.get("cites", {}).items():
                            typical_viewpoint.append(tmp_content)
                if not typical_viewpoint:
                    typical_viewpoint = list(typical_viewpoint_res.get("model_full_res", {}).keys())
                typical_viewpoint_mid_list = typical_viewpoint_res.get("mids", [])

                past_event_start_time_str, past_event_end_time_str, past_event_time = get_start_end_time(
                    past_events_res.get("m_version", ""))
                typical_viewpoint_start_time_str, typical_viewpoint_end_time_str, typical_viewpoint_time = get_start_end_time(
                    typical_viewpoint_res.get("m_version", ""))

                if past_event_time:
                    analysis_time = past_event_time
                elif typical_viewpoint_time:
                    analysis_time = typical_viewpoint_time
                else:
                    analysis_time = 0

                past_event_struct = []
                past_event_list = []
                for past_event_ele in past_event:
                    if past_event_ele.strip() == "":
                        continue
                    past_event_struct.append({"内容类型": "概况", "内容": past_event_ele,
                                              "内容分析周期": past_event_start_time_str + "~" + past_event_end_time_str})
                    past_event_list.append(past_event_ele)

                typical_viewpoint_struct = []
                typical_viewpoint_list = []
                for typical_viewpoint_ele in typical_viewpoint:
                    if typical_viewpoint_ele.strip() == "":
                        continue
                    typical_viewpoint_struct.append({"内容类型": "观点", "内容": typical_viewpoint_ele,
                                                     "内容分析周期": typical_viewpoint_start_time_str + "~" + typical_viewpoint_end_time_str})
                    typical_viewpoint_list.append(typical_viewpoint_ele)
                res[res_key]["past_events_struct"] = past_event_struct
                res[res_key]["typical_viewpoint_struct"] = typical_viewpoint_struct
                res[res_key]["past_events_mids"] = past_event_mid_list
                res[res_key]["typical_viewpoint_mids"] = typical_viewpoint_mid_list
                res[res_key]["typical_viewpoint"] = typical_viewpoint_list
                res[res_key]["past_events"] = past_event_list
                res[res_key]["analysis_time"] = int(analysis_time)
                if past_event_list or typical_viewpoint_list:
                    res[res_key]["get_data_flag"] = True
                else:
                    res[res_key]["get_data_flag"] = False
                pass
            except Exception as e:
                continue
    except Exception as e:
        pass
        # return {"24h":{}, "7d":{}, "30d":{},"hot_tab":{}}
    return res


async def get_query_type(query, redis_client):
    """通过Redis获取category等信息"""
    query = query.strip("#")
    if query == "":
        return "-1", "-1", "-1"

    redis_key = f"llm_hash_attr_{query}"
    redis_res = await redis_client.hgetall(redis_key)
    res = {}
    for key, val in redis_res.items():
        val = val.decode("utf-8")
        key = key.decode("utf-8")
        res[key] = val
    category = res.get("category", "-1")
    up_billboard = res.get("hot_today", "-1")
    hot_search = res.get("query_type", "-1")
    return category, up_billboard, hot_search

async def get_zhisou_emotion_res(pid, pre_log_msg, query):
    """获取情感中间态观点"""
    try:
        res_data = await ModelEmotion(pid, pre_log_msg).async_call(query)
        star_json = res_data.get("data", {}).get("stars", {})
        emotion_temp = json.loads(star_json.get("desc", "[]"))
        emotion_label = []
        for num, i in enumerate(emotion_temp):
            if (num < 3 and i["val"] > 0) or i["val"] >= 15:
                emotion_label.append(i["name"])
        emotion_res = "，".join(emotion_label)
        return emotion_res, star_json
    except:
        return "", {}


async def get_knowledge(query, content_list, tag3, logger, traceid=""):
    if not len(content_list):
        return ""

    top_one_content = content_list[0]
    search_knowledge = query + " " + top_one_content
    number = 2
    knowledge_text = ""
    knowledge_texts = []
    for i in range(number):
        tasks = []
        task1 = get_knowledge_api(query, search_knowledge, logger, traceid, 60)
        tasks.append(task1)
        if tag3 and tag3[0]:
            task2 = get_knowledge_api(query, tag3[0], logger, traceid, 60)
            tasks.append(task2)

        results = await asyncio.gather(*tasks)
        k_text, k_score, flag = results[0]
        k_text2, k_score2, flag2 = results[1] if len(results) > 1 else ([], 0, 0)

        # 均取Top1知识
        knowledge_texts += k_text[:1] + k_text2[:1]
        # 去重
        knowledge_text = "\n\n\n".join(set(knowledge_texts))
        # 接口没有异常
        if flag <= 0 or flag2 <= 0:
            logger.info(
                "get_knowledge:ok\tquery:{}\ttraceid:{}\tknowledge:{}\tmidtext:{}\tk1:{}\ttag3:{}\tk2:{}".format(
                    query, traceid, json.dumps(knowledge_text, ensure_ascii=False),
                    json.dumps(search_knowledge, ensure_ascii=False),
                    json.dumps(k_text[:1], ensure_ascii=False), tag3,
                    json.dumps(k_text2[:1], ensure_ascii=False)))
            return knowledge_text
    logger.info("get_knowledge:fail\tquery:{}\ttraceid:{}\tknowledge:{}\tmidtext:{}\ttag3:{}".format(
        query, traceid, json.dumps(knowledge_text, ensure_ascii=False),
        json.dumps(search_knowledge, ensure_ascii=False), tag3))
    return knowledge_text


async def get_baike_knowledge(query, logger=None, traceid=""):
    number = 2
    max_num = 3
    knowledge_text = ""
    knowledge_texts = []
    for i in range(number):
        # 使用query去检索知识
        k_text, k_score, flag = await get_knowledge_api(query, query, logger, traceid, 60)
        for ki in k_text:
            if ki not in knowledge_texts:
                knowledge_texts.append(ki)
        knowledge_text = "\n\n\n".join(knowledge_texts[:max_num])
        # 接口没有异常
        if flag <= 0:
            if logger:
                logger.info("get_knowledge:ok\tquery:{}\ttraceid:{}\tknowledge:{}\tk1:{}".format(
                        query, traceid, json.dumps(knowledge_text, ensure_ascii=False), json.dumps(k_text, ensure_ascii=False)))
            return knowledge_text
    if logger:
        logger.info("get_knowledge:fail\tquery:{}\ttraceid:{}\tknowledge:{}".format(
            query, traceid, json.dumps(knowledge_text, ensure_ascii=False)))
    return knowledge_text


async def get_micro_knowledge(query, logger=None, traceid=""):
    number = 2
    max_num = 3
    knowledge_text = ""
    knowledge_texts = []
    for i in range(number):
        # 使用query去检索知识
        k_text, k_score, flag = await get_macro_knowledge_api(query, query, logger, traceid, 60)
        for ki in k_text:
            if ki not in knowledge_texts:
                knowledge_texts.append(ki)
        knowledge_text = "\n".join(knowledge_texts[:max_num])
        # 接口没有异常
        if flag <= 0:
            if logger:
                logger.info("get_knowledge:ok\tquery:{}\ttraceid:{}\tknowledge:{}\tk1:{}".format(
                        query, traceid, json.dumps(knowledge_text, ensure_ascii=False), json.dumps(k_text, ensure_ascii=False)))
            return knowledge_text
    if logger:
        logger.info("get_knowledge:fail\tquery:{}\ttraceid:{}\tknowledge:{}".format(
            query, traceid, json.dumps(knowledge_text, ensure_ascii=False)))
    return knowledge_text


async def get_article_sina_api(search_knowledge, logger=None, traceid="", threshold=60):
    # 接口异常返回flag=1
    try:
        headers = {'Content-Type': 'application/json'}
        datas = {
            'query': search_knowledge
        }
        data = {}
        res = list()
        async with aiohttp.ClientSession() as session:
            async with session.get("http://summary.search.weibo.com/v1/search_knowledge", params=datas, headers=headers,
                                    timeout=1) as r:
                if r.status == 200:
                    res_json = await r.json()
                    data = res_json.get('statuses', {})
        if data:
            res = [ii for ii in data if ii.get("TEXT", "").strip() and float(ii.get("score", 0)) >= threshold and ii.get("source", 0) in [5, 6]]
        return res, 0
    except Exception as e:
        if logger:
            logger.error(
                "query:{}\ttraceid:{}\terror:{}\t请求知识的函数发生了异常, 请检查知识接口以及代码".format(
                    search_knowledge, traceid, e))
        return [], 1

async def get_article_sina(query, logger=None, traceid=""):
    number = 2
    knowledge_texts = []
    for i in range(number):
        # 使用query去检索
        k_text, flag = await get_article_sina_api(query, logger, traceid, 60)
        for ki in k_text:
            ki.pop('IDXTEXT', '')
            ki.pop('WEIBO_SEMANTIC_VEC', '')
            if ki not in knowledge_texts:
                knowledge_texts.append(ki)
        # 接口没有异常
        if flag <= 0:
            if logger:
                logger.info("get_article_sina:ok\tquery:{}\ttraceid:{}\tknowledge:{}\tk1:{}".format(
                        query, traceid, json.dumps(knowledge_texts, ensure_ascii=False), json.dumps(k_text, ensure_ascii=False)))
            return knowledge_texts
    if logger:
        logger.info("get_article_sina:fail\tquery:{}\ttraceid:{}\tknowledge:{}".format(
            query, traceid, json.dumps(knowledge_texts, ensure_ascii=False)))
    return knowledge_texts

async def read_search_knowledge(query, logger, trace_id=""):
    try:
        key = "wis_summary_search_tag_" + query
        last_three = await async_redis_client.get_redis_server(query).lrange(key, 0, 2)
        last_three = [val.decode('utf-8') for val in last_three] if last_three else []
        return last_three
    except Exception as e:
        if logger:
            logger.error("read search tag error: {}\t{}\t{}".format(trace_id, query, e))
    return []

async def read_parse_cron_hot_from_redis(key_date: str):
    async def _redis_hgetall_with_retry(key, retry_times=3):
        for i in range(retry_times):
            try:
                return await async_redis_client.get_redis_server(key).hgetall(key)
            except Exception as e:
                if i == retry_times - 1:
                    raise e
                await asyncio.sleep(0.1)
        return {}
    ret = []
    key = f"wis_daily_cron_gen_hot_{key_date}"
    result = await _redis_hgetall_with_retry(key)
    for _, v in result.items():
        try:
            ret.append(json.loads(v.decode('utf-8')))
        except:
            pass
    return ret

async def read_cur_hot_via_redis(pre_log_msg: str, logger) -> tuple[dict[str, list[dict]], list[str]]:
    try:
        now_date = datetime.datetime.now()
        last_6_days = []
        for i in range(1, 7):
            old_date = now_date - datetime.timedelta(days=i)
            last_6_days.append(old_date.strftime('%Y年%m月%d日'))

        key_list = [now_date.strftime("%Y年%m月%d日")] + last_6_days
        tasks = []
        all_redis_date = {}
        for key_date in key_list:
            tasks.append(read_parse_cron_hot_from_redis(key_date))

        redis_res = await asyncio.gather(*tasks)

        for idx, res_item in enumerate(redis_res):
            all_redis_date[key_list[idx]] = res_item
        
        return all_redis_date, last_6_days

    except Exception as e:
        if logger:
            logger.error(f"{pre_log_msg}\tread_cur_hot_via_redis error: {traceback.format_exc()}")
    return None, None

@timeit(logger_mode="param")
async def struct_cur_hot(cur_hot_list: list[dict], logger, pre_log_msg):
        def _rdecode_json(terminated_str: str) -> dict | None:
            """
            最大可能解码截断的json
            """
            try:
                return json.loads(terminated_str)
            except:
                try:
                    good_index = terminated_str.rfind(', {"query":')
                    t_str = terminated_str[:good_index] + "]"
                    return json.loads(t_str)
                except Exception as e:
                    print(f"Parse json failed, error: {e}")
                    return None

        if not cur_hot_list:
            return cur_hot_list
        res = []
        try:
            redis_data, last_6_days = await read_cur_hot_via_redis(pre_log_msg=pre_log_msg, logger=logger)
            if not redis_data:
                logger.warning(f"{pre_log_msg}\tread_cur_hot_via_redis error: redis_data is None")
                return res
            
            # 替换后6天
            # 格式化今天
            today_data_dict = cur_hot_list[0]
            try:
                
                today_zs_data = _rdecode_json(today_data_dict.get('5'))
                today_ts_str = today_data_dict.get('4', '')
                today_date = datetime.datetime.strptime(today_ts_str, "%Y-%m-%d %H:%M:%S").strftime("%Y年%m月%d日")
                if today_zs_data:
                    redis_data[today_date] = []
                    for item in sorted(today_zs_data, key=lambda x: x.get('raw_hot', 0), reverse=True):
                        redis_data[today_date].append({
                            "query": item.get('query', ''),
                            "raw_hot": item.get('raw_hot', 0),
                            "short_overview": item.get('zs_data', ''),
                            "query_date": today_date,
                        })
            except Exception as e:
                logger.info(f"{pre_log_msg}\tstruct_cur_hot api parse error: today_data_dict is invalid: {e}, use redis data instead")
                today_date = datetime.datetime.now().strftime("%Y年%m月%d日")
        

            for key in [today_date] + last_6_days:
                # 按照热度排序
                hot_items = redis_data.get(key, [])
                if not hot_items:
                    continue
                hot_items = sorted(hot_items, key=lambda x: x.get('raw_hot', 0), reverse=True)
                for hot_item in hot_items[:10]:
                    hot_item_date = hot_item.get('query_date', '')
                    content_header = f"{hot_item_date}的关注热度：{hot_item.get('raw_hot')}\n热点：{hot_item.get('query')}"
                    res.append({
                        "内容": f"{content_header}\n正文：{hot_item.get('short_overview')}",
                        "内容来源": "微博",
                        "内容类型": "历史热点",
                        "发布账号类型": "媒体账号",
                        "url": 'hot_res://',
                        "发布时间": hot_item_date,
                    })
            
            logger.info(f"{pre_log_msg}\tstruct_cur_hot success: {res}")
        except Exception as e:
            logger.error(f"{pre_log_msg}\tstruct_cur_hot error:{e}\n{traceback.format_exc()}")
        
        return res

def build_stock_content(stock_info_list: list, logger, pre_log_msg) -> list[dict]:
    """
    生成股票信息、公司资讯的物料

    return eg:
    [{
        "内容" : "",
        "内容来源" : "微博",
        "发布账号名": "新浪财经",
        "内容类型" : "历史热点",
        "发布账号类型" : "媒体账号",
        "url" : "link",
        "发布时间" : "2025年4月18日"
    }]
    """
    if not isinstance(stock_info_list, list):
        return []
    logger.info(pre_log_msg + "start build stock content.")

    MARKET_MAPPING = { "cn": "A股", "us": "美股", "hk": "港股" }
    CURRENCY_UNIT = { "cn": "元", "us": "美元", "hk": "港元"}
    

    def _build_stock_info(name: str, market: str, plate: str,
                        market_price: str, asset_rate: str, link: str,
                        change_rate: str, daily_data: list[dict],
                        company_info: dict, finance_report: tuple) -> dict[str, str]:
        """
        Build stock information string from components
        
        Args:
            name: Stock name
            plate: Stock plate/sector
            market_price: Market price
            asset_rate: Asset rate
            link: Stock url link
            change_rate: Change rate
            daily_data: List of 7 days data, each containing:
                - day: Date
                - open: Opening price
                - high: Highest price
                - low: Lowest price
                - close: Closing price
            company_info: Company information
            finance_report: Finance report
        """
        FR_KEYS_LAMBDA = {
            "年度净利润": lambda x: f"{(float(x) / 10000):.2f}万{CURRENCY_UNIT.get(market, '')}",
            "年度近利润增长": lambda x: f"{float(x):.2f}%",
            "流动比率": lambda x: f"{float(x):.2f}",
            "毛利率": lambda x: f"{float(x):.2f}%",
            "总资产周转率": lambda x: f"{float(x):.2f}",
            "归母净利润": lambda x: f"{(float(x) / 10000):.2f}万{CURRENCY_UNIT.get(market, '')}",
            "营业总收入": lambda x: f"{(float(x) / 10000):.2f}万{CURRENCY_UNIT.get(market, '')}",
            "净利润增长率": lambda x: f"{float(x):.2f}%",
            "营业总收入增长率": lambda x: f"{float(x):.2f}%",
            "经营现金流净额": lambda x: f"{(float(x) / 10000):.2f}万{CURRENCY_UNIT.get(market, '')}",
            "股东权益合计": lambda x: f"{(float(x) / 10000):.2f}万{CURRENCY_UNIT.get(market, '')}",
            "净资产收益率": lambda x: f"{float(x):.2f}%",
            "营业成本": lambda x: f"{(float(x) / 10000):.2f}万{CURRENCY_UNIT.get(market, '')}"
        }
        base_info = ""

        if company_info and isinstance(company_info, dict):
            base_info += (
                f"公司名称：{company_info.get('CorpName', '')}\n"
                f"公司类型：{company_info.get('orgType', '')}\n"
                f"公司简介：{company_info.get('introduction', '')}\n"
                f"主营业务：{company_info.get('mainBusiness', '')}\n"
            )
        
        base_info += f"股票名称：{name}\n"

        if company_info and isinstance(company_info, dict):
            base_info += f"发行价格：{company_info.get('price', '')}\n"

        base_info += (
                f"上市板块：{MARKET_MAPPING.get(market, '')}\n"
                f"{plate}\n"
                f"{market_price}{CURRENCY_UNIT.get(market, '')}\n"
                f"{asset_rate}\n"
                f"{change_rate}\n"
            )

        if daily_data:
            base_info += "近期股价走势：\n"
            for day_data in daily_data:
                base_info += (
                    f"{day_data.get('day', '')}，"
                    f"开盘价：{day_data.get('open', '')}{CURRENCY_UNIT.get(market, '')} ，"
                    f"最高价：{day_data.get('high', '')}{CURRENCY_UNIT.get(market, '')} ，"
                    f"最低价：{day_data.get('low', '')}{CURRENCY_UNIT.get(market, '')}，"
                    f"收盘价：{day_data.get('close', '')}{CURRENCY_UNIT.get(market, '')}\n"
                )
            

        if finance_report and isinstance(finance_report, tuple) and all(finance_report):
            fr_pub_date, fr_type, fr_list = finance_report
        
            fr_pub_data_str = datetime.datetime.strptime(fr_pub_date, "%Y%m%d").strftime("%Y年%m月%d日")
            base_info += (
                "基本财务信息：\n"
                f"财报发布时间：{fr_pub_data_str}\n"
                f"财报类型：{fr_type}\n"
            )
            fr_key_set = set()
            for item in fr_list:
                if (item_title := item.get("item_title", '')) in FR_KEYS_LAMBDA:
                    tongbi_value = float(item.get("item_tongbi", 0.0) or '0.0') * 100
                    if tongbi_value and item_title not in fr_key_set:
                        base_info += (
                            f"{item_title}：{FR_KEYS_LAMBDA[item_title](item.get('item_value', ''))}，"
                            f"同比增长：{tongbi_value:.2f}%\n"
                        )
                        fr_key_set.add(item_title)

        return {
            "内容": base_info,
            "内容来源" : "微博",
            "发布账号名": "新浪财经",
            "内容类型": "历史热点",
            "发布账号类型": "媒体账号",
            "url": link,
            "发布时间": datetime.datetime.now().strftime("%Y年%m月%d日")
        }

    def _build_news_info_list(news_list: list[dict]) -> list:
        """
        Build news information string from components
        
        Args:
            news_list: List of news items, each containing:
                - media: News media
                - title: News title
                - content: News content
                - ctime_str: News publish time: 2025-04-17 20:51:27
        """
        news_info = []
        for news in news_list:
            now_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            news_date = datetime.datetime.strptime(news.get("ctime_str", now_date), "%Y-%m-%d %H:%M:%S")
            news_info.append({
                "内容": f"{news.get('title', '')}\n{news.get('content', '')}",
                "内容来源": "微博",
                "发布账号名": news.get("media", ""),
                "内容类型": "历史热点",
                "发布账号类型": "媒体账号",
                "url": news.get("url", ""),
                "发布时间": news_date.strftime("%Y年%m月%d日"),
            })
        return news_info
    
    try:
        stock_res_list = []
        for stock_res in stock_info_list:
            stock_dict = stock_res.get('data', {})
            stock_market_price = stock_dict.get('market_price', '')
            if stock_market_price in ["市值：0", "市值："]:
                logger.info(pre_log_msg + "stock market price is 0, skip.")
                continue
            fr_pub_date, fr_type, fr_list = '', '', []
            finance_report = stock_dict.get('financeReport2', {})
            if isinstance(finance_report, dict) and finance_report:
                # sort by datekey
                fr_pub_list = finance_report.get("report_date", [])
                fr_pub_list.sort(key=lambda x: x.get("date_value", ""), reverse=True)
                if fr_pub_list:
                    fr_pub_date = fr_pub_list[0].get("date_value", "")
                    fr_type = fr_pub_list[0].get("date_description", "")
                    fr_list = finance_report.get("report_list", {}).get(fr_pub_date, []).get("data", [])
                
            stock_content = _build_stock_info(
                name=stock_dict.get('name', ''),
                market=stock_dict.get('market', ''),
                plate=stock_dict.get('plate', ''),
                market_price=stock_dict.get('market_price', ''),
                asset_rate=stock_dict.get('asset_rate', ''),
                link=stock_dict.get('link', ''),
                change_rate=stock_dict.get('change_rate', ''),
                daily_data=stock_dict.get('dailyk', []),
                company_info=stock_dict.get('companyInfo', {}),
                finance_report=(fr_pub_date, fr_type, fr_list)
            )
            stock_res_list.append(stock_content)

        news_content_list = []
        for stock_res in stock_info_list:
            stock_dict = stock_res.get('data', {})
            if (stock_news := stock_dict.get("stocknews", [])):
                news_content_list = _build_news_info_list(
                    stock_news
                )
                break

        logger.info(pre_log_msg + "finish build stock content.")
        return stock_res_list + news_content_list
    except:
        logger.error(pre_log_msg + "build stock content failed: {}".format(traceback.format_exc()))
        return []

gaokao_fetch_sema = asyncio.Semaphore(10)
@timeit(logger_mode='param')
async def get_gaokao_agent_material(query, pre_log_msg, logger) -> dict[str, str]:
    URL = "http://10.185.6.227:30012/api/gaokao/mcp"
    try:
        async with aiohttp.ClientSession() as session:
            async with gaokao_fetch_sema:
                
                    async with session.post(URL, json={"query": query}, timeout=2) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            if data.get("status", "") != "ok":
                                raise Exception("200 status error: {}".format(data.get("data", "")))
                            content = data.get("data", "")
                            if not content:
                                return {}
                            return {
                                    "内容": content,
                                    "内容来源": "微博",
                                    "内容类型": "历史热点",
                                    "发布账号类型": "普通账号",
                                    "url": "gaokaoweibo://http://10.185.6.227:30012/api/gaokao/mcp",
                                    "发布时间": datetime.datetime.now().strftime("%Y年%m月%d日")
                                }
                        else:
                            raise Exception("http status error: {}".format(resp.status))
    except asyncio.TimeoutError:
        logger.warning(pre_log_msg + " get gaokao agent material error: request timeout")
    except Exception:
        logger.error(pre_log_msg + " get gaokao agent material error: {}".format(traceback.format_exc()))
    return {}

@timeit(logger_mode='param')
async def read_starip_result(query, trace_id, logger):
    try:
        struct_result = []
        result = {}
        key = f"{query}_star_ip"
        res = await async_redis_client.get_redis_server(key).hgetall(key)
        for key, val in res.items():
            result[key.decode('utf-8')] = val.decode('utf-8')
        struct_result = struct_starip_result(result, trace_id, logger)
        return struct_result
    except Exception as e:
        if logger:
            logger.error("read star ip res error: {}\t{}\t{}".format(trace_id, query, e))
    return []

def struct_starip_result(data_dict, trace_id, logger):
    out_res = list()
    try:
        base_content_list = json.loads(data_dict.get('llm_res', ''))
        ref_meta = json.loads(data_dict.get('ref_meta', '{}'))
        reference_mids = ref_meta.get('mid_list', [])
    except:
        return out_res
    try:
        if len(reference_mids) > 0:
            top_mid = reference_mids[0]
        else:
            top_mid = ''
        if top_mid:
            url = f'staripweibo://{top_mid}'
        else:
            url = ''
        create_ts = float(data_dict.get('create_time', '0.0'))
        query_time = (datetime.datetime.fromtimestamp(create_ts)).strftime("%Y年%m月%d日")
        if base_content_list and url:
            for base_content in base_content_list:
                for key, val in base_content.items():
                    inp = {
                            "内容": f"# {key}\n{val}",
                            "内容来源": "微博",
                            "内容类型": "历史热点",
                            "发布账号类型": "普通账号",
                            "url": url,
                            "发布时间": query_time
                        }
                    out_res.append(inp)
    except Exception as e:
        if logger:
            logger.error('struct_starip_res_error:{}'.format(e))
    return out_res

def make_event_deep_research_his_summary(query: str, data_list: list[str], logger, pre_log_msg) -> str:
    try:
        event_intro_str = f"以下是与热点事件“{query}”相关的一组热点话题词，每个话题词都给出了概述："
        return {
            '内容': "\n".join([event_intro_str] + data_list),
            "内容来源": "微博",
            "内容类型": "历史热点",
            "发布账号类型": "普通账号",
            "url": 'event_hist://',
        }
    except Exception:
        logger.error(pre_log_msg + f"make_event_deep_research_his_summary error: {traceback.format_exc()}")
        return ""


async def read_and_struct_his_s_summary(query_ts_list: list[tuple[str, int]], logger, pre_log_msg, event_deep_research_flag=False) -> tuple[list[dict | str], list[tuple]]:
    res = []
    need_refresh_query = []
    key_prefix = 'history_ss_1210:'
    key_length = len(key_prefix)
    try:
        logger.info(pre_log_msg + f"read_and_struct_his_s_summary query_ts_list: {query_ts_list}")
        key_list = [f"{key_prefix}{query}" for query, _ in query_ts_list]
        query_ts_dict = {q: v for q, v in query_ts_list}

        results = await async_redis_client.batch_get(key_list, include_missing=True)
        idx = 1
        for key, value in results.items():
            query = key[key_length:]
            if not value:
                need_refresh_query.append((query, query_ts_dict[query]))
                continue
            if isinstance(value, bytes):
                value = value.decode()
            if event_deep_research_flag:
                res.append(f'话题词"{query}"的概述:{value.strip()}')
            else:
                res.append({
                    f'热点{idx}': query,
                    "摘要": value.strip()
                })
            idx += 1

        logger.info(pre_log_msg + f"finish handle: {len(res)}\t{len(need_refresh_query)} need refresh.")
        
    except Exception:
        logger.error(pre_log_msg + f"read_and_struct_his_s_summary: {traceback.format_exc()}")
    
    return res, need_refresh_query



async def read_weibo_click4hotstar(logger, pre_log_msg, query: str, hour_str_list: list[str], topn: int | None = None) -> dict[str, tuple[int, int, int]]:
    """
    starclk5916_龙飞_20250916_15
    return: {mid: (点击, 真实曝光, 排序（从0开始）)}
    参数:
        query: 查询关键词
        hour_str_list: 小时列表
        topn: 返回的Top N（按click排序），如果为None则返回全部
    """
    ret = {}
    try:
        key_list = [f"starclk5916_{query}_{hour_str}" for hour_str in hour_str_list]

        results = await async_redis_client.batch_get(key_list)

        # {mid: [pv_sum, click_sum]}
        agg = defaultdict(lambda: [0, 0])

        for key, val_str in results.items():
            if not val_str:
                continue
            val_list = json.loads(val_str)
            for item in val_list:
                mid = item[0]
                pv = item[1]
                click = item[2]
                agg[mid][0] += pv
                agg[mid][1] += click

        # 排序 (按 click 降序)
        sorted_items = sorted(agg.items(), key=lambda x: x[1][1], reverse=True)

        # 如果 topn 有值，截取前 topn
        if topn is not None:
            sorted_items = sorted_items[:topn]

        # 生成返回结果
        for idx, (mid, (pv_sum, click_sum)) in enumerate(sorted_items):
            ret[mid] = (pv_sum, click_sum, idx)
    except Exception as e:
        if logger:
            logger.error(pre_log_msg + f"read weibo click4star error: {e}")
    return ret

@timeit(logger_mode='param')
async def read_r1_res_via_http(query: str, version: str, pre_log_msg, logger) -> str | None:
    def remove_media_block(text: str):
        if not isinstance(text, str):
            return ''
        # 使用正则表达式匹配<media-block>标签及其内容（包括换行）
        pattern = r'<media-block>.*?</media-block>'
        # 使用re.DOTALL标志让.匹配换行符
        cleaned_text = re.sub(pattern, '', text, flags=re.DOTALL)
        # print(cleaned_text)
        pattern = r'```wbCustomBlock\{"(.*?)\}```'
        cleaned_text = re.sub(pattern, '', cleaned_text, flags=re.DOTALL)
        cleaned_text = re.sub(r"[\[\^]+\d+[\]\^]+", '',  cleaned_text, flags=re.DOTALL)
        return cleaned_text.strip()  # 移除首尾空白
    try:
        URL = f'http://admin.ai.s.weibo.com/api/llm/get_redrocks.json?query={query}&version={version}&model=deepseek&sid=annotations'
        async with aiohttp.ClientSession() as session:
            async with session.get(URL, timeout=2) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    llm_str = remove_media_block(data.get('data', {}).get('deepseek', {}).get('content', ''))
                    return split_think_and_content(llm_str)[1].strip()
                else:
                    raise Exception(f"HTTP request failed with status {resp.status}: {await resp.text()}")
    except Exception:
        if logger:
            logger.warning(pre_log_msg + f"read r1 res error: {traceback.format_exc()}")
    return None

def find_largest_ctr_version(data_dict: dict[str, str], pre_log_msg, logger) -> tuple[str, datetime.datetime | None]:
    def parse2date(version_str: str) -> datetime.datetime:
        # timestamp_str = "2025-08-07+23:15:55.019999-9814"
        # 替换 + 为空格，方便解析
        datetime_str = version_str.replace('+', ' ')  # "2025-08-04 17:30:32.013000-1732"
        # 分离日期时间和时区偏移
        datetime_part = datetime_str[:-5]  # "2025-08-04 17:30:32.013000"
        timezone_offset = datetime_str[-5:]  # "-1732"
        # 解析为 datetime 对象
        return datetime.datetime.strptime(datetime_part, "%Y-%m-%d %H:%M:%S.%f")

    def dt_is_more_than_2_hours(dt: datetime.datetime) -> bool:
        now = datetime.datetime.now()
        time_diff = now - dt
    
        # 判断是否超过 2 小时
        return time_diff > datetime.timedelta(hours=2)
    try:
        # 分成两个dict
        if not data_dict:
            return '', None
        click_dict: dict[str, int] = {}
        click_set = set()
        expo_dict: dict[str, int] = {}
        expo_set = set()
        for k, v in data_dict.items():
            if k.startswith('click_'):
                dt_str = k[6:]
                click_dict[dt_str] = int(v)
                click_set.add(dt_str)
            else: # expo_
                dt_str = k[5:]
                expo_dict[dt_str] = int(v)
                expo_set.add(dt_str)
        
        merged_set = expo_set & click_set
        largest_ctr = 0.0
        largest_version = ''
        log_ctr_dict = {}
        for version in list(merged_set):
            expo_v = int(expo_dict[version])
            click_v = int(click_dict[version])
            if expo_v < 1:
                continue
            ctr = click_v / expo_v
            # 日志记录
            log_ctr_dict[version] = {
                "ctr": ctr,
                "click_v": click_v,
                "expo_v": expo_v
            }
            if dt_is_more_than_2_hours(parse2date(version)):
                continue
            if ctr >= 0.028 and expo_v >= 1000 and ctr > largest_ctr:
                largest_ctr = ctr
                largest_version = version
        logger.info(pre_log_msg + f"ctr_dict: {log_ctr_dict}")
        logger.info(pre_log_msg + f"find largest ctr: {largest_ctr}, version: {largest_version}")
        if not largest_ctr or not largest_version:
            return '', None
        return largest_version.replace('+', ' '), parse2date(largest_version)
    except Exception:
        logger.error(pre_log_msg + f"find largest ctr error: {traceback.format_exc()}")
        return '', None



async def struct_ctr_result(query: str, data_dict: dict[str, str] | None, pre_log_msg, logger) -> list[dict]:
    try:
        version_str, version_dt = find_largest_ctr_version(data_dict, pre_log_msg, logger)
        if not version_str:
            logger.info(pre_log_msg + f"can not find lagest ctr & version.")
            return []
        llm_res = await read_r1_res_via_http(query, version_str, pre_log_msg, logger)
        if not llm_res:
            logger.info(pre_log_msg + f"r1 res if none.")
            return []

        return [{
                "内容": llm_res,
                "内容来源": "微博",
                "内容类型": "历史热点",
                "发布账号类型": "普通账号",
                "url": 'ctr://',
                "发布时间": version_dt.strftime("%Y年%m月%d日")
            }]
    except Exception as e:
        if logger:
            logger.error('struct_ctr_res_error:{}'.format(e))
    return []


@timeit(logger_mode='param')
async def read_ctr_res_via_redis(query: str, pre_log_msg, logger) -> dict | None:
    try:
        struct_result = []
        result = {}
        cleand_query = query.lower()
        if cleand_query.startswith('#') and cleand_query.endswith('#'):
            cleand_query = cleand_query[1:-1]
        key = f"content_card_q_{cleand_query}"
        res = await async_redis_client.get_redis_server(key).hgetall(key)
        for key, val in res.items():
            result[key.decode('utf-8')] = val.decode('utf-8')
        logger.info(pre_log_msg + f"read_ctr_res_via_redis: used key {key} , got redis res: {result}")
        return result
    except Exception as e:
        if logger:
            logger.error(pre_log_msg + f"read star ip res error: {traceback.format_exc()}")
    return None

@timeit(logger_mode='param')
async def read_broadsocial_res_res_via_redis(query: str, pre_log_msg, logger) -> dict | None:
    try:
        result = {}
        client = async_redis_client.get_redis_server(query)
        key = f"wis_summary_verification_{query}"
        val = await client.get(key)
        if val and isinstance(val, bytes):
            val = val.decode('utf-8')
            verfication_dict = json.loads(val)
            return {
                    "内容": '\n'.join(verfication_dict.get('verification_result', [])),
                    "内容来源": "微博",
                    "内容类型": "泛社会类干预事实",
                    "发布账号类型": "媒体账号",
                    "url": 'broadsocial_res://',
                    "发布时间": verfication_dict.get('pub_date', ''),
                }
        logger.info(pre_log_msg + f"read_broadsocial_res_res_via_redis: used key {key} , got redis res: {result}")
        return result
    except Exception as e:
        if logger:
            logger.error(pre_log_msg + f"read_broadsocial_res_res_via_redis error: {traceback.format_exc()}")
    return None

@timeit(logger_mode='param')
async def read_sina_news_via_http(query: str, pre_log_msg, logger) -> dict[str, str] | None:
    URL = "http://admin.ai.s.weibo.com/api/mcp_proxy/url.json"
    params = {
        "type": "http",
        "query": query,
        "prompt_scene": "sina_news",
        "sid": "sina_news_verification"
    }
    headers = {
        "Host": "admin.ai.s.weibo.com"
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(URL, headers=headers, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    # return data.get('data', {}).get('title', ''), data.get('data', {}).get('content', '')
                    return {
                        "title": data.get('data', {}).get('title', ''),
                        "content": data.get('data', {}).get('content', '')
                    }
                else:
                    raise Exception(f"HTTP request failed with status {response.status}: {await response.text()}")
    except Exception:
        if logger:
            logger.error(pre_log_msg + f"read sina news res error: {traceback.format_exc()}")
    return None


async def read_previous_result(query, llm_name, self_account, trace_id, logger):
    try:
        result = {}
        key = f"wis_summary_{query}_{llm_name}_{self_account}"
        res = await async_redis_client.get_redis_server(query).hgetall(key)
        for key, val in res.items():
            result[key.decode('utf-8')] = val.decode('utf-8')
        return result
    except Exception as e:
        if logger:
            logger.error("read search tag error: {}\t{}\t{}".format(trace_id, query, e))
    return {}


async def write_previous_result(query, llm_name, self_account, trace_id, data, logger):
    try:
        redis_key = f"wis_summary_{query}_{llm_name}_{self_account}"
        redis_server = async_redis_client.get_redis_server(query)
        tasks = []
        for key, val in data.items():
            tasks.append(redis_server.hset(redis_key, key, val))
        if tasks:
            await asyncio.gather(*tasks)
            await redis_server.expire(redis_key, 3 * 60 * 60 * 24)
    except Exception as e:
        if logger:
            logger.error("read search tag error: {}\t{}\t{}".format(trace_id, query, e))

async def fetch_stock_via_api(oid: str, retry=2):
    """Fetch stock information from API

    Args:
        oid: Stock code

    Returns:
        Stock information as a dictionary
    """
    url = f"http://i.api.stock.weibo.com/stock/zhisou.json?oid={oid}"

    for _ in range(retry):
        try:
            timeout = aiohttp.ClientTimeout(total=2)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as r:
                    if r.status == 200:
                        res = await r.json()
                        return res
        except Exception as e:
            pass
    
    return {}

async def fmt_stock_info(code, name):
    async def get_stock_info(code):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f'http://i.api.stock.weibo.com/stock/zhisou.json?oid={code}') as r:
                    if r.status == 200:
                        res = await r.json()
            return res
        except:
            pass
        return {}

    def gen_stock_info_blog(stock_info):
        realtime_keys = ['stock_price', 'fallingup_percent']
        static_keys = ['name', 'plate', 'market_price', 'asset_rate', 'change_rate']
        keys = static_keys + realtime_keys
        values = [('updatetime', f'截止时间：{datetime.datetime.now().strftime("%Y年%m月%d日")}')]
        for k in keys:
            if k not in stock_info['data']:
                continue
            v = stock_info['data'][k]
            if k == 'name':
                vs = v.split()
                if len(vs) == 1:
                    v = f'{name} {v}'
                v = f'股票：{v}'
            else:
                _idx = v.find('：')
                if _idx == -1 or _idx == len(v) - 1:
                    continue
            values.append([k, v])
        info = '\n'.join([t[1] for t in values if t[0] not in realtime_keys]).strip()
        return info

    stock_info = await get_stock_info(code)
    stock_info_blog = gen_stock_info_blog(stock_info)
    return stock_info_blog

def _replace_numbers_in_text(text: str) -> tuple[str, bool]:
    # pattern = r'(?i)(?=.*(账号|下载|神秘代码|神秘code|联系人|电话号|手机号))(?=.*\d{5,})'
    pattern = r'(?i)(?=.*(账号|下载|神秘代码|神秘code|联系人|电话号|手机号))(?=.*[A-Za-z0-9]{5,})'
    replaced = False
    if re.search(pattern, text):
        # phone number
        if "电话号" in text or "手机号" in text or "联系人" in text:
            text = re.sub(r'^1[3-9]\d{9}$', '', text)
        
        # v2
        text = re.sub(r'\d{5,}', '', text)
        replaced = True

    return text, replaced


def replace_emoji(input_text: str) -> str:
    """
    将unicode的emoji替换成描述，每个emoji字符单独输出[表情:描述]格式，并且每个表情之间有空格。
    """
    # 用来查询emoji描述的函数
    emoji_pattern = re.compile(
        u"["  
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
        u"\U00002702-\U000027B0"
        u"\u2600-\u2B55" u"\U00010000-\U0010ffff"
        "]{1}", flags=re.UNICODE
    )

    def get_emoji_description(emoji_char):
        """
        获取emoji字符的文本描述
        """
        description = emoji.demojize(emoji_char)  # 获取emoji描述
        if description.startswith(':') and description.endswith(':'):
            return description[1:-1]  # 移除前后冒号
        return ""

    def replace_emoji_in_text(match):
        """
        替换匹配到的emoji字符为[表情:描述]格式
        """
        emoji_char = match.group(0)
        description = get_emoji_description(emoji_char)
        if description != "":
            return f"[表情:{description}]"
        return emoji_char

    def replace_custom_emoji(match):
        """
        替换自定义表情文字为[表情:描述]格式
        """
        custom_emoji = match.group(1)
        return f"[表情:{custom_emoji}]"

    # 替换自定义表情[表情文字]为统一格式
    input_text = re.sub(r'\[(.*?)\]', replace_custom_emoji, input_text)
    # 替换每个emoji字符为独立的[表情:描述]格式，确保它们用空格分隔
    input_text = re.sub(emoji_pattern, replace_emoji_in_text, input_text)

    # 返回替换后的文本，确保表情之间有空格
    return input_text

def ht_hashtag_rewrite(content):
    #头部、尾部话题词，表述重写
    rewrite_pattern = r"#[^#]*?#"
    mat_rwt_match = re.compile(rewrite_pattern)
    content = content.strip()
    match_strs = mat_rwt_match.findall(content)
    if match_strs:
        if len(match_strs) == 1:
            match_str = match_strs[0]
            if content.startswith(match_str) or content.endswith(match_str):
                content = content.replace(match_str, "")
                content = "在{}的主题下发布 ".format(match_str) + content
        else:
            hit_match_strs = []
            # 开头的匹配话题词
            if content.startswith(match_strs[0]):
                content = content.replace(match_strs[0], "")
                hit_match_strs.append(match_strs[0])
            if content.endswith(match_strs[-1]):
                content = content.replace(match_strs[-1], "")
                hit_match_strs.append(match_strs[-1])
            if hit_match_strs:
                content = "在{}的主题下发布 ".format(" ".join(hit_match_strs)) + content
    return content

def ht_filter(content):
    rewrite_pattern = r"#[^#]*?#"
    mat_rwt_match = re.compile(rewrite_pattern)
    content = content.strip()
    match_strs = mat_rwt_match.findall(content)
    if match_strs:
        for ht in match_strs:
            if '生日快乐' in ht or '小喇叭' in ht :
                content = content.replace(ht,'')
    return content

def get_content_user_name(content):
    nickname_pattern = re.compile(
        r'@([\u4e00-\u9fff'       # 基本汉字区
        r'\u3400-\u4dbf'         # 扩展A
        r'A-Za-z0-9_\-'
        r'\u00b7\u2022'          # 中点 · 和 •
        r']+)'
    )
    match_strs = nickname_pattern.findall(content)
    return match_strs

def content_user_rewrite(content):
    rewrite_pattern = u"@[^ ]*"
    mat_rwt_match = re.compile(rewrite_pattern)
    content = content.strip()
    match_strs = mat_rwt_match.findall(content)
    if match_strs:
        for at in match_strs:
            user_name = at.replace('@','')
            user_ = '（提醒账号：{}）'.format(user_name)
            content = content.replace(at,user_)
    return content

def clean_text(content, remove_url=True, remove_sina=True, weibo_at=False,
               remove_emoji=True, weibo_topic=False, remove_space=False,
               remove_puncts=False, remove_mcode=True):
    '''
    去除话题词，链接，@用户，图标，emoji，标点符号，空白符

    :param content: 输入文本
    :param remove_url: （默认使用）是否去除网址链接
    :param remove_sina: （默认使用）是否去除sina链接
    :param weibo_at: （默认不使用）是否去除\@相关文本
    :param remove_emoji: （默认不使用）去除\[\]包围的文本，一般是表情符号
    :param weibo_topic: （默认不使用）去除##包围的文本，一般是话题
    :param remove_puncts: （默认不使用）移除所有标点符号
    :param remove_space: （默认不使用）移除空白符

    :return: 清洗后的文本
    '''

    ### @用户改写成（提醒账号：账号名）
    content = content_user_rewrite(content)
    ###话题包含‘生日快乐、小喇叭的过滤话题词’
    content = ht_filter(content)

    query = content.replace("\xe2\x80\x8b", "")
    #     if star_name:
    #         query = query.replace("#{}#".format(star_name), " {} ".format(star_name))

    query = re.sub(r'<[^>]+>', '', query)
    if weibo_topic:
        query = re.sub(u"#[^#]*?#", "", query)
    if weibo_at:
        query = re.sub(u"@[^ ]*", "", query)
    if remove_sina:
        query = re.sub(u"<sina.*?>", "", query)
    if remove_url:
        try:
            URL_REGEX = re.compile(
                u'(?i)http[s]?://(?:[a-zA-Z]|[0-9]|[#$%*-;=?&@~.&+]|[!*,])+',
                re.IGNORECASE)
            query = re.sub(URL_REGEX, "", query)
        except:
            # sometimes lead to "catastrophic backtracking"
            zh_puncts1 = u"，；、。！？（）《》【】"
            URL_REGEX = re.compile(
                u'(?i)((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>' + zh_puncts1 + u']+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’' + zh_puncts1 + u']))',
                re.IGNORECASE)
            query = re.sub(URL_REGEX, "", query)

    #在删除图标表情[xx]前，删除超话话题词
    query = re.sub(r"#[^#]*?\[超话\]#", "", query)

    if remove_emoji:
        # 去除图标 表情
        query = re.sub(u"\[\S+?\]", "", query)
        # 去除真,图标式emoji
        emoji_pattern = re.compile("["
                                   u"\U0001F600-\U0001F64F"  # emoticons
                                   u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                                   u"\U0001F680-\U0001F6FF"  # transport & map symbols
                                   u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                                   u"\U00002702-\U000027B0"
                                   u"\u2600-\u2B55" u"\U00010000-\U0010ffff"
                                   "]+", flags=re.UNICODE)
        query = emoji_pattern.sub('', query)
    if remove_mcode:
        query, _ = _replace_numbers_in_text(query)
    # query = query.replace("#", " ").replace("@", " ")
    query = query.replace("\n\n", "。").replace("【", "").replace("】", "").replace('\u200b', '').replace("\n", ";").replace('\t', '').replace(
        '&nbsp;', '')

    return query.strip()


def mid_clean(content, weibo_topic=True, weibo_at=True, remove_sina=True, remove_url=True):

    try:
        query = content.replace("\xe2\x80\x8b", "")
        if weibo_topic:
            query = re.sub(u"#[^#]*?#", "", query)
        if weibo_at:
            query = re.sub(u"@[^ :/#]*", "", query)
        if remove_sina:
            query = re.sub(u"<sina.*?>", "", query)
        if remove_url:
            try:
                URL_REGEX = re.compile(
                    u'(?i)http[s]?://(?:[a-zA-Z]|[0-9]|[#$%*-;=?&@~.&+]|[!*,])+',
                    re.IGNORECASE)
                query = re.sub(URL_REGEX, "", query)
            except:
                # sometimes lead to "catastrophic backtracking"
                zh_puncts1 = u"，；、。！？（）《》【】"
                URL_REGEX = re.compile(
                    u'(?i)((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>' + zh_puncts1 + u']+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’' + zh_puncts1 + u']))',
                    re.IGNORECASE)
                query = re.sub(URL_REGEX, "", query)
        return query.strip()
    except Exception as e:
        pass

    return content

def get_weibo_year(mid):
    un_time = (int(mid) >> 22) + 515483463
    times = datetime.datetime.fromtimestamp(un_time)
    return times.strftime('%Y年')


def get_weibo_time(mid):
    un_time = (int(float(mid)) >> 22) + 515483463
    times = datetime.datetime.fromtimestamp(un_time)
    return times.strftime("%Y-%m-%d %H:%M:%S")


def shorttv_material_filter(all_tag):

    tag_type = ['短剧','内地剧','言情剧','电视剧']
    is_filter = True

    tag1_parse = all_tag.get('r1',{})
    if not tag1_parse:
        tag1_parse = all_tag.get('m1', {})
    for t in tag1_parse.keys():
        if tag1_parse[t]>=0.5 and t in tag_type:
            is_filter = False

    tag2_parse = all_tag.get('r2', {})
    if not tag1_parse:
        tag2_parse = all_tag.get('m2', {})
    for t in tag2_parse.keys():
        if tag2_parse[t]>=0.5 and t in tag_type:
            is_filter = False
    if not tag1_parse and not tag2_parse:
        is_filter = False
    return is_filter


def media_material_filter(all_tag):

    tag_type = ['综艺','电视剧','电影']
    is_filter = True
    tag1_parse = all_tag.get('r1', {})
    if not tag1_parse:
        tag1_parse = all_tag.get('m1', {})
    for t in tag1_parse.keys():
        if tag1_parse[t]>=0.5 and t in tag_type:
            is_filter = False
    if not tag1_parse:
        is_filter = False
    return is_filter


def repl_time_year(text, year="2024年"):
    # text是输入博文文本；year是博文发博时间的年份；
    # 确保匹配的日期前面不是：年.空格及数字
    pattern = r"(?<![年\.\s\d])(?<!年的)(\d{1,2}月)(\d{1,2}[日号])"
    replacement = year + r"\1\2"
    result = re.sub(pattern, replacement, text)
    # 是否替换
    flag = 0
    if text != result:
        flag = 1
    return result, flag

# 0828下线 物料包含智搜关键词过滤策略
def material_filter(query, text):
    # ## 返回 True 标识这条物料被过滤掉，返回False 表示这条物料不被过滤
    if text == "":
        return True
    # if "智搜" in query:
    #     return False

    # black_key_word = ["智叟", "智搜", "智能总结"]
    # for word in black_key_word:
    #     if word in text:
    #         return True
    return False

def add_extra_topic_role4crucial_res(data_list: list[dict]) -> list[dict]:
    if not data_list or not isinstance(data_list, list):
        return data_list
    for data in data_list:
        if not isinstance(data, dict):
            continue
        try:
            data['is_crucial'] = True
            category = int(data.get("category", 0))
            role = BLOG_TOPIC_MAPPING.get(category, "")
            if role:
                data["topic_role"] = role
        except:
            pass
    return data_list


def compatible_mat(data_dict):
    if data_dict.get("long_text"):
        data_dict['text'] = data_dict.get("long_text")
    if not data_dict.get('from'):
        if int(data_dict.get('category', 0)) in [31, 1005]:
            data_dict['from'] = 'unify_socialtime'
        elif int(data_dict.get('category', 0)) == 636:
            data_dict['from'] = 'vs'
        else:
            data_dict['from'] = 'unify_base'
    if not data_dict.get('a_feature'):
        data_dict['a_feature'] = {}
        if data_dict.get('authoritative_features'):
            try:
                afea = json.loads(data_dict.get('authoritative_features'))
            except:
                afea = {}
            data_dict['a_feature'] = afea
    if data_dict.get('abs_info') and isinstance(data_dict.get('abs_info'), dict):
        data_dict.update(data_dict.get('abs_info'))
    if not data_dict.get('verified_type_ext'):
        if data_dict.get('user', {}).get('verified_type_ext'):
            data_dict['verified_type_ext'] = data_dict.get('user', {}).get('verified_type_ext')
        else:
            data_dict['verified_type_ext'] = -999
    return data_dict

def build_compatible_mat(data_dict: dict, idx: int):
    """
    包括对权益类、综合、语义、文章的统一处理
    20251219，排序对齐ps_idx
    """
    data_dict['ps_idx'] = idx
    if 'mid' in data_dict:
        data_dict = compatible_mat(data_dict) 
        category = int(data_dict.get("category", 0))
        if category in [306, 130, 343, 344, 569, 570, 571, 668, 572]:
            # crucial
            data_dict['is_crucial'] = True
            role = BLOG_TOPIC_MAPPING.get(category, "")
            if role:
                data_dict["topic_role"] = role
    return data_dict
    

async def get_hot_brief_material(query: str, pre_log_msg: str, logger) -> dict:
    res = {}
    timeout = aiohttp.ClientTimeout(3)
    async with aiohttp.ClientSession() as session:
        for i in range(3):
            async with session.get(f"http://hoteventbrief.search.weibo.com:19711/event/event_mid?event={query}", timeout=timeout) as resp:
                if resp.status == 200:
                    res_json = {}
                    try:
                        res_json = await resp.json()
                    except Exception:
                        res_str = await resp.read()
                        res_json = json.loads(res_str.decode('utf-8', 'ignore'))

                    if isinstance(res_json, dict) and res_json.get('data', {}):
                        return res_json.get('data', {})
                    break
                else:
                    logger.error(f"{pre_log_msg} get_hot_brief_material failed, status: {resp.status}, retry: {i}")
    return res

async def get_search_material(trace_id, query, post_url, stime=0, etime=0, logger=None, page=1, page_size=20, source="", llm_name="", search_type="", query_category="", abtest=False):
    res_list = list()
    MAX_RETRY = 1
    sema = asyncio.Semaphore(5) if "deepseek" in llm_name else asyncio.Semaphore(1)
    ext_mats = {}
    # raw_time_grade = ""
    # article_data = {}
    is_less_old_res = 0
    ocr_log = ''
    new_format = False
    weibo_article_data_list = []
    async def _get_page_data(page_num: int):
        retry = 0
        page_res = []
        nonlocal new_format
        async with sema:
            while retry <= MAX_RETRY:
                seqid = str(random.randrange(0, 999999, 1))
                post_data = {
                    'query': query,
                    "sequence_id": seqid,
                    "model": llm_name,
                    "limit": page_size,
                    "source": source,
                }
                if abtest and search_type != 'vs':
                    post_data.update({"version": 1.1})
                if query_category:
                    post_data.update({'query_category': query_category})
                if llm_name in ['deepseek_verification']:
                    post_data.update({'simple': 2})

                if stime and etime:
                    post_data.update({"starttime": int(stime), "endtime": int(etime), "search_type": search_type})
                # if 'material' in post_url and 'fragment' in post_data:
                #     post_data.pop('fragment')
                headers = {'Content-Type': 'application/json'}
                res = None
                ocr_log = []
                each_start_time = time.time()
                try:
                    data_list = []

                    async with aiohttp.ClientSession() as session:
                        async with session.post(url=post_url, json=post_data, headers=headers) as r:
                            if r.status == 200:
                                try:
                                    res = await r.json()
                                except:
                                    res = await r.read()
                                    res = json.loads(res.decode('utf-8', 'ignore'))
                                if search_type == "":
                                    data_list = res.get('data', {}).get('weibo', {}).get('list', [])
                                    # 综合
                                    new_format = bool(res.get('data', {}).get('weibo', {}).get('version', ''))
                                    if new_format:
                                        tmp_data_list = res.get('data', {}).get('weibo', {}).get('list', [])
                                        weibo_article_data_list.extend([build_compatible_mat(item, idx) for idx, item in enumerate(tmp_data_list)])
                                else:
                                    data_list = res.get('data', {}).get('list', [])
                                    data_list = [{
                                        'vs_idx': idx,
                                        **item,
                                    } for idx, item in enumerate(data_list) if isinstance(item, dict)]
                                # is_less_old_res = int(res.get('data', {}).get('weibo', {}).get('is_less_old_res', 0))
                                crucial_res = res.get('data', {}).get('weibo', {}).get('crucial_res', [])
                                if crucial_res and isinstance(crucial_res, list):
                                    crucial_res = [compatible_mat(i) for i in crucial_res]
                                    crucial_res = add_extra_topic_role4crucial_res(crucial_res)
                                    ext_mats['crucial_res'] = crucial_res
                                    logger.info(f'trace_id: {trace_id}\tcrucial_res_mids:{[i.get("mid", "") for i in crucial_res]}\tcrucial_res_category:{[i.get("category", 0) for i in crucial_res]}')
                                baike_res = res.get('data', {}).get('baike', [])
                                if baike_res:
                                    ext_mats['baike_res'] = baike_res
                                article_res = res.get('data', {}).get('article', [])
                                if article_res:
                                    ext_mats['article_res'] = article_res
                                history_hot_res = res.get('data', {}).get('hothis', [])
                                if history_hot_res:
                                    ext_mats['history_hot_res'] = history_hot_res
                                user_search_res = res.get('data', {}).get('user', {}).get('users', [])
                                if user_search_res:
                                    ext_mats['user_search_res'] = user_search_res
                                account_mats = res.get('data', {}).get('user', {}).get('users_materials', [])
                                if account_mats:
                                    ext_mats['account_mats'] = account_mats[0].get('list', [])
                                ocr_log = res.get('data', {}).get('ocr_log', [])
                                current_hot_res = res.get('data', {}).get("hot_data", [])
                                if current_hot_res and isinstance(current_hot_res, list):
                                    ext_mats['current_hot_res'] = current_hot_res
                                gaokao = res.get('data', {}).get("gaokao", [])
                                if gaokao and isinstance(gaokao, list):
                                    ext_mats['gaokao_mats'] = gaokao[:100]
                                zs_knowledge = res.get('data', {}).get("knowledge", [])
                                if zs_knowledge and isinstance(zs_knowledge, list):
                                    ext_mats['zs_knowledge'] = zs_knowledge
                                first_grid_doc_num = res.get('data', {}).get('weibo', {}).get("first_grid_doc_num", 0)
                                if first_grid_doc_num:
                                    logger.info(f'trace_id: {trace_id}\tfirst_grid_doc_num:{first_grid_doc_num}')
                                    if crucial_res and isinstance(crucial_res, list):
                                        first_grid_doc_num += len(crucial_res)
                                    ext_mats['first_grid_doc_num'] = int(first_grid_doc_num)
                                    logger.info(f'trace_id: {trace_id}\t+crucial_len+first_grid_doc_num:{first_grid_doc_num}')
                            else:
                                raise Exception('status code:{}'.format(r.status))
                except Exception as e:
                    if logger:
                        logger.error('query:{}, intf_res:{}, error:{}, post_data:{}, ocr_log:{}, is_new_format:{}'.format(query, res, e, post_data, ocr_log, new_format))
                    data_list = []
                    retry = retry + 1
                    continue
                each_end_time = time.time()
                if logger:
                    logger.info('query:{}\ttraceid:{}\teach_cost:{}\tpost_url:{}\tmids:{}\tpost_data:{}\tseqid:{}\tocr_log:{}\tcategory:{}'.format(query, trace_id, each_end_time-each_start_time, post_url, [i.get("mid", "") for i in data_list], post_data, seqid, ocr_log, [i.get("category", 0) for i in data_list]))
                for i in data_list:
                    new_i = compatible_mat(i)
                    text = new_i.get('text', "")
                    if text:
                        page_res.append(new_i)
                break
        return page_res
    
    post_tasks = []
    for fragment in range(page):
        post_tasks.append(_get_page_data(fragment))
    total_start_time = time.time()
    all_page_res = await asyncio.gather(*post_tasks)
    # flatten
    res_list = [item for sublist in all_page_res for item in sublist]
    total_end_time = time.time()
    if logger:
        logger.info('query:{}\ttraceid:{}\ttotal_cost:{}\tllm_name:{}'.format(query, trace_id, total_end_time-total_start_time, llm_name))
    return res_list, is_less_old_res, ext_mats, weibo_article_data_list


def get_tm_dict(ts, trunk, duration):
    return {i+1: ts - 86400*duration*(i+1) for i in range(trunk)}


async def get_query_time_grade(trace_id, query, source, logger=None):
    MAX_RETRY = 3
    retry = 1
    raw_time_grade = ""
    total_start_time = time.time()
    post_data = {
        'query': query,
        'source': source,
        "seqid": str(random.randrange(0, 999999, 1))
    }

    query_field = -1
    headers = {'Content-Type': 'application/json'}
    res = None
    while retry <= MAX_RETRY:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url='http://i.huati.search.weibo.com/llm/query_timegrade.json', params=post_data, headers=headers) as r:
                    if r.status == 200:
                        res = await r.json()
                        raw_time_grade = res.get('data').get('get_time_grade', "")
                        query_field = res.get('data').get('query_field', -1)
                    else:
                        if logger:
                            logger.error('[time grade error], query:{}, traceid:{}, intf_res:{}'.format(query, trace_id, r))
        except Exception as e:
            if logger:
                logger.error('[time grade error], query:{}, traceid:{}, intf_res:{}, error:{}'.format(query, trace_id, res, e))
        if not raw_time_grade:
            retry = retry + 1
            continue
        break
    total_end_time = time.time()
    if logger:
        logger.info('[time grade]\tquery:{}\ttraceid:{}\ttotal_cost:{}\tretry:{}\traw_time_grade:{}'.format(query, trace_id, total_end_time-total_start_time, retry, raw_time_grade))
    return raw_time_grade if raw_time_grade else 'mid', query_field

def change_material_save_top1_topic(query, text):
    query = re.sub(r'^#+|#+$', '', query)
    huati_dict = dict()

    # 使用正则表达式提取 #***# 之间的内容
    hashtags,text_nohuati,res_begin,res_end = extract_topics(text)
    if not hashtags or len(set(hashtags)) == 1:
        return text

    huati_dict[query] = query
    for huati in hashtags:
        huati_dict[huati] = huati
    res_str_emb = emb_u.get_text_embedding_batch(huati_dict)
    if not res_str_emb:
        return text
    # 记录索引:话题
    huati_index_str = {}
    index = 0
    # 需要计算的话题向量
    emb_query = []
    for s in res_str_emb:
        if s == query:
            continue
        emb_query.append(res_str_emb[s])
        huati_index_str[index] = s
        index += 1

    # 提取第一个元素
    first_element = res_str_emb[query]
    # 计算欧几里得距离
    distances = np.linalg.norm(np.array(emb_query) - np.array(first_element), axis=1)
    # 找到最小值
    min_value = min(distances)
    # 获取最小值的索引
    distances = list(distances)
    min_index = distances.index(min_value)
    save_huati = huati_index_str[min_index]

    final_text = ''
    if save_huati in res_begin:
        final_text = '#'+save_huati+'#'+ text_nohuati
    if save_huati in res_end:
        final_text = text_nohuati + '#'+save_huati+'#'

    return final_text


def extract_topics(text):
    # 正则表达式匹配 #话题#
    topics = re.findall(r'#(.*?)#', text)

    res = []
    res_begin = []
    res_end = []
    # 只提取开头的连续话题词
    start_index = 0
    while start_index < len(topics) and text.startswith('#'+topics[start_index]+'#'):
        text = text[len('#'+topics[start_index]+'#'):]
        res.append(topics[start_index])
        res_begin.append(topics[start_index])
        start_index += 1

    # 只提取结尾的连续话题词
    end_index = len(topics)-1
    while end_index > 0 and text.endswith('#'+topics[end_index]+'#'):
        text = text[:-len('#'+topics[end_index]+'#')]
        end_index -= 1
        res.append(topics[end_index])
        res_end.append(topics[end_index])

    return res,text,res_begin,res_end

def get_ocr_info(mid, logger=None):
    url = 'http://hbaseapi.search.weibo.com/getdata/querydata2.php'
    args = {
        'condition':mid,
        'mode':'weibo',
        'format':'json',
        'hbase':1
    }
    try:
        res = requests.get(url, params=args, timeout=1)
        hbase_res = res.json()
        ocr_info = json.loads(hbase_res.get('PICS_FEATURE','{}')).get('res',[])
        return ocr_info
    except Exception as e:
        if logger:
            logger.error('mid:{}\tocr_info_error:{}'.format(mid, e))
        return []

def get_batch_hbase(mids=[]):
    batch_executor = concurrent.futures.ThreadPoolExecutor(max_workers=20)
    futures = [batch_executor.submit(get_ocr_info, mid) for mid in mids]
    pic_features = {}
    for mid, future in zip(mids, futures):
        try: 
            hbase_res = future.result()
            pic_features[mid] = hbase_res
        except Exception as e:
            continue
    return pic_features

def extract_history_struct_data(history_hot_res, logger=None) -> tuple[list[dict], list[tuple[str, int]]]:
    from datetime import datetime
    removed_dup_history_hot_res = []
    history_hot_old_query_dic = {}
    seen_query_ts_list = []
    seen_query_set = set()
    for p, item in enumerate(history_hot_res):
        history_hot = json.loads(item.get('5', '{}'))
        query = history_hot.get('query', '')
        remove_time_stamp = history_hot.get('remove_time', int(time.time()))
        if query not in seen_query_set:
            seen_query_set.add(query)
            seen_query_ts_list.append((query, remove_time_stamp))
        remove_time_stamp_k = datetime.fromtimestamp(remove_time_stamp).strftime("%Y-%m-%d")
        calculate_time = history_hot.get("calculate_time", datetime.fromtimestamp(int(time.time())).strftime("%Y-%m-%d %H:%M:%S"))
        temp_k = query + "_" + remove_time_stamp_k
        if temp_k not in history_hot_old_query_dic:
            history_hot_old_query_dic[temp_k] = {'last_remove_time':remove_time_stamp,'ori_m':item,"ori_p":p,'calculate_time':calculate_time}
        elif remove_time_stamp > history_hot_old_query_dic[temp_k]['last_remove_time']:
            history_hot_old_query_dic[temp_k] = {'last_remove_time':remove_time_stamp,'ori_m':item, "ori_p":p,'calculate_time':calculate_time}
        elif remove_time_stamp == history_hot_old_query_dic[temp_k]['last_remove_time'] and calculate_time > history_hot_old_query_dic[temp_k]['calculate_time']:
            history_hot_old_query_dic[temp_k] = {'last_remove_time':remove_time_stamp,'ori_m':item, "ori_p":p,'calculate_time':calculate_time}
            
    for k in history_hot_old_query_dic.keys():
        removed_dup_history_hot_res.append({"ori_m":history_hot_old_query_dic[k]['ori_m'],"ori_p":history_hot_old_query_dic[k]['ori_p']})
    sorted_removed_dup_history_hot_res = sorted(removed_dup_history_hot_res,key=lambda x:x['ori_p'])
    history_hot_res = [item['ori_m'] for item in sorted_removed_dup_history_hot_res]
        
    # logger.info("zsss@sorted_removed_dup_history_hot_res:{}".format(json.dumps(sorted_removed_dup_history_hot_res,ensure_ascii=False)))
    
    out_res = list()
    for k in history_hot_res:
        try:
            history_hot = json.loads(k.get('5', '{}'))
            reference_mids = history_hot.get('reference_mids', [])
            if len(reference_mids) > 0:
                top_mid = reference_mids[0]
            else:
                top_mid = ''
            if top_mid:
                url = f'historyweibo://{top_mid}'
            else:
                url = ''
            query = history_hot.get('query', '')
            remove_time_stamp = history_hot.get('remove_time', int(time.time()))
            dt_object = datetime.fromtimestamp(remove_time_stamp)
            query_time = dt_object.strftime("%Y年%m月%d日")          
            core_content = history_hot.get('core_content', '')
            if query and query_time and core_content:
                base_content = f'在{query_time}的热点话题“{query}”下，有以下内容：\n{core_content}'
            else:
                base_content = ''
            sort_key = query_time
            if base_content and url and sort_key:
                
                inp = {"内容": base_content.strip(), "内容来源": "微博", "内容类型": "历史热点",
                            "发布账号类型": "普通账号", "url": url, "sort_key": sort_key, "发布时间": query_time}
                out_res.append(inp)
        except Exception as e:
            if logger:
                logger.error('history_hot_res_error:{}'.format(e))
    # out_res = sorted(out_res, key=lambda x: x.get('sort_key', ''), reverse=True)
    return out_res, seen_query_ts_list

async def call_query_extend(trace_id, query, llm_name, logger=None):
    MAX_RETRY = 2
    retry = 1
    total_start_time = time.time()
    post_data = {
        'query': query,
        'model': llm_name,
        'limit': 20
    }

    if llm_name in ['deepseek_verification']:
        post_data.update({'simple': 2})

    headers = {'Content-Type': 'application/json'}
    res = {}
    while retry <= MAX_RETRY:
        tmp_start_time = time.time()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url='http://i.search.weibo.com/search/wis_get_material.json', json=post_data, headers=headers) as r:
                    if r.status == 200:
                        try:
                            data = await r.json()
                        except:
                            data = await r.read()
                            data = json.loads(data.decode('utf-8', 'ignore'))
                        if logger:
                            tmp_cost = time.time() - tmp_start_time
                            logger.info('[call_query_extend]\tquery:{}\ttraceid:{}\tplan_querys:{}\tplan_res:{}\tsingle_cost:{}'.format(query, trace_id, data.get("plan_querys", []), data.get("plan_res", []), tmp_cost))
                        plan_querys = data.get("plan_querys", [])
                        if isinstance(plan_querys, list) and len(plan_querys) > 0:
                            for k in plan_querys[:3]:
                                if k not in data or str(k) == query:
                                    continue
                                res[k] = data[k]
                    else:
                        if logger:
                            logger.error('[call_query_extend error], query:{}, traceid:{}, intf_res:{}'.format(query, trace_id, r))
        except Exception as e:
            if logger:
                logger.error('[call_query_extend error], query:{}, traceid:{}, intf_res:{}, error:{}'.format(query, trace_id, res, e))
        if not res:
            retry = retry + 1
            continue
        break
    total_end_time = time.time()
    if logger:
        logger.info('[call_query_extend]\tquery:{}\ttraceid:{}\ttotal_cost:{}\tretry:{}'.format(query, trace_id, total_end_time-total_start_time, retry))
    return {"extends_querys": res}

async def get_refute_material(trace_id, query, logger):
    res_list = list()
    mids = set()
    MAX_RETRY = 1
    retry = 0
    post_url = 'http://admin.ai.s.weibo.com/api/llm/refute_material.json'
    headers = {'Content-Type': 'application/json'}
    while retry <= MAX_RETRY:
        res = None
        try:
            data_list = []
            timeout = aiohttp.ClientTimeout(total=2)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url=post_url, headers=headers) as r:
                    if r.status == 200:
                        res = await r.json()
                        data_list = res.get('data', [])
        except Exception as e:
            if logger:
                logger.error('query:{}, intf_res:{}, trace_id:{}, error:{}'.format(query, res, trace_id, e))
            data_list = []
        if not data_list:
            retry = retry + 1
            continue
        for data_item in data_list:
            for i in data_item.get('data', {}).get('list', []):
                is_retweeted = i.get('is_retweeted', False)
                if is_retweeted:
                    retweeted_status = i.get('retweeted_status', {})
                    mid = retweeted_status.get('mid')
                    if mid:
                        i['mid'] = mid
                    if retweeted_status.get('longText', {}).get('longTextContent'):
                        text = retweeted_status.get('longText', {}).get('longTextContent', '')
                    else:
                        text = retweeted_status.get('text', '')
                    if text:
                        i['text'] = text
                text = i.get('text', '')
                mid = i.get('mid')
                text = clean_text(text, remove_emoji=True)
                text = ht_hashtag_rewrite(text)
                i['text'] = text
                if not text or material_filter(query, text) or mid in mids:
                    continue
                res_list.append(i)
                mids.add(mid)
        break
    return res_list


async def get_query_version_list_via_http(query: str, start_day: str, end_day: str, pre_log_msg: str, logger)-> list[dict]:
    """获取query对应所有版本的智搜结果（仅需version）"""
    all_versions: list[dict] = []
    page = 1          # 从第一页开始
    page_size = 20    # 按你要求设置为 20
    url = "http://admin.ai.s.weibo.com//intfs/intervention/getInterventionList"

    timeout = aiohttp.ClientTimeout(total=2)

    async with aiohttp.ClientSession() as session:
        while True:
            params = {
                "query": query,
                "page": page,
                "page_size": page_size,
                "start_day": start_day,
                "end_day": end_day,
            }

            try:
                async with session.get(url, params=params, timeout=timeout) as resp:
                    resp.raise_for_status()
                    data = await resp.json()

                if data.get("status") != 1000:
                    logger.warning(pre_log_msg + f"get_query_version_list_via_http fail, status={data.get('status')}, msg={data.get('msg')}")
                    break

                info = data.get("data") or {}
                items = info.get("list") or []
                total_count = info.get("total_count", 0)

                if not items:
                    break

                for item in items:
                    if not isinstance(item, dict):
                        continue
                    version_str = item.get("version", "")
                    time_part = version_str[:19]  # 'YYYY-MM-DD HH:MM:SS'

                    try:
                        version_time = datetime.datetime.strptime(time_part, "%Y-%m-%d %H:%M:%S")
                    except Exception as e:
                        logger.warning(pre_log_msg + f"parse version fail, version={version_str}, err={e}")
                        continue

                    all_versions.append(
                        {
                            "id": item.get("id"),
                            "version": version_str,
                            "version_time": version_time,
                            "query": item.get("query"),
                            "insert_time": item.get("insert_time"),
                            "model": item.get("model"),
                        }
                    )

                # 根据 total_count + page_size 计算是否还有下一页
                # 当前已覆盖的最大条目索引 = page * page_size
                if page * page_size >= total_count:
                    break

                page += 1
                await asyncio.sleep(0.2)  # 略微限速，避免打爆接口

            except Exception as e:
                logger.error(
                    pre_log_msg + f"get_query_version_list_via_http unknown error, page={page}, err={e}",
                )
                break

    return all_versions

async def _get_via_http(url: str, retry: int = 3, pre_log_msg: str = "", logger=None) -> dict:
    res = {}
    timeout = aiohttp.ClientTimeout(3)
    async with aiohttp.ClientSession() as session:
        for i in range(retry):
            try:
                async with session.get(url, timeout=timeout) as resp:
                    if resp.status == 200:
                        res_json = {}
                        try:
                            res_json = await resp.json()
                        except Exception:
                            res_str = await resp.read()
                            res_json = json.loads(res_str.decode('utf-8', 'ignore'))
                        if isinstance(res_json, dict) and res_json:
                            return res_json
                        else:
                            logger.error(f"{pre_log_msg} _get_via_http parse failed, res_json: {res_json}, try: {i}")
                    else:
                        logger.error(f"{pre_log_msg} _get_via_http failed, status: {resp.status}, retry: {i}")
            except Exception:
                logger.error(f"{pre_log_msg} _get_via_http failed, error: {traceback.format_exc()}, retry: {i}")
    return res


async def get_hot_query_list_90d(query: str, pre_log_msg: str, logger) -> list[str]:
    res = []
    URL = f"http://starprofilepage.search.weibo.com:358/hot_collection_list_v3?word={query}&sort_type=me"
    json_res = await _get_via_http(URL, pre_log_msg=pre_log_msg, logger=logger)
    if isinstance(json_res, dict) and json_res.get('data', {}):
        hot_q_list = json_res.get('data', {}).get('hotQuery')
        if isinstance(hot_q_list, list) and hot_q_list:
            for hot_q in hot_q_list:
                if isinstance(hot_q, dict) and hot_q.get('query'):
                    res.append(hot_q.get('query'))
    return res

async def get_hot_query_list_full_year(query: str, pre_log_msg: str, logger) -> dict[str, list]:
    def parse_timestamp_to_month(timestamp: int) -> tuple[int, str]:
        """统一时间戳解析（处理毫秒/秒级时间戳）"""
        if timestamp > 1e12:
            timestamp = int(timestamp / 1000)
        time_struct = time.localtime(timestamp)
        return time_struct.tm_year, time.strftime("%m", time_struct)
    res = {}
    URL = f"http://zsbd.api.search.weibo.com:12321/word/{query}"
    json_res = await _get_via_http(URL, pre_log_msg=pre_log_msg, logger=logger)
    if isinstance(json_res, dict) and json_res.get('data', {}):
        try:
            related_queries_by_month: dict[str, list[str]] = defaultdict(list)
            entries = json_res.get("data", {}).get("results", [])
        
            for entry in entries:
                related_query = entry.get("related_query", "").strip()
                on_time = entry.get("on_time", 0)
                
                if not related_query or on_time <= 0:
                    continue
                
                year, month = parse_timestamp_to_month(on_time)
                if year == 2025 and related_query not in related_queries_by_month[month]:
                    related_queries_by_month[month].append(related_query)

            return related_queries_by_month
        except Exception:
            logger.error(pre_log_msg + f"get hot query_list full year error: {traceback.format_exc()}")
    else:
        logger.info(pre_log_msg + f"get hot query_list full year res is none")
        
    return res



if __name__ == "__main__":
    data = {'m1': '社会@0.9505940546989441', 'm2': '社会民生@0.9515940546989441', 'm3': '吴柳芳@0.8782390598677214'}
    tag1, tag3, tag_score_dict = parse_tags(data)
    print(tag1, tag3, tag_score_dict)
