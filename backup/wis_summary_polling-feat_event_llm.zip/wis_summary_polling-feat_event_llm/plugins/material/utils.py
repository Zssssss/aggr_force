import logging
import random
import time
from collections import defaultdict
from concurrent import futures
from functools import wraps
import requests


class Utils:
    TEXT_EMB_LEN_LIMIT = 1500
    CLUTSER_EXAMPLE_NUM = 20
    CLUSTER_NEAREST_POINT_NUM = 10
    GET_EMB_LOG_STEP = 1000
    @staticmethod
    def setup_logging():
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            handlers=[logging.StreamHandler()],
        )

    @staticmethod
    def log_execution_time(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.perf_counter()
            result = func(*args, **kwargs)
            end_time = time.perf_counter()
            execution_time = end_time - start_time
            logging.info(
                f"Execution time of {func.__name__}: {execution_time:.2f} seconds"
            )
            return result

        return wrapper

    @staticmethod
    def get_text_embedding(texts, retry=5):
        url = "http://mproxy.search.weibo.com/embedding/vectors"
        post_data = {
            "texts": texts,
            "sid": "smart_ algorithm_sstj",
            "model": "vector",
            "seqid": f"jingxuan_{int(time.time())}",
        }
        headers = dict()
        headers["content-Type"] = "application/json"
        for i in range(retry):
            try:
                with requests.post(
                    url, headers=headers, json=post_data, timeout=10.0
                ) as result:
                    ans = result.json()
                    status = ans["status"]
                    if status != 1000:
                        if i == retry - 1:
                            logging.error(f"fail to get vector , {result.text}")
                            return []
                        else:
                            continue
                    return ans["data"]
            except Exception as e:
                if i == retry - 1:
                    logging.error(f"fail to get vector , err is {e}, {result.text}")
                    return []
                else:
                    continue
        return []

    @staticmethod
    def get_text_embedding_batch(id_to_text: dict[str, str]) -> dict[str, list[float]]:
        batches = []
        cur_batch = []
        cur_max_len = 0
        for id, text in id_to_text.items():
            text = text[: Utils.TEXT_EMB_LEN_LIMIT]
            if (len(cur_batch) + 1) * max(
                cur_max_len, len(text)
            ) >= Utils.TEXT_EMB_LEN_LIMIT:
                batches.append(cur_batch)
                cur_batch = []
                cur_max_len = 0

            cur_batch.append((id, text))
            cur_max_len = max(cur_max_len, len(text))

        if cur_batch:
            batches.append(cur_batch)

        logging.info(f"# of text: {len(id_to_text)}, Split into {len(batches)} batches")

        id_to_embedding = {}
        with futures.ThreadPoolExecutor(max_workers=20) as executor:
            tasks = {
                executor.submit(Utils.get_text_embedding, [i[-1] for i in batch]): batch
                for batch in batches
            }
            finished = 0
            for future in futures.as_completed(tasks):
                batch = tasks[future]
                embeddings = future.result()
                for item, emb in zip(batch, embeddings):
                    id_to_embedding[item[0]] = emb
                finished += 1
                if finished % Utils.GET_EMB_LOG_STEP == 0:
                    logging.info(f"{finished}/{len(batches)} batches finished")
        return id_to_embedding

    @staticmethod
    def queue_message(mid, emb, action):
        data = {
            "ID": str(mid),
            "WEIBO_SEMANTIC_VEC": ",".join(map(str, emb)),
            "ACTION": action,
        }
        lines = ["@"]
        for key, value in data.items():
            lines.append(f"@{key}:{value}")
        return "\n".join(lines) + "\n"

    @staticmethod
    def gen_cluster_info(mid_to_cluster: dict) -> dict:
        cluster2mid = defaultdict(list)
        for mid, cluster in mid_to_cluster.items():
            cluster2mid[cluster].append(mid)
        cluster_info = {}
        for cluster_id, mid_list in cluster2mid.items():
            example_mid_list = random.sample(
                mid_list, min(Utils.CLUTSER_EXAMPLE_NUM, len(mid_list))
            )
            sample_url = f'http://scout.s.weibo.com/view/regular/blogdetail?list1={",".join(example_mid_list)}'
            cluster_info[cluster_id] = {
                "size": len(mid_list),
                "example_url": sample_url,
            }

        sorted_cluster_info = sorted(
            cluster_info.items(), key=lambda x: x[1]["size"], reverse=True
        )
        sorted_cluster_info = {k: v for k, v in sorted_cluster_info}
        return sorted_cluster_info

    @staticmethod
    def log_weibo_mid_feature(weibo_list: list[dict], logger, pre_log_msg):
        mid_s_feature_dict = defaultdict(list)
        for item in weibo_list:
            mid = item.get('mid', '')
            # 是否使用video_abs
            mid_s_feature_dict[mid].append(item.get('use_video_abs', False))
            # 是否使用video_vovice
            mid_s_feature_dict[mid].append(item.get('use_video_voice', False))
            # 是否使用pic_ocr
            mid_s_feature_dict[mid].append(item.get('use_pic_ocr', False))
            # 分档is_good
            mid_s_feature_dict[mid].append(item.get('is_good', 0))
            # from来源
            mid_s_feature_dict[mid].append(item.get('from', ''))
            # api来源， 0：综合， 1：vs 2：ext
            api_source = -1
            if 'ps_idx' in item:
                api_source = 0
            elif 'vs_idx' in item:
                api_source = 1
            elif 'ext_idx' in item:
                api_source = 2
            mid_s_feature_dict[mid].append(api_source)

        logger.info(pre_log_msg + f"log_view mid_s_feature with list:{mid_s_feature_dict}")
    
    @staticmethod
    def log_article_feature(content_list: list[dict], logger, pre_log_msg):
        mid_s_feature_dict = defaultdict(list)
        for item in content_list:
            url = item.get('url', '')
            # 是否使用video_abs
            mid_s_feature_dict[url].append(item.get('is_kuake', '0'))
            # 分档is_good
            mid_s_feature_dict[url].append(item.get('is_good', 0))

        logger.info(pre_log_msg + f"log_view article_s_feature with list:{mid_s_feature_dict}")
    
    @staticmethod
    def log_url_feature(content_list: list[dict], logger, pre_log_msg):
        url_list = [item.get('url', '') for item in content_list]
        logger.info(pre_log_msg + f"log_view url with list:{url_list}")
    
    @staticmethod
    def log_final_material_feature(material_list: list[dict], logger, pre_log_msg):
        type_list = ['placeholder']
        log_item_2d_list: list[list] = []
        LOG_TYPE_MAPPING = {
            '博文': Utils.log_weibo_mid_feature,
            '文章': Utils.log_article_feature,
        }
        for item in material_list:
            if isinstance(item, str):
                item = eval(item)
            if isinstance(item, dict):
                content_type = item.get('内容类型', '')
                if type_list[-1] == content_type:
                    log_item_2d_list[-1].append(item)
                else:
                    log_item_2d_list.append([item])
                    type_list.append(content_type)
        
        for t, item in zip(type_list[1:], log_item_2d_list):
            LOG_TYPE_MAPPING.get(t, Utils.log_url_feature)(item, logger, pre_log_msg)

    @staticmethod
    def truncate_mats4xiaomi_stream(data_groups: list, config_groups: list[dict], logger, pre_log_msg):
        """
        压缩策略说明（
        - 超过 1w 字符启动压缩
        """

        if len(data_groups) != len(config_groups):
            raise ValueError("数据组和配置组数量必须一致")
        if len(data_groups) != 13:
            raise ValueError("数据组数量必须为 13")

        MAX_LEN = 10000
        each_mat_base_length = 300

        filtered_groups = [list(group) for group in data_groups]

        # ---------- 工具函数 ----------

        def calc_total_len(groups):
            total = 0
            for i, grp in enumerate(groups):
                getter = config_groups[i].get(
                    "content_getter", lambda x: x.get("内容", "")
                )
                for item in grp:
                    total += len(str(getter(item))) + each_mat_base_length
            return total

        def pop_bottom(idx: int, min_keep: int = 0):
            """通用：自底向上删除，保留 min_keep 条"""
            nonlocal current_length
            getter = config_groups[idx].get(
                "content_getter", lambda x: x.get("内容", "")
            )

            while len(filtered_groups[idx]) > min_keep and current_length > MAX_LEN:
                item = filtered_groups[idx].pop()
                current_length -= len(str(getter(item))) + each_mat_base_length

        def shrink_pic_ocr_weibo(idx: int):
            """
            博文中的图片转文字（use_pic_ocr=True）
            自底向上删除，只保留 1 条
            不改变原始顺序
            """
            nonlocal current_length
            getter = config_groups[idx].get(
                "content_getter", lambda x: x.get("内容", "")
            )

            # 记录所有 OCR item 的原始位置
            ocr_positions = [
                i for i, item in enumerate(filtered_groups[idx])
                if item.get("use_pic_ocr", False)
            ]

            # 从后往前删，保留最后 1 条
            for pos in reversed(ocr_positions[:-1]):
                if current_length <= MAX_LEN:
                    break

                item = filtered_groups[idx].pop(pos)
                current_length -= len(str(getter(item))) + each_mat_base_length


        def shrink_voice_weibo(idx: int):
            """
            博文中的音转文内容（use_video_voice=True）
            自底向上删除
            不改变原始顺序
            """
            nonlocal current_length
            getter = config_groups[idx].get(
                "content_getter", lambda x: x.get("内容", "")
            )

            voice_positions = [
                i for i, item in enumerate(filtered_groups[idx])
                if item.get("use_video_voice", False)
            ]

            for pos in reversed(voice_positions):
                if current_length <= MAX_LEN:
                    break

                item = filtered_groups[idx].pop(pos)
                current_length -= len(str(getter(item))) + each_mat_base_length


        def shrink_kuake_articles(article_idxs: list[int], max_keep: int):
            """
            夸克文章压缩：
            - is_kuake == 1
            - 跨多个 article_list
            - 自底向上
            - 全局最多保留 max_keep 条
            - 严格保持各 group 内原始顺序
            """
            nonlocal current_length

            # [(global_order, idx, pos)]
            kuake_positions = []

            global_order = 0
            for idx in article_idxs:
                for pos, item in enumerate(filtered_groups[idx]):
                    if item.get("is_kuake") == 1:
                        kuake_positions.append((global_order, idx, pos))
                        global_order += 1

            if len(kuake_positions) <= max_keep:
                return

            # 从后往前删（全局顺序）
            for _, idx, pos in reversed(kuake_positions[:-max_keep]):
                if current_length <= MAX_LEN:
                    break

                getter = config_groups[idx].get(
                    "content_getter", lambda x: x.get("内容", "")
                )

                item = filtered_groups[idx].pop(pos)
                current_length -= len(str(getter(item))) + each_mat_base_length


        # ---------- 初始长度 ----------
        current_length = calc_total_len(filtered_groups)
        logger.info(pre_log_msg + f"xiaomi initial total_size={current_length}")

        if current_length <= MAX_LEN:
            return filtered_groups

        # ================= 压缩开始（顺序即优先级） =================

        # 1️⃣ 一般文章 / 一般博文
        pop_bottom(10)  # other_article_list
        pop_bottom(9)   # other_weibo_list

        # 2️⃣ 音转文博文
        shrink_voice_weibo(9)
        shrink_voice_weibo(4)

        # 3️⃣ 图片转文字博文
        shrink_pic_ocr_weibo(9)
        shrink_pic_ocr_weibo(4)

        # 4️⃣ 历史热点（保留 2）
        pop_bottom(8, min_keep=2)

        # 5️⃣ 夸克文章（top + other，全局只保留 6）
        shrink_kuake_articles(article_idxs=[5, 10], max_keep=6)

        # 6️⃣ 股票财经
        pop_bottom(1)

        # 7️⃣ 明星作品
        pop_bottom(2)

        # 8️⃣ 最近热点
        pop_bottom(12)

        # 9️⃣ 账号信息
        pop_bottom(11)

        # 🔟 一档 / 优质文章（全局只保留 1 条夸克已处理，这里是普通 article）
        pop_bottom(5, min_keep=1)

        # 1️⃣1️⃣ 一档 / 优质博文
        pop_bottom(4, min_keep=3)

        # 百科（6）、智搜知识库（0）永不删除

        logger.info(pre_log_msg + f"xiaomi after compress total_size={current_length}")
        return filtered_groups
    
    @staticmethod
    def truncate_mats4xiaomi_stream_new(
        data_groups: list,
        config_groups: list[dict],
        logger,
        pre_log_msg,
    ):
        """
        Xiaomi 新压缩策略（修正版）
        - 目标 <= 10000 字符
        - 严格顺序执行，满足即停
        """

        if len(data_groups) != len(config_groups):
            raise ValueError("data_groups 与 config_groups 数量不一致")
        if len(data_groups) != 10:
            raise ValueError("当前 data_groups 数量必须为 10")

        MAX_LEN = 10000
        each_mat_base_length = 300

        filtered_groups = [list(g) for g in data_groups]

        # ---------- 工具函数 ----------

        def getter(idx):
            return config_groups[idx].get("content_getter", lambda x: "")

        def calc_total_len():
            total = 0
            for i, grp in enumerate(filtered_groups):
                g = getter(i)
                for item in grp:
                    total += len(str(g(item))) + each_mat_base_length
            return total

        def pop_bottom(idx: int, min_keep: int = 0):
            nonlocal current_length
            g = getter(idx)

            while len(filtered_groups[idx]) > min_keep and current_length > MAX_LEN:
                item = filtered_groups[idx].pop()
                current_length -= len(str(g(item))) + each_mat_base_length

        # ---------- App 顺序裁剪（只针对 0 号） ----------

        def shrink_app_order_only_idx0():
            """
            仅对 weibo_article_unify_list（idx=0）做裁剪
            """
            nonlocal current_length

            grp = filtered_groups[0]
            g = getter(0)

            def count_types():
                web = article = weibo = 0
                for it in grp:
                    if it.get("is_kuake") == 1:
                        web += 1
                    elif it.get("内容类型") == "文章":
                        article += 1
                    elif it.get("内容类型") == "博文":
                        weibo += 1
                return web, article, weibo

            pos = len(grp) - 1
            while pos >= 0 and current_length > MAX_LEN:
                item = grp[pos]
                web_cnt, art_cnt, wb_cnt = count_types()

                can_delete = False
                if item.get("is_kuake") == 1 and web_cnt > 6:
                    can_delete = True
                elif item.get("内容类型") == "文章" and art_cnt > 1:
                    can_delete = True
                elif item.get("内容类型") == "博文" and wb_cnt > 3:
                    can_delete = True

                if can_delete:
                    grp.pop(pos)
                    current_length -= len(str(g(item))) + each_mat_base_length

                pos -= 1

        # ---------- 初始长度 ----------

        current_length = calc_total_len()
        logger.info(pre_log_msg + f"xiaomi initial total_size={current_length}")

        if current_length <= MAX_LEN:
            return filtered_groups

        # ================= 压缩开始 =================

        # 1. 历史热点（保留 2）
        pop_bottom(6, min_keep=2)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 2. 股票财经
        pop_bottom(3)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 3. 最近热点
        pop_bottom(7)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 4. 账号信息
        pop_bottom(4)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 5. 删除 weibo_article_ext_list（2）
        pop_bottom(2)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 6. 删除 weibo_vs_list（1）
        pop_bottom(1)
        if current_length <= MAX_LEN:
            return filtered_groups

        # 7. App 顺序裁剪（仅 idx=0）
        shrink_app_order_only_idx0()

        logger.info(pre_log_msg + f"xiaomi after compress total_size={current_length}")
        return filtered_groups