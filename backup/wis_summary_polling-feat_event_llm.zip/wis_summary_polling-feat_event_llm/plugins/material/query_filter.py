import json
import time
import traceback

from api.model_api import QWEN3_30B_Wrapper, count_tokens
from lib.base import Base
from plugins.prompt.query_filter import QueryFilterPrompt


class QueryFilter(Base):

    def log(self, weibo, llm_result, is_filter):
        query = weibo.get("query", "")
        version = weibo.get("version", "")
        q_attr = weibo.get("q_attr", "")
        self.logger.info(self.pre_log_msg + f"filter log: {version}\t{json.dumps(query,ensure_ascii=False)}\t{json.dumps(llm_result, ensure_ascii=False)}\t{is_filter}\t{q_attr}")

    async def run(self, **kwargs):
        start = time.time()
        stage = '诱导Query判断'
        weibo = kwargs.get("weibo", {})
        query = weibo.get("query", "")
        trace_id = weibo.get("trace_id", "")
        prompt_scene = weibo.get("prompt_scene", "")
        is_intervene = weibo.get("is_intervene", False)
        self.update_pre_log_msg(weibo)
        # if (prompt_scene == 'deepseek' or prompt_scene == 'deepseek_stream') and len(query) >= 30 and not is_intervene:
        #     llm_model = QWEN3_30B_Wrapper(weibo, pid=self.pid, pre_log_msg=self.pre_log_msg, llm_call_stage=stage)
        #     prompt = QueryFilterPrompt(weibo)
        #     for _ in range(2):
        #         try:
        #             prompt_content = prompt.prompt()
        #             response = await llm_model.async_call(prompt=prompt_content, timeout=1, temperature=0)
        #             count_tokens(weibo, response, 'qwen3-30b', start, stage)
        #             llm_result = response.get("text", "")
        #             is_filter = prompt.post_process(llm_result)
        #             self.log(weibo, llm_result, is_filter)
        #             self.logger.info(self.pre_log_msg + f"response: {json.dumps(llm_result, ensure_ascii=False)}, result: {is_filter}")
        #             weibo['query_filter_reason'] = json.dumps(llm_result, ensure_ascii=False)
        #             if is_filter:
        #                 weibo['is_query_filter'] = True
        #             break
        #         except Exception as e:
        #             self.logger.error(f"query filter retry call qwen30b llm: {e}")
        #
        #     self.logger.info("{}, cost: {}".format(trace_id, time.time() - start))
