# -*- coding:utf-8 -*-
import asyncio
import json
import os.path
import re
import traceback
import requests
from datetime import datetime, timedelta
import aiohttp
from openai import OpenAI, AsyncOpenAI
import time
import pandas as pd

from lib.normalize import topic_normalize
from lib.trie import Trie, KeywordMatcher
from lib.mysql_op import MySQLOperator
from lib.base import Base
from lib.timeit import timeit


class HotQueryLlm(Base):
    db = MySQLOperator('s4473i.eos.grid.sina.com.cn', 'wis_data_r', '46qLAu2iWaTGtolM', 'wis_data')

    def __init__(self, pid):
        super().__init__(pid)
        # 本地兼容 OpenAI API 的 LLM 服务
        self.hot_query_openai_api_key = "EMPTY"
        self.hot_query_openai_api_base = "http://10.85.96.185:8080/v1"

        self.hot_query_client = AsyncOpenAI(
            api_key=self.hot_query_openai_api_key,
            base_url=self.hot_query_openai_api_base,
        )

    def replace_reponse_columns(self, text_sql):
        pattern = r'SELECT\b.*\bFROM'
        re.match(pattern, text_sql, re.IGNORECASE | re.DOTALL)
        matches = re.findall(pattern, text_sql)
        for matche_str in matches:
            text_sql = text_sql.replace(matche_str, 'SELECT * FROM')
        return text_sql

    async def qwen7b(self, prompt, traceid, seqid):
        url = 'http://mproxy.search.weibo.com/llm/generate'
        request_body = {
            "id": seqid,
            "temperature": 0.1,
            "max_tokens": 8092,
            "repetition_penalty": 1.15,
            "messages": prompt,
            # "schema_idx": 0
        }

        data = {"payload": request_body, "sid": "smart_app_nknxw", "model": "qwen257b"}
        request_body = data

        for step in range(0, 2):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(2)) as session:
                    async with session.post(url=url, json=request_body) as r:
                        if r.status == 200:
                            response_data = await r.json()
                            text = response_data["data"]['text']
                            return text
            except Exception as e:
                pass
        return ''
    
    @timeit(logger_mode='self')
    async def qwen38b(self, prompt):
        url = "http://llm-yizhuang.multimedia.wml.weibo.com/mm-wb-search/qwen3-8b-weibo-search-681c2019/v2/models/llm/generate"
        headers = {"Content-Type": "application/json"}
        datas = {
                "temperature": 0.1,
                "stream": False,
                "max_tokens": 2000,
                "id": "123",
                # "rid": "31000",
                # "repetition_penalty": 1.2,
                # "model": "qwen15-72b-chat",
                "messages": ["system", datetime.now().strftime('当前时间 %Y-%m-%d.'), "user", prompt]}
    #     datas = {
    #         "temperature": "0.1",
    #         "max_tokens": 2048, 
    #         "repetition_penalty": "1.15", 
    #         "messages": 
    #             [ "user",  "\n\n".join([instruction, context, question])]
        
            
    #     }
    #     response = requests.post(url, json=datas, headers=headers)
    # #     print(response)
    #     res = response.json()
    # #     print(res)
    #     return res
        for step in range(0, 2):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(2)) as session:
                    async with session.post(url=url, json=datas) as r:
                        if r.status == 200:
                            response_data = await r.json()
                            # text = response_data["data"]['text']
                            return response_data
            except Exception as e:
                pass
        return {}
        


    @timeit(logger_mode='self')
    async def call_llm_tags(self, prompt, sys_prompt=None, seqid='11111111', model='7b') -> list[str]:
        prompt = [
            {'role': 'system', 'content': datetime.now().strftime('当前日期是 %Y-%m-%d.')},
            # {'role': 'system', 'content': sys_prompt},
            {'role': 'user', 'content': prompt}
        ]
        prompt_format = []
        for p in prompt:
            prompt_format.append(p['role'])
            prompt_format.append(p['content'])

        t = time.time()
        try:
            if model == '7b':
                llm_res = await self.qwen7b(prompt_format, 'test', seqid)
                self.logger.info(self.pre_log_msg + f"llm_res:{llm_res}")
                re_temp = re.compile(r'\{[\s\S]+\}')
                result_temp = json.loads(re_temp.search(llm_res).group())
                # date convert 20240101 -> 2024-01-01
                if result_temp.get('has_time', False) and'start_time' in result_temp and 'end_time' in result_temp:
                    end_date = datetime.strptime(result_temp['end_time'], '%Y%m%d').strftime('%Y-%m-%d')
                    start_date = datetime.strptime(result_temp['start_time'], '%Y%m%d').strftime('%Y-%m-%d')
                    return [start_date, end_date]
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"call_llm_tags Exception: {traceback.format_exc()} seqid:{seqid}")

        self.logger.info(self.pre_log_msg + f"\tcall_llm_tags\tseq_id:{seqid}\tcost:{time.time()-t}")
        now = datetime.now()
        return [(now - timedelta(days=7)).strftime('%Y-%m-%d'), now.strftime('%Y-%m-%d')]

    def get_prompt(self, query):
        current_time = time.localtime()
        year = current_time.tm_year 
        month = current_time.tm_mon  
        day = current_time.tm_mday   
        cur_time = f"{year}年{month}月{day}日"
        prompt = f'''<任务说明>
你的任务是根据用户输入的查询内容：“{query}”，分析其时间表达特征，以辅助后续数据库检索，输出标准 JSON 格式结果。请注意以下几点：
可以借鉴但不限于以下规则，判断是否包含有效的时间信息，并输出标准 JSON 格式结果：
1. 当前日期为：{cur_time}。
2. 若 query 中明确提到具体日期（如“2024年8月”、“2023-11-01”、“2024年第一季度”），请提取该时间段：
   - 若仅提及一个日期，则 start_time 和 end_time 设为该日期；
   - 若提及时间区间，则按区间确定起止时间。
3. 若 query 中出现模糊时间表达，请根据需要推算起始和终止时间，例如出现：“最近”、“前段时间”、“过去几天”、“近一周”、“近几天”、“最新”词语时
   可以设定：start_time = 当前日期向前推7天，end_time = 当前日期。
4. 若 query 中出现“今日”、“今天”、“当前”、“实时”、“目前”：
   - 设定：start_time = end_time = 当前日期。
5. 若无法识别任何时间相关信息：
   - 只输出 "has_time": false，不包含 start_time 和 end_time 字段。
【输出要求】：
- 严格返回**标准 JSON 格式**；
- 所有字段均为字符串（即加引号）；
- 日期格式必须为 8 位字符串：YYYYMMDD；
- 禁止输出任何额外注释或说明文字。
【输出示例】：
有具体时间段：
{{"has_time": true, "start_time": "20240401", "end_time": "20240408"}}
仅为今日（单日）：
{{"has_time": true, "start_time": "20250430", "end_time": "20250430"}}
无法识别时间：
{{"has_time": false}}
请开始处理/nothink
    '''
#         prompt = f"""
# <任务说明>你的任务是根据用户输入的查询内容:{query}，分析查询特征，帮助后续检索数据库，仅以标准JSON格式输出结果：
# 分析确定需要查询数据的时间范围：确定起始时间（start_time）和结束时间（end_time），时间格式为'20240102'，若只提到一个时间，start_time和end_time相同，若无法识别则不输出start_time和end_time字段，但无论是否识别，均需输出"has_time"字段（true/false）。

# 输出示例：{{"has_time": true, "start_time": "20240101", "end_time": "20240131"}}

# 你要处理的问题是<query>{query}</query>,请严格按照输出要求给出答案。
# """
        return prompt
    
    def get_keyword_prompt(self, query):
        prompt = f"""你是一个关键词提取助手，任务是从用户的自然语言查询 query 中，提取出**用于查询热榜数据库的核心关键词**，以便后续数据库筛选使用。
            该热榜数据库记录了跨时间段的热门话题词。用户 query 通常表示他们想了解的热搜话题、热点领域、人物或事件。你的任务是判断用户的 query 是否属于以下两类，并据此输出关键词：
---
### 类型 1：热榜时间类查询（无需关键词）
若用户 query 是纯粹表示热榜、热搜、榜单、排行榜等统计目的的查询，例如：
- 今日热搜第一
- 上周热搜前十
- 2024年8月4日热搜
- 最近热搜榜单
此类查询不需要关键词，请输出 `关键词: 无需关键词`。

---

### 类型 2：主题类查询（提取关键词）
若用户 query 中表达了对某个话题、领域、人物、事件的关注，例如：
- 最近教育领域的热点政策有哪些
- 再见爱人4的热度高吗
- 最近医疗健康领域发生了什么
关键词生成注意事项:
1.请注意关键词应该是这个用户query中的话题，领域，任务，事件等，生成关键词的目的是为了使用关键词作为额外的信息从数据库中进行辅助查询。
2.因此这里生成的关键词不需要包含，热搜，热点，问题等词，
3.请仅提取 query 中**原始出现的关键词**，不要改写或扩展，关键词之间用中文逗号 `，` 分隔。

---

### 输出格式（严格遵守）：
用户query: <原始query内容>  
关键词: <关键词1，关键词2，...> 或 “无需关键词” 或 “无关键词”

请处理以下用户query: {query}/nothink
"""
        return prompt


    @timeit(logger_mode='self')
    async def parse_res_from_mysql(self, sql_results):

        results = []
        start = time.time()
        try:

            #ADD COLUMN detailed_description TEXT,     #r1结果
            #ADD COLUMN brief VARCHAR(900);            #导语
            #ADD COLUMN overview VARCHAR(900),         #简版

            materials = []
            new_materials = {}
            #query_set = set()
            for res in sql_results:
                if not res.get('overview'):
                    continue
                if res.get('query', ''):
                    date = res.get("date")
                    if not date:
                        self.logger.error(self.pre_log_msg + f"sql date is empty: {res}")
                        continue
                    formatted_date = date.strftime("%Y年%m月%d日")
                    new_s = "### 热搜词：%s;\n **热度：** %s \n **内容：** %s \n **榜单来源：** %s \n **领域：**%s" % (res.get("query",''), res.get("hot", ''), res.get("overview",''), res.get("source",''), res.get("cate",''))
                    # s = "%s 榜单：%s 榜单词：%s 热度：%s 正文：%s;" % (formatted_date, res.get("source",''), res.get("query",''),res.get("hot", ''), res.get("overview",''))
                    new_material = new_materials.get(formatted_date, "")
                    if new_s not in new_material:
                        new_material += new_s
                        new_material += "\n\n"
                    new_materials[formatted_date] = new_material    
            for date, material in new_materials.items():
                    content = f"# {date}热搜\n{material.strip()}"
                    results.append({
                        "内容": content,
                        '内容来源': "微博",
                        "内容类型": "榜单热点",
                        "发布账号类型": "媒体账号",
                        "发布时间": date})

            self.logger.info(self.pre_log_msg + \
                f"get_res_from_mysql: summary:{results}")

        except Exception as e:
            self.logger.error(self.pre_log_msg + \
                f"get_res_from_mysql:error\terror:{repr(e)}\ttraceback:{traceback.format_exc()}")

        self.logger.info(self.pre_log_msg + f"get_res_from_mysql\tcost:{time.time() - start}")
        return results

    async def call_llm(self, prompt, query, trace_id):
        SYSTEM_PROMPT =  """你是一个专业级的 SQL 生成助手，用户将向你提供一个自然语言问题，你的目标是：基于问题语义，结合数据库结构，自动生成一个 高质量、可执行的 MySQL 查询语句。"""
        try:
            t1 = time.time()
            response = await self.hot_query_client.chat.completions.create(
                model="natural-sql-7b",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                top_p=0.8,
                max_tokens=1000,
                extra_body={"repetition_penalty": 1.05}
            )
            t2 = time.time()
            result = response.choices[0].message.content
            return result
        except Exception as e:
            self.logger.error(
                f"\tcall_llm:error\tprompt:{json.dumps(prompt, ensure_ascii=False)}\terror:{repr(e)}\ttraceback:{traceback.format_exc()}")
            return ""

    @timeit(logger_mode='self')
    async def llm_get_sql(self, query, trace_id):
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        prompt = f"""
        ###任务
    现在有一个查询问题{query},该查询内容保存在数据库中，请你根据用户的查询问题和下面提供的数据库的具体存储结构，生成满足用户查询需求的MYSQL语句。
    ### MySQL 数据库结构
    查询将在一个包含不同类型榜单及其对应榜单词的数据表结构上运行:
 

        ```

    CREATE TABLE `hot_search_results` (
    `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `query` varchar(255) NOT NULL DEFAULT '' COMMENT '热搜榜单词，表示用户关注的具体话题内容',
    `date` date NOT NULL DEFAULT ' ' COMMENT '日期保存格式为 yyyy-mm-dd',
    `source` varchar(255) NOT NULL DEFAULT ''  COMMENT '榜单来源只有两类: 主榜: 综合热度最高的榜单词; 文娱:明星、文艺类热度较高的榜单词; 
    `hot` int(11) NOT NULL DEFAULT '0' COMMENT '热度值',
    `cate` varchar(255) NOT NULL DEFAULT '' COMMENT '领域',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uniq_idx_unique_query_date_source` (`query`,`date`,`source`),
    KEY `idx_cate` (`cate`)
    ) ENGINE=InnoDB AUTO_INCREMENT=7261689 DEFAULT CHARSET=utf8 
    ```
    在生成sql语句时请注意:
    1.当前的日期为 {cur_date}。
    2.将表示近期的时间词（如“最近”、“这两天”、“本周”等）转换为相应的天数范围，并在 SQL 中据此构建合适的日期条件。
    4.如果在 SQL 的任何条件表达式中同时使用了 AND 和 OR，请根据逻辑需要添加括号，确保语义优先级正确,避免 OR 逻辑优先级错误。
    5.保留必要的关键词作为筛选条件,以增强查询的准确性。
    6.当用户的问题涉及热度排序时，热度字段为int类型，选择合适排序方向，并结合需要使用 LIMIT 控制返回条数。
    7.请注意字段名使用 MySQL 标准写法,字段名不得使用双引号包裹例如，应使用 query, hot，而非 "query", "hot"。

     ### 答案:
    以下是回答该问题的 MYSQL 查询语句: {query} 
    ```sql
    
    """
        start = time.time()
        output_text = await self.call_llm(prompt, query, trace_id)
        sql_result = output_text.split("```sql")[-1].strip().strip("```").strip()
        self.logger.info(
            f"\tllm_get_sql:ok\tquery:{query}\trace_id:{trace_id}\tprompt:{prompt}\toutput:{output_text}\tsql_result:{sql_result}\tcost:{time.time() - start}")
        return sql_result
    
    def build_sql_kwargs(self, query: str, date_range: list[str]) -> dict:
        """需判断是否需要转义"""
        if len(date_range) != 2:
            self.logger.error(self.pre_log_msg + f"build_sql_kwargs:error\tquery:{query}\tdate_range:{date_range}")
            return {}
        
        # 同时处理 % 和 _ 两个通配符的转义
        if '%' in query or '_' in query:
            sql_tpl = "SELECT * FROM hot_search_results WHERE query LIKE %s AND date BETWEEN %s AND %s ESCAPE \\ "
            # 转义两种通配符
            query = query.replace('%', '\\%').replace('_', '\\_')
        else:
            sql_tpl = "SELECT * FROM hot_search_results WHERE query LIKE %s AND date BETWEEN %s AND %s LIMIT 200"
        like_pattern = f"%{query}%"
        self.logger.info(self.pre_log_msg + f"build_sql_kwargs:ok\tquery:{query}\tdate_range:{date_range}\tsql_tpl:{sql_tpl}\tlike_pattern:{like_pattern}")
        return {"query": sql_tpl, "params": (like_pattern, date_range[0], date_range[1])}
    
    @timeit(logger_mode='self')
    async def exec_sql_with_timeout(self, sql_kwargs, timeout):
        try:
            # 创建任务以便可以取消
            self.logger.info(self.pre_log_msg + f"sql_kwargs: {sql_kwargs}")
            task = asyncio.create_task(self.db.execute(**sql_kwargs))
            result = await asyncio.wait_for(task, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            # 超时后主动取消任务，避免资源泄漏
            task.cancel()
            self.logger.warning(self.pre_log_msg + f"db.execute timeout({timeout}): {sql_kwargs}")
            return []
        except Exception as e:
            self.logger.warning(self.pre_log_msg + f"db.execute error: {repr(e)}, sql_kwargs: {sql_kwargs}")
            return []

    @timeit(logger_mode='self')
    async def run(self, query, star_list,  trace_id, use_1_day=False):
        self.update_pre_log_msg({"query": query, "traceid": trace_id})
        await self.db.init_pool()
        tmp_prompt = self.get_prompt(query)
        time_result = await self.qwen38b(tmp_prompt)
        if time_result:
            time_result = time_result.get("text",  "")
            output_time = re.search(r'\{.*?\}', time_result, re.DOTALL)
            time_result = output_time.group()
        else:
            time_result = '{"has_time": false}'
        self.logger.info(self.pre_log_msg + f"trace_id:{trace_id}\t time_result:{time_result}")
        result_temp = json.loads(time_result)
        time_results = [(datetime.now() - timedelta(days=6)).strftime('%Y-%m-%d'), datetime.now().strftime('%Y-%m-%d')]
        try:
            if result_temp.get('has_time', False) and'start_time' in result_temp and 'end_time' in result_temp:
                end_date = datetime.strptime(result_temp['end_time'], '%Y%m%d').strftime('%Y-%m-%d')
                start_date = datetime.strptime(result_temp['start_time'], '%Y%m%d').strftime('%Y-%m-%d')
                time_results =  [start_date, end_date]
        except Exception as e:
            self.logger.warning(self.pre_log_msg + f"parse time_result error: {repr(e)}, time_result: {time_result}")
        
        if use_1_day:
            time_results = [(datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d'), datetime.now().strftime('%Y-%m-%d')]
            self.logger.info(self.pre_log_msg + f"trace_id:{trace_id}\t use 1 day for deepseek_stream time_results:{time_results}")
        star_list = [item for item in star_list]
        self.logger.info(self.pre_log_msg + f"trace_id:{trace_id}\t star_list:{star_list}")
        if star_list:
            sql_kwargs_list = [self.build_sql_kwargs(item, time_results) for item in star_list]
        else:
            if (datetime.strptime(time_results[1], '%Y-%m-%d') - datetime.strptime(time_results[0], '%Y-%m-%d')).days > 3:  #无关键词而且时间大于3天，修正为3天，热度排序限制500，再时间倒序
                time_results[0] = (datetime.strptime(time_results[1], '%Y-%m-%d') - timedelta(days=2)).strftime('%Y-%m-%d')
                sql_tpl = "SELECT * FROM (SELECT * FROM hot_search_results WHERE date BETWEEN %s AND %s ORDER BY hot DESC LIMIT 200) AS sub ORDER BY date DESC"
                sql_kwargs_list = [{"query": sql_tpl, "params": (time_results[0], time_results[1])}]
            else:
                sql_tpl = "SELECT * FROM hot_search_results WHERE date BETWEEN %s AND %s LIMIT 200"
                sql_kwargs_list = [{"query": sql_tpl, "params": (time_results[0], time_results[1])}]
        tasks = [self.exec_sql_with_timeout(sql_kwargs, timeout=2) for sql_kwargs in sql_kwargs_list]
        hot_querys = await asyncio.gather(*tasks)
        # flatten
        hot_querys = [item for sublist in hot_querys for item in sublist]
        res = await self.parse_res_from_mysql(hot_querys)
        #return res, time_result, keyword_conditions, star_list, sql_kwargs_list
        return res


class QueryTrie:

    def __init__(self, query_list=[]):
        # paths = ['movie.json', 'star.json', 'tv.json']
        # query_list = []
        # for path in paths:
        #    relative_path = os.path.join("data", path)
        #    if not os.path.exists(relative_path):
        #        continue
        #    with open(relative_path, 'r', encoding='utf-8') as f:
        #        data = json.load(f)
        #        query_list += data
        self.trie = Trie(query_list)

    def search(self, query):
        return self.trie.search_all(query)
    
class SCKeywordTrie:
    def __init__(self):
        data_list = []
        relative_path = os.path.join("data", "sc_filter_words.txt")
        if os.path.exists(relative_path):
            with open(relative_path, 'r', encoding='utf-8') as f:
                for item in f.readlines():
                    item = item.strip()
                    if item:
                        data_list.append(item)
        else:
            print(f"{relative_path} not found")
        self.kwm_cls = KeywordMatcher(data_list)
        
    def search(self, query) -> list[str]:
        return self.kwm_cls.match(query)


class StockDict:
    def __init__(self):
        self.stock_dict = {}
        relative_path = os.path.join("data", "stock.json")
        if os.path.exists(relative_path):
            with open(relative_path, 'r', encoding='utf-8') as f:
                self.stock_dict = json.load(f)

    def search(self, query):
        return self.stock_dict.get(query, [])


class KolDict:
    def __init__(self):
        self.kol_dict = {}
        # relative_path = os.path.join("data", "kol.json")
        # if os.path.exists(relative_path):
        #    with open(relative_path, 'r', encoding='utf-8') as f:
        #        self.kol_dict = json.load(f)

    def search(self, query):
        return self.kol_dict.get(query, "")


def get_media_uids():
    media_uids = set()
    relative_path = os.path.join("data", "media_uids.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    media_uids.add(line.strip())
    return media_uids

def get_consulate_uids():
    consulate_uids = set()
    relative_path = os.path.join("data", "consulate_uids.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    consulate_uids.add(line.strip())
    return consulate_uids


def get_risk_filter_uids():
    risk_uids = set()
    relative_path = os.path.join("data", "risk_filter_uids.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    risk_uids.add(line.strip())
    return risk_uids

def get_star_white_uids():
    star_white_uids = set()
    relative_path = os.path.join("data", "star_white_uids.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    star_white_uids.add(str(line.strip()))
    return star_white_uids

def get_star_black_uids():
    star_black_uids = {}
    relative_path = os.path.join("data", "star_black_uids.json")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            star_black_uids = json.load(f)
    return star_black_uids


def get_credible_media_uids():
    media_uids = set()
    relative_path = os.path.join("data", "credible_media_uids.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    media_uids.add(line.strip())
    return media_uids

def get_medical_uids():
    media_uids = set()
    relative_path = os.path.join("data", "medical_uids.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    media_uids.add(line.strip())
    return media_uids


def get_credible_uids():
    try:
        excel_path = os.path.join("data", "可信度评级账号.xlsx")
        zhanghao_data = pd.read_excel(excel_path)
        zhanghao_data['UID'] = zhanghao_data['UID'].astype(str)
        media_uids = set(zhanghao_data[zhanghao_data["评级"] == '5级']["UID"].to_list())
        da_v_uids = set(zhanghao_data[zhanghao_data["评级"].isin( ['4级','3级'] )]["UID"].to_list())
        certified_uids = set(zhanghao_data[zhanghao_data["评级"].isin( ['1级','2级'] )]["UID"].to_list())
        return media_uids, da_v_uids, certified_uids
    except Exception as e:
        print(f"Error reading Excel file: {e}")

    return set(), set(), set()
    
def get_displayed_uids():
    displayed_uids_dict = {}
    displayed_uids_path = os.path.join("data", "displayed_uid.json")
    if os.path.exists(displayed_uids_path):
        data = open(displayed_uids_path,"r").read()
        displayed_uids_dict = json.loads(data)
        for i in displayed_uids_dict:
            displayed_uids_dict[i] = set(displayed_uids_dict[i])
    return displayed_uids_dict

def get_reliable_5level_uids():
    reliable_5level_uids = set()
    relative_path = os.path.join("data", "reliable_5level_uids.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    reliable_5level_uids.add(line.strip())
    return reliable_5level_uids

def get_filtered_keywords():
    filtered_keywords = set()
    relative_path = os.path.join("data", "filtered_keywords.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    filtered_keywords.add(line.strip())
    return filtered_keywords


def get_hot_query():
    query_set = set()
    relative_path = os.path.join("data", "hot_query.txt")
    if os.path.exists(relative_path):
        with open(relative_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    query_set.add(topic_normalize(line.strip()))
    return query_set