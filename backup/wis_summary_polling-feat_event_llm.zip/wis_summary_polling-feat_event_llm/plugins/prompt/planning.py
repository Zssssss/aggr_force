# -*- coding:utf-8 -*-
import json
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
from plugins.material.filter import RiskLevel
from plugins.prompt.base import BasePrompt
from plugins.prompt.json_utils import parse_json

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/planning.j2')


class PlanningPrompt(BasePrompt):

    def prompt(self):
        query = self.weibo.get("query", "")
        content = self.weibo.get('content', "")
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        parametric_knowledge_permit = True
        # query命中D级风控禁用参数化知识
        if self.weibo.get("limit_material"):
            parametric_knowledge_permit = False
        prompt = prompt_template.render(question=query,
                                        context=content,
                                        cur_date=cur_date,
                                        parametric_knowledge=parametric_knowledge_permit,
                                        )
        return prompt

    def post_process(self, result):
        try:
            plan_knowledge = parse_json(result)
            content = plan_knowledge.get("写作计划", "")
            if content:
                self.weibo['plan_knowledge'] = f"""[写作计划 begin]{content}[写作计划 end]\n"""
                return content
        except Exception as e:
            pass
        return ""
