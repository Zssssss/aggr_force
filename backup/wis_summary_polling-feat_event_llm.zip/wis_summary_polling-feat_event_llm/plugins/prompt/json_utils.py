# -*- coding:utf-8 -*-

"""文本处理工具函数"""
import json
import re
from typing import Optional, Dict, Any


def extract_json_block(text: str) -> Optional[str]:
    """从文本中提取JSON内容，支持多种格式：
    1. ```json标记的代码块
    2. 裸JSON格式（可能出现在think标签后）
    3. 纯JSON字符串
    4. 带前后空格的JSON字符串

    Args:
        text: 可能包含JSON内容的文本

    Returns:
        提取出的合法JSON字符串或None

    Raises:
        ValueError: 当输入文本为空时
    """
    if not text or not text.strip():
        raise ValueError("Input text cannot be empty")

    # 按优先级尝试不同提取方式
    for extractor in [
        _extract_json_code_block,
        _extract_bare_json,
        _extract_pure_json,
        _extract_truncated_json
    ]:
        result = extractor(text)
        if result is not None:
            return result

    return None


def _extract_json_code_block(text: str) -> Optional[str]:
    """提取```json标记的代码块中的JSON内容"""
    pattern = r'```json\s*(\{.*?\})\s*```'
    match = re.search(pattern, text, re.DOTALL)
    return match.group(1) if match else None


def _extract_bare_json(text: str) -> Optional[str]:
    """提取可能出现在think标签后的裸JSON"""
    pattern = r'(?:\n\s*|\A)(\{.*?\})(?=\s*\Z|\n)'
    match = re.search(pattern, text, re.DOTALL)
    if not match:
        return None

    json_str = match.group(1)
    return json_str if _is_valid_json(json_str) else None


def _extract_pure_json(text: str) -> Optional[str]:
    """尝试直接解析整个文本是否为JSON"""
    return text if _is_valid_json(text) else None


def _is_valid_json(json_str: str) -> bool:
    """验证字符串是否为合法JSON"""
    try:
        json.loads(json_str)
        return True
    except json.JSONDecodeError:
        return False


def _extract_truncated_json(text: str) -> Optional[str]:
    """尝试截取到最后一个大括号（处理末尾有多余内容的情况）"""
    last_brace = text.rfind('}')
    if last_brace == -1:
        return None

    truncated = text[:last_brace + 1]  # 包含最后一个大括号
    return truncated if _is_valid_json(truncated) else None


def remove_think_tags(text: str) -> str:
    """移除LLM响应中的<think>标签内容

    Args:
        text: 包含think标签的原始文本

    Returns:
        移除think标签后的文本
    """
    return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()


def parse_json(response: str) -> Dict[str, Any]:
    """解析LLM响应并提取结构化数据

    Args:
        response: LLM原始响应文本

    Returns:
        包含cot和plan的字典
    """
    content = remove_think_tags(response)
    json_str = extract_json_block(content)
    if not json_str:
        raise ValueError("未找到有效的JSON内容")
    return json.loads(json_str)
