# -*- coding:utf-8 -*-
import re
from datetime import datetime
from plugins.prompt.base import BasePrompt

# 先联调后续更新
class NewsTitlePrompt(BasePrompt):
    def prompt(self):
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        blog_content = self.weibo.get("mid_content", "")
        llm_res = self.weibo.get("ori_result", "")

        prompt_str = f"""以下是一篇微博：
[text begin]
{blog_content}
[text end]

以下是针对上述微博给出的博文分析，包含微博内容的求证和解读：
[analysis begin]
{llm_res}
[analysis end]

全面理解微博内容和博文分析的求证部分，按照以下要求，聚焦于微博中被求证的核心部分，提出一个“「xxx」求证”样式的标题。
具体要求如下：
- 要求标题包含关键的主体名称、信息准确。
- 要求标题具备很好的可读性，“「」”内应是一个完整的句子或短语，符合真人表达方式，保证语句通顺、通俗易懂。
- 避免提出宽泛、形而上、高立意的标题。
- 禁止使用非特指指代词，所有指代对象必须具体命名。
- 提出的标题要安全：不讨论政治、宗教、迷信、黄赌毒等话题，不做负面的舆论引导。
- 保持中立，不对任何博主、粉丝群体有负面影响。
- 提出的标题必须是中文，不包含句号和问号。 
- 标题的字符数必须在15字以内。

现在，请按以下格式输出标题：
<title>「xxx」求证</title>"""
        return prompt_str

    def post_process(self, result):
        if "</think>" in result:
            result = result.split("</think>")[1]

        match = re.search(r'<title>(.*?)</title>', result)
        if match:
            result = match.group(1)
            return result
        return ""