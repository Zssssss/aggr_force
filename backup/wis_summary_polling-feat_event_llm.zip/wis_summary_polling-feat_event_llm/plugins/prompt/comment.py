# -*- coding:utf-8 -*-
# -*- coding:utf-8 -*-
import json
import re
from datetime import datetime

from plugins.prompt.base import BasePrompt
from plugins.prompt.ds import DsPrompt


intention_template = """你是微博智搜，正在微博平台上回复用户评论。
用户“{nick_name}”在“{blog_time}”发表的原博如下:
{blog_content}

以下是用户在原博评论区提及你（@微博智搜）的评论内容：
{blog_comment}

请你仔细阅读原博与评论内容，然后判断用户提及你的意图：
(求证)：用户要你对原博进行求证。
(其它)：用户没有让你对原博求证。
请先输出理由再输出意图。
理由: ...
意图：(求证/其它)"""


verification_template = """博主“{nick_name}”在{blog_time}发表的原博（待分析博文）如下：
{blog_content}
以下是检索出的参考结果：
{search_material}
在检索出的参考结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。如果回答中参考了相关搜索结果，在一段话的末尾引用对应的搜索结果。请按照引用编号[^X]的格式在答案中对应部分引用所参考的搜索结果。如果一句话参考了多个搜索结果，请列出所有相关的引用编号，例如[^3][^5]，切记不要将引用集中在最后返回引用编号，而是在答案对应部分列出，且回答结尾处不要输出任何引用说明内容。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。

仔细阅读原博，结合相关参考结果和自身知识，对原博不可靠内容完成求证。如果原博中存在错误或不可靠内容，并可能造成误导或负面影响时，生成时进行纠正并给出说明。

在生成时，请注意以下几点：
- 今天是{today}。
- 并非参考结果的所有内容都与原博密切相关，你需要结合原博与自身知识，对参考结果进行甄别、筛选。
- 针对原博内容进行分析，检索出的参考结果仅作为辅助分析的资料，参考结果中的不可靠内容无需说明。
- 自身知识可以直接使用，无需添加引用或来源说明。
- 参考相关结果时，将有效信息自然地融入到生成中，避免在行文中直接提及结果X，如有引用使用规定的引用格式。
- 生成的正文不能使用信息整合型句式开头（如“根据相关结果...”、“结合多方信息...”）。
- 针对原博用一句话给出简练明确的求证结论，只输出核心结论，避免输出多段内容，避免使用markdown格式。"""


filter_template = """你是微博智搜，正在微博平台上回复用户评论。
用户“{nick_name}”在“{blog_time}”发表的原博如下:
{blog_content}

以下是用户在原博评论区提及你（@微博智搜）的评论内容：
{blog_comment}

以下是你的回复内容：
{response}

请你仔细阅读原博、评论内容和回复内容，然后结合展现标准判断回复内容是否可以展现给用户。
展现标准如下：
- 回复内容紧扣用户评论内容。
- 回复内容严格遵守以下全部原则：
    - 必须坚定不移地拥护中国共产党的领导，始终与党中央保持高度一致，严格遵守《中华人民共和国宪法》、《中华人民共和国刑法》、《中华人民共和国网络安全法》、《中华人民共和国数据安全法》、《中华人民共和国个人信息保护法》、《互联网信息服务管理办法》、《互联网新闻信息服务管理规定》、《网络信息内容生态治理规定》、《未成年人网络保护条例》等各项法律法规，贯彻落实网络信息内容生态治理规定，坚持社会主义核心价值观，积极传播正能量，维护国家利益和民族尊严。
    - 涉及国家表述时必须使用规范用语，统一使用“我国”指代中华人民共和国，使用“台湾地区”、“香港地区”等规范表述，要坚决拥护中国共产党的领导，严格遵守国家法律法规。不出现任何分裂国家相关的图文，包括但不限于反对“一个中国”“一国两制”，反映台独、港独、藏独、疆独等形式的内容。
    - 严禁对国家领导人使用不明确的词语进行代指或内涵，必须使用完整规范的职务称谓。不对历任高层领导人及家属进行主观评价。
    - 政治类信息表述必须与官方表述完全一致，不得使用任何暗示性、模糊性表述，严禁使用网络流行语等非正式表达。
    - 不提供不明来源文件，不提供任何非公开文件，保证用户信息安全。
    - 不参与讨论敏感话题，对“六四事件”、“89学潮事件”、“法轮功”“白纸运动”“四通桥事件”等敏感话题只采用官方媒体和权威部门发布的信息，不参与讨论、不发表评论，并建议用户通过官方渠道获取最新信息。
    - 需要避免任何可能引起争议的内容，不涉及地域歧视、民族政策、性别对立等敏感话题，不提及具体案例，不评论现行政策法规，保证回答的概括性，保持立场中立但旗帜鲜明。
    - 避免在公开平台泄露敏感信息，不响应涉及他人隐私的查询，不讨论具体个案。
    - 不提供任何煽动群众聚集、聚众上访的信息。
    - 确保信息准确、客观、权威，根据用户问题提供针对性回答，保持政治性、科学性、时效性的统一，避免主观臆断和情绪化表达。
    - 针对用户具体需求提供精准服务，避免信息堆砌和无关内容，对超出服务范围的要求予以婉拒。

回复内容需要符合以上全部展现标准才可以展现，请先输出理由再输出是否可以展现。
理由: ...
是否可以展现：(是/否)"""


class CommentIntentionPrompt(BasePrompt):
    def prompt(self):
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("mid_content", "")
        content = self.weibo.get('content', "")
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        nick_name = ""
        blog_time = ""
        blog_comment = ""
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                nick_name = json_data.get("v_nickname", "") or self.weibo.get("mid_nick", "")
                blog_time = json_data.get("v_pbtime", "") or self.weibo.get("mid_time", "")
                blog_comment = json_data.get("comment", "")
                dt = datetime.strptime(blog_time, "%a %b %d %H:%M:%S %z %Y")
                blog_time = dt.strftime("%Y年%m月%d日")
            except Exception as e:
                self.logger.error("{} q_attr:{}, error:{}".format(trace_id, q_attr, e))

        prompt = intention_template.format(nick_name=nick_name, blog_time=blog_time, blog_content=query, blog_comment=blog_comment)
        return prompt

    def post_process(self, result):

        if not result:
            return False

        sentences = result.strip().split('\n')
        sentences = [sentence for sentence in sentences if sentence.strip()]
        if not sentences:
            return False

        match = re.search(r"意图[:：]?[（(]?\s*(求证|其他)\s*[）)]?", sentences[-1])
        if match and match.group(1) == '求证':
            return True

        return False


class CommentVerificationPrompt(DsPrompt):
    def prompt(self):
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("mid_content", "")
        content = self.weibo.get('content', "")
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        nick_name = ""
        blog_time = ""
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                nick_name = json_data.get("v_nickname", "") or self.weibo.get("mid_nick", "")
                blog_time = json_data.get("v_pbtime", "") or self.weibo.get("mid_time", "")
                dt = datetime.strptime(blog_time, "%a %b %d %H:%M:%S %z %Y")
                blog_time = dt.strftime("%Y年%m月%d日")
            except Exception as e:
                self.logger.error("{} q_attr:{}, error:{}".format(trace_id, q_attr, e))

        prompt = verification_template.format(nick_name=nick_name, blog_time=blog_time, blog_content=query, search_material=content, today=cur_date)
        return prompt

    @staticmethod
    def filter_invalid_str(s: str):
        """过滤非法字符，返回过滤后的字符串，当前过滤策略：
        [^2-^32]、[^2~^32]、(结果2][23)、(结果2)、(参考结果2、3)、^[result=1]^
        """
        pattern_list = [r"\[\^\d+[\-\~]\^\d+\]", r"[\(（\[【](?:参考|如|)结果\d+(?:(?:[\]\[]+|、)\d+)*[\)）\]】]",
            r"[\(（](?:注|图片示例)[:：][^\n\(（\)）]*[\)）]", r"\[\^\d+\^?\]\^?", r"\^\[result=\d+\]\^", r"[\(（\[【][\)）\]】]"]
        result = s
        all_deleted_matches = []
        for pattern in pattern_list:
            # 查找所有需要删除的字符
            deleted_matches = re.findall(pattern, result)
            # 替换掉不符合条件的部分
            result = re.sub(pattern, '', result)
            # 更新删除字符列表
            all_deleted_matches.extend(deleted_matches)
        return result, list(set(all_deleted_matches))

    def post_process(self, result):
        ori_result = result
        result, all_deleted_matches = self.filter_invalid_str(result)
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        trace_id = self.weibo.get("trace_id", "")
        ready = self.weibo.get("output_all_ready", False)
        if ready and len(all_deleted_matches) > 0:
            self.logger.info(f"trace_id:{trace_id} query:{query} all_deleted_matches:{all_deleted_matches}, ori_result:{ori_result}")
        return result


class CommentFilterPrompt(BasePrompt):
    def prompt(self):
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("mid_content", "")
        content = self.weibo.get('content', "")
        response = self.weibo.get("comment_response", "")
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        nick_name = ""
        blog_time = ""
        blog_comment = ""
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                nick_name = json_data.get("v_nickname", "") or self.weibo.get("mid_nick", "")
                blog_time = json_data.get("v_pbtime", "") or self.weibo.get("mid_time", "")
                blog_comment = json_data.get("comment", "")
                dt = datetime.strptime(blog_time, "%a %b %d %H:%M:%S %z %Y")
                blog_time = dt.strftime("%Y年%m月%d日")
            except Exception as e:
                self.logger.error("{} q_attr:{}, error:{}".format(trace_id, q_attr, e))

        prompt = filter_template.format(nick_name=nick_name, blog_time=blog_time, blog_content=query, blog_comment=blog_comment, response=response)
        return prompt

    def post_process(self, result):
        if not result:
            return False

        sentences = result.strip().split('\n')
        sentences = [sentence for sentence in sentences if sentence.strip()]
        if not sentences:
            return False

        match = re.search(r"是否可以展现[:：]?[（(]?\s*(是|否)\s*[）)]?", sentences[-1])
        if match and match.group(1) == '是':
            return True

        return False