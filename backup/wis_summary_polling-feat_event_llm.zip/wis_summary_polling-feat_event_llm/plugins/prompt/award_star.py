from typing import List

from jinja2 import Template


# 分片生成
def get_award_generate_prompt(query: str, mat: str) -> tuple:
    prompt_template = Template("""
以下内容是明星“{{ query }}”的热搜事件搜索结果：
{{ hot_event }}

搜索结果均以[结果 X begin]...[结果 X end]格式呈现（X为结果数字索引），每个结果包含以下固定格式数据：
- 内容类型：[type begin]...[type end]（如“微博”）
- 博主昵称：[username begin]...[username end]（发博者昵称）
- 内容数据：[content begin]...[content end]（核心内容部分）
- 发布时间：[date begin]...[date end]（内容发布时间）
- 作者类别：[account type begin]...[account type end]（含“认证账号”“媒体账号”“大V账号”“普通账号”），各类别说明如下：
  ● 媒体账号：微博可信媒体账号，内容相对可信；
  ● 大V账号：微博高影响力、专业性账号，内容相对专业可信；
  ● 认证账号：微博身份认证账号（身份真实但内容未必可信）；
  ● 普通账号：微博无认证普通用户账号（内容未必可信）。

## 任务说明
作为专业颁奖词撰写专家，仅基于搜索结果筛选出的有效信息创作简洁生动、富有感染力的颁奖词。筛选核心：仅保留与明星{{query}}直接强相关、事件主体完全为该明星本人、**事件实际发生于{{cur_date}}年且涉及的作品实际上映/播出时间为{{cur_date}}年**的正向热搜事件，聚焦其主演/参与的{{cur_date}}年相关作品（需明确标注“由{{query}}主演/参与”的关联表述，且作品实际上映/播出于{{cur_date}}年）及个人正向表现与价值；**完全排除非搜索结果提及、未明确标注与{{query}}主演/参与关联、作品实际上映/播出非{{cur_date}}年的任何作品，绝不引入该明星未参与的影视综作品、无关热搜事件及非{{cur_date}}年发生的任何信息**。

## 约束条件
1. 严格限定双时间维度：**事件实际发生时间必须为{{cur_date}}年，且涉及的作品实际上映/播出时间必须为{{cur_date}}年**；任一维度非{{cur_date}}年的，均视为无效并彻底剔除。
2. 七重筛选标准：仅保留“事件主体为{{query}}本人，剔除其他任何无关人物”“发布时间+事件实际发生时间均为{{cur_date}}年”“涉及作品实际上映/播出时间为{{cur_date}}年”“正向无争议”“与该明星主演/参与的作品（需有明确关联表述）或个人直接相关”“来自搜索结果明确提及”“作品标注与{{query}}的主演/参与关联”的内容，无任何模糊空间，其余全部排除。
3. 绝对基于热搜事件创作：仅提取热搜结果中明确提及、标注与{{query}}主演/参与关联且实际上映/播出于{{cur_date}}年的作品及个人信息，禁止将无关联标注、非{{cur_date}}年上映/播出的作品归为{{query}}所有，禁止杜撰未提及的作品、事件、表现，禁止引入任何搜索结果未涉及的人物、无关热搜事件及该明星未参与的影视综作品。
4. 完全排除非搜索结果提及、未明确标注与{{query}}主演/参与关联、作品实际上映/播出非{{cur_date}}年的任何作品，绝不引入该明星未参与的影视综作品、无关热搜事件及非{{cur_date}}年发生的任何信息。
5. 严格基于热搜事件创作：仅提取明确提及的信息，禁止杜撰未提及的作品、事件、表现，禁止引入任何无关人物、热搜事件及该明星未参与的影视综作品。
6. 禁止使用第二人称代词，仅用第三人称或泛指表达。
7. 直接切入核心，不得以“致...”或类似表述开头。
8. 语气积极鼓舞，突出正能量。
9. 必须包含明星姓名、其主演/参与的正向相关作品名（作品名需来自搜索结果有效信息，明确对应“{{query}}主演/参与”的关联表述，且实际上映/播出于{{cur_date}}年），不得出现搜索结果未提及、无关联标注、非{{cur_date}}年上映/播出或非该明星主演/参与的作品名。

## 输出格式
纯文本颁奖词，200字以内。
""")
    prompt_base = prompt_template.render(
        hot_event=mat,
        query=query,
        cur_date="2025",
        debug=False
    )
    prompt_optim = prompt_template.render(
        hot_event=mat,
        query=query,
        cur_date="2025",
        debug=True
    )
    return prompt_base, prompt_optim


# 摘要生成
def get_final_summary_prompt(query: str, mat: List[str]) -> tuple:
    award_speech = '\n'.join(mat)
    prompt_template = Template("""
## 背景信息
以下内容是明星“{{ query }}”的多角度草稿颁奖词：
{{award_speech}}
草稿颁奖词以[结果 X begin]...[结果 X end]格式呈现，X为结果数字索引。

## 任务要求
深入理解“{{ query }}”相关各草稿颁奖词，忽略重复信息、不遗漏关键信息，生成最终版{{cur_date}}年度颁奖词。

## 注意事项
- 仅输出颁奖词内容，不呈现思考过程。
- 完整融入{{award_speech}}核心信息，不遗漏关键要点。
- 颁奖词字数控制在120字以内。
- 禁止使用第二人称代词（如“你”“您”），仅用第三人称或泛指表达。
- 直接切入核心，绝对禁止以“致...”或类似表述开头。
- 严格基于草稿创作：仅提取明确提及的信息，禁止杜撰未提及的作品、事件、表现，禁止引入任何无关人物、热搜事件及该明星未参与的影视综作品。
- 以积极、鼓舞人心的语气呈现，突出正能量。
- 必须包含该明星姓名及正向相关的已发生影视等作品名，未发生事件 / 作品如需提及需明确标注状态。

## 输出格式
直接生成纯文本颁奖词，无需额外标题或标记。
""")
    prompt_base = prompt_template.render(
        award_speech=award_speech,
        query=query,
        cur_date="2025",
        debug=False
    )
    prompt_optim = prompt_template.render(
        award_speech=award_speech,
        query=query,
        cur_date="2025",
        debug=True
    )
    return prompt_base, prompt_optim


# 意图验证
def get_final_intent(query: str, mat: str) -> tuple:
    prompt_template = Template("""
## 背景信息

你是一位专业的微博颁奖词幻觉修复专家。

明星{{query}}的待修正颁奖词：
{{ award_summ }}

## 任务要求
请结合背景信息，深入理解待修正颁奖词的意图，并将其拆解为若干任务步骤以修正存在的负向或者幻觉问题。输出步骤前应先完成内部的语义与意图判断；若仍不确定或存在歧义，可在任务步骤中直接通过<search>检索。
- 任务步骤应简洁清晰。
- 若需要额外信息支持，必须在当前任务步骤中发起检索，且检索词只能出现在 <search> 标签中，否则视为错误。
- <search>检索词应为简洁、聚焦的关键词或短语，保持语义完整，能直接用于搜索。
- 严格控制任务步骤数量：若能够在单一任务步骤内完成，则禁止再进行拆分。

## 注意事项
- **必须判断作品或者事情是否是{{cur_date}}发生的**。
- 每个影视作品单独作为一个任务。
- 仅做任务规划，不要直接回答。

## 输出格式
每个任务步骤单独一行，i表示编号（从1开始），必须判断是否是{{cur_date}}年的作品或事件，格式如下:
```
任务步骤i: ... <search>检索词</search>
```
""")
    prompt_base = prompt_template.render(
        award_summ=mat,
        query = query,
        cur_date="2025",
        debug=False
    )
    prompt_optim = prompt_template.render(
        award_summ=mat,
        query = query,
        cur_date="2025",
        debug=True
    )
    return prompt_base,prompt_optim


def get_final_verify(query, summ, search_results, step_verify):
    from jinja2 import Template
    prompt_template = Template("""
你是专业的微博颁奖词幻觉修复专家，核心需严格遵循**修正思路** 逐一验证，在待修正颁奖词原有内容基础上，检测并修正时间相关错误，剔除歧义、非正向内容，不引入新信息，确保内容准确、正面且符合颁奖词风格。

### 背景信息
- 参考基准年：{{cur_date}}年（用于判断时间合理性）
- 明星姓名：{{query}}
- 待修正的颁奖词：{{award_summ}}
- 相关搜索结果：{{search_results}}
- 修正思路：{{step_verify}}（需按此步骤逐一验证执行）

搜索结果均以[结果 X begin]...[结果 X end]格式呈现（X为结果数字索引），每个结果包含以下固定格式数据：
- 内容类型：[type begin]...[type end]（如“微博”）
- 博主昵称：[username begin]...[username end]（发博者昵称）
- 内容数据：[content begin]...[content end]（核心内容部分）
- 发布时间：[date begin]...[date end]（内容发布时间）
- 作者类别：[account type begin]...[account type end]（含“认证账号”“媒体账号”“大V账号”“普通账号”），各类别说明如下：
  ● 媒体账号：微博可信媒体账号，内容相对可信；
  ● 大V账号：微博高影响力、专业性账号，内容相对专业可信；
  ● 认证账号：微博身份认证账号（身份真实但内容未必可信）；
  ● 普通账号：微博无认证普通用户账号（内容未必可信）。

### 任务要求
需严格按照**修正思路：{{step_verify}}** 逐一验证，对明星{{query}}的颁奖词进行幻觉检测与修复，**仅在原有内容基础上操作，不新增任何未提及的信息**，重点处理时间错误和非正向、歧义内容：
1. **禁止提及其他任何明星，删除任何其他人名**
2. 时间修正：按修正思路逐一验证时间合理性，修正/删除误标为{{cur_date}}年的作品，剔除非{{cur_date}}年且未误标时间的作品，仅保留当年真实信息；
3. 内容过滤：按修正思路逐一排查，聚焦该明星，移除歧义、非正向、争议及排名相关内容，基调积极；
4. 内容修正：按修正思路逐一核验，摒弃番位、粉丝打榜表述，不新增未提及的作品、事件等；
5. **按修正思路判断为非{{cur_date}}年的作品或内容，直接剔除**。
 

### 注意事项
- 120字内，用第三人称，禁止以“致...”开头；
- 包含明星姓名及正向已发生作品名，未发生事件需标注状态（仅限原有提及），语气积极，不重构核心语义；
- 优先使用已有搜索结果（优先采信媒体账号、大V账号信息）按修正思路逐一进行时间验证，信息不足时按常识处理；
- 严格把控时间准确性和内容正向性，按修正思路落实非{{cur_date}}年相关信息及非正向、歧义内容的修正；
- 坚守正面导向，不引入任何负面、争议内容，不提及其他明星及粉丝打榜相关表述；
- 输出内容必须简洁、连贯，符合微博平台传播特点；
- **在原文基础上修改输出**；
- 字数要求：修正后需保证 80 字以上，若原有内容修正后不足 80 字，需在不引入新信息的前提下，补充贴合明星已有正向特质、符合颁奖词风格的表扬语句（如夸赞专业能力、敬业态度、正向影响力等），确保内容连贯自然。

### 输出格式
直接输出修正后的纯文本颁奖词，无需额外说明。
""")
    prompt_base = prompt_template.render(
        award_summ=summ,
        query=query,
        search_results=search_results,
        step_verify=step_verify,
        cur_date="2025",
        debug=False
    )
    prompt_optim = prompt_template.render(
        award_summ=summ,
        query=query,
        search_results=search_results,
        step_verify=step_verify,
        cur_date="2025",
        debug=True
    )
    return prompt_base, prompt_optim