from typing import List
from jinja2 import Template
CUR_DATE = "2025"
def get_award_generate_prompt(query: str, mat: str) -> tuple:
    prompt_template = Template(
"""
## 背景信息

以下是二次元人物“{{ query }}”的热搜事件搜索结果：
{{ hot_event }}

搜索结果均以[结果 X begin]...[结果 X end]格式呈现（X为结果数字索引），每个结果包含固定格式数据（内容类型、博主昵称、核心内容、发布时间、作者类别），各类作者类别说明如下：
- 媒体账号：微博可信媒体账号，内容相对可信；
- 大V账号：微博高影响力、专业性账号，内容相对专业可信；
- 认证账号：微博身份认证账号（身份真实但内容未必可信）；
- 普通账号：微博无认证普通用户账号（内容未必可信）。

## 任务说明
基于搜索结果筛选有效信息，创作简洁生动、富有感染力的年度寄语。筛选核心：仅保留与二次元人物{{query}}直接强相关、主体为该角色本身、事件实际发生于{{cur_date}}年的正向热搜事件，聚焦其人物介绍、性格特点、高光表现及正向价值。

## 约束条件
1. 时间限定：仅选取事件发生时间为{{cur_date}}年的内容，不满足则剔除。
2. 内容筛选：仅保留主体为{{query}}、正向无争议、来自搜索结果明确提及、与角色直接相关的信息，其余全部排除。
3. 创作依据：绝对基于搜索结果提取信息，禁止杜撰未提及内容，不引入无关角色及非{{cur_date}}年相关信息。
4. 表达要求：禁用第二人称，仅用第三人称或泛指，语气积极鼓舞，语言自然流畅。
5. 核心要素：必须包含二次元人物名，篇幅控制在200字以内。

## 输出格式
纯文本年度寄语（无需额外格式，直接呈现内容）。
""")

    prompt_base = prompt_template.render(
        hot_event=mat,
        query=query,
        cur_date=CUR_DATE,
        debug=False
    )
    prompt_optim = prompt_template.render(
        hot_event=mat,
        query=query,
        cur_date=CUR_DATE,
        debug=True
    )
    return prompt_base, prompt_optim


def get_final_summary_prompt(query: str, mat: List[str]) -> tuple:
    award_speech = '\n'.join(mat)
    prompt_template = Template(
        """
## 背景信息
以下是二次元人物“{{ query }}”的多角度草稿年度寄语：
{{award_speech}}
草稿年度寄语以[结果 X begin]...[结果 X end]格式呈现，X为结果数字索引。

## 任务要求
深入理解二次元人物{{ query }}相关各草稿内容，剔除重复信息、完整保留关键信息，生成最终版{{cur_date}}年度寄语。

## 注意事项
1. 仅输出纯文本年度寄语，不呈现思考过程，字数控制在120字以内。
2. 完整融入草稿核心信息，不遗漏角色性格、高光表现等关键要点。
3. 禁用第二人称代词，仅用第三人称或泛指表达，直接切入核心，禁止以“致...”开头。
4. 严格基于草稿创作：仅提取明确提及的信息，禁止杜撰未提及的内容、无关角色以及无关内容。
5. 语气积极鼓舞，突出正能量，必须包含二次元角色名，语言自然流畅。

## 输出格式
直接生成纯文本年度寄语，无需额外标题或标记。
""")

    prompt_base = prompt_template.render(
        award_speech=award_speech,
        query=query,
        cur_date=CUR_DATE,
        debug=False
    )
    prompt_optim = prompt_template.render(
        award_speech=award_speech,
        query=query,
        cur_date=CUR_DATE,
        debug=True
    )
    return prompt_base, prompt_optim


def get_final_intent(query: str, mat: str) -> tuple:
    prompt_template = Template("""
## 背景信息
你是一位专业的微博二次元年度寄语幻觉修复专家。
二次元领域{{query}}的待修正年度寄语：
{{ award_summ }}

## 任务要求
请结合背景信息，深入理解待修正年度寄语的意图，拆解为若干任务步骤以修正负向表述或幻觉信息。输出步骤前需先完成内部语义与意图判断；若存在不确定或歧义点，可在任务步骤中通过<search>发起检索。
- 任务步骤需简洁清晰，聚焦二次元相关内容。
- 若需额外信息支持，必须在当前任务步骤中发起检索，检索词仅能出现在<search>标签内，否则视为错误。
- <search>检索词应为简洁聚焦的二次元相关关键词或短语，语义完整，可直接用于搜索。
- 严格控制任务步骤数量：单一任务步骤可完成的，禁止拆分。

## 注意事项
- 今天是{{cur_date}}。
- 涉及的每部二次元相关事件单独作为一个任务。
- 仅做任务规划，不直接输出修正后的寄语。

## 输出格式
每个任务步骤单独一行，i表示编号（从1开始），格式如下:
```
任务步骤i: ... <search>检索词</search>
```
"""
                               )
    prompt_base = prompt_template.render(
        award_summ=mat,
        query=query,
        cur_date='2025',
        debug=False
    )
    prompt_optim = prompt_template.render(
        award_summ=mat,
        query=query,
        cur_date='2025',
        debug=True
    )
    return prompt_base, prompt_optim


def get_final_verify(query, summ, search_results, step_verify):
    from jinja2 import Template
    prompt_template = Template(

"""
你是专业的微博二次元人物年度寄语幻觉修复专家，专注于在待修正年度寄语原有内容基础上，检测并修正时间相关错误，剔除歧义、非正向内容，不引入新信息，确保内容准确、正面且贴合二次元风格。

### 背景信息
- 参考基准年：{{cur_date}}年（用于判断时间合理性）
- 二次元人物：{{query}}
- 待修正的年度寄语：{{award_summ}}
- 相关搜索结果：{{search_results}}

搜索结果均以[结果 X begin]...[结果 X end]格式呈现（X为结果数字索引），每个结果包含以下固定格式数据：
- 内容类型：[type begin]...[type end]（如“微博”）
- 博主昵称：[username begin]...[username end]（发博者昵称）
- 内容数据：[content begin]...[content end]（核心内容部分）
- 发布时间：[date begin]...[date end]（内容发布时间）
- 作者类别：[account type begin]...[account type end]（含“认证账号”“媒体账号”“大V账号”“普通账号”），各类别说明如下：
  ● 媒体账号：微博可信媒体账号，内容相对可信；
  ● 大V账号：微博高影响力、二次元领域专业性账号，内容相对专业可信；
  ● 认证账号：微博身份认证账号（身份真实但内容未必可信）；
  ● 普通账号：微博无认证普通用户账号（内容未必可信）。

### 任务要求
基于参考基准年{{cur_date}}年，对二次元人物{{query}}的年度寄语进行幻觉检测与修复，**仅在原有内容基础上操作，不新增任何未提及的信息**，重点处理**时间错误和非正向、歧义内容**：
1. 时间修正：修正/删除误标为{{cur_date}}年的内容，剔除非{{cur_date}}年且未误标时间的内容，仅保留当年真实的二次元相关信息。
2. 内容过滤：聚焦该二次元主体，移除歧义、非正向、争议及排名相关内容，基调积极。
3. 内容修正：摒弃与二次元无关的表述，不新增未提及的二次元作品、角色、事件等。

### 注意事项
- 优先采信高优先级搜索结果，信息不足按二次元领域常识处理。
- 120字内，用第三人称，禁止以“致...”开头，不提及非二次元相关内容。
- 包含二次元主体名称及正向已发生的相关作品名/事件，未发生事件需标注状态（仅限原有提及），语气积极，不重构核心语义。
- 字数要求：修正后需保证 80 字以上，若原有内容修正后不足 80 字，需在不引入新信息的前提下，补充贴合该二次元人物的表扬语句，确保内容连贯自然。


### 输出格式
直接输出修正后的纯文本年度寄语，无需额外说明。
""")
    prompt_base = prompt_template.render(
        award_summ=summ,
        query=query,
        search_results=search_results,
        cur_date='2025',
        step_verify=step_verify,
        debug=False
    )
    prompt_optim = prompt_template.render(
        award_summ=summ,
        query=query,
        search_results=search_results,
        step_verify=step_verify,
        cur_date='2025',
        debug=True
    )
    return prompt_base, prompt_optim