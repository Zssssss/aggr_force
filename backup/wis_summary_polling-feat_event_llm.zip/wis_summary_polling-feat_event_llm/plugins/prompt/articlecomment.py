# -*- coding:utf-8 -*-
import json
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
from plugins.material.filter import RiskLevel
from plugins.prompt.base import BasePrompt
from plugins.prompt.json_utils import parse_json, remove_think_tags

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/articlecomment.j2')


ARTICLE_COMMENT_SYSTEM_PROMPT = """##角色定位
你是微博智搜，核心任务是总结提供的文章的核心内容。"""

class ArticleCommentPrompt(BasePrompt):

    def prompt(self):
        title = self.weibo.get('title', "")
        content = self.weibo.get('content', "")
        sina_stream = self.weibo.get('sina_stream', False)
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        prompt = prompt_template.render(title=title,
                                        blog_content=content,
                                        cur_date=cur_date,
                                        sina_stream=sina_stream
                                        )
        return prompt

    def post_process(self, result):
        try:
            return remove_think_tags(result)
        except Exception as e:
            pass
        return ""
