# -*- coding:utf-8 -*-
from datetime import datetime
import re
import json

from plugins.prompt.base import BasePrompt
from plugins.post_process.filter_process import filter_invalid_str
from plugins.post_process.quote_process import standardize_quote


robot_prompt_tpl = """
以下内容是基于用户发送的/query：“{question}”的搜索结果:
{search_result}
深入理解用户需求，结合搜索结果和自身知识，只回答用户的问题，如果自身知识与搜索结果无冲突时，回答时无需限于搜索结果中的内容，可以使用自身知识。
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。如果回答中参考了相关搜索结果，在一段话的末尾引用对应的搜索结果。请按照引用编号[^X]的格式在答案中对应部分引用所参考的搜索结果。如果一句话参考了多个搜索结果，请列出所有相关的引用编号，例如[^3][^5]，切记不要将引用集中在最后返回引用编号，而是在答案对应部分列出，且回答结尾处不要输出任何引用说明内容。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。

在回答时，请注意以下几点：
- 今天是{cur_date}。
- 自身知识可以直接使用，无需添加引用或来源说明。
- 输出时直接给出简洁答案，重点信息放前面。
- 保持口语化，控制在100-140字，确保符合微博评论区风格。
- 并非搜索结果的所有内容都与用户的问题密切相关，你需要结合用户的需求与自身知识，对搜索结果进行甄别、筛选，然后输出符合用户需求的回答。
- 回答正文不能使用信息整合型句式开头（如“根据搜索结果...”、“结合多方信息...”）。
- 在输出时避免简单罗列具体账号（如@账号名）的内容，在生成结果的末尾部分，不要解释信息的来源，不要生成其他的引导语。
- 你的回答应该综合多个相关内容来回答，不能重复引用一个内容。

{question}："""



class RobotPrompt(BasePrompt):
    def prompt(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)

        # 新浪新闻
        if query.endswith("_sinanews"):
            query = modify_query

        content = self.weibo.get('content', "")

        cur_date = datetime.now().strftime('当前时间 %Y年%m月%d日.')


        prompt = robot_prompt_tpl.format(search_result=content, cur_date=cur_date, question=query)
        return prompt

    def remove_between_tags(self, text):
        # 使用正则表达式匹配<think>和</think>之间的内容，并将其替换为空字符串
        pattern = r'<think>.*?</think>'
        result = re.sub(pattern, '', text, flags=re.DOTALL)
        result = result.lstrip("\n")
        return result


    def replace_invalid_str_and_log(self, s: str, query: str, trace_id: str, weibo_link_index_list: list, ready: bool = False):
        """替换非法字符，并记录日志"""
        result, replaced_matches = standardize_quote(s, weibo_link_index_list)
        if (len(result) != len(s) or len(replaced_matches)) and ready:
            self.logger.info("traceid:{}\tquery:{}\treplaced_matches_len:{}\treplaced_matches:{}\tweibo_link_index_list:{}\tbefore_result:{}".format(
                trace_id, query, len(replaced_matches), replaced_matches, weibo_link_index_list, json.dumps(s, ensure_ascii=False)))
        return result


    def filter_invalid_str_and_log(self, s: str, query: str, trace_id: str, ready: bool = False):
        """过滤非法字符，并记录日志"""
        result, filtered_matches = filter_invalid_str(s)
        if len(result) != len(s) and ready:
            self.logger.info("traceid:{}\tquery:{}\tfiltered_matches_len:{}\tfiltered_matches:{}\tbefore_result:{}".format(
                trace_id, query, len(filtered_matches), filtered_matches, json.dumps(s, ensure_ascii=False)))
        return result
    

    def check_need_change(self, result):
        """检查是否需要更改"""
        if "wbCustomBlock" in result:
            return True
        if not self.weibo.get("verify_judge", True):
            return True
        return False


    def post_process(self, result):
        """后处理"""
        result = self.remove_between_tags(result)
        result = result.replace("\n","").replace("*","")
        query = self.weibo.get("query", "")
        trace_id = self.weibo.get("trace_id", "")
        if self.check_need_change(result):
            return "无法回答"
        ready = True
        weibo_link_index_list = []
        result = self.replace_invalid_str_and_log(result, query, trace_id, weibo_link_index_list, ready=ready)
        result = self.filter_invalid_str_and_log(result, query, trace_id, ready=ready)
        return result


def robot_factory(weibo):
    weibo['configs'] = []
    return RobotPrompt(weibo)
