# -*- coding:utf-8 -*-
import re
from datetime import datetime
import json
import traceback

from jinja2 import Template

from plugins.prompt.base import BasePrompt
from plugins.post_process.filter_process import filter_invalid_str, filter_jieguo_str
from plugins.post_process.utils import delete_empty_brackets


class NotifyVerifyPrompt(BasePrompt):
    """消息箱R1结果-验证"""
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """以下内容是基于用户查询的/query：“{{ question }}”近24小时的最新动态：
{{ result }}

以下内容是基于用户查询的/query：“{{ question }}”近24小时新增的搜索结果:
{%- if search_result %}
{{ search_result }}
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。
{%- endif %}
## 任务说明
根据近24小时新增的搜索结果，检验“{{ question }}”近24小时的最新动态是否存在以下问题，若存在则输出“是”，否则输出“否”：
- 存在错误内容。
- 无{{ yesterday_date }}至{{ today_date }}近24小时的最新事件或动态。

请按照以下格式输出你判断的结果：
<label>是/否</label>"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("query", "")
        search_result = self.weibo.get("content", "")
        result = self.weibo.get("notify_result_content", "")
        q_attr = self.weibo.get("q_attr", '')
        q_attr = json.loads(q_attr)
        yesterday_date = datetime.fromtimestamp(q_attr.get('start_ts')).strftime("%Y年%m月%d日%H点")
        today_date = datetime.fromtimestamp(q_attr.get('end_ts')).strftime("%Y年%m月%d日%H点")
       
        context = {
            "question": query,
            "search_result": search_result,
            "result": result,
            "yesterday_date": yesterday_date,
            "today_date": today_date
            }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nnotify verifyprompt is: \n{prompt}")
        return prompt

    def post_process(self, text):
        """
        从文本中提取<label></label>标签中的内容
        
        参数:
        text (str): 输入的文本字符串
        
        返回:
        str: 第一个<label>标签中的内容，如果未找到则返回None
        """
        if '</think>' in text:
            text = text.split('</think>')[-1]
        pattern = r'<label>(.*?)</label>'
        match = re.search(pattern, text)
        if match:
            return match.group(1)
        return ""
    


class NotifySummaryPrompt(BasePrompt):
    """消息箱R1结果"""
    def prompt(self):

        # 定义完整的Jinja模板
        template_str = """以下内容是基于用户查询的/query：“{{ question }}”的智搜总结：
- 昨日智搜总结（{{ yesterday_date }}）：
{{ yesterday_result }}

- 今日智搜总结（{{ today_date }}）
{{ today_result }}

以下内容是基于用户查询的/query：“{{ question }}”近24小时新增的搜索结果:
{%- if search_result %}
{{ search_result }}
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。请按照引用编号[^X]的格式在答案中对应部分引用所参考的搜索结果。如果一句话参考了多个搜索结果，请列出所有相关的引用编号，例如[^3][^5]，切记不要将引用集中在最后返回引用编号，而是在答案对应部分列出，且回答结尾处不要输出任何引用说明内容。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。
{%- endif %}

{%- if is_people %}
## 任务说明
给用户生成“{{question}}”本人近24小时的最新动态，基于提供的数据，对比{{yesterday_date}}与{{today_date}}的智搜总结内容，提取“{{question}}”本人新增的事件/信息，并利用近24小时新增搜索结果对新增的事件/信息逐一核验。动态内容严格限定为近24小时内、经明星本人/工作室官方账号或权威媒体等可靠来源验证的、以本人为主体的公开动态或商业/官方行为（如公开活动、节目官宣、品牌合作、媒体采访、作品发布等），不包含个人生活分享类社交发博。排除历史回顾、主观评论、未经证实的传闻、粉丝行为及非本人直接相关内容。若经全面核实无符合要求的动态，请直接输出 “无最新动态”，有符合要求的动态则直接输出“{{question}}”本人的近24小时最新动态。

{%- if search_result %}
## 搜索结果使用说明
- 近24小时新增的搜索结果仅用于核验新增的事件/信息的准确性。
{%- endif %}
## 生成要求
- 保留细节：确保关键事实、数据和人物细节等得到完整呈现。
- 除非用户要求，否则你回答的语言需要和用户提问的语言保持一致。
- 回答正文避免使用如“基于对比...智搜总结差异，并结合...新增结果”、“根据对比分析与新增信息”等形式的表述。
- 禁止在生成结果的开头和末尾部分输出相关注释或解释说明。
- 在输出时避免简单罗列具体账号（如@账号名）的内容，在生成结果的末尾部分，不要解释信息的来源。
## 内容组织和呈现要求
- 如果回答很长，请尽量结构化、分段落总结。如果需要分点作答，尽量控制在10个点以内，并合并相关的内容。
- 你需要根据用户要求和回答内容选择合适、美观的回答格式，确保可读性强。

{{ question }}近24小时的最新动态整理如下：
{%- else %}
## 任务说明
给用户生成“{{question}}”近24小时的最新动态，基于提供的数据，对比{{yesterday_date}}与{{today_date}}的智搜总结内容，提取“{{question}}”新增的事件/信息，并利用近24小时新增搜索结果对新增的事件/信息逐一核验。

{%- if search_result %}
## 搜索结果使用说明
- 近24小时新增的搜索结果仅用于核验新增的事件/信息的准确性。
{%- endif %}
## 生成要求
最新动态边界要求
- 动态内容严格限定为近24小时内、经官方账号或权威媒体等可靠来源验证的、以“{{question}}”为主体的公开动态或商业/官方行为。
- 排除历史回顾、主观评论、未经证实的传闻、粉丝行为及与“{{question}}”非直接相关的内容。
- 若经全面核实无符合要求的动态，请直接输出 “无最新动态”，有符合要求的动态则直接输出“{{question}}”的近24小时最新动态。

内容组织和呈现要求
- 保留细节：确保关键事实、数据和人物细节等得到完整呈现。
- 除非用户要求，否则你回答的语言需要和用户提问的语言保持一致。
- 回答正文避免使用如“基于对比...智搜总结差异，并结合...新增结果”、“根据对比分析与新增信息”等形式的表述。
- 禁止在生成结果的开头和末尾部分输出相关注释或解释说明。
- 在输出时避免简单罗列具体账号（如@账号名）的内容，在生成结果的末尾部分，不要解释信息的来源。
- 如果回答很长，请尽量结构化、分段落总结。如果需要分点作答，尽量控制在10个点以内，并合并相关的内容。
- 你需要根据用户要求和回答内容选择合适、美观的回答格式，确保可读性强。

{{ question }}近24小时的最新动态整理如下：
{%- endif %}"""
        # 创建模板
        template = Template(template_str)
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("query", "")
        search_result = self.weibo.get("content", "")
        q_attr = self.weibo.get("q_attr", '')
        q_attr = json.loads(q_attr)
        yesterday_date = datetime.fromtimestamp(q_attr.get('start_ts')).strftime("%Y年%m月%d日%H点")
        today_date = datetime.fromtimestamp(q_attr.get('end_ts')).strftime("%Y年%m月%d日%H点")
        q_4msg_type = q_attr.get('q_4msg_type', 'star')
        q_4msg_label = q_attr.get('q_4msg_label', '')
        is_people = False if q_4msg_type in ['ip', 'game_ip'] else True
        q_r1_res_list = self.weibo.get("q_r1_res_list", [])
        yesterday_result, today_result = q_r1_res_list[0], q_r1_res_list[1]
        parametric_knowledge = True
        if q_4msg_type == 'ip':
            keywords = ["电视剧", "综艺", "电影", "剧集", "短剧", "网剧"]
            for j in keywords:
                if j in query: 
                    q_4msg_label = ""
                    break
            query =  q_4msg_label + query
        elif q_4msg_type == 'game_ip':
            keywords = ["官方微博", "官博", "官微", "官方"]
            for j in keywords:
                if j in query: 
                    query = query.replace(j,"")
                    break
        else:
            # star/game_star
            if q_4msg_label:
                query = q_4msg_label + query
        # 准备实际数据
        context = {"question": query, "search_result": search_result, "yesterday_result": yesterday_result, "today_result": today_result,
                "yesterday_date":yesterday_date,"today_date":today_date}
        # 准备实际数据
        context = {
            "question": query,
            "search_result": search_result,
            "yesterday_result": yesterday_result,
            "today_result": today_result,
            "yesterday_date": yesterday_date,
            "today_date": today_date,
            "is_people": is_people,
        }
        # 渲染并输出
        prompt = template.render(**context).strip()
        self.logger.info(trace_id + f"\nNotify Summary prompt is: \n{prompt}")
        return prompt

    def post_process(self, text):

        """
        删除内容中"---\n"及后面的部分
        """

        def clean_references_strict(text):
            """
            严格清理：只保留纯数字引用，非纯数字引用完全删除
            """
            # 匹配所有引用标记
            pattern = r'\[\^([^\]]+)\]'
            
            def replace_match(match):
                content = match.group(1)
                # 检查内容是否只包含数字
                if content.isdigit():
                    return f'[^{content}]'
                else:
                    # 如果不是纯数字，返回空字符串（删除该引用）
                    return ''
            
            return re.sub(pattern, replace_match, text)

        def remove_parentheses_with_keywords(text, keywords=None):
            """
            删除包含特定关键词的中文括号及括号内的内容
            
            Args:
                text (str): 输入的文本
                keywords (list): 关键词列表，默认为["点", "至", "基于"]
                
            Returns:
                str: 处理后的文本
            """
            if keywords is None:
                keywords = ["点", "至", "基于", "核验"]
            
            # 构建正则表达式模式，匹配中文括号及内容
            # 使用非贪婪匹配，确保匹配到最近的右括号
            pattern = r'（[^）]*?(?:' + '|'.join(keywords) + r')[^）]*?）'
            
            # 使用正则表达式进行替换
            result = re.sub(pattern, '', text)
            
            return result
        
        def remove_last_paragraph_if_contains_keywords(text):
            """
            检测最后一段是否包含"排除"、"未纳入"或"主观评价"，
            如果包含则删除最后一段
            
            Args:
                text (str): 输入的文本内容
                
            Returns:
                str: 处理后的文本
            """
            # 定义关键词列表
            keywords = ["排除", "未纳入", "未涉及", "主观评价", "核验", "验证", "无新增", "无符合", "注：", "搜索结果", "历史回顾", "说明", "---", ">", "]:"]
            
            # 按段落分割文本（空行作为分隔符）
            paragraphs = text.split('\n\n')
            
            # 如果只有一段，检查是否包含关键词
            if len(paragraphs) == 1:
                if any(keyword in paragraphs[0] for keyword in keywords):
                    return ""
                else:
                    return text

            # 检查最后一段是否包含关键词
            last_paragraph = paragraphs[-1]
            if any(keyword in last_paragraph for keyword in keywords):
                # 删除最后一段
                return '\n\n'.join(paragraphs[:-1]).rstrip()
            else:
                # 返回原文本
                return text

        """
        删除内容中最后的"---"
        """
        if text[-3:] == "---":
            text = text[:-3]
        
        """
        删除文本中最后一个中文括号及括号中的内容
        """
        text = text.strip()
        # 匹配中文括号及括号内的所有内容（包括换行）
        pattern = r'（[^）]*）\s*$'
        # 使用re.sub进行替换，删除匹配到的内容
        result = re.sub(pattern, '', text, flags=re.DOTALL)

        result = remove_parentheses_with_keywords(result)

        text_temp = result.strip()
        res = remove_last_paragraph_if_contains_keywords(text_temp)

        if res[-3:] == "---":
            res = res[:-3]
        res = clean_references_strict(res)
        res = res.strip()
        return res


