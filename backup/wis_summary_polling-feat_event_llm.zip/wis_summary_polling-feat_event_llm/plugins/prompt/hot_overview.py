# -*- coding:utf-8 -*-
from datetime import datetime
import re

from plugins.prompt.base import BasePrompt


hot_overview_prompt_tpl = \
"""
以下内容是基于用户发送的/query：“{question}”的搜索结果:
{search_result}
结合搜索结果, 生成一句话概览式概况，帮助用户快速了解发生了什么，如果自身知识与搜索结果无冲突时，回答时无需限于搜索结果中的内容，可以使用自身知识。
在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。
每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”等。
- 百科知识内容往往经过审核和验证，内容一般来说较为可信。
- 资料是可能和查询相关的其他关键内容。
每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
- 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
- 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
- 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
- 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。

在回答时，请注意以下几点：
- 今天是{cur_date}。
- 总结的事件概述应语句通顺，并且精简、简洁，以确保最终字数限制在50字以内。
- 自身知识可以直接使用，无需添加引用或来源说明。
- 并非搜索结果的所有内容都与用户的问题密切相关，你需要结合问题与自身知识，对搜索结果进行甄别、筛选。
- 总结的正文不能使用信息整合型句式开头（如“根据搜索结果...”、“结合多方信息...”）。
- 在输出时避免简单罗列具体账号（如@账号名）的内容，在生成结果的末尾部分，不要解释信息的来源，不要生成其他的引导语。
- 在提及不确定的可能引起误解或具有争议的内容时，应使用谨慎的语言，避免将不确定的信息作为事实。
"""

# shot_content_promot = """"对下列总结，按照主题进一步进行精简，并保持原来的段落结构，要求生成的字数在80字以内，直接生成最终结果。不要重复输出主题。结果末尾不要生成全文的总字数。
# 主题：{query}

# 总结：{result}"""

cove_prompt_tpl = \
"""
以下内容是我提供给你的关于“{query}”的概述：
"{claim1}"

你的任务是根据我提供的要求或正确的事实内容修改提供给你的概述的对应内容；
以下是我提供的要求或正确的事实内容：
{knowledge}

修改要求：
- 仅修改与我提供的要求或正确事实内容相对应的部分。
- 修改后的内容应语句通顺，且整体字数限制在50字以内。
- 输出结果中不得包含任何其他额外信息。
严禁在开头输出“以下是按要求修改后的内容：”等类似内容。请直接输出满足要求的修改后的完整概述：
"""


class HotOverviewPrompt(BasePrompt):
    def prompt(self, first=True, last_result=''):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)

        # 新浪新闻
        if query.endswith("_sinanews"):
            query = modify_query

        cur_date = datetime.now().strftime('当前时间 %Y-%m-%d.')

        # if first:
        content = self.weibo.get('content', "")
        prompt_with_data = hot_overview_prompt_tpl.format(search_result=content, question=query, cur_date=cur_date)
        # else:
        #     prompt_with_data = shot_content_promot.format(query=query, result=last_result)
        return prompt_with_data

    def remove_between_tags(self, text):
        # 使用正则表达式匹配<think>和</think>之间的内容，并将其替换为空字符串
        pattern = r'<think>.*?</think>'
        result = re.sub(pattern, '', text, flags=re.DOTALL)
        result = result.lstrip("\n")
        return result


    def post_process(self, result):
        """后处理"""

        result = self.remove_between_tags(result).strip().replace("\n\n","\n")
        
        # 分段
        if "\n" not in result[:-1]:
            index = result.find("。")
            if index != -1 and index != (len(result) - 1):
                result = result[:index+1] + "\n" + result[index+1:]
        return result
    
class HVCovePrompt(HotOverviewPrompt):

    def prompt(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)

        # 新浪新闻
        if query.endswith("_sinanews"):
            query = modify_query

        # if first:
        claim1 = self.weibo.get('claim1', "")
        knowledge = self.weibo.get('knowledge', "")
        prompt_with_data = cove_prompt_tpl.format(query=query, claim1=claim1, knowledge=knowledge)
        # else:
        #     prompt_with_data = shot_content_promot.format(query=query, result=last_result)
        return prompt_with_data


def hot_overview_factory(weibo):
    weibo['configs'] = []
    return HotOverviewPrompt(weibo)

def hv_cove_factory(weibo):
    weibo['configs'] = []
    return HVCovePrompt(weibo)
