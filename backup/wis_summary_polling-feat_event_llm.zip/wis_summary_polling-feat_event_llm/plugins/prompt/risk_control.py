# -*- coding:utf-8 -*-
import json

from plugins.prompt.base import BasePrompt
from plugins.prompt.ds import ds_factory

import json, re
import numpy as np

from plugins.prompt.mid import mid_factory


class RiskControlPrompt(BasePrompt):
    def __init__(self, weibo):
        super().__init__(weibo)
        out_sample = [
            '重写结果0',
            '重写结果1'
        ]
        self.out_sample_str = json.dumps(out_sample, ensure_ascii=False, indent=2)
        self.pmt_fmt = '''你的任务是重写以下内容：
{sens_text}
因为它命中了风控策略。以下是详细说明：
{keyword_json}
说明：每行是一个 JSON，属性 `keywords` 表示命中的敏感词（列表形式），属性 `reason` 表示命中风控策略的原因。若 `keywords` 包含多个词，则表示这些词同时出现导致命中。

重写要求：
- 保留原文的 Markdown 结构，换行空格等空白符也完整保留，特别是开头结尾。
- 仅重写命中风控的关键部分，其余内容保持不变。
- 引用保持不变，引用的格式<a>[num]</a>，num是引用，比如：<a>[1]</a><a>[3]</a>。
- 每次生成 3 个不同的重写版本，并以 JSON 列表形式输出。
- 输出结果中不得包含任何额外信息。

输出示例：
{out_sample}

请直接输出符合要求的 JSON 列表。'''

    @staticmethod
    def get_sens_text_window(weibo):
        try:
            redis_info = weibo.get('risk_control', {})
            ori_content = redis_info.get('ori_content', '')
            content_text = redis_info.get('content', '')
            sens_reason_str = redis_info.get('sens_reason', '[]')
            if not ori_content or not content_text or not sens_reason_str:
                return None
            # 不改写“涉习自动私关键词合集”
            if '"涉习自动' in sens_reason_str:
                return None

            ori_content_text = ori_content.split('</think>')[-1]
            content_text = content_text.split('</think>')[-1]
            try:
                sens_reason = json.loads(sens_reason_str)
            except:
                return None
            data = []
            for sens_item in sens_reason:
                for txt, si_info in sens_item.items():
                    if txt not in ori_content_text:
                        continue
                    if txt in content_text:
                        continue
                    idx = ori_content_text.find(txt)
                    if idx < 0:
                        continue
                    item = {
                        'text': txt,
                        'start_idx': idx
                    }
                    if isinstance(si_info, str):
                        try:
                            si_info = json.loads(si_info)
                        except:
                            continue
                    if not isinstance(si_info, dict):
                        continue
                    keywords_dict = {}
                    if 'kwdt_results' in si_info:
                        for t in si_info['kwdt_results']:
                            kw_list = t['keyword'].split(':)')
                            kw_list.sort()
                            kw_key = ' '.join(kw_list)
                            keywords_dict[kw_key] = kw_list
                    elif 'matched_info' in si_info:
                        for t in si_info['matched_info']:
                            for kw_list in t['words'].split('|'):
                                kw_list = kw_list.split(' ')
                                kw_list.sort()
                                kw_key = ' '.join(kw_list)
                                keywords_dict[kw_key] = kw_list
                    item['kw_list'] = []
                    for kw_list in keywords_dict.values():
                        flag = True
                        for w in kw_list:
                            if w.lower() not in txt.lower():
                                flag = False
                        if flag:
                            item['kw_list'].append(kw_list)
                    if item['kw_list']:
                        data.append(item)
            weibo['sens_kw_list'] = data
            data.sort(key=lambda x: x['start_idx'])
            if not data:
                return None
            return data[0]
        except Exception as e:
            pass
        return None
        
    def prompt(self):
        trace_id = self.weibo.get("trace_id", "")
        sens_text = ''
        keyword_json = ''
        sens_info = self.weibo.get('sens_kw_list', [])
        self.logger.info('{} sens_info: {}'.format(trace_id, sens_info))
        if sens_info:
            sens_info = sens_info[0]
            sens_text = sens_info['text']
            keyword_json = '\n'.join(json.dumps({'keywords': kw, 'reason': ''}, ensure_ascii=False) for kw in sens_info['kw_list'][:10])
        self.weibo['sens_text'] = sens_text
        pmt = self.pmt_fmt.format(sens_text=json.dumps(sens_text, ensure_ascii=False), keyword_json=keyword_json, out_sample=self.out_sample_str)
        return pmt


    def post_process(self, result):
        def parse_result(content):
            re_temp = re.compile(r'\[[\s\S]+\]')
            re_res = re_temp.search(content)
            res = []
            if re_res:
                try:
                    txt = re_res.group()
                    txt1 = txt.replace('\n', '\t'*8)
                    txt1_res = eval(txt1)
                    res = eval(str(txt1_res).replace('\\t'*8, '\\n'))
                except:
                    pass
            return res
        
        def cmp_txt(txt0, txt1):
            c0 = set(txt0)
            c1 = set(txt1)
            c_union = c0 | c1
            c_inter = c0 & c1
            d = len(c_inter) / len(c_union)
            if d > 0.5:
                return True
            return False

        query = self.weibo.get('query', '')
        trace_id = self.weibo.get("trace_id", "")
        redis_info = self.weibo.get('risk_control', {})
        ori_content = redis_info.get('ori_content', '')
        if ori_content and '</think>' not in ori_content:
            self.logger.error('{} no think end ori_content: {}'.format(trace_id, json.dumps(ori_content, ensure_ascii=False)))
            raise Exception('no think end')

        ori_content_text = ori_content.split('</think>')[-1]
        
        sens_text = self.weibo['sens_text']
        result_content = result.split('</think>')[-1]
        result_json = parse_result(result_content)
        if result_json and isinstance(result_json[0], str):
            result_rw = result_json[0]
            self.logger.info('query: {}, trace_id: {} result_rw: {}, sens_text: {}'.format(query, trace_id, json.dumps(result_rw), json.dumps(sens_text)))
            flag = cmp_txt(sens_text, result_rw)
            if flag:
                ori_content_sub = ori_content_text.replace(sens_text, result_rw)
                content = redis_info.get('content', '')
                content_think = content.split('</think>')[0]
                result_new = content_think + '</think>' + ori_content_sub
                self.weibo['sens_text_rw'] = result_rw
                # self.weibo['sens_rw_result'] = result
                self.weibo['is_risk_control'] = 2
                return result_new
        return ori_content


def risk_control_factory(weibo):
    llm_name = weibo.get("llm_name", {})
    risk_control = weibo.get("risk_control", {})
    if not risk_control or not RiskControlPrompt.get_sens_text_window(weibo):
        return mid_factory(weibo) if llm_name == 'deepseek_verification' else ds_factory(weibo)

    # 回传结果需要的字段
    weibo['link_list'] = json.loads(risk_control.get('link_list', "[]") or "[]")
    weibo['card_multimodal'] = json.loads(risk_control.get("card_multimodal", "{}") or '{}')
    weibo['share_card_multimodal'] = json.loads(risk_control.get("share_card_multimodal", "{}") or '{}')

    weibo['configs'] = []
    weibo['is_risk_control'] = 1
    return RiskControlPrompt(weibo)


if __name__ == '__main__':
    weibo = {
        'redis_info': {'blacked': '0', 'blacked_json': '0', 'content': '<think>\n\n</think>\n\n关于导演马进的相关事件，综合多方信息梳理如下：\n\n### 一、案件基本情况\n1. **判决与刑期**：导演马进被曝于2021年8月因强奸罪被判处三年有期徒刑，目前已刑满出狱。案件涉及一名女演员，法院判决后相关信息未在当年公开<a>[2]</a><a>[19]</a><a>[20]</a>。\n2. **案件细节**：据称，马进在剧组对女演员实施侵犯，受害者在酒店内报警，证据确凿后马进认罪<a>[20]</a><a>[47]</a>。\n\n### 二、舆论争议焦点\n1. **受害者隐私泄露**：\n   - 狗仔账号“懂瓜呱”在爆料中公开了受害者姓名、照片及背景信息，引发公众强烈批评。多数网友认为此举构成二次伤害，且违反刑事案件中保护受害者的基本原则<a>[1]</a><a>[4]</a><a>[7]</a><a>[22]</a><a>[24]</a><a>[58]</a>。\n   - 微博官方以“暴露隐私”“恶意炒作”为由，对“懂瓜呱”账号先实施90天禁言，后追加永久封禁<a>[1]</a><a>[44]</a><a>[49]</a><a>[56]</a>。\n\n2. **对媒体伦理的质疑**：\n   - 部分内容强调受害者外形、职业背景等细节，被指利用“知名女星”标签博取流量，偏离对施害者的批判<a>[77]</a><a>[79]</a><a>[86]</a><a>[94]</a>。\n   - 舆论呼吁媒体应聚焦施暴者，避免消费受害者，并建议采用“某导演因强奸入狱”等中性表述<a>[85]</a><a>[89]</a><a>[92]</a>。\n\n### 三、行业与社会反应\n1. **法律与道德讨论**：\n   - 网友质疑强奸罪量刑过轻（三年有期徒刑），认为刑罚威慑力不足，建议参考其他国家加重刑罚（如鞭刑）<a>[5]</a><a>[76]</a>。\n   - 部分声音指出，马进出狱后仍可能参与影视工作，要求行业对其作品实施封杀<a>[75]</a><a>[114]</a>。\n\n2. **对行业生态的反思**：\n   - 事件引发对娱乐圈权力滥用的批评，业内人士揭露行业内存在系统性侵害风险，呼吁建立更安全的从业环境<a>[98]</a>。\n   - 公众关注焦点从单一案件延伸至对行业监管的期待，要求司法部门严惩类似犯罪行为<a>[98]</a><a>[122]</a>。\n\n### 四、未解疑问与争议\n1. **爆料动机存疑**：\n   - 有观点认为，案件时隔三年被曝光，可能是马进出狱后的报复行为，或涉及行业资源争夺<a>[9]</a><a>[54]</a><a>[78]</a><a>[108]</a>。\n   - 部分网友质疑狗仔与平台共谋炒作，要求追究泄露隐私的法律责任<a>[41]</a><a>[62]</a><a>[70]</a>。\n\n2. **信息真实性待验证**：\n   - 百度百科曾短暂出现“马进因强奸被判刑”词条，但未获官方通报或权威媒体确认<a>[6]</a>。\n\n### 五、后续进展\n1. **平台治理**：微博加强对类似爆料的审核，强调对受害者隐私的保护，并处理了多个关联账号<a>[1]</a><a>[44]</a><a>[56]</a>。\n2. **司法程序**：尚无证据表明受害者对狗仔提起法律诉讼，但舆论持续呼吁通过司法途径追责<a>[17]</a><a>[62]</a>。\n\n该事件折射出刑事案件报道中隐私保护与公众知情权的平衡难题，同时凸显娱乐圈权力结构与道德风险的深层矛盾。', 'content_json': '', 'error': 'no', 'get_time_grade': 'strong', 'high_quality': '', 'is_less_old_res': '0', 'label': 'ds', 'link_list': '["sinaweibo://detail?mblogid=5138047550358123", "sinaweibo://detail?mblogid=5138023689224985", "sinaweibo://detail?mblogid=5138116152132075", "sinaweibo://detail?mblogid=5138019084665529", "sinaweibo://detail?mblogid=5138047817748403", "sinaweibo://detail?mblogid=5138016316165337", "sinaweibo://detail?mblogid=5138013677422937", "sinaweibo://detail?mblogid=5138013863284553", "sinaweibo://detail?mblogid=5138013227320953", "sinaweibo://detail?mblogid=5138016211571070", "sinaweibo://detail?mblogid=5138015506140239", "sinaweibo://detail?mblogid=5138036839416424", "sinaweibo://detail?mblogid=5138017633175296", "sinaweibo://detail?mblogid=5138056678476088", "sinaweibo://detail?mblogid=5138024553776595", "https://baike.baidu.com/item/\\u9a6c\\u8fdb?fromModule=lemma_search-box", "sinaweibo://detail?mblogid=5138033162847192", "sinaweibo://detail?mblogid=5138014426631091", "sinaweibo://detail?mblogid=5138068005978644", "sinaweibo://detail?mblogid=5138044480130310", "sinaweibo://detail?mblogid=5138067705041157", "sinaweibo://detail?mblogid=5138077220079080", "sinaweibo://detail?mblogid=5138019642508453", "sinaweibo://detail?mblogid=5138014324133823", "sinaweibo://detail?mblogid=5138016534793227", "sinaweibo://detail?mblogid=5138015173477083", "sinaweibo://detail?mblogid=5138011282735434", "sinaweibo://detail?mblogid=5138011362689064", "sinaweibo://detail?mblogid=5138017326728724", "sinaweibo://detail?mblogid=5138017540901480", "sinaweibo://detail?mblogid=5138020875114725", "sinaweibo://detail?mblogid=5138019420737712", "sinaweibo://detail?mblogid=5138021956977147", "sinaweibo://detail?mblogid=5138011652100290", "sinaweibo://detail?mblogid=5138016701780435", "sinaweibo://detail?mblogid=5138012566194212", "sinaweibo://detail?mblogid=5138012537095179", "sinaweibo://detail?mblogid=5138024222166430", "sinaweibo://detail?mblogid=5138021519458364", "sinaweibo://detail?mblogid=5138015466821319", "sinaweibo://detail?mblogid=5138019774628137", "sinaweibo://detail?mblogid=5138237697821961", "sinaweibo://detail?mblogid=5138002232476321", "sinaweibo://detail?mblogid=5138089241215242", "sinaweibo://detail?mblogid=5138044158216908", "sinaweibo://detail?mblogid=5138063330646483", "sinaweibo://detail?mblogid=5138091258676351", "sinaweibo://detail?mblogid=5138080451002440", "sinaweibo://detail?mblogid=5138039699410560", "sinaweibo://detail?mblogid=5138013967614500", "sinaweibo://detail?mblogid=5138013977840706", "sinaweibo://detail?mblogid=5138012759396007", "sinaweibo://detail?mblogid=5138014025810099", "sinaweibo://detail?mblogid=5138020177024371", "sinaweibo://detail?mblogid=5138016450380269", "sinaweibo://detail?mblogid=5138025831465548", "sinaweibo://detail?mblogid=5138014373678908", "sinaweibo://detail?mblogid=5138014187817802", "sinaweibo://detail?mblogid=5138013849652008", "sinaweibo://detail?mblogid=5138014947772753", "sinaweibo://detail?mblogid=5138013881371265", "sinaweibo://detail?mblogid=5138030992559680", "sinaweibo://detail?mblogid=5138024694546591", "sinaweibo://detail?mblogid=5138031063861914", "sinaweibo://detail?mblogid=5138023896056549", "sinaweibo://detail?mblogid=5138016224677152", "sinaweibo://detail?mblogid=5138015371924110", "sinaweibo://detail?mblogid=5138018912440847", "sinaweibo://detail?mblogid=5137936134181456", "sinaweibo://detail?mblogid=5138016283136894", "sinaweibo://detail?mblogid=5138021865752007", "sinaweibo://detail?mblogid=5138011123354594", "sinaweibo://detail?mblogid=5138035058937160", "sinaweibo://detail?mblogid=5138061831966559", "sinaweibo://detail?mblogid=5138047266722395", "sinaweibo://detail?mblogid=5138075055557508", "sinaweibo://detail?mblogid=5138091533140187", "sinaweibo://detail?mblogid=5138054367676725", "sinaweibo://detail?mblogid=5137880246650604", "sinaweibo://detail?mblogid=5137903978286584", "sinaweibo://detail?mblogid=5137970552902011", "sinaweibo://detail?mblogid=5137971302369349", "sinaweibo://detail?mblogid=5137935129121978", "sinaweibo://detail?mblogid=5137922834305382", "sinaweibo://detail?mblogid=5137939929501025", "sinaweibo://detail?mblogid=5138004426100301", "sinaweibo://detail?mblogid=5137924272949414", "sinaweibo://detail?mblogid=5137926291724399", "sinaweibo://detail?mblogid=5137960499155325", "sinaweibo://detail?mblogid=5137969188700886", "sinaweibo://detail?mblogid=5137920684200659", "sinaweibo://detail?mblogid=5137991559285225", "sinaweibo://detail?mblogid=5137941032339490", "sinaweibo://detail?mblogid=5138011220607184", "sinaweibo://detail?mblogid=5138028541772445", "sinaweibo://detail?mblogid=5137930846997551", "sinaweibo://detail?mblogid=5137957965268082", "sinaweibo://detail?mblogid=5137951473011734", "sinaweibo://detail?mblogid=5137918039429225", "sinaweibo://detail?mblogid=5137927028080795", "sinaweibo://detail?mblogid=5137915562688679", "sinaweibo://detail?mblogid=5137923152285578", "sinaweibo://detail?mblogid=5137915552205029", "sinaweibo://detail?mblogid=5137945495867457", "sinaweibo://detail?mblogid=5137956115319516", "sinaweibo://detail?mblogid=5137931272716752", "sinaweibo://detail?mblogid=5137940099370015", "sinaweibo://detail?mblogid=5138026747922362", "sinaweibo://detail?mblogid=5137943482598006", "sinaweibo://detail?mblogid=5137996339219639", "sinaweibo://detail?mblogid=5137932293768105", "sinaweibo://detail?mblogid=5137923290694815", "sinaweibo://detail?mblogid=5137975636132515", "sinaweibo://detail?mblogid=5138015118688928", "sinaweibo://detail?mblogid=5137919331798022", "sinaweibo://detail?mblogid=5137916470236027", "sinaweibo://detail?mblogid=5137922263880494", "sinaweibo://detail?mblogid=5137981214821571", "sinaweibo://detail?mblogid=5137881452511735", "sinaweibo://detail?mblogid=5137915610399185", "sinaweibo://detail?mblogid=5137921970275620", "sinaweibo://detail?mblogid=5137939774575630", "sinaweibo://detail?mblogid=5137927380928963", "sinaweibo://detail?mblogid=5137929956229820", "sinaweibo://detail?mblogid=5137927255099680", "sinaweibo://detail?mblogid=5137611805692348"]', 'local_blacked': '1', 'ori_content': '<think>\n\n</think>\n\n关于导演马进的相关事件，综合多方信息梳理如下：\n\n### 一、案件基本情况\n1. **判决与刑期**：导演马进被曝于2021年8月因强奸罪被判处三年有期徒刑，目前已刑满出狱。案件涉及一名女演员，法院判决后相关信息未在当年公开<a>[2]</a><a>[19]</a><a>[20]</a>。\n2. **案件细节**：据称，马进在剧组对女演员实施侵犯，受害者在酒店内报警，证据确凿后马进认罪<a>[20]</a><a>[47]</a>。\n\n### 二、舆论争议焦点\n1. **受害者隐私泄露**：\n   - 狗仔账号“懂瓜呱”在爆料中公开了受害者姓名、照片及背景信息，引发公众强烈批评。多数网友认为此举构成二次伤害，且违反刑事案件中保护受害者的基本原则<a>[1]</a><a>[4]</a><a>[7]</a><a>[22]</a><a>[24]</a><a>[58]</a>。\n   - 微博官方以“暴露隐私”“恶意炒作”为由，对“懂瓜呱”账号先实施90天禁言，后追加永久封禁<a>[1]</a><a>[44]</a><a>[49]</a><a>[56]</a>。\n\n2. **对媒体伦理的质疑**：\n   - 部分内容强调受害者外形、职业背景等细节，被指利用“知名女星”标签博取流量，偏离对施害者的批判<a>[77]</a><a>[79]</a><a>[86]</a><a>[94]</a>。\n   - 舆论呼吁媒体应聚焦施暴者，避免消费受害者，并建议采用“某导演因强奸入狱”等中性表述<a>[85]</a><a>[89]</a><a>[92]</a>。\n\n### 三、行业与社会反应\n1. **法律与道德讨论**：\n   - 网友质疑强奸罪量刑过轻（三年有期徒刑），认为刑罚威慑力不足，建议参考其他国家加重刑罚（如鞭刑）<a>[5]</a><a>[76]</a>。\n   - 部分声音指出，马进出狱后仍可能参与影视工作，要求行业对其作品实施封杀<a>[75]</a><a>[114]</a>。\n\n2. **对行业生态的反思**：\n   - 事件引发对娱乐圈权力滥用的批评，业内人士揭露行业内存在系统性侵害风险，呼吁建立更安全的从业环境<a>[98]</a>。\n   - 公众关注焦点从单一案件延伸至对行业监管的期待，要求司法部门严惩类似犯罪行为<a>[98]</a><a>[122]</a>。\n\n### 四、未解疑问与争议\n1. **爆料动机存疑**：\n   - 有观点认为，案件时隔三年被曝光，可能是马进出狱后的报复行为，或涉及行业资源争夺<a>[9]</a><a>[54]</a><a>[78]</a><a>[108]</a>。\n   - 部分网友质疑狗仔与平台共谋炒作，要求追究泄露隐私的法律责任<a>[41]</a><a>[62]</a><a>[70]</a>。\n\n2. **信息真实性待验证**：\n   - 百度百科曾短暂出现“马进因强奸被判刑”词条，但未获官方通报或权威媒体确认<a>[6]</a>。\n   - 马进过往作品（如《春风十里不如你》《鹿鼎记》）的公开资料未提及相关案件，其本人尚未回应<a>[16]</a><a>[20]</a>。\n\n### 五、后续进展\n1. **平台治理**：微博加强对类似爆料的审核，强调对受害者隐私的保护，并处理了多个关联账号<a>[1]</a><a>[44]</a><a>[56]</a>。\n2. **司法程序**：尚无证据表明受害者对狗仔提起法律诉讼，但舆论持续呼吁通过司法途径追责<a>[17]</a><a>[62]</a>。\n\n该事件折射出刑事案件报道中隐私保护与公众知情权的平衡难题，同时凸显娱乐圈权力结构与道德风险的深层矛盾。', 'ori_content_json': '', 'q_attr': '{"strategy_source":1,"orifid":"100013098047004","lfid":"100013098047004","qwen72b":1,"qwen72b_stream":1,"deepseek":1,"deepseek_stream":1,"mtop5_diff_num":2,"m_top5_status":1,"m_top5_40diff_status":1,"m_top3_status":1,"m_top10_status":1,"old_high_level":3,"action_from":3011,"sens_status":2,"m_use_counts":36,"new_high_level":3,"async":1}', 'query_category': 'Gossip', 'reference_num': '125', 'sens_reason': '[{"\\n   - 马进过往作品（如《春风十里不如你》《鹿鼎记》）的公开资料未提及相关案件，其本人尚未回应<a>[16]<\\/a><a>[20]<\\/a>。":"{\\"filter\\":true,\\"matched_info\\":[{\\"words\\":\\"春风十里不如你 1\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545240,\\"etime\\":1893427200},{\\"words\\":\\"春风十里不如你 2\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545240,\\"etime\\":1893427200},{\\"words\\":\\"春风十里不如你 6\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545240,\\"etime\\":1893427200},{\\"words\\":\\"春风十里不如你 16\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545256,\\"etime\\":1893427200},{\\"words\\":\\"春风十里不如你 20\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545256,\\"etime\\":1893427200},{\\"words\\":\\"春风十里 不如你 1\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545256,\\"etime\\":1893427200},{\\"words\\":\\"春风十里 不如你 2\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545256,\\"etime\\":1893427200},{\\"words\\":\\"春风十里 不如你 6\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545256,\\"etime\\":1893427200},{\\"words\\":\\"春风十里 不如你 16\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545256,\\"etime\\":1893427200},{\\"words\\":\\"春风十里 不如你 20\\",\\"level\\":5,\\"polity\\":0,\\"user_type\\":0,\\"user_vtype\\":0,\\"user_vlevel\\":0,\\"user_status\\":0,\\"resrc_type\\":19,\\"btime\\":1500545256,\\"etime\\":1893427200}],\\"H_default_rule\\":\\"1|1_1_3|0_2_4_5_6||,1|1_1_3|0_2_4_5_6||,\\\\u0002\\"}"},{}]', 'sens_reason_json': '[{},{}]', 'source': '99', 'status': '2', 'status_stage': '0', 'time': '1740565702', 'version': '2025-02-26 18:27:02.468461-3213'}
    }
    rcp = RiskControlPrompt(weibo)
    pmt = rcp.prompt()
    result = '''[
  "  - 马进过往作品（如《某部青春题材剧作》《鹿鼎记》）的公开资料未提及相关案件，其本人尚未回应<a>[16]</a><a>[20]</a>。",
  "  - 马进此前参与制作的《春风系列作品》及《鹿鼎记》等影视项目的公开信息中，均未发现案件相关记录，其本人暂未作出回应<a>[16]</a><a>[20]</a>。",
  "  - 在《鹿鼎记》等马进参与创作的影视作品公开档案中，尚未查询到与案件相关的记载，当事人目前保持沉默<a>[16]</a><a>[20]</a>。",
  "  - 经查证马进影视作品档案（含经典改编剧作等），未见涉及该案件的公开信息，创作者本人仍未就事件表态<a>[16]</a><a>[20]</a>。",
  "  - 马进参与制作的影视项目（包括但不限于古装题材作品）公开资料中，均无该案件相关信息披露，相关方暂未发表声明<a>[16]</a><a>[20]</a>。"
]'''
    result = '''[
  "\n   - 马进过往作品（如《春风十里》《鹿鼎记》等）的公开资料未提及相关案件，其本人尚未回应<a>[16]</a><a>[20]</a>。",
  "\n   - 马进曾参与制作的某青春题材剧集及其他作品（如《鹿鼎记》）公开资料中未见案件关联信息，其本人尚未回应<a>[16]</a><a>[20]</a>。",
  "\n   - 马进涉及的多部影视作品（包括某知名都市剧与《鹿鼎记》）公开信息均未涉及该案件，其本人尚未作出回应<a>[16]</a><a>[20]</a>。"
]'''
    result = '''<think>
好的，我现在需要处理用户的这个任务，重写一段关于风控策略的内容。首先，我得仔细阅读用户的要求，确保完全理解。用户希望保留原有的Markdown结构，包括换行和空格，特别是开头和结尾的部分。这意味着我不能改动任何格式，只能修改命中风控的关键部分。

接下来，用户提到要保留引用格式，比如<a>[1]</a>这样的部分，所以在重写时不能动这些引用链接。然后需要生成三个不同的版本，每个版本只修改敏感词和原因部分，其他内容不变。同时，输出必须是JSON列表，不能有其他信息。

首先，我需要分析原文的结构。原文有两部分，keywords和reason，每行是一个JSON对象。重写的时候需要替换其中的keywords列表和reason描述，但保持JSON结构不变。例如，原来的keywords可能有多个词，导致reason中的解释需要相应调整。

然后，我要考虑如何生成不同的重写版本。可能的策略包括替换不同的敏感词组合，或者调整原因的描述方式。例如，第一个版本可能使用“违规用语”和“组合触发”，第二个版本可能用“不当内容”和“关联风险”，第三个版本可能用“禁用词汇”和“策略规则”。

需要注意的是，每次生成时，keywords里的词要不同，同时reason要对应这些关键词的出现情况。如果keywords有多个词，reason要说明是同时出现导致的命中。比如，如果keywords是["广告", "推广"]，那么reason可能是“检测到广告和推广同时存在”。

另外，必须确保生成的每个版本都符合用户的所有要求，特别是保留原有的空白符和结构。这可能涉及到检查每个生成的版本是否与原格式完全一致，除了keywords和reason部分。

最后，要将三个版本以正确的JSON格式输出，没有额外的说明或标记，确保直接可用。可能需要验证JSON的语法是否正确，比如引号的使用和逗号分隔。

总结步骤：
1. 确定需要修改的部分：keywords和reason。
2. 生成三个不同的keywords组合，每个组合包含不同的敏感词。
3. 为每个keywords组合编写对应的reason，说明同时出现的原因。
4. 保持其他所有内容不变，包括格式和引用。
5. 验证每个版本是否符合要求，输出为JSON列表。

现在，开始具体生成内容。例如，第一个版本可能使用“广告”和“推广”，第二个用“虚假”和“欺诈”，第三个用“违禁品”和“药品”。对应的reason需要说明这些词同时出现触发了风控策略。这样就能生成三个不同的重写版本，满足用户的需求。

</think>


[
  "因为它触发了风险控制机制。以下是详细说明：\n\n说明：每行是一个 JSON，属性 `keywords` 表示关联的违禁词汇（列表形式），属性 `reason` 表示触发风控的依据。若 `keywords` 包含多个词，则表示这些词汇存在关联性触发规则。",
  "因为它被系统策略拦截。以下是详细说明：\n\n说明：每行是一个 JSON，属性 `keywords` 表示检测到的违规术语（列表形式），属性 `reason` 表示拦截策略的判断依据。多个 `keywords` 条目代表存在复合型触发条件。",
  "因为它不符合内容安全规范。以下是详细说明：\n\n说明：每行是一个 JSON，属性 `keywords` 表示识别到的限制性词汇（列表形式），属性 `reason` 表示触发管控的具体规则。当 `keywords` 含多词时，代表存在协同作用导致拦截。"
]'''
    result1 = rcp.post_process(result)
    print(pmt)
    print('new result')
    print(result1)
    print('content')
    print(weibo['redis_info']['content'])
    print('ori_content')
    print(weibo['redis_info']['ori_content'])