# -*- coding:utf-8 -*-
import re
from datetime import datetime

from plugins.prompt.base import BasePrompt

cur_prompt_template = """以下内容是基于用户发送的/query：“{question}”的搜索结果:
    {search_results}
    深入理解用户需求，结合搜索结果和自身知识，回答好用户的问题，如果自身知识与搜索结果无冲突时，回答时无需限于搜索结果中的内容，可以使用自身知识。
    在我给你的搜索结果中，每个结果都是[结果 X begin]...[结果 X end]格式的，X代表每个结果的数字索引。
    每个结果中的数据类型都是[type begin]...[type end]格式，内容类型包括“微博”，“文章”，“百科”，“资料”，“网页”等。
    - 百科知识内容往往经过审核和验证，内容一般来说较为可信。
    - 资料是可能和查询相关的其他关键内容。
    每个结果中的博主昵称都是[username begin]...[username end]格式，是每个搜索结果中的发博者昵称。
    每个结果中的内容数据都是[content begin]...[content end]格式，是每个搜索结果中的内容部分。
    每个结果中的发布时间数据都是[date begin]...[date end]格式，是每个搜索结果的发布时间。
    每个结果中的作者类别数据都是[account type begin]...[account type end]格式，用于标识发布内容的账号类型，包括“认证账号”、“媒体账号”、“大V账号”和“普通账号”，其中：
    - 媒体账号：微博中的可信媒体账号，对应结果中的内容相对可信；
    - 大V账号：微博中具有较高影响力和专业性的账号，提供的结果相对专业可信；
    - 认证账号：微博中有认证身份的账号，发布者身份进行了真实性审核，提供的内容未必可信；
    - 普通账号：微博中无认证的普通用户账号，提供的内容未必可信。
    
    在回答时，请注意以下几点：
    - 今天是{cur_date}。
    - 回答务必和/query: “{question}”密切相关。只输出高度相关的内容。
    - 输出结构优先呈现关键内容。如果query是问题，不要重复问题，在开头直接回答。
    - 回答的字数控制在250字左右。
    - 生成结果优先参考最新、权威、可信内容。
    - 自身知识可以直接使用，无需添加引用或来源说明。
    - 并非搜索结果的所有内容都与用户的问题密切相关，你需要结合用户的需求与自身知识，对搜索结果进行甄别、筛选，然后输出符合用户需求的回答。
    - 回答正文不能使用信息整合型句式开头（如“根据搜索结果...”、“结合多方信息...”）。
    - 你需要根据用户要求和回答内容选择合适、美观的回答格式，确保可读性强。
    - 除非用户要求，否则你回答的语言需要和用户提问的语言保持一致。
    - 在提及不确定的可能引起误解或具有争议的内容时，应使用谨慎的语言，避免将不确定的信息作为事实。
    
    {question}："""

class Qwen3XiaoYiPrompt(BasePrompt):

    def prompt(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)

        # 新浪新闻
        if query.endswith("_sinanews"):
            query = modify_query
        content = self.weibo.get('content', "")
        cur_date = datetime.now().strftime(' %Y-%m-%d')
        prompt = cur_prompt_template.format(search_results=content, question=query, cur_date=cur_date)
        return prompt

    @staticmethod
    def filter_invalid_str(s: str):
        """过滤非法字符，返回过滤后的字符串，当前过滤策略：
        [^2-^32]、[^2~^32]、(结果2][23)、(结果2)、(参考结果2、3)、(注:以下)、(图片示例：此为示例图片)、^[result=1]^
        """
        pattern_list = [r"[*#\"”“ ]", r"</?think>", r"\[\^\d+[\-\~]\^\d+\]", r"[\(（\[【](?:参考|如|)结果\d+(?:(?:[\]\[]+|、)\d+)*[\)）\]】]",
            r"[\(（][^\n\(（\)）]*[\)）]", r"[\[\^]+\d+[\]\^]+", r"[\[\^@_]+result[=_]*\d+[\]\^]+", r"[\(（\[【][\)）\]】]", r"[\(（][^\n\(（\)）]*$"]
        result = s
        all_deleted_matches = []
        for pattern in pattern_list:
            # 查找所有需要删除的字符
            deleted_matches = re.findall(pattern, result)
            # 替换掉不符合条件的部分
            result = re.sub(pattern, '', result)
            # 更新删除字符列表
            all_deleted_matches.extend(deleted_matches)
        return result, list(set(all_deleted_matches))


    def post_process(self, result):
        ori_result = result
        result, all_deleted_matches = self.filter_invalid_str(result)
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        trace_id = self.weibo.get("trace_id", "")
        ready = self.weibo.get("output_all_ready", False)
        result = re.sub(r"\n", "", result)
        if ready and len(all_deleted_matches) > 0:
            self.logger.info(f"trace_id:{trace_id} query:{query} all_deleted_matches:{all_deleted_matches}, ori_result:{ori_result}")
        return result


def xiaoyi_factory(weibo):
    weibo['configs'] = []
    return Qwen3XiaoYiPrompt(weibo)
