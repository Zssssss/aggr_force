# -*- coding:utf-8 -*-
import re
import plugins.prompt.reason_struct
from plugins.prompt.base import BasePrompt


OV_OUTPUT_SAMPLE = """严格按照输出示例的格式输出。
    <输出示例>
    {
        '概况': [
            {
                "概况正文": "",
                '引用博文序号': []
            },
        ]
    }"""

OV_TASK_DES = """<任务描述> 请你仔细阅读并深刻理解与“{query}”相关的内容集合/content，你的任务是：围绕主题词“{query}”进行内容分析与整理，并生成一系列概况，然后严格按照<输出示例>生成json。
总结生成概况时，应严格遵守以下<通用要求>。

<通用要求> 按重要性依次如下：
<准确性要求>：
    1. 信息准确：严格根据提供给你的内容进行整理，不得添加没有提及的细节内容、主观推测或假设。
    2. 客观中立：内容应保持客观，不带有明显的个人意见或情感色彩，尽量采用第三人称叙述。
<输出结构要求>：
    1. 段落：每个段落应该围绕一个中心思想或论点展开，当讨论的主题发生变化时，应该开始一个新的段落。尽可能保留与主题词/query相关的所有主题信息。段落正文严禁输出引用博文序号等参考信息。
    2. 引用博文序号：对于每个段落正文，如果撰写的段落正文是根据某些带序号的博文内容总结得到，则将对应的博文序号放在json的"引用博文序号"字段中，引用的博文序号与撰写的段落内容直接相关，确保读者能够通过序号追溯到段落涉及到的原始博文。注意每处引用的博文序号数量不能超过五个,若引用的博文序号数量超过五个，则保留最相关的五个博文序号。
    3. 保留细节：在总结信息时，确保提供的内容中的关键细节，关键事实、数据和人物细节得到呈现，专注于与主题词直接相关的细节，确保这些信息得到完整呈现。
<表述要求>：
    1. 用更加口语化而不是书面的表达方式，便于阅读和理解。
    2. 避免生硬的连接词以及引导性语言，例如：总的来说、值得注意的是、综合来看、综上所述、总之等。
    3. 注意避免使用“近日”、“近期”等不明确的表述。
<相关性要求>：
    1. 主题相关：确保每一段都与主题词密切相关，不包含与主题词无关的细节或背景信息。
    2. 你需要判断主题词/query和上下文内容/content中每一条发博内容的相关性，判断原则如下：主题词/query中的元素，例如时间、地点、人物、事件、影视作品名等都出现在对应的发博内容中，判定为主题词/query与当前上下文内容/content中的发博内容相关；如果当前上下文内容/content中的发博内容能够满足主题词/query的意图，也可以认为是相关的；如果你无法正确理解主题词/query，主题词/query完整出现在了当前上下文内容/content的发博内容中，也可以认为是相关的。
    3. 生成内容时需要忽视无关的发博内容，防止它干扰正常结果。
<条理清晰要求>：
    1. 可读性：句子间的衔接应自然，阅读起来顺畅，没有突然的中断或跳跃。
    2. 删除重复内容：去除原文中重复的细节和信息，避免冗余。
<信息审查与验证准则>：
    1. 深度自省：在总结信息前充分理解相关信息的上下文，深入评估信息的来源、背景及其潜在偏差，特别注意容易混淆的细节，例如人物间的关系、人物属性（如明星的作品名）以及作品类型（如电影、电视剧、游戏或歌曲等）、事件的时间和地点等。
    2. 明确不确定性：在处理信息时，识别并明确指出不确定性较高的区域，避免在这些区域给出过于确定的结论。例如，避免将歌词错误地识别为歌曲名，或混淆不同演员的角色，以及避免人物关系的混淆。
    3. 适时终止：在无法提供确切信息的情况下，选择不输出相关信息，以防止误导用户。对于涉及到需要非常明确信息的人物关系、人物作品名称、作品类型、事件时间和地点等，除非有确凿证据，否则应省略不提。对于明显存在逻辑矛盾的信息，如事件时间前后矛盾，坚决不予以输出。
</通用要求>
"""

OV_INSTRUCT = """主题词/query 和 内容集合/texts数据如下：
    <query>{query}</query>
    <content>
    {content}
    </content>"""


# json: viewpoint_1k_steps


class Overview1KPrompt(BasePrompt):

    def __init__(self, weibo, config=None):
        self.weibo = weibo
    
    def task_desc(self):
        query=self.weibo.get('query', '')
        return OV_TASK_DES.format(query=query)
    
    def data_content(self):
        content_list = self.weibo.get('content_list', [])
        filter_content = []
        for i in range(len(content_list)):
            material = "{}.{}".format(i+1, str(content_list[i]))
            filter_content.append(material)
        content_str= "\n".join(filter_content)
        return OV_INSTRUCT.format(query=self.weibo.get('query', ''), content=content_str)

    def prompt(self):
        return self.task_desc() + "\n" \
            + self.output_example() + "\n" \
            + self.data_content() + "\n" \
            + self.reason_struct() + "\n" \
            + self.end_desc()

    def output_example(self):
        return OV_OUTPUT_SAMPLE

    def reason_struct(self):
        rs = getattr(plugins.prompt.reason_struct, "overview_1k_steps")
        return "\n<JSON格式推理规划>\n{}".format(rs)

    def end_desc(self):
        return "遵从上述【JSON格式推理规划】中分步骤推理规划，解决这项任务，并严格按照输出示例的格式输出。"

    def schema_index(self):
        return 16


def ov_1k_factory(query, content_list):
    return Overview1KPrompt(weibo={
        "query": query,
        "content_list": content_list,
    })
