import re
from datetime import datetime
from plugins.prompt.base import BasePrompt
from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/guide_text.j2')


class GuideTextPrompt(BasePrompt):

    def prompt(self):
        query = self.weibo.get("query", "")
        content = self.weibo.get('content', "")
        response = self.weibo.get('ori_result', "")
        final_ab_top3_output = self.weibo.get('ds_ab_top3_m_list', [])
        final_ab_good_output = self.weibo.get('ds_ab_good_m_list', [])
        first_material = "\n\n".join(final_ab_top3_output)
        if "</think>" in response:
            response = response.split("</think>")[1]

        cur_date = datetime.now().strftime('%Y年%m月%d日')
        prompt = prompt_template.render(query=query,
                                        r1_res=response,
                                        first_material=first_material
                                        )
        return prompt

    def post_process(self, result):
        try:
            if "</think>" in result:
                response = result.split("</think>")[1]
                return response.strip()
        except Exception as e:
            pass
        return ""
