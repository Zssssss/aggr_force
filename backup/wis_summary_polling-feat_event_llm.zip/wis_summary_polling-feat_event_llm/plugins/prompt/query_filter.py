# -*- coding:utf-8 -*-
import re
from jinja2 import Environment, FileSystemLoader
from plugins.prompt.base import BasePrompt

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/query_filter.j2')


class QueryFilterPrompt(BasePrompt):
    @staticmethod
    def remove_urls(text):
        # 匹配更全面的URL模式，包括www开头的网址
        url_pattern = r'https?://[^\s\u4e00-\u9fa5]+|www\.[^\s\u4e00-\u9fa5]+'
        return re.sub(url_pattern, '', text)

    def prompt(self):
        query = self.weibo.get("query", "")
        clean_query = self.remove_urls(query)
        prompt = prompt_template.render(user_input=clean_query)
        return prompt

    def post_process(self, result):
        try:
            decision_match = re.search(r'decision:\s*([^\r\n]*)', result)
            category_match = re.search(r'category:\s*([^\r\n]*)', result)
            disguise_match = re.search(r'disguise[：:]\s*([^\r\n]*)', result)

            decision = ""
            category = ""
            disguise = ""
            if decision_match:
                decision = decision_match.group(1).strip()
            if category_match:
                category = category_match.group(1).strip()
            if disguise_match:
                 disguise = disguise_match.group(1).strip()

            if decision == '有风险' and (category == '政治风险' or category == '违法犯罪' or category == '系统安全') and disguise == '有诱导':
                return True
        except Exception as e:
            pass
        return False
