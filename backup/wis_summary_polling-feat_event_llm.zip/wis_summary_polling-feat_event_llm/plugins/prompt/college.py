# -*- coding:utf-8 -*-
import re
import json
from datetime import datetime
from plugins.prompt.ds import DsPrompt
from plugins.material.filter import RiskLevel
from conf.config import GAOKAO_STATEMENT
from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/ds_template.j2')


class CollegeCheckPrompt(DsPrompt):

    def prompt(self):
        query = self.weibo.get("query", "")
        prompt = f'''用户发送的/query：{query}
深入理解用户需求，判断回答好用户查询query，是否需要引入“大众经验”（如普遍观点、常见做法等）。若问题有官方明确的客观答案，应直接给出权威、准确的信息，无需引入大众经验；若问题涉及经验分享、生活方式选择或价值判断，可引入大众经验。

按以下json格式输出：
```json
{{"是否需要引入大众经验内容"："是"或"否","理由"：输出理由}}
```'''
        return prompt

    def post_process(self, result):
        try:
            if "</think>" in result:
                result = result.split("</think>")[1].strip("\n")
            result = result.strip("```").strip("json").strip("\n")
            data = json.loads(result)
            return data.get("是否需要引入大众经验内容") == "是"
        except Exception as e :
            return False


def colege_check_factory(weibo):
    weibo['configs'] = []
    return CollegeCheckPrompt(weibo)


class CollegePrompt(DsPrompt):

    def prompt(self):
        modify_query = self.weibo.get("query", "")
        query = self.weibo.get("ori_query", modify_query)
        query_category = self.weibo.get("query_category", "")
        is_star = query_category == '明星'
        is_account = self.weibo.get('account_struct_content_list', []) or self.weibo.get('query_category', "") in ['Account_Nor', 'kol']
        is_gaokao = query_category == 'Education_Gaokao'

        # 新浪新闻
        if query.endswith("_sinanews"):
            query = modify_query

        # 高考双拼
        if query.endswith("_gaokaosp"):
            query = modify_query

        # 商业定制
        business_query = self.business_query()
        if business_query:
            query = business_query

        content = self.weibo.get('content', "")
        last_result = self.weibo.get("zs_data", "")

        cur_date = datetime.now().strftime('%Y年%m月%d日')
        modify_content = ""
        if last_result:
            modify_content = "以下是用户已经阅读过的/content：\n{last_result}\n/query：“{query}”是用户阅读/content后的追问。".format(last_result=last_result, query=query)

        parametric_knowledge_permit = True
        # query命中D级风控禁用参数化知识
        if self.weibo.get("limit_material"):
            parametric_knowledge_permit = False
        prompt = prompt_template.render(modify_content=modify_content,
                                        question=query,
                                        search_result=content,
                                        cur_date=cur_date,
                                        is_account=is_account,
                                        is_star=is_star,
                                        parametric_knowledge=parametric_knowledge_permit,
                                        is_gaokaosp=True,
                                        is_gaokao=is_gaokao,
                                        )
        return prompt

    def post_process(self, result):
        result = re.sub("^[ ]*(\d+\.|[一二三四五六七八九]、)", "", result)
        result = re.sub("\n[ ]*(\d+\.|[一二三四五六七八九]、)", "\n", result)
        search = re.search("[^#]*(#+)([^#\n]+评价[ ]*)\n", result)
        if search:
            title_str = search.group(1)
            delete_str = title_str + search.group(2)
            result = result.replace(delete_str, "")
            result = re.sub(r"#+", title_str, result)
        result = super().post_process(result)
        result = result.replace(GAOKAO_STATEMENT, "")
        return result

def colege_factory(weibo):
    weibo['configs'] = []
    return CollegePrompt(weibo)

def third_text_process(content):
    """第三方高考内容后处理"""
    re_link = re.compile(r"\[(.*?)\]\((https?://[^\s\)]+)\)")
    link_list = re_link.findall(content)
    for link_str, link in link_list:
        ori_text = f"[{link_str}]({link})"
        new_text = f"<a style='color: #4078f2; text-decoration: underline;' scheme='{link}' >{link_str}</a>"
        content = content.replace(ori_text, new_text)
    patterns = [
        r"如需[^\n]*?掌上高考(数据|官方)平台",
        r"更多(?:详细)?信息可以?(参考|查看|通过)",
        r"更多专业数据",
        r"^[* ]*注[:：]",
        r"如需[^\n]*进一步(分析|查询)",
        r"###[^\n]*(注意事项|建议|说明)"
        r"^最终"
    ]
    pre_content = []
    after_content = []
    content_list = content.split("\n")
    is_pre = True
    for line in content_list:
        for pattern in patterns:
            if re.search(pattern, line):
                is_pre = False
                break
        if is_pre:
            pre_content.append(line)
        else:
            after_content.append(line)
    content = "\n".join(pre_content)
    end_content = "\n".join(after_content)
    return content, end_content


def get_split_content(content):
    """"分割段落"""
    result = []
    split_content = re.split(r"\n{2,}", content)
    for text in split_content:
        if text.strip():
            result.append(text)
    return result

def check_is_table(content):
    """判断是否是表格"""
    if re.search(r"\|.*\|", content):
        return True
    return False

def third_text_process_new(content):
    """第三方高考内容后处理"""
    re_link = re.compile(r"\[(.*?)\]\((https?://[^\s\)]+)\)")
    link_list = re_link.findall(content)
    for link_str, link in link_list:
        ori_text = f"[{link_str}]({link})"
        new_text = f"<a style='color: #4078f2; text-decoration: underline;' scheme='{link}' >{link_str}</a>"
        content = content.replace(ori_text, new_text)
    split_content = get_split_content(content)
    if len(split_content) <= 1:
        end_content = ""
    elif check_is_table(split_content[-1]):
        end_content = ""
    else:
        end_content = split_content[-1]
        split_content = split_content[:-1]
    content = "\n\n".join(split_content)
    end_content += GAOKAO_STATEMENT
    return content, end_content

class CollegeIntentionPrompt(DsPrompt):

    def prompt(self):
        query = self.weibo.get("query", "")
        prompt = f"""你是一个高考信息查询分类器，请严格按以下规则对用户查询进行分类：

### 分类规则
1. 查高考作文：请求作文题目
   - 如："22届上海高考作文"

2. 查高考真题：请求试题或答案
   - 如："山东2023年高考语文试题及答案"

3. 查录取分数：询问分数线（院校/专业/批次控制线）
   - 如："2024年华中科技大学电子信息专业在广东要多少分？"

4. 查询招生简章：查询学校/专业招生简章、学校特色专业介绍
   - 如："北京师范大学本科招生简章出了没？"

5. 相同专业不同学校对比：
   - 如："同济和东南大学的建筑学哪个好？"

6. 相同学校不同专业对比：
   - 如："⼭东⼤学软件⼯程和计算机科学与技术专业哪个好?"

7. 查询学校/专业：学校基本信息查询/专业基本信息查询
   - 如："北京理工大学"，"清华大学数学专业"，"金融专业"，"华中科技大学怎么样？"，"南京大学是文科吗？"

8. 学校/专业选报建议：根据选科组合咨询适配方向
   - 如："江苏物生地考生适合哪些高校？"

9. 学校/专业就业情况：询问专业/院校就业前景
   - 如："哈工大毕业好找工作吗？"

10. 其他：不符合以上任何类别
   - 如："2024北京高考"，"马嘉祺读的什么专业"

### 输出要求
- 仅输出最匹配的类别名称（10选1）
- 禁止添加说明、标点或额外文本
- 类别名称必须完全匹配以下表述：
  "查高考作文" | "查高考真题" | "查录取分数" | "查询招生简章" | "相同专业不同学校对比" | "相同学校不同专业对比" |
  "查询学校/专业" | "学校/专业选报建议" | "学校/专业就业情况" | "其他"

### 待分类查询
{query}"""

        return prompt

    def post_process(self, result):
        try:
            if "</think>" in result:
                result = result.split("</think>")[1].strip("\n")
            result = result.strip("```").strip("json").strip("\n")
            data = json.loads(result)
            return data.get("是否需要引入大众经验内容") == "是"
        except Exception as e :
            return False

def college_intention_factory(weibo):
    weibo['configs'] = []
    return CollegeIntentionPrompt(weibo)
