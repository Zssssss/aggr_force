# -*- coding:utf-8 -*-
import json
from datetime import datetime

from plugins.material.material import MEDIA_UIDS
from plugins.prompt.base import BasePrompt
from plugins.prompt.ds import DsPrompt
from plugins.material.filter import RiskLevel
from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/mid_template.j2')
mid_analyze_template = env.get_template('plugins/prompt/mid_analyze_template.j2')
blog_recognize_template = env.get_template('plugins/prompt/blog_recognize.j2')
highlight_word_prompt_template = env.get_template('plugins/prompt/mid_highlight_word.j2')

class MidPrompt(DsPrompt):
    def prompt(self):
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("mid_content", "")
        is_forward = self.weibo.get("is_forward", 0)
        content = self.weibo.get('content', "")
        external_site = False
        sid = self.weibo.get("sid", "")
        inner_prompt_scene = self.weibo.get("inner_prompt_scene", "")
        mid_voice = self.weibo.get("mid_voice", "")
        mid_ocr = self.weibo.get("mid_ocr", "")

        # 站外url求证标记
        if sid == "sina_news_verification" or inner_prompt_scene == 'chat_url':
            query = self.weibo.get("url_sina_content", {}).get("content")
            external_site = True 
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        uid = self.weibo.get("mid_uid", "")
        is_star = self.weibo.get("is_star", False)
        mid_is_medical = self.weibo.get("mid_is_medical", False)
        nick_name = ""
        blog_time = ""
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                nick_name = json_data.get("v_nickname", "")
                blog_time = json_data.get("v_pbtime", "")
                dt = datetime.strptime(blog_time, "%a %b %d %H:%M:%S %z %Y")
                blog_time = dt.strftime("%Y年%m月%d日")
            except Exception as e:
                self.logger.warning("{} q_attr:{}, error:{}".format(trace_id, q_attr, e))

        is_authoritative = uid in MEDIA_UIDS
        parametric_knowledge_permit = True
        # query命中D级风控禁用参数化知识
        if self.weibo.get("limit_material"):
            parametric_knowledge_permit = False
        if_func_call = self.weibo.get('if_func_call', False)
        use_model = self.weibo.get("use_model", "")
        prompt = prompt_template.render(nick_name=nick_name,
                                        blog_time=blog_time,
                                        blog_content=query,
                                        search_material=content,
                                        today=cur_date,
                                        is_authoritative=is_authoritative,
                                        is_star=is_star,
                                        parametric_knowledge=parametric_knowledge_permit,
                                        external_site=external_site,
                                        forward=is_forward,
                                        is_medical=mid_is_medical,
                                        pic=mid_ocr,
                                        video=mid_voice,
                                        if_func_call=if_func_call,
                                        use_model=use_model
                                        )
        return prompt

    def highlight_word_prompt(self, query, result):
        prompt = highlight_word_prompt_template.render(answer=result)
        return prompt

class MidAnalysisPrompt(DsPrompt):
    def prompt(self):
        trace_id = self.weibo.get("trace_id", "")
        query = self.weibo.get("mid_content", "")
        sid = self.weibo.get("sid", "")
        external_site = False
        # 站外url求证标记
        if sid == "sina_news_verification":
            query = self.weibo.get("url_sina_content", {}).get("content")
            external_site = True 
        is_forward = self.weibo.get("is_forward", 0)
        content = self.weibo.get('content', "")
        cur_date = datetime.now().strftime('%Y年%m月%d日')
        uid = self.weibo.get("mid_uid", "")
        is_star = self.weibo.get("is_star", False)
        mid_is_medical = self.weibo.get("mid_is_medical", False)
        nick_name = ""
        blog_time = ""
        q_attr = self.weibo.get("q_attr", "")
        if q_attr:
            try:
                json_data = json.loads(q_attr)
                nick_name = json_data.get("v_nickname", "")
                blog_time = json_data.get("v_pbtime", "")
                dt = datetime.strptime(blog_time, "%a %b %d %H:%M:%S %z %Y")
                blog_time = dt.strftime("%Y年%m月%d日")
            except Exception as e:
                self.logger.warning("{} q_attr:{}, error:{}".format(trace_id, q_attr, e))

        is_authoritative = uid in MEDIA_UIDS
        parametric_knowledge_permit = True
        # query命中D级风控禁用参数化知识
        if self.weibo.get("limit_material"):
            parametric_knowledge_permit = False
        prompt = mid_analyze_template.render(nick_name=nick_name,
                                        blog_time=blog_time,
                                        blog_content=query,
                                        search_material=content,
                                        today=cur_date,
                                        is_authoritative=is_authoritative,
                                        is_star=is_star,
                                        parametric_knowledge=parametric_knowledge_permit,
                                        external_site=external_site,
                                        forward=is_forward,
                                        is_medical=mid_is_medical)
        return prompt


class BlogRecognizePrompt(DsPrompt):

    def prompt(self):
        nick_name = self.weibo.get("nick_name", "")
        blog_content = self.weibo.get("mid_content", "")
        prompt = blog_recognize_template.render(
            nick_name=nick_name,
            blog_content=blog_content
        )
        return prompt
    
    def post_process(self, result):
        if not isinstance(result, str):
            self.logger.error(f"blog recginize result is not str: {result}")
            return ""
        label1 = result.split("</label1>")[0].split("<label1>")[1]
        return label1.strip()

def mid_factory(weibo):
    weibo['configs'] = []
    prompt_scene = weibo.get("prompt_scene", "")
    sid = weibo.get("sid", "")
    if prompt_scene == "deepseek_analyze" and sid != "sina_news_verification":
        return MidAnalysisPrompt(weibo)
    return MidPrompt(weibo)

def blog_recognize_mid_factory(weibo):
    weibo['configs'] = []
    return BlogRecognizePrompt(weibo)
