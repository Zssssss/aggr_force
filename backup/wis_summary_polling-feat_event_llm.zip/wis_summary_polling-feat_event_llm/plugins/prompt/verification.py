# -*- coding:utf-8 -*-
import json
from datetime import datetime

from plugins.material.material import MEDIA_UIDS
from plugins.prompt.base import BasePrompt
from plugins.prompt.ds import DsPrompt
from plugins.material.filter import RiskLevel
from jinja2 import Environment, FileSystemLoader

from plugins.prompt.json_utils import parse_json

env = Environment(loader=FileSystemLoader('.'), autoescape=True)
prompt_template = env.get_template('plugins/prompt/verification.j2')


class VerificationPrompt(DsPrompt):
    def prompt(self):
        query = self.weibo.get("query", "")
        zs_content = self.weibo.get("ori_result", "")
        content = self.weibo.get('all_content', "")
        cur_date = datetime.now().strftime('%Y年%m月%d日%X')

        prompt = prompt_template.render(question=query,
                                        zs_content=zs_content,
                                        search_results=content,
                                        current_time=cur_date)
        return prompt

    def post_process(self, result):
        try:
            json_str = parse_json(result)
            ttype = json_str.get("是否存在不可信回答内容", "否")
            if ttype == '是':
                return json_str.get("干预事实", [])
        except Exception as e:
            pass
        return []

