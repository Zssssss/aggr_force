"""更新点击率"""
# -*- coding:utf-8 -*-
import asyncio
import aiohttp
from plugins.post_process.card_process import get_multi_pic_first
from plugins.post_process.cache_multimodal import ClickRateRealtime

async def fetch_mid_pic_v3(semaphore, session, query, mid, url):
    result = {}
    try:
        async with semaphore:
            async with session.get(url, params={"query": query, "mids": mid}) as response:
                res_data = await response.json()
                for data in res_data["data"]:
                    mid = data["mid"]
                    pids = data.get("pids", [])
                    if pids:
                        result[mid] = pids
                return result
    except Exception as e:
        pass
    return result

async def get_selected_data_click(query, mid_list, fetch_url="http://10.133.12.196:17933/v3/caibian/pic_video"):

    tasks = []
    selected_data = {}
    # 限制并发为 5
    semaphore = asyncio.Semaphore(5)
    timeout = aiohttp.ClientTimeout(total=2)
    step = 10
    async with aiohttp.ClientSession(timeout=timeout) as session:
        for i in range(0, len(mid_list), step):
            mid = ",".join(mid_list[i:i+step])
            task = asyncio.create_task(fetch_mid_pic_v3(semaphore, session, query, mid, fetch_url))
            tasks.append(task)
        results = await asyncio.gather(*tasks)
        for result in results:
            if not result:
                continue
            selected_data.update(result)

    return selected_data


async def get_realtime_click(weibo, pid, query, all_ready_list):
    search_list = [[w.get("cur_mid"), w.get("img_pid")] for w in all_ready_list]
    # 获取搜索流和card实时点击率
    click_class = ClickRateRealtime(weibo, pid)
    result = await click_class.get_merge_data(query, search_list)
    return result

def get_a1_a2_a3(weibo, pid, result, all_ready_list):
    """获取a1、a2、a3三类数据"""
    click_class = ClickRateRealtime(weibo, pid)
    card_exp_threshold = 50
    zonghe_exp_threshold = 50
    card_rate_threshold = 0.02
    a1 = []
    a2 = []
    a3 = []
    card_rate_dict = {"click_num<=50": 0}
    card_rate_list = []
    # 分组并统计点击率
    for w in all_ready_list:
        mid = w.get("cur_mid", "")
        pid = w.get("img_pid", "")
        cur_dict = {"rate_zonghe": 0, "exp_zonghe": 0, "rate_card": 0, "exp_card": 0}
        click_info = result.get(mid, {}).get(pid, {})
        if not click_info:
            w.update(cur_dict)
            a3.append(w)
            continue
        click_zonghe = click_info.get("click_zonghe", 0)
        click_card = click_info.get("click_card", 0)
        exp_zonghe = click_info.get("exp_zonghe", 0)
        exp_card = click_info.get("exp_card", 0)
        rate_card = click_card / exp_card if exp_card else 0
        rate_zonghe = click_zonghe / exp_zonghe if exp_zonghe else 0
        cur_dict = {"rate_zonghe": rate_zonghe, "exp_zonghe": exp_zonghe, "rate_card": rate_card, "exp_card": exp_card}
        w.update(cur_dict)
        if exp_card > card_exp_threshold and rate_card > card_rate_threshold:
            click_class.logger.info(click_class.pre_log_msg + f"mid {mid} pid {pid} rate_card {rate_card} exp_card {exp_card}")
            a1.append(w)
        elif exp_zonghe > zonghe_exp_threshold:
            a2.append(w)
        else:
            a3.append(w)

        # 统计card点击率，便于后续调整阈值
        if exp_card <= 50:
            card_rate_dict["click_num<=50"] += 1
        else:
            card_rate_list.append(rate_card)
    # 按照点击率排序，并图片优先策略
    a1 = sorted(a1, key=lambda x: x.get("rate_card", 0), reverse=True)
    # a1 = get_multi_pic_first(a1)
    a2 = sorted(a2, key=lambda x: x.get("rate_zonghe", 0), reverse=True)
    # a2 = get_multi_pic_first(a2)
    a3 = sorted(a3, key=lambda x: x.get("rate_zonghe", 0), reverse=True)
    # a3 = get_multi_pic_first(a3)
    click_class.logger.info(click_class.pre_log_msg + f"[update_shishi_click_rate], a1: {len(a1)}, a2: {len(a2)}, a3: {len(a3)}")
    click_class.logger.info(click_class.pre_log_msg + f"[card_rate_dict], {card_rate_dict}, card_rate_list: {card_rate_list}")
    return a1, a2, a3

async def get_card_multimodal_lab_h2(weibo, pid, query, all_ready_list):
    # 获取实时点击率数据
    result = await get_realtime_click(weibo, pid, query, all_ready_list)
    a1, a2, a3 = get_a1_a2_a3(weibo, pid, result, all_ready_list)
    return a1 + a2 + a3

