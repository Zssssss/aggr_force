"""后处理handler"""
import copy
# -*- coding:utf-8 -*-
import json
import re
from urllib.parse import quote

import aiohttp
import emoji
from conf.config import MULTIMODAL_DEBUG, GAOKAO_STATEMENT
from lib.safe_logger import get_logger
from lib.weibo_interface import fetch_user_showbatch
from plugins.post_process.business_process import process_content
from plugins.post_process.utils import (convert_credential_part, split_think_and_content, split_paragraphs_with_markdown_title,
                                        get_weibo_link_index_list, clean_markdown_title, find_markdown_title,
                                        get_paragraph_list_by_h1_or_above, remove_result_notation,
                                        replace_first_sentence)
from plugins.post_process.quote_process import standardize_quote, replace_quote_with_url, quote_special_process, preprocess_quotes
from plugins.post_process.multimodal_process import pic_process_ds, process_called_account
from plugins.post_process.filter_process import filter_invalid_str
from plugins.post_process.md_special_format_process import process_special_format, back_special_format
from plugins.post_process.card_process import get_multi_pic_first

class ProcessUtils:
    def __init__(self,pid):
        log_filename = "log/post_process-" + str(pid) + ".log"
        self.logger = get_logger(log_filename, self.__class__.__name__)

    def replace_invalid_str_and_log(self, s: str, query: str, trace_id: str, weibo_link_index_list: list,
                                    ready: bool = False) :
        """替换非法字符，并记录日志"""
        result, replaced_matches = standardize_quote(s, weibo_link_index_list)
        if (len(result) != len(s) or len(replaced_matches)) and ready :
            self.logger.info(
                "traceid:{}\tquery:{}\treplaced_matches_len:{}\treplaced_matches:{}\tweibo_link_index_list:{}\tbefore_result:{}".format(
                    trace_id, query, len(replaced_matches), replaced_matches, weibo_link_index_list,
                    json.dumps(s, ensure_ascii=False)))
        return result

    def filter_invalid_str_and_log(self, s: str, query: str, trace_id: str, ready: bool = False):
        """过滤非法字符，并记录日志"""
        result, filtered_matches = filter_invalid_str(s)
        if len(result) != len(s) and ready:
            self.logger.info("traceid:{}\tquery:{}\tfiltered_matches_len:{}\tfiltered_matches:{}\tbefore_result:{}".format(
                trace_id, query, len(filtered_matches), filtered_matches, json.dumps(s, ensure_ascii=False)))
        return result

    def _get_mid_to_quote(self, link_list):
        """获取引用字符"""
        mid_to_quote = {}
        for index, link in enumerate(link_list):
            if "detail?mblogid=" in link:
                mid = link.split("mblogid=")[1]
                mid_to_quote[mid] = index + 1
        return mid_to_quote

    def transform_item(self, raw) :
        t = raw.get("type", "")
        pid = ""

        if t == "video" :
            vids = raw.get("vids", "")
            pid = vids.split(" ")[0].split("/")[-1].split(".")[0] if vids else ""
            mid = raw.get("id", "")
        elif t == "pic" :
            pid = raw.get("pid", "")
            mid = raw.get("mid", "")
        else :
            return {}

        return {
            "pid" : pid,
            "type" : t,
            "query" : raw.get("query", ""),
            "mid" : mid,
            "click_rate" : float(raw.get("click_rate", 0)),
            "is_caibian" : 1,
            "flag" : 1,
        }

    def _convent_multi_modal_info2str(self, extra_multi_modal_info: dict, mid_to_quote, selected_data):
        """将多模态信息转换为字符串"""
        extra_multi_modal_info_str = {}
        for part, info_list in extra_multi_modal_info.items():
            cur_str = ""
            for info in info_list:
                single_select = self.transform_item(info)
                mid = single_select.get("mid", "")
                selected_data.setdefault(mid, []).append(single_select)
                if mid and mid in mid_to_quote:
                    cur_str += f"<a>[{mid_to_quote[mid]}]</a>"
            extra_multi_modal_info_str[part] = cur_str
        return extra_multi_modal_info_str

    def add_extra_quotes(self, s: str, extra_multi_modal_info: dict, mid_to_quote, selected_data):
        think, content = split_think_and_content(s)
        paragraph_list = get_paragraph_list_by_h1_or_above(content)
        extra_multi_modal_info_str = self._convent_multi_modal_info2str(extra_multi_modal_info, mid_to_quote, selected_data)
        for part, info_str in extra_multi_modal_info_str.items():
            part_index = int(part.split(" ")[1]) - 1
            if part_index < len(paragraph_list):
                paragraph_list[part_index] += info_str
        return think + "\n".join(paragraph_list)

    def get_all_quote_list(self, s: str):
        """获取所有引用字符"""
        quote_list = []
        for i in re.finditer(r"<a>\[(\d+)\]</a>", s):
            quote_list.append(i.group(1))
        quote_list = list(set(quote_list))
        return quote_list

    def replace_picture_and_log(self, s: str, query_info_dict, pic_url_list: list, vector_dict: dict, ready_pid_dict: dict, pid_dup_dict: dict, pic_info_dict_all, link_list: list, video_mid_dict, mid_feature_dict, ready: bool=False, is_stream=False,log_func = None ):
        """过滤图片引用字符，并记录日志"""
        # 额外多模态引用插入正文
        extra_multi_modal_info = query_info_dict.get("extra_multi_modal_info",{})
        abtest_label = query_info_dict.get("abtest_label","")
        if extra_multi_modal_info and abtest_label in ["lab_a1"]:
            selected_data = query_info_dict.get("selected_data", {})
            mid_to_quote = self._get_mid_to_quote(link_list)
            ori_quote_list = self.get_all_quote_list(s)
            s = self.add_extra_quotes(s, extra_multi_modal_info, mid_to_quote, selected_data)
            dst_quote_list = self.get_all_quote_list(s)
            self.logger.info(f"traceid:{query_info_dict['trace_id']}, query:{query_info_dict['query']}, [v3.1 add media], ori_quote_list:{ori_quote_list}, dst_quote_list:{dst_quote_list}, mid_to_quote:{mid_to_quote}")
        ########
        # result, picture_matches = picture_process(s, pic_url_list, vector_dict, ready_pid_dict, pid_dup_dict, pic_info_dict_all, ready=ready, log_func=log_func, is_stream=is_stream)
        result = pic_process_ds(s, pic_info_dict_all, link_list, vector_dict, video_mid_dict, mid_feature_dict, ready_pid_dict, query_info_dict, ready=ready, log_func=log_func)
        if len(result) != len(s) and ready:
            self.logger.info("traceid:{}\tquery:{}\tbefore_result:{}".format(
                query_info_dict["trace_id"], query_info_dict["query"], json.dumps(s, ensure_ascii=False)))
        return result

    def process_code_block_multimodal_content(self, result):
        """处理由于4个以上空格导致的前端识别为代码块，不解析多模态内容的问题"""
        think, content = split_think_and_content(result)
        if not content:
            return think
        split_list = split_paragraphs_with_markdown_title(content)
        space_re = re.compile(r"^\s{4,}")
        for single_content in split_list:
            ori_content = single_content
            source_str = "\n"
            replace_str = "\n"
            # if "```wbCustomBlock" not in single_content and "<media-block>" not in single_content:
            #     continue
            single_list = single_content.split("\n")
            for index, single_line in enumerate(single_list):
                if index == 0 or not single_line.strip():
                    continue
                search = space_re.search(single_line)
                if search:
                    length = search.end()
                    source_str += " " * length
                break
            if source_str == replace_str:
                continue
            single_content = single_content.replace(source_str, replace_str)
            content = content.replace(ori_content, single_content)
        return think + content

    def think_process(self, result):
        """思考态处理"""
        if "</think>" in result:
            pre_result = result.split("</think>")[0] + "</think>"
            result = result.split("</think>")[1]
        elif "<think>" in result:
            pre_result = result
            result = ""
        else:
            pre_result = ""
        re_delete = re.compile(r"(不|避免)[\u4e00-\u9fa5]+(隐私|负面|细节数据)")
        new_pre = []
        for text in pre_result.split("\n"):
            if re_delete.search(text):
                continue
            new_pre.append(text)
        return "\n".join(new_pre) + result

    def link_process(self, result) :
        # 查找个人主页卡片标记
        card_pattern = r'\[\^个人主页卡片\]'
        if not re.search(card_pattern, result, re.DOTALL) :
            return result

        # 先尝试匹配中文括号内包含"点击"和链接的内容
        bracket_pattern = r'（.*?点击.*?\[[^\n\]]+\]\([^\)\n]+\).*?）'
        match_list = re.findall(bracket_pattern, result, re.DOTALL)
        for match in match_list :
            to_remove = match
            new_content = result.replace(to_remove, '', 1).strip()
            return new_content

        # 如果没有匹配到中文括号内容，再尝试匹配完整句子
        sentence_pattern = r'[。!！？\n][^。!！？\n]*\[\^个人主页卡片\][^。!！？\n]*?[。!！？\n]'
        match_list = re.findall(sentence_pattern, result, re.DOTALL)
        for match in match_list :
            full_sentence = match
            full_sentence = full_sentence[1 :]
            end = full_sentence[-1]
            prefix = "[^个人主页卡片]"
            if end == "\n" :
                prefix += "\n"
            result = result.replace(full_sentence, prefix)

        # 如果都没有匹配到，返回原始结果
        return result

    def get_personal_card_str(self, user_search_res):
        """获取个人卡片"""
        if not user_search_res:
            return ""
        # 判断是否开启一键防护
        idstr = user_search_res[0].get("用户uid", "")
        res = fetch_user_showbatch([idstr])
        green_mode = 0
        if res:
            green_mode = res.get(idstr,{}).get("green_mode",0)
        if green_mode:
            self.logger.info(f"uid: {idstr} green_mode:{green_mode}")
            return ""

        result = {
            "type": "homepage",
            "data": {
                "name": user_search_res[0].get("内容", {}).get("微博昵称", ""),
                "img": user_search_res[0].get("avatar_large", ""),
                "scheme": user_search_res[0].get("url", ""),
                "fans_number": user_search_res[0].get("内容", {}).get("微博粉丝量", 0),
                "verified": user_search_res[0].get("verified", False),
                "verified_type": user_search_res[0].get("verified_type", -1),
                "verified_type_ext": user_search_res[0].get("verified_type_ext", -1),
                "ai_tab": "",
                "authentication":  user_search_res[0].get("内容", {}).get("微博认证信息", ""),
                "introduction": "",
                "mbtype": user_search_res[0].get("mbtype", -1),
            }
        }
        # 优先取微博认证信息 再取微博简介
        if not user_search_res[0].get("内容", {}).get("微博认证信息", ""):
            result["data"]["introduction"] = user_search_res[0].get("内容", {}).get("微博简介", "")
        return f"```wbCustomBlock{json.dumps(result, ensure_ascii=False)}```"

    def creat_personal_card(self, result, user_search_res):
        """创建个人卡片"""
        if "</think>" in result:
            pre_result = result.split("</think>")[0] + "</think>"
            result = result.split("</think>")[1]
        elif "<think>" in result:
            return result
        else:
            pre_result = ""
        # 去除链接等内容
        result = self.link_process(result)
        # 去掉开头个人主页卡片
        result = result.strip()
        prefix = "[^个人主页卡片]"
        replace_str = self.get_personal_card_str(user_search_res)
        # 个人主页卡片出现在段尾、去除重复卡片
        split_result = re.split(r"\n{2,}", result)
        for i in range(len(split_result)):
            if prefix in split_result[i]:
                split_result[i] += "\n\n"
                split_result[i] += replace_str
                break
        result = "\n\n".join(split_result)
        re_person = re.compile(r"\[\^个人主页卡片\]")
        result = re_person.sub("", result)
        return pre_result + result

    def add_feedback(self, result, query_category, exact_account_query, ready=False):
        """添加反馈信息"""
        # if not ready or not result or exact_account_query != 1 or query_category == "Education_Gaokao":
        #     return result
        # result = result.strip("\n")
        # result += "\n\n若发现内容有不足或存在改进空间，欢迎点击「反馈」按钮提交建议。我们会根据建议及时调整修改，为您提供更好的体验。"
        if ready and query_category == "Education_Gaokao":
            result = result.rstrip()
            result += GAOKAO_STATEMENT
        return result

    def strip_wrapping_quotes_around_refs(self, text: str) -> str:
        # 仅当成对符号内部只包含 [^数字]（可含空白）时，去掉外层符号
        PAIRS = [
            ("“", "”"), ("‘", "’"), ("`", "`"),
            ("(", ")"), ("[", "]"),
            ("《", "》"), ('"', '"'), ("'", "'"),
            ("（", "）"), ("【", "】"), ("「", "」"), ("『", "』")
        ]
        for left, right in PAIRS:
            # 允许 [^n] 两侧有可选空白，但不允许其他字符
            pattern = re.compile(
                re.escape(left) + r" *(\[\^\d+\]) *" + re.escape(right)
            )
            # 多次替换，直到不再匹配该对符号
            while True:
                text, n = pattern.subn(r"\1", text)
                if n == 0:
                    break
        return text

    def delete_quote_case(self, result: str):
        """删除括号里面的无用的引文"""
        l_bracket = r"[\(（]"
        r_bracket = r"[\)）]"
        pre_quote = r"(?:如|见|参考|百科|自|源|结果|案例|数据)"
        mid_quote = r"['\"‘’“” ]*"
        quote = r"\[\^\d+\]"
        other = r"[^\(（\)）\n]*"
        re_search = re.compile(rf"{l_bracket}{other}{pre_quote}{mid_quote}{quote}{other}{r_bracket}")
        check_list = list(set(re_search.findall(result)))
        for cur in check_list:
            quote_list = re.findall(quote, cur)
            replace_str = ''.join(quote_list)
            if len(cur) - len(replace_str) < 8:
                result = result.replace(cur, replace_str)
        # 删除引文前后的特殊字符
        result = self.strip_wrapping_quotes_around_refs(result)
        # 删除引文后的 的、等、中
        after_quote = r"(?:的|中|等)"
        re_search = re.compile(rf"({quote}){after_quote}")
        result = re_search.sub(r'\1', result)
        return result
    
    def process_invalid_quote(self, result):
        """处理正文错误的的引用格式, 在引文标准化之前"""
        think, content = split_think_and_content(result)
        # \\[^6]、\\[^6\\]
        content = re.sub(r'\\([\[\]])', r'\1', content)
        # （例如[^6]）
        content = self.delete_quote_case(content)
        return f"{think}\n{content}"

    def process_markdown_title(self, result, weibo_update_dict):

        def gen_title_data(num,title):

            # 提取标题中的文本
            text = clean_markdown_title(title)

            title_data = {
                "type": "emphasis_tag",
                "data": f"emphasis-tag-{num}"
            }
            list_data = {
                "id": f"emphasis-tag-{num}",
                "text": text
            }
            return title_data, list_data
        title_list = find_markdown_title(result)
        if not title_list:
            return result
        if len(title_list[0]) <= 2 and len(title_list) > 1 and len(title_list[1]) > 1:
            first_title_list = title_list[1][:3]
        else:
            first_title_list = title_list[0][:3]
        num = 0
        title_list_data = []
        for title in first_title_list:
            if title in result:
                title_data, list_data = gen_title_data(num, title)

                handled_title = title + "```wbCustomBlock" + json.dumps(title_data, ensure_ascii=False) + "```"
                result = result.replace(title, handled_title)
                title_list_data.append(list_data)
                num += 1
        weibo_update_dict["emphasis_tag"] = title_list_data
        return result

    def process_first_title(self, result):
        """处理正文第一个无用的标题"""
        def clean_first_title(text):
            """清理第一个标题"""
            # 1. 去除井号（如 # 标记）
            text = text.replace("#", "")
            # 2. 去除 emoji
            text = emoji.replace_emoji(text, replace="")
            # 3. 去除星号
            text = text.replace("*", "")
            return text.strip()
        think, content = split_think_and_content(result)
        split_text = content.strip().split("\n")
        if len(clean_first_title(split_text[0])) < 20 and "关键信息" in split_text[0]:
            split_text = split_text[1:]
        content = "\n".join(split_text)
        return f"{think}\n{content}"

    def get_log_func(self, context):
        """获取日志函数"""
        query = context.get("query", "")
        trace_id = context.get("trace_id", "")
        ready = context.get("ready", False)
        def log_func(message: str):
            """日志函数"""
            if ready:
                self.logger.info("traceid:{}\tquery:{}\t{}".format(trace_id, query, message))
        return log_func

    def get_card_multi_list(self, all_ready_list, limit_list):
        """根据limit_list获取卡片多模态列表"""
        n = len(all_ready_list)
        for limit in limit_list:
            if n >= limit:
                return all_ready_list[:limit]
        return []

    def card_output(self, all_ready_list, context):
        """card页输出多模态信息"""
        abtest_label = context.get("abtest_label", "")
        all_ready_list = sorted(all_ready_list, key=lambda x: x['click_rate'], reverse=True)

        all_ready_list = get_multi_pic_first(all_ready_list)
        # 不限制，直接返回所有结果
        multi_list = all_ready_list
        if multi_list:
            result = {"type": "mediablock", "data": multi_list}
        else:
            result = {}
        return result

    async def get_click_rate(self, p_id_list):
        """获取点击率（CTR）"""
        url = "http://10.2.32.47:1336/clickinfo"
        data = {"pids": p_id_list}
        try:
            timeout = aiohttp.ClientTimeout(total=2)  # 可适当调整超时时间
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, json=data) as response:
                    result = await response.json()
                    raw_data = result.get("result", {})

                    # 计算点击率 CTR = click / expo
                    rate_dic = {}
                    for pid, stats in raw_data.items():
                        expo = float(stats.get("expo", 0))
                        click = float(stats.get("click", 0))
                        rate_dic[pid] = (click / expo) if expo > 0 else 0
                    return rate_dic
        except Exception as e:
            # 失败时返回空字典
            return {}

    async def card_output_new(self, all_ready_list, context):
        """根据点击率排序并取前三"""
        log_func = self.get_log_func(context)
        # 深拷贝原始数据
        original_list = copy.deepcopy(all_ready_list)
        original_top3 = original_list[:3]

        # 获取 pid 列表
        p_id_list = [item.get("img_pid") for item in all_ready_list]
        # print(f"p_id_list: {p_id_list}")
        # 获取点击率字典
        rate_dic = await self.get_click_rate(p_id_list)
        # 按点击率排序
        sorted_by_rate = sorted(
            all_ready_list,
            key=lambda x: rate_dic.get(x.get("img_pid"), 0),
            reverse=True
        )

        # 取点击率大于 0 的前 3 个
        top_click_items = [item for item in sorted_by_rate if rate_dic.get(item.get("img_pid"), 0) > 0][:3]
        # print(f"top_click_items: {top_click_items}")
        # 补足 3 个，避免重复 pid
        seen_pids = {item.get("img_pid") for item in top_click_items}
        for item in original_top3:
            if len(top_click_items) >= 3:
                break
            if item.get("img_pid") not in seen_pids:
                top_click_items.append(item)
                seen_pids.add(item.get("img_pid"))

        # 最终结果
        final_list = top_click_items[:3]
        num = 3
        if len(final_list) < num:
            return {}
        # print(f"original_top3: {original_top3}")
        # print(f"final_list: {final_list}")
        message = f"rate_dic: {json.dumps(rate_dic)}\tfinal_list: {json.dumps(final_list)}"
        log_func(message)
        return {
            "type": "mediablock",
            "data": final_list
        }



    def share_card_output(self, all_ready_list):
        """share_card页输出多模态信息"""
        if not all_ready_list:
            return {}
        result = all_ready_list[0].copy()
        # 图片改为中等图
        if result.get("img"):
            result["img"] = result["img"].replace("sinaimg.cn/large/", "sinaimg.cn/middle/")
        return result


class PostProcessHandler:

    def __init__(self, pid):
        self.pid = pid
        self.process_utils = ProcessUtils(pid)

    def handle(self, result: str, context: dict) -> str:
        raise NotImplementedError


class PostProcessor:
    def __init__(self, handlers: list[PostProcessHandler]):
        self.handlers = handlers

    def run(self, result: str, context: dict) -> str:
        for handler in self.handlers:
            result = handler.handle(result, context)
        return result


class ReplaceInvalidStrHandler(PostProcessHandler):
    def handle(self, result, context):
        # [⁠6⁠][⁠11⁠]。当做引文
        result = preprocess_quotes(result)
        # 取出特殊格式， 后面需要加回写特殊格式
        result, special_md = process_special_format(result)     
        if context.get("is_credential", False):
            result = convert_credential_part(result)
        result = remove_result_notation(result)

        context["special_md"] = special_md
        result = self.process_utils.add_feedback(result, context["query_category"], context["exact_account_query"], context["ready"])
        link_index = get_weibo_link_index_list(context["link_list"])
        result = self.process_utils.process_invalid_quote(result)
        result = self.process_utils.replace_invalid_str_and_log(result, context["query"], context["trace_id"], link_index, ready=context["ready"])
        result = self.process_utils.filter_invalid_str_and_log(result, context["query"], context["trace_id"], ready=context["ready"])
        return result


class ReplaceMultimodalHandler(PostProcessHandler):
    def handle(self, result, context):
        return self.process_utils.replace_picture_and_log(
            result,
            {
                "query": context["query"],
                "trace_id": context["trace_id"],
                "ban_object": context["ban_object"],
                "is_hot_query": context["is_hot_query"],
                "special_md": context.get("special_md", {}),
                "selected_data": context["selected_data"],
                "unsimilar_pic": context["unsimilar_pic"],
                "business_link_list" : context["business_link_list"],
                "output_all_ready" : context["output_all_ready"],
                "abtest_label": context.get("abtest_label", ""),
                "extra_multi_modal_info": context.get("extra_multi_modal_info", {}),
                "is_credential": context.get("is_credential", False),
            },
            context["picture_urls"],
            context["vector_dict"],
            context["ready_pid_dict"],
            context["pid_dup_dic"],
            context["pic_info_dict_all"],
            context["link_list"],
            context["video_mid_dict"],
            context["mid_feature_dict"],
            ready=context["ready"],
            is_stream=context["is_stream"],
            log_func=self.process_utils.get_log_func(context)
        )


class QuoteHandler(PostProcessHandler):
    def handle(self, result, context):
        if MULTIMODAL_DEBUG:
            return replace_quote_with_url(result, context["link_list"])
        else:
            log_func = self.process_utils.get_log_func(context)
            return quote_special_process(result, log_func=log_func)


class AccountIntentionHandler(PostProcessHandler):
    def handle(self, result, context):
        if context["is_zhanghao_attention"]:
            result = self.process_utils.think_process(result)
            result = self.process_utils.creat_personal_card(result, context["user_search_res"])
        return result


class CodeBlockFixHandler(PostProcessHandler):
    def handle(self, result, context):
        # 处理由于4个以上空格导致的前端识别为代码块，不解析多模态内容的问题
        result = self.process_utils.process_code_block_multimodal_content(result)
        # 处理正文第一个无用的标题
        result = self.process_utils.process_first_title(result)
        # 明星词处理
        if context["query_category"] == "明星" or context["da_intention"]:
            result = self.process_utils.process_markdown_title(result, context["weibo_update_dict"])
        # 回写特殊格式
        spe_md = context.get("special_md", {})
        context["weibo_update_dict"]["special_md"] = spe_md
        result = back_special_format(result, spe_md)
        # 处理账号
        result = process_called_account(result, context["user_feature_dict"])
        self.process_utils.get_log_func(context)(f"user_feature_dict: {json.dumps(context['user_feature_dict'], ensure_ascii=False)}")
        if spe_md:
            self.process_utils.get_log_func(context)(f"special_markdown_format: {json.dumps(spe_md, ensure_ascii=False)}")
        return result

class CardOutputHandler(PostProcessHandler):
    def handle(self, result, context):
        all_ready_list = context.get("ready_pid_dict", {}).get("all_ready_list", [])
        context["weibo_update_dict"]["card_multimodal"] = self.process_utils.card_output(all_ready_list, context)
        context["weibo_update_dict"]["share_card_multimodal"] = self.process_utils.share_card_output(all_ready_list)
        return result

class NewCardOutputHandler():

    def __init__(self,pid):
        self.pid = pid
        self.process_utils = ProcessUtils(pid)

    async def handle(self, result, context):
        all_ready_list = context.get("ready_pid_dict", {}).get("all_ready_list", [])
        context["weibo_update_dict"]["card_multimodal"] = await self.process_utils.card_output_new(all_ready_list, context)
        context["weibo_update_dict"]["share_card_multimodal"] = self.process_utils.share_card_output(all_ready_list)
        return result

class BusinessLinkHandler(PostProcessHandler):

    def __init__(self, pid):
        super().__init__(pid)
        self.process_utils = ProcessUtils(pid)

    def handle(self, result, context):
        output_all_ready = context["output_all_ready"]
        if_business_link = context["if_business_link"]
        if output_all_ready and if_business_link:
            return process_content(result, context)
        return result

