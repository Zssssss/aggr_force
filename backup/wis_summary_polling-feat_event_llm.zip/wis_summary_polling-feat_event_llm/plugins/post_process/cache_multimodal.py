import asyncio
import json
import time
import traceback

from lib.base import Base
from lib.redis_utils import async_redis_client, real_time_async_redis_client


class CacheMultimodal(Base):

    def __init__(self, weibo, pid):
        super().__init__(pid)
        self.weibo = weibo
        self.update_pre_log_msg(weibo)

    async def get_cached_multi_modal(self, abtest_label) :
        try :
            query = self.weibo.get("query")
            key = f"zhisou_multimodal_{query}_{abtest_label}"
            cache_redis = await async_redis_client.get_redis_server(key)
            cache_data = await cache_redis.get(key)
            if not cache_data :
                self.logger.info(
                    self.pre_log_msg + f"[{abtest_label}], get_cached_multi_modal, key:{key}, cache not found")
                return None
            cached_dict = json.loads(cache_data)
            self.logger.info(
                self.pre_log_msg + f"[{abtest_label}], get_cached_multi_modal, key:{key}, cache hit, count:{len(cached_dict)}")
            return cached_dict
        except Exception as e :
            self.logger.error(self.pre_log_msg + f"[{abtest_label}], get_cached_multi_modal, error: {e}")
            return None

    async def cache_multi_modal(self, abtest_label, all_ready_list) :
        try :
            if not all_ready_list :
                self.logger.info(
                    self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, all_ready_list is empty, skip cache")
                return False
            query = self.weibo.get("query")
            if not query :
                self.logger.info(self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, query is empty, skip cache")
                return False
            key = f"zhisou_multimodal_{query}_{abtest_label}"
            cache_redis = await async_redis_client.get_redis_server(key)
            if not cache_redis :
                self.logger.error(self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, redis connection failed")
                return False
            value = []
            for item in all_ready_list :
                if not isinstance(item, dict) :
                    self.logger.info(
                        self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, item is not a dict, skip, type:{type(item)}")
                    continue
                mid = item.get("cur_mid", "")
                data = {
                    "mid" : mid,  # 微博ID
                    "pid" : item.get("img_pid", ""),  # 图片ID或视频封面图ID
                    "type" : item.get("type", ""),  # 类型：pic=图片，video=视频
                    "click_rate" : item.get("click_rate", 0), # 点击率
                    "sort_1": item.get("sort_1", 0), # 实验组点击率
                    "sort_2": item.get("sort_2", 0), # 实验组点击率
                    "click_num" : item.get("click_num", 0), # 点击量
                    "is_caibian" : 1, # 是否采编
                    "expose_num" : item.get("expose_num", 0) # 曝光量
                }
                if not data["mid"] or not data["pid"] or not data["type"] :
                    self.logger.info(
                        self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, missing required fields, skip, data:{data}")
                    continue
                value.append(data)
            if not value :
                self.logger.info(self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, no valid data to cache")
                return False
            # 将数据序列化为JSON并存入Redis
            # ex=60*60*24*7 表示缓存有效期为7天（604800秒）
            json_str = json.dumps(value, ensure_ascii=False)
            await cache_redis.set(key, json_str, ex=60 * 60 * 24 * 7)
            # 记录缓存写入日志
            self.logger.info(
                self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, cache success, key:{key}, count:{len(value)}")
            return True
        except Exception as e :
            self.logger.error(
                self.pre_log_msg + f"[{abtest_label}], cache_multi_modal, error: {e}, traceback: {traceback.format_exc()}")
            return False

    async def append_cache_multi_modal(self, abtest_label, all_ready_list):
        """
        追加缓存多模态数据，会先获取现有缓存，然后追加新数据，并根据 mid 和 pid 过滤重复数据

        Args:
            abtest_label: AB测试标签
            all_ready_list: 待追加的数据列表

        Returns:
            bool: 追加成功返回True，失败返回False
        """
        try:
            if not all_ready_list:
                self.logger.info(
                    self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, all_ready_list is empty, skip cache")
                return False
            query = self.weibo.get("query")
            if not query:
                self.logger.info(self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, query is empty, skip cache")
                return False
            key = f"zhisou_multimodal_{query}_{abtest_label}"
            cache_redis = await async_redis_client.get_redis_server(key)
            if not cache_redis:
                self.logger.error(self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, redis connection failed")
                return False

            # 第一步：获取现有缓存数据
            existing_data = []
            cache_data = await cache_redis.get(key)
            if cache_data:
                try:
                    existing_data = json.loads(cache_data)
                    self.logger.info(
                        self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, existing cache count:{len(existing_data)}")
                except Exception as e:
                    self.logger.error(
                        self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, parse existing cache error: {e}")
                    existing_data = []
            else:
                self.logger.info(
                    self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, no existing cache found")

            # 第二步：构建现有数据的 mid+pid 集合，用于去重
            existing_keys = set()
            for item in existing_data:
                mid = item.get("mid", "")
                pid = item.get("pid", "")
                if mid and pid:
                    existing_keys.add(f"{mid}_{pid}")

            # 第三步：处理新数据，过滤重复的 mid+pid
            new_data = []
            duplicate_count = 0
            for item in all_ready_list:
                if not isinstance(item, dict):
                    self.logger.info(
                        self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, item is not a dict, skip, type:{type(item)}")
                    continue
                mid = item.get("cur_mid", "")
                pid = item.get("img_pid", "")
                data = {
                    "mid": mid,  # 微博ID
                    "pid": pid,  # 图片ID或视频封面图ID
                    "type": item.get("type", ""),  # 类型：pic=图片，video=视频
                    "click_rate": item.get("click_rate", 0),  # 点击率
                    "sort_1": item.get("sort_1", 0),  # 实验组点击率
                    "sort_2": item.get("sort_2", 0),  # 实验组点击率
                    "click_num": item.get("click_num", 0),  # 点击量
                    "is_caibian": 1,  # 是否采编
                    "expose_num": item.get("expose_num", 0),  # 曝光量
                }
                if not data["mid"] or not data["pid"] or not data["type"]:
                    self.logger.info(
                        self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, missing required fields, skip, data:{data}")
                    continue

                # 检查是否重复
                key_str = f"{mid}_{pid}"
                if key_str in existing_keys:
                    duplicate_count += 1
                    self.logger.info(
                        self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, duplicate mid_pid, skip, mid:{mid}, pid:{pid}")
                    continue

                new_data.append(data)
                existing_keys.add(key_str)  # 添加到集合中，防止新数据内部重复

            if not new_data:
                self.logger.info(
                    self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, no new valid data to append, duplicate_count:{duplicate_count}")
                return False

            # 第四步：合并现有数据和新数据
            merged_data = existing_data + new_data

            # 第五步：将合并后的数据写入Redis
            # ex=60*60*24*7 表示缓存有效期为7天（604800秒）
            json_str = json.dumps(merged_data, ensure_ascii=False)
            await cache_redis.set(key, json_str, ex=60 * 60 * 24 * 7)

            # 记录缓存写入日志
            self.logger.info(
                self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, append success, "
                f"key:{key}, existing_count:{len(existing_data)}, new_count:{len(new_data)}, "
                f"duplicate_count:{duplicate_count}, total_count:{len(merged_data)}")
            return True
        except Exception as e:
            self.logger.error(
                self.pre_log_msg + f"[{abtest_label}], append_cache_multi_modal, error: {e}, traceback: {traceback.format_exc()}")
            return False

    def trans_cache_data(self, cache_data):
        """
        将缓存数据转换为 {mid: [{"pid": "...", "type": "...", ...}]} 的格式
        """
        map_dict = {"p": "pic", "v": "video"}
        try:
            if not cache_data:
                return {}
            trans_data = {}
            for item in cache_data:
                mid = item.get("mid", "")
                if not mid:
                    continue
                item["type"] = map_dict.get(item["type"], "")
                trans_data.setdefault(mid, []).append(item)
            return trans_data
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"trans_data error: {e}")

    @staticmethod
    def reverse_trans_cache_data(trans_data: dict):
        """
        将 {mid: [{"pid": "...", "type": "...", ...}]} 格式
        转回 [{"mid": "...", "type": "p", ...}, ...] 的列表格式
        """
        reverse_map = {"pic": "p", "video": "v"}
        result = []

        if not trans_data:
            return result

        for mid, items in trans_data.items():
            for item in items:
                new_item = item.copy()
                new_item["mid"] = mid
                new_item["type"] = reverse_map.get(item.get("type", ""), "")
                result.append(new_item)

        return result

    def filter_cache_multi_modal(self, abtest_label, cache_data):
        """
        过滤缓存的多模态数据，添加 content 字段

        Args:
            abtest_label: AB测试标签
            cache_data: 缓存数据字典，格式：{mid: [{"pid": "...", "type": "...", ...}]}

        Returns:
            dict: 过滤后的字典，格式：{mid: [{"pid": "...", "content": "...", ...}]}
        """
        try:
            mid_feature_dict = self.weibo.get("mid_feature_dict", {})
            filtered_data = {}
            all_skip_list = []
            filter_count = 0
            for mid, items in cache_data.items():
                # 从 mid_feature_dict 获取 content
                content = mid_feature_dict.get(mid, {}).get("relevance_info", {}).get("mid_text", "")
                if content:
                    # 为每个 item 添加 content 字段
                    for item in items:
                        item["content"] = content
                    filtered_data[mid] = items
                    filter_count += len(items)
                else:
                    all_skip_list.extend(items)
                    self.logger.info(self.pre_log_msg + f"[{abtest_label}], filter_cache_multi_modal, no content, skip, mid:{mid}")
            self.logger.info(self.pre_log_msg + f"[{abtest_label}], filter_cache_multi_modal final_all, filter_count: {filter_count}, all_skip_count: {len(all_skip_list)}")
            return filtered_data
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"[{abtest_label}], filter_cache_multi_modal, error: {e}, traceback: {traceback.format_exc()}")
            return {}

    def merge_multi_modal(self, abtest_label, final_card_multi, cache_data):
        try:
            # ========== 取并集：优先使用 final_card_multi ==========
            # 初始化合并后的结果字典（深拷贝，避免修改原数据）
            merged_dict = {}
            # 统计信息
            unpick_pids = []  # 记录未被采用的 pid（因为已存在）
            # 第一步：添加 final_card_multi 中的所有数据（优先级最高）
            for mid, items in final_card_multi.items():
                # 深拷贝，避免修改原数据
                merged_dict[mid] = list(items)
            # 第二步：补充缓存中的数据
            for mid, items in cache_data.items():
                if mid not in merged_dict:
                    # ========== 情况1：mid 不在 final_card_multi 中，直接添加 ==========
                    merged_dict[mid] = list(items)
                else:
                    # ========== 情况2：mid 已存在，检查每个 pid 是否重复 ==========
                    existing_pids = [item.get("pid", "") for item in merged_dict[mid]]
                    # 遍历缓存中的每个 item
                    for item in items:
                        pid = item.get("pid", "")
                        if pid and pid not in existing_pids:
                            # pid 不存在，补充该 item
                            merged_dict[mid].append(item)
                            existing_pids.append(pid)  # 更新已有 pid 集合
                        else:
                            # pid 已存在或为空，跳过
                            if pid:
                                unpick_pids.append(f"{mid}:{pid}")
            self.logger.info(
                self.pre_log_msg + f"[{abtest_label}], merge_multi_modal, unpick_pids: {unpick_pids}"
            )
            return merged_dict
        except Exception as e:
            self.logger.error(
                self.pre_log_msg + f"[{abtest_label}], merge_multi_modal, "
                f"error: {e}, traceback: {traceback.format_exc()}"
            )
            # 异常时返回 final_card_multi（保底策略）
            return final_card_multi if final_card_multi else {}

class ClickRateRealtime(Base):
    """
    实时点击率数据获取类

    功能:
        从Redis获取多模态内容（图片/视频）的实时点击数和曝光数

    数据来源:
        - 综合页数据：wis_{mid}_exp_search, wis_{pid}_{mid}_click_search
        - 卡片页数据：wis_{pid}_exp_click_search

    主要方法:
        - get_realtime_zonghe: 获取综合页单个mid-pid的点击/曝光数
        - get_realtime_card: 获取卡片页单个pid的点击/曝光数
        - get_merge_data: 批量获取多个mid-pid的点击/曝光数并合并
    """
    def __init__(self, weibo, pid):
        super().__init__(pid)
        self.weibo = weibo
        self.update_pre_log_msg(weibo)

    def gen_zonghe_key(self, mid, pid, type):
        if type == "exp":
            return f"wis_{mid}_exp_search"
        return f"wis_{pid}_{mid}_{type}_search"

    def gen_card_key(self, query, pid):
        return f"wis_{pid}_exp_click_search"
    
    def gen_card_key_new(self, query, pid):
        return f"wis_{query}_{pid}_exp_click_search"

    async def get_realtime_zonghe(self, mid, pid, type):
        try:
            key = self.gen_zonghe_key(mid, pid, type)
            cache_redis = await real_time_async_redis_client.get_redis_server(key)
            cache_data = await cache_redis.get(key)
            if not cache_data:
                return 0
            data = json.loads(cache_data)
            # 返回数值，如果解析失败返回0
            return int(data) if data else 0
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"get_realtime_zonghe error, mid:{mid}, pid:{pid}, type:{type}, error:{e}")
            return 0

    async def get_realtime_card(self, query, mid, pid):
        try:
            key = self.gen_card_key(query, pid)
            cache_redis = await real_time_async_redis_client.get_redis_server(key)
            # hgetall 返回的是字典，键和值都是 bytes 类型
            # 例如：{b'click': b'386', b'exp': b'10943'}
            cache_data = await cache_redis.hgetall(key)
            if not cache_data:
                return {"click": 0, "exp": 0}
            return {
                "click": int(cache_data.get(b"click", b"0").decode()),
                "exp": int(cache_data.get(b"exp", b"0").decode())
            }
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"get_realtime_card error, mid:{mid}, pid:{pid}, error:{e}")
            return {"click": 0, "exp": 0}

    async def get_realtime_card_new(self, query, mid, pid):
        try:
            key = self.gen_card_key_new(query, pid)
            cache_redis = await real_time_async_redis_client.get_redis_server(key)
            # hgetall 返回的是字典，键和值都是 bytes 类型
            # 例如：{b'click': b'386', b'exp': b'10943'}
            cache_data = await cache_redis.hgetall(key)
            if not cache_data:
                return {"click": 0, "exp": 0}
            return {
                "click": int(cache_data.get(b"click", b"0").decode()),
                "exp": int(cache_data.get(b"exp", b"0").decode())
            }
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"get_realtime_card error, mid:{mid}, pid:{pid}, error:{e}")
            return {"click": 0, "exp": 0}

    async def get_merge_data(self, query, item_list):
        """
        批量获取多个mid-pid的实时点击/曝光数据并合并

        参数:
            item_list: 列表，每个元素为 [mid, pid]

        返回:
            dict: 嵌套字典，格式为 {"mid": {"pid": {"click_zonghe": 综合页点击数, "exp_zonghe": 综合页曝光数, "click_card": 卡片页点击数, "exp_card": 卡片页曝光数}}}

        示例:
            输入: [["5236101077797471", "abc123"], ["5236101077797472", "def456"]]
            输出: {
                "5236101077797471": {
                    "abc123": {
                        "click_zonghe": 10,
                        "exp_zonghe": 100,
                        "click_card": 5,
                        "exp_card": 50
                    }
                }
            }
        """
        try:
            if not item_list:
                return {}

            # ========== 第一步：创建并发任务 ==========
            # 为每个 mid-pid 对创建4个任务：综合页点击数、综合页曝光数、卡片页点击数、卡片页曝光数
            tasks = []
            task_info = []  # 记录每个任务对应的 mid, pid, source, type

            for item in item_list:
                if not item or len(item) < 2:
                    continue
                mid = item[0]
                pid = item[1]

                # 创建获取综合页点击数的任务
                tasks.append(asyncio.create_task(self.get_realtime_zonghe(mid, pid, "click")))
                task_info.append((mid, pid, "zonghe", "click"))

                # 创建获取综合页曝光数的任务
                tasks.append(asyncio.create_task(self.get_realtime_zonghe(mid, pid, "exp")))
                task_info.append((mid, pid, "zonghe", "exp"))

                # 创建获取卡片页数据的任务
                tasks.append(asyncio.create_task(self.get_realtime_card(query, mid, pid)))
                task_info.append((mid, pid, "card", None))

                # 创建获取卡片页数据的任务
                tasks.append(asyncio.create_task(self.get_realtime_card_new(query, mid, pid)))
                task_info.append((mid, pid, "card_new", None))

            # ========== 第二步：并发执行所有任务 ==========
            start = time.time()
            results = await asyncio.gather(*tasks, return_exceptions=True)
            # ========== 第三步：组装结果为嵌套字典 ==========
            merge_data = {}
            for i, result in enumerate(results):
                mid, pid, source, data_type = task_info[i]

                # 处理异常结果
                if isinstance(result, Exception):
                    self.logger.error(
                        self.pre_log_msg + f"get_merge_data task failed, mid:{mid}, pid:{pid}, "
                        f"source:{source}, type:{data_type}, error:{result}"
                    )
                    if source == "card" or source == "card_new":
                        result = {"click": 0, "exp": 0}
                    else:
                        result = 0

                # 初始化嵌套字典结构
                if mid not in merge_data:
                    merge_data[mid] = {}
                if pid not in merge_data[mid]:
                    merge_data[mid][pid] = {
                        "click_zonghe": 0, # 搜索流实时点击量
                        "exp_zonghe": 0,   # 搜索流实时曝光量
                        "click_card": 0,   # 卡片页实时点击量（不是query级别的）
                        "exp_card": 0,      # 卡片页实时曝光量（不是query级别的）
                        "click_card_new": 0, # 卡片页实时点击量（query级别的）
                        "exp_card_new": 0    # 卡片页实时曝光量（query级别的）
                    }

                # 填充数据
                if source == "zonghe":
                    # 综合页数据
                    merge_data[mid][pid][f"{data_type}_zonghe"] = result
                elif source == "card":
                    # 卡片页数据（返回的是字典）
                    merge_data[mid][pid]["click_card"] = result.get("click", 0)
                    merge_data[mid][pid]["exp_card"] = result.get("exp", 0)
                elif source == "card_new":
                    # 卡片页数据（返回的是字典）
                    merge_data[mid][pid]["click_card_new"] = result.get("click", 0)
                    merge_data[mid][pid]["exp_card_new"] = result.get("exp", 0)
            self.logger.info(self.pre_log_msg + f"get_merge_data success,cost time: {start} merge_data: {json.dumps(merge_data, ensure_ascii=False)}")
            return merge_data

        except Exception as e:
            self.logger.error(
                self.pre_log_msg + f"get_merge_data error: {e}, traceback: {traceback.format_exc()}"
            )
            return {}

async def test_case():
    weibo = {}
    query = "曝林俊杰女友是七七"
    item_list = [["5236896968213045", "007xqkhgly1i7oi99xltuj30ym080adt"]]
    result = await ClickRateRealtime(weibo, "test").get_merge_data(query, item_list)
    print(result)

if __name__ == "__main__":
    asyncio.run(test_case())
