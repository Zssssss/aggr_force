"""后处理公共方法"""
# -*- coding:utf-8 -*-
import json
import re
from collections import defaultdict

import emoji

# ============= 基础的正则表达式 =============
# 匹配中文字符
ZH_PATTERN = r'[\u4e00-\u9fa5]'
# 匹配数字
NUM_PATTERN = r'\d'
# 匹配英文字符
EN_PATTERN = r'[A-Za-z]'
# 匹配特殊字符
SPECIAL_CHAR_PATTERN = r'[^\w\s]'
# 匹配链接
LINK_PATTERN = r'https?://\S+'

# ============= 分割思考态和正文 =============
def split_think_and_content(result):
    """分割思考态和正文"""
    if "</think>" in result:
        think = result.split("</think>")[0] + "</think>"
        content = result.split("</think>")[1]
    elif "<think>" in result:
        think = result
        content = ""
    else:
        think = ""
        content = result
    return think, content

# ============= 分割正文段落（细致分割） =============
# ============= 入口函数 split_markdown_paragraphs =============
def check_is_next_paragraph(text: str):
    """判断是否是下一个段落"""
    is_header = re.match(r'^#{1,6}\s', text)   # 标题
    is_list = re.match(r'^ *[-*+] |^ *\d+\. ', text)  # 列表项
    is_blockquote = re.match(r'^ *> ', text)  # 引用

    if is_header or is_list or is_blockquote:
        return True
    return False

def single_split_markdown_paragraphs(text: str):
    """单\n区分"""
    split_list = []
    line_list = text.split("\n")
    cur_text = ""
    for i in range(len(line_list) - 1):
        cur_text += line_list[i] + "\n"
        if check_is_next_paragraph(line_list[i + 1]):
            split_list.append(cur_text)
            cur_text = ""
    cur_text += line_list[-1]
    split_list.append(cur_text)
    return split_list

def split_markdown_paragraphs(text: str):
    """按段落拆分markdown格式文本"""
    split_list = []
    line_list = text.split("\n\n")
    for single_text in line_list[:-1]:
        single_text += "\n\n"
        split_list.extend(single_split_markdown_paragraphs(single_text))
    split_list.extend(single_split_markdown_paragraphs(line_list[-1]))
    return split_list

# ============= 分割段落（粗略分割, 多个换行符） =============
def split_paragraphs_with_multiple_linefeed(text: str):
    """按段落拆分文本，段落以两个或多个换行符分割"""
    split_result = re.split(r"\n{2,}", text)
    return split_result

# ============= 分割段落（通过markdown #开头的标题分割） =============
def split_paragraphs_with_markdown_title(text: str):
    """按段落拆分文本，段落以markdown #开头的标题分割"""
    split_result = re.split(r"\n#+", text)
    return split_result

# ============= 删除空括号 =============
def delete_empty_brackets(text: str):
    """删除空括号"""
    return re.sub(r"[\(（\[【][\)）\]】]", "", text)

# ============ 找到markdown标题 =============
def find_markdown_title(result) -> list[str]:
    # 去除特殊字符块
    result = re.sub(r'```.*?```', "", result, flags=re.DOTALL)
    result = re.sub(r'<media-block>.*?</media-block>', "", result, flags=re.DOTALL)
    lines = result.split('\n')
    categorized = defaultdict(list)

    for line in lines:

        if not line.startswith('#'):
            continue

        level = len(line) - len(line.lstrip('#'))

        # 清除 <a>...</a> 标签并去除尾部空白
        clean_line = re.sub(r"<a>.*?</a>", "", line).strip()

        categorized[level].append(clean_line)

    # 返回按标题等级升序排序的列表
    return [categorized[level] for level in sorted(categorized)]

# ============ 清洗markdown标题 =============
def clean_markdown_title(title: str) -> str:
    # 1. 去除井号（如 # 标记）
    text = title.replace("#", "")
    # 2. 去除编号前缀：如 1.、一、等
    text = re.sub(r"^[\s\W]*(\d+\.\s*|[一二三四五六七八九]、)", "", text)
    # 3. 去除 emoji
    text = emoji.replace_emoji(text, replace="")
    # 4. 去除星号
    text = text.replace("*", "")
    # 5. 去除副标题（以中英文冒号分隔）
    for sep in ("：", ":"):
        if sep in text:
            text = text.split(sep, 1)[0]
            break
    # 6. 去除全角括号及其中内容（如：标题（推荐） → 标题）
    text = re.sub(r"（.*?）", "", text)
    # 7. 去除首尾空格
    return text.strip()
# ============= 去除并保存段落末尾的空格和换行符 =============
def remove_and_save_trailing(s):
    """去除并保存段落末尾的空格和换行符"""
    # 移除末尾所有空格和换行符
    stripped_str = s.rstrip()
    # 计算被移除的长度
    removed_length = len(s) - len(stripped_str)
    removed_part = s[-removed_length:] if removed_length > 0 else ""
    return stripped_str, removed_part

# ============= 获取微博链接索引列表 =============
def get_weibo_link_index_list(link_list: list):
    """获取微博链接索引列表"""
    index_list = []
    for index, link_item in enumerate(link_list):
        if link_item.startswith("sinaweibo:"):
            index_list.append(index + 1)
    return index_list

# ============= 通过第一级标题获取段落列表 =============
def get_paragraph_list_by_h1(content: str):
    """按首次出现的标题级别分段，常用于 Markdown 文本处理"""
    lines = content.split("\n")
    paragraph_list = []
    cur_paragraph = []
    cur_level = -1
    title_re = re.compile(r"^(#{1,6})\s")  # 捕获标题等级

    for line in lines:
        match = title_re.match(line)
        if match:
            level = len(match.group(1))
            if cur_level == -1:
                cur_level = level
            if level == cur_level:
                if cur_paragraph:
                    paragraph_list.append("\n".join(cur_paragraph))
                    cur_paragraph = []
        cur_paragraph.append(line)

    if cur_paragraph:
        paragraph_list.append("\n".join(cur_paragraph))
    return paragraph_list

# ============= 通过>= 首次标题级别 的标题获取段落列表 =============
def get_paragraph_list_by_h1_or_above(content: str):
    """按所有 >= 首次标题级别 的标题分段，常用于 Markdown 文本处理"""
    lines = content.split("\n")
    paragraph_list = []
    cur_paragraph = []
    cur_level = -1
    title_re = re.compile(r"^(#{1,6})\s")  # 捕获标题等级

    for line in lines:
        match = title_re.match(line)
        if match:
            level = len(match.group(1))
            # 记录首次标题级别
            if cur_level == -1:
                cur_level = level
            # 如果标题级别 >= 首次标题级别，就分段
            if level >= cur_level:
                if cur_paragraph:
                    paragraph_list.append("\n".join(cur_paragraph))
                    cur_paragraph = []
        cur_paragraph.append(line)

    if cur_paragraph:
        paragraph_list.append("\n".join(cur_paragraph))
    return paragraph_list


def replace_first_sentence(text, new_first_sentence):
    try:
        # 匹配 ##回答首句： 和 ##回答主体：，允许冒号后面有0个或多个空格
        # 使用命名分组
        pattern = r'(?P<start>##\s*回答首句[：:]?\s*).*?(?P<end>\s*##\s*回答主体[：:]?\s*)'

        # 使用命名引用
        replacement = r'\g<start>' + new_first_sentence + r'\g<end>'
        # 只替换第一个匹配项
        result = re.sub(pattern, replacement, text, count=1, flags=re.DOTALL)

        return result
    except Exception as e:
        pass
    return text


def remove_result_notation(result: str):
    """
    移除结果文本中的标记符号
    
    Args:
        result (str): 待处理的文本
        
    Returns:
        str: 移除标记后的文本
    """
    # 定义需要移除的标记模式列表
    patterns = [
        # 匹配 ##回答主体： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'##\s*回答主体[：:]?\s*\n?',
        
        # 匹配 ##回答首句： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'##\s*回答首句[：:]?\s*\n*',
        
        # 匹配 ## **回答主体**： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'##\s*\*\*\s*回答主体\s*\*\*[：:]?\s*\n?',
        
        # 匹配 ## **回答首句**： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'##\s*\*\*\s*回答首句\s*\*\*[：:]?\s*\n*',
        
        # 匹配 **回答主体**： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'\*\*\s*回答主体\s*\*\*[：:]?\s*\n?',
        
        # 匹配 **回答首句**： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'\*\*\s*回答首句\s*\*\*[：:]?\s*\n*',

        # 回答正文删除

        # 匹配 ##回答主体： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'##\s*回答正文[：:]?\s*\n?',

        # 匹配 ## **回答主体**： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'##\s*\*\*\s*回答正文\s*\*\*[：:]?\s*\n?',

        # 匹配 **回答主体**： 格式的标记（支持中英文冒号，可选冒号后空格和换行符）
        r'\*\*\s*回答正文\s*\*\*[：:]?\s*\n?',

    ]
    
    # 循环应用所有正则表达式模式
    cleaned_result = result
    for pattern in patterns:
        cleaned_result = re.sub(pattern, '', cleaned_result)
    
    return cleaned_result


def convert_credential_part(text: str):
    """将输出的可信度部分转换为wbCustomBlock"""
    try:
        # 快速检查：如果文本中不包含关键词，直接返回
        if '核心结论可信度评分' not in text:
            return text

        # 统一正则模式：
        # - 核心结论可信度评分: 可选## + 可选** + 核心结论可信度评分 + 可选** + 可选冒号
        pattern = (
            r'(?P<start>.*)'
            r'(?P<credential>##\s*\*?\*?\s*核心结论可信度评分\s*\*?\*?[：:]?\s*(?:[^\n]+|(?:\n[^\n]+)))'
            r'(?P<end>.*)'
        )

        def replace_func(match):
            start = match.group('start')
            credential = match.group('credential')
            end = match.group('end')

            # 提取credential中第一个出现的连续数字
            first_number_match = re.search(r'\d+', credential)
            if first_number_match:
                # 只取第一个连续数字
                number_str = first_number_match.group()
                try:
                    number = int(number_str)
                except Exception as e:
                    number = 0
                # 使用<p>标签包裹
                block_data = {
                    "type": "reliability",
                    "data": {
                        "tag_name": f"可信度{number * 10}%",
                        "tag_normal_color": '#FF8200',
                        "tag_dark_color": '#EA8011',
                        "tips": '智搜AI对求证结论的可信度评估，仅供参考'
                    }
                }
                wrapped_number = f"""```wbCustomBlock{json.dumps(block_data, ensure_ascii=False)}```"""
            else:
                wrapped_number = ''

            # 确保start和wrapped_number间没有换行符和空格，wrapped_number与end之间要有一个换行符
            # 去除start末尾的换行符和空格
            start_clean = start.rstrip('\n ')
            # 确保end开头有换行符
            end_clean = end if end.startswith('\n') else '\n' + end

            return f'{start_clean}{wrapped_number}{end_clean}'

        # 执行正则替换
        if re.search(pattern, text, flags=re.DOTALL):
            text = re.sub(pattern, replace_func, text, count=1, flags=re.DOTALL)

        return text
    except Exception as e:
        pass
    return text


def test_remove_result_notation():
    """测试 remove_result_notation 函数的多种场景"""
    
    # 定义测试用例列表
    test_cases = [
        {
            "name": "测试用例1：包含所有标记格式",
            "input": '''
##回答首句：冬日暖阳下，梅婷在菜园里摘着芋头突然笑问公公："爸，现在最喜欢快快还是阳阳？"

**回答主体**

### 一、九年轮回的温情名场面
这是测试内容。
            ''',
            "expected": '''
冬日暖阳下，梅婷在菜园里摘着芋头突然笑问公公："爸，现在最喜欢快快还是阳阳？"

### 一、九年轮回的温情名场面
这是测试内容。
            '''
        },
        {
            "name": "测试用例2：使用中文冒号",
            "input": '''
##回答首句：这是首句内容

##回答主体：这是主体内容

### 标题
正文内容。
            ''',
            "expected": '''
这是首句内容

这是主体内容

### 标题
正文内容。
            '''
        },
        {
            "name": "测试用例3：使用英文冒号",
            "input": '''
##回答首句: 首句内容

**回答主体**: 主体内容

### 标题
正文。
            ''',
            "expected": '''
首句内容

主体内容

### 标题
正文。
            '''
        },
        {
            "name": "测试用例4：使用加粗格式",
            "input": '''
**回答首句**：加粗的首句标记

**回答主体**：加粗的主体标记

### 标题
内容。
            ''',
            "expected": '''
加粗的首句标记

加粗的主体标记

### 标题
内容。
            '''
        },
        {
            "name": "测试用例5：混合格式",
            "input": '''
## **回答首句**  
普通首句

**回答主体**：加粗主体

### 标题
这是正文内容。
            ''',
            "expected": '''
普通首句

加粗主体

### 标题
这是正文内容。
            '''
        },
        {
            "name": "测试用例6：无标记格式",
            "input": '''
### 标题
这是没有标记的正文内容。

#### 子标题
更多内容。
            ''',
            "expected": '''
### 标题
这是没有标记的正文内容。

#### 子标题
更多内容。
            '''
        },
        {
            "name": "测试用例7：只有部分标记",
            "input": '''
##回答首句：只有首句标记

### 标题
内容。

#### 子标题
更多内容。
            ''',
            "expected": '''
只有首句标记

### 标题
内容。

#### 子标题
更多内容。
            '''
        },
        {
            "name": "测试用例8：标记后无空格",
            "input": '''
##回答首句：紧接内容

**回答主体**：紧接内容

### 标题
正文。
            ''',
            "expected": '''
紧接内容

紧接内容

### 标题
正文。
            '''
        },
        {
            "name": "测试用例9：标记后有换行",
            "input": '''
##回答首句：
首句内容在下一行

**回答主体**：
主体内容在下一行

### 标题
正文。
            ''',
            "expected": '''
首句内容在下一行

主体内容在下一行

### 标题
正文。
            '''
        },
        {
            "name": "加粗",
            "input": "\n## **回答首句**  \n中国女足即将在温布利球场挑战新科欧洲冠军英格兰队，这场承载复仇与练兵双重使命的对决，门票已售超8万张，创女足友谊赛罕见盛况[^21][^27][^7]。\n\n## **回答主体**  \n\n### ⚽ 一、焦点赛事：中英女足温布利对决\n1. **时间与地点**：  \n   - 伦敦时间11月29日17:30（北京时间11月30日1:30），于温布利球场举行友谊赛[^1][^6][^13]。  \n   - 此战是中国女足首次登陆温布利，亦是亚洲冠军与欧洲冠军的首次碰撞[^7][^19]。  \n\n2. **赛事背景**：  \n   - **复仇之战**：2023年世界杯小组赛，中国女足曾1-6惨败英格兰，创队史世界杯最大分差失利[^14][^45]。  \n   - **练兵目标**：为2026年女足亚洲杯备战（中国与朝鲜、乌兹别克斯坦、孟加拉国同组），通过与世界第5的强敌交锋检验实力[^7][^13][^43]。  \n\n3. **现场热度**：  \n   - 门票售出超8万张，客队球迷区2000余张票售罄，预计上座率将逼近1999年女足世界杯决赛纪录[^21][^27]。  \n\n---\n\n### 📊 二、双方现状与阵容对比  \n1. **英格兰女足**：  \n   - **欧洲霸主**：2025年欧洲杯点球击败西班牙卫冕，战术执行力强，主帅威格曼5次率队进大赛决赛[^13][^19]。  \n   - **人员构成**：依托英超成熟体系，注册球员超300万",
            "expected": ""
        }
    ]
    
    # 执行测试
    print("=" * 80)
    print("开始测试 remove_result_notation 函数")
    print("=" * 80)
    
    passed = 0
    failed = 0
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n【测试 {i}】{test_case['name']}")
        print("-" * 50)
        
        # 执行函数
        result = remove_result_notation(test_case['input'])
        
        # 比较结果
        if result == test_case['expected']:
            print("✅ 测试通过")
            passed += 1
        else:
            print("❌ 测试失败")
            print(f"输入: {repr(test_case['input'])}")
            print(f"期望: {repr(test_case['expected'])}")
            print(f"实际: {repr(result)}")
            failed += 1
        
        print("-" * 50)
    
    # 输出测试结果统计
    print("\n" + "=" * 80)
    print("测试结果统计")
    print("=" * 80)
    print(f"总测试数: {len(test_cases)}")
    print(f"通过: {passed}")
    print(f"失败: {failed}")
    print(f"通过率: {passed/len(test_cases)*100:.1f}%")
    
    if failed == 0:
        print("🎉 所有测试用例都通过了！")
    else:
        print(f"⚠️  有 {failed} 个测试用例失败，请检查函数实现。")

def test_replace_first_sentence():
    """测试 replace_first_sentence 函数"""
    
    # 测试用例
    input_text = '''
    \n## 回答首句  \n日本在冲绳及西南诸岛加速部署导弹系统、引入多国军舰的军事行动，正将这片距离台湾仅110公里的岛屿群推入地缘冲突的最前沿，而当地民众的生存焦虑与东亚安全格局的重构已悄然交织成一场无声的博弈。  \n\n## 回答主体  \n\n### 一、军事部署动态与战略意图  \n1. **导弹系统推进**  \n   日本防卫大臣小泉进次郎于2025年11月23日视察冲绳石垣岛和与那国岛，    
    '''
    
    new_first_sentence = "这是新的首句内容"
    
    expected = '''
    ## 回答首句  \n这是新的首句内容  \n\n## 回答主体  \n\n### 一、军事部署的核心动向  \n1. **导弹密集进驻西南诸岛**
    '''
    # 执行函数
    result = replace_first_sentence(input_text, new_first_sentence)
    
    # 输出测试结果
    print("=" * 80)
    print("测试 replace_first_sentence 函数")
    print("=" * 80)
    print(f"输入文本: {repr(input_text)}")
    print(f"新首句: {repr(new_first_sentence)}")
    print(f"期望结果: {repr(expected)}")
    print(f"实际结果: {repr(result)}")
    
    if result == expected:
        print("✅ 测试通过")
    else:
        print("❌ 测试失败")

if __name__ == "__main__":
    # 运行测试函数
    # test_remove_result_notation()
    print("\n" + "=" * 80)
    test_replace_first_sentence()