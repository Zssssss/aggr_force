# -*- coding:utf-8 -*-
def merge_and_map_link_lists(
    link_lists: list[list[str]],
) -> tuple[list[str], list[dict[int, int]]]:
    """
    合并多个link_list，去重，并返回每个link_list中的link在整个去重后的link列表中的位置映射关系
    Args:
        link_lists: 多个link_list
    Returns:
        list[str]: 合并后的link_list
        list[dict[int, int]]: 每个link_list中的link在整个去重后的link列表中的位置映射关系
    """
    merged_links = []
    position_mappings = []

    # 记录每个link_str在merged_links中的位置索引（用于快速查找）
    link_to_index = {}
    for lst in link_lists:
        # temp_mapping记录当前lst中的quote_num在merged_links中对应的位置索引
        temp_mapping = {}

        # 引文编号从1开始
        for quote_num, link_str in enumerate(lst, 1):
            # 如果link_str不在字典中，则添加到merged_links中，并记录link_str在merged_links中的位置
            if link_str not in link_to_index:
                merged_links.append(link_str)
                link_to_index[link_str] = len(merged_links) - 1
            temp_mapping[quote_num] = link_to_index[link_str]

        position_mappings.append(temp_mapping)
    return merged_links, position_mappings


def update_quote_position(content: str, position_mapping: dict[int, int]) -> str:
    """
    更新引文位置
    Args:
        content: 内容
        position_mapping: link列表中的位置映射关系
    Returns:
        str: 更新后的内容
    """
    # 临时占位符，避免引文重复被替换
    TEMP_MARKER = "\uE000"
    # 从后往前替换，避免新生成的编号被后续替换影响
    for quote_num in sorted(position_mapping.keys(), reverse=True):
        link_index = position_mapping[quote_num]
        # link_index表示在列表中的位置，从0开始；引文编号从1开始，这里需要加1
        # 使用临时标记标识已处理的内容，避免被后续替换误处理
        content = content.replace(f"[^{quote_num}]", f"[{TEMP_MARKER}^{link_index + 1}]")
    # 处理完成后，移除临时标记
    content = content.replace(TEMP_MARKER, "")
    return content


def merge_weibo_multi_modal_info(weibo_dicts: list[dict[str, any]]) -> dict[str, any]:
    """
    提取多个weibo字典中的多模态信息，更新返回
    Args:
        weibo_dicts: 多个weibo字典列表，每个字典包含相关多模态信息
    Returns:
        dict[str, any]: 更新后的多模态信息
    """
    # 合并后的多模态信息
    merged_multi_modal_info = {
        "pic_info_dict_all" : {},   # 所有图片信息字典
        "video_mid_dict" : {},      # 所有视频MID字典
        "mid_feature_dict" : {},    # 所有MID特征字典
        "user_feature_dict" : {},    # 所有用户特征字典
        "from_zhisou_quote_dict" : {}, # 来自博文信息字典
        "uid_attrs_mapping" : {},    # 所有用户属性字典
    }
    for weibo_dict in weibo_dicts:
        merged_multi_modal_info["pic_info_dict_all"].update(weibo_dict.get("pic_info_dict_all", {}))
        merged_multi_modal_info["video_mid_dict"].update(weibo_dict.get("video_mid_dict", {}))
        merged_multi_modal_info["mid_feature_dict"].update(weibo_dict.get("mid_feature_dict", {}))
        merged_multi_modal_info["user_feature_dict"].update(weibo_dict.get("user_feature_dict", {}))
        merged_multi_modal_info["from_zhisou_quote_dict"].update(weibo_dict.get("from_zhisou_quote_dict", {}))
        merged_multi_modal_info["uid_attrs_mapping"].update(weibo_dict.get("uid_attrs_mapping", {}))
    return merged_multi_modal_info


if __name__ == "__main__":
    link_list_a = ["a", "b", "c"]
    link_list_b = ["a", "c", "d"]
    merged_links, position_mappings = merge_and_map_link_lists(
        [link_list_a, link_list_b]
    )
    print(merged_links)
    print(position_mappings)
    content = "xx[^1]kk[^2]oo[^3]"
    print(update_quote_position(content, position_mappings[1]))
