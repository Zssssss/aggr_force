import asyncio
import json
import time
import traceback

import aiohttp

from lib.base import Base
from lib.redis_utils import async_redis_client
from plugins.post_process.utils import split_paragraphs_with_markdown_title, split_markdown_paragraphs, \
    split_think_and_content


def process_business_link(content, context):
    business_link_list = context["business_link_list"]
    query = context["query"]
    precise_query_list = [item.get("query") for item in business_link_list if item.get("query_type",0) == 1]
    core_query_list = [item.get("query") for item in business_link_list if item.get("query_type",0) == 2]
    all_business_dict = {item.get("query"): item for item in business_link_list}
    business_dict = all_business_dict.get(query, {})
    if query in precise_query_list:
        content = process_content(content, context, business_dict)
    else:
        for core_query in core_query_list:
            if core_query in query:
                content = process_content(content, context, all_business_dict.get(core_query, {}))
                break
    return content

def process_content(content, context):
    output_all_ready = context["output_all_ready"]
    business_dict = context["business_dict"]
    think, content = split_think_and_content(content)
    content = content.lstrip('\n')
    paragraph_list = split_markdown_paragraphs(content)
    business_material = business_dict.get("material", {})

    text = business_material.get("text", "")
    scheme = business_material.get("scheme", "")
    frequency = business_material.get("freq", 0)
    ai_business_list = business_dict.get("ai_business_list", [])
    cur_base = {"type": "business_link", "data": {"name": text, "scheme": scheme}}

    # ========== ✅ AI 模式 ==========
    if ai_business_list:
        ai_business_list.sort(key=lambda x: x.get("insert_part", 0))
        ai_business_list = ai_business_list[:frequency]
        for i, ai_item in enumerate(ai_business_list):
            insert_part = ai_item.get("insert_part") - 1
            wenan = ai_item.get("wenan", "")
            if insert_part is None or insert_part >= len(paragraph_list):
                continue

            cur = {
                "type": "business_link",
                "index": f"business_link_ai_{i}",
                "data": {
                    "name": wenan,
                    "scheme": scheme
                }
            }
            repl = f"```wbCustomBlock{json.dumps(cur, ensure_ascii=False)}```"
            stripped = paragraph_list[insert_part].rstrip("\n")
            tail_newlines = paragraph_list[insert_part][len(stripped):]
            paragraph_list[insert_part] = stripped + repl + tail_newlines

        return think + "".join(paragraph_list)

    # ========== 🧩 正常模式 ==========
    center_word_list = business_dict.get("center_word", "").split(",")
    counter = 0
    for i, paragraph in enumerate(paragraph_list):
        for center_word in center_word_list:
            if center_word in paragraph and counter < frequency:
                cur = cur_base.copy()
                cur["index"] = f"business_link_{counter}"
                repl = f"```wbCustomBlock{json.dumps(cur, ensure_ascii=False)}```"
                stripped = paragraph.rstrip("\n")
                tail_newlines = paragraph[len(stripped):]
                paragraph_list[i] = stripped + repl + tail_newlines
                counter += 1
                break

    content = "".join(paragraph_list)

    if counter == 0 and output_all_ready:
        cur = cur_base.copy()
        cur["index"] = f"business_link_{counter}"
        repl = f"```wbCustomBlock{json.dumps(cur, ensure_ascii=False)}```"
        content += repl
    result = think + content
    return result

async def fetch_external_data() :
    """模拟请求外部接口"""
    async with aiohttp.ClientSession() as session :
        url = "http://admin.s.weibo.com/intfs/Commerce/adDataForWis"
        # url = "http://10.54.6.52:13145/intfs/Commerce/adDataForWis"
        headers = {
            # "Host": "test.admin.s.weibo.com",
            "User-Agent" : "my-app/1.0"
        }
        async with session.get(url, headers=headers) as resp :
            data = await resp.json()
            return data.get("data", [])

class BussinessMaterial(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.pid = pid

    async def run(self, **kwargs):
        try:
            weibo = kwargs.get("weibo", {})
            business_link_list = await get_business_link(ttl=60, lock_timeout=30, logger=self.logger)
            weibo["business_link_list"] = business_link_list
        except Exception as e:
            self.logger.error(traceback.format_exc())
            pass

async def get_business_link(ttl: int = 60, lock_timeout: int = 30, logger=None) :
    """
    获取数据（逻辑过期 + 分布式锁 + 初始化等待）
    :param ttl: 逻辑过期秒数
    :param lock_timeout: 锁超时秒数
    """
    CACHE_KEY = "wis_business_link:cache"
    LOCK_KEY = "wis_business_link:lock"
    cache_redis = await async_redis_client.get_redis_server(CACHE_KEY)
    lock_redis = await async_redis_client.get_redis_server(LOCK_KEY)
    cache = await cache_redis.get(CACHE_KEY)
    
    old_data = []
    if cache :
        cache = json.loads(cache)
        old_data = cache.get("data", [])
        logger.info(f"old data: {cache}")
        if cache["expire_at"] > time.time() :
            return old_data
        else :
            # 过期数据：返回旧值，同时尝试后台刷新
            if await lock_redis.set(LOCK_KEY, "1", ex=lock_timeout, nx=True) :
                try :
                    new_data = await fetch_external_data()
                    logger.info(f"fetch new business link: {new_data} ")
                    # 对比数据并调用flash_query
                    await _compare_and_flash_query(old_data, new_data, logger)
                    await cache_redis.set(
                        CACHE_KEY,
                        json.dumps({"data" : new_data, "expire_at" : time.time() + ttl})
                    )
                finally :
                    await lock_redis.delete(LOCK_KEY)
            return old_data

    # 缓存根本不存在 → 初始化阶段
    if await lock_redis.set(LOCK_KEY, "1", ex=lock_timeout, nx=True) :
        try :
            new_data = await fetch_external_data()
            logger.info(f"fetch new business link: {new_data} ")
            # 初始化时也需要对比（如果有旧数据的话）
            await _compare_and_flash_query(old_data, new_data, logger)
            await cache_redis.set(
                CACHE_KEY,
                json.dumps({"data" : new_data, "expire_at" : time.time() + ttl})
            )
            return new_data
        finally :
            await lock_redis.delete(LOCK_KEY)
    else :
        # 等待初始化完成（避免直接报错）
        deadline = time.time() + 5  # 最长等 5 秒
        while time.time() < deadline :
            cache = await cache_redis.get(CACHE_KEY)
            if cache :
                return json.loads(cache)["data"]
            await asyncio.sleep(0.05)
        raise TimeoutError("等待缓存初始化超时")

async def _safe_flash_query(query, logger):
    """安全调用 flash_query"""
    try:
        await flash_query(query)
        logger.info(f"flash_query success: {query}")
    except Exception as e:
        logger.exception(f"flash_query failed for query: {query}")

def _is_changed(new_item, old_item):
    """query_type==1 时检测字段变化"""
    keys_to_check = ["query_type", "material", "content"]
    return any(new_item.get(k) != old_item.get(k) for k in keys_to_check)

def _get_black_word_diff(new_item, old_item):
    """query_type==2 时检测 black_word 差异，返回新增/减少的词"""
    new_words = set((new_item.get("black_word") or "").split(","))
    old_words = set((old_item.get("black_word") or "").split(","))
    added = new_words - old_words
    removed = old_words - new_words
    return added, removed

async def _compare_and_flash_query(old_data: list, new_data: list, logger):
    """
    对比新旧数据：
    - query_type == 1：任意字段变化都刷新
    - query_type == 2：black_word 新增或减少时，刷新对应词
    """
    try:
        old_dict = {item.get("query"): item for item in old_data if item.get("query")}
        tasks = []

        for new_item in new_data:
            query = new_item.get("query")
            query_type = new_item.get("query_type", 0)
            if not query:
                continue

            old_item = old_dict.get(query)

            # 新增 query -> 全量刷新
            if not old_item:
                tasks.append(_safe_flash_query(query, logger))
                continue

            # query_type==1：字段变化就刷 query
            if query_type == 1 and _is_changed(new_item, old_item):
                tasks.append(_safe_flash_query(query, logger))
                continue

            # query_type==2：black_word变化就刷变化词
            if query_type == 2:
                added, removed = _get_black_word_diff(new_item, old_item)
                # 刷新增或减少的 black_word
                for w in added | removed:
                    tasks.append(_safe_flash_query(w, logger))
                    logger.info(f"black_word changed -> refresh: {w}")

        if tasks:
            await asyncio.gather(*tasks)

    except Exception:
        logger.exception(f"_compare_and_flash_query failed")

async def flash_query(query):
    """
    异步调用 analysis_once_queue 接口
    """
    models = "deepseek"
    source = "102"
    url = "http://admin.ai.s.weibo.com/api/llm/analysis_once_queue.json"
    headers = {
        "Host" : "admin.ai.s.weibo.com",
        "User-Agent" : "Apifox/1.0.0 (https://apifox.com)",
        "Accept" : "*/*",
        "Connection" : "keep-alive",
    }
    params = {
        "query" : query,
        "models" : models,
        "source" : source
    }

    async with aiohttp.ClientSession(headers=headers) as session :
        async with session.get(url, params=params) as response :
            response.raise_for_status()
            res = await response.json()
            return res