"""正则基础方法, 用于处理文本相关问题, 不打印日志"""
# -*- coding:utf-8 -*-
import re


class BaseRE:
    """正则基础方法类"""

    # ====== 常用模式 ======
    ZH_PATTERN = re.compile(r'[\u4e00-\u9fa5]')

    # ====== 通用功能方法 ======
    @staticmethod
    def has_chinese(text: str) -> bool:
        """判断文本中是否含有中文"""
        return bool(BaseRE.ZH_PATTERN.search(text))

    @staticmethod
    def convert_chinese_punctuation_to_english(text: str) -> str:
        """将中文/全角标点转换为英文/半角标点"""

        mapping = {
            '，': ',',
            '。': '.',
            '！': '!',
            '？': '?',
            '【': '[',
            '】': ']',
            '（': '(',
            '）': ')',
            '％': '%',
            '＃': '#',
            '＠': '@',
            '＆': '&',
            '：': ':',
            '；': ';',
            '、': '/',
            '《': '<',
            '》': '>',
            '“': '"',
            '”': '"',
            '‘': "'",
            '’': "'",
        }

        # 全角数字 → 半角数字
        for i in range(10):
            mapping[chr(ord('０') + i)] = str(i)

        # 全角英文：Ａ(a) 到 Ｚ(z) / ａ 到 ｚ
        for i in range(26):
            mapping[chr(ord('Ａ') + i)] = chr(ord('A') + i)
            mapping[chr(ord('ａ') + i)] = chr(ord('a') + i)

        # 全角空格
        mapping['　'] = ' '

        return text.translate(str.maketrans(mapping))
