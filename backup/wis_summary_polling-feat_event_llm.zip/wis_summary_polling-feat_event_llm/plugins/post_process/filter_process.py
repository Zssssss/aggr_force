"""对于大模型异常输出的过滤策略"""
# -*- coding:utf-8 -*-
import re
from typing import Tuple, List


class TextFilterProcessor:
    """文本过滤处理器，提供多种过滤策略"""

    def __init__(self):
        """初始化预编译的正则表达式模式"""
        # 基本过滤模式
        l_bracket = r"[\(（\[【]"
        r_bracket = r"[\)）\]】]"

        # 初始过滤模式
        self._basic_patterns = [
            re.compile(r"\[\^\d+[\-\~]\^\d+\]"),  # [^2-^32]、[^2~^32]
            re.compile(rf"{l_bracket}(?:参考|如|)结果\d+(?:(?:[\]\[]+|、)\d+)*{r_bracket}"),  # (结果2][23)、(参考结果2、3)
            re.compile(rf"{l_bracket}(?:注|图片示例)[:：][^\n\(（\)）]*{r_bracket}"),  # (注:以下)、(图片示例：此为示例图片)
            re.compile(r"\[\^\d+\]"),  # [^2]
            re.compile(rf"{l_bracket}{r_bracket}"),  # 空括号
            re.compile(r"\[\^?原博图?\]"),  # [原博]、[^原博]
            re.compile(rf"{l_bracket}图\d+{r_bracket}"),  # (图1)
            re.compile(r"(?<=\n)\s*(?:<a>\[\d+\]</a>|\[\^?\d+\])\W.{,20}(?:\n|$)"),  # \n[^1]: 钱局长本人微博\n
        ]
        
        # 结果格式过滤模式
        pre = r"(?:例[:：])?"
        jieguo = r'[\u4e00-\u9fa5#]{,6}结果'
        jieguo_extend = rf"(?:{jieguo}|\d| |、|/|,|-|至|和|与|到|—|\]|\[)*"
        end = r'[\u4e00-\u9fa5]{,6}\d*'
        self._jieguo_pattern = re.compile(rf"{l_bracket}{pre}{jieguo}\d+{jieguo_extend}{end}{r_bracket}")
        
        # 综搜过滤模式
        self._zongsou_patterns = [
            re.compile(r"[*#\"""]"),  # 特殊字符和换行
            re.compile(r"</?think>"),  # think标签
            re.compile(r"\[\^\d+[\-\~]\^\d+\]"),  # [^2-^32]
            re.compile(rf"{l_bracket}(?:参考|如|)结果\d+(?:(?:[\]\[]+|、)\d+)*{r_bracket}"),  # 结果引用
            re.compile(r"[\(（][^\n\(（\)）]*[\)）]"),  # 括号内容
            re.compile(r"[\[\^]+\d+[\]\^]+"),  # [^1^]格式
            re.compile(r"[\[\^@_]+result[=_]*\d+[\]\^]+"),  # [^result=1^]格式
            re.compile(rf"{l_bracket}{r_bracket}"),  # 空括号
            re.compile(r"[\(（][^\n\(（\)）]*$"),  # 未闭合括号
            re.compile(r"\[\^\d+[\-\~]\d+\]"), # [^15-21]
            re.compile(r'\[(?!\^\d+\]).+?\]'), # 匹配非[^数字]的引号内容
            re.compile(r"\[[^\]]*\^[^\]]*$"),  # 未闭合
            re.compile(r"\[[^\]]+\]\^"),  # ^ 在外
            re.compile(r"\[\]\(\^\d+\)") # [](^20)
        ]
        
        # 中文内部空格模式
        self._chinese_space_pattern = re.compile(r'(?<=[\u4e00-\u9fff]) +(?=[\u4e00-\u9fff])')

    def apply_patterns(self, text: str, patterns: List[re.Pattern]) -> Tuple[str, List[str]]:
        """应用正则表达式模式列表进行过滤
        
        Args:
            text: 待过滤的文本
            patterns: 正则表达式模式列表
            
        Returns:
            过滤后的文本和被删除的匹配项列表
        """
        result = text
        all_deleted_matches = []
        
        for pattern in patterns:
            # 查找所有匹配项
            matches = pattern.findall(result)
            if matches:
                all_deleted_matches.extend(matches)
                # 执行替换
                result = pattern.sub('', result)
        
        return result, all_deleted_matches

    def filter_basic_invalid(self, text: str) -> Tuple[str, List[str]]:
        """基础过滤功能的公共接口"""
        return self.apply_patterns(text, self._basic_patterns)
    
    def filter_jieguo_format(self, text: str) -> str:
        """结果格式过滤功能的公共接口"""
        return self._jieguo_pattern.sub("", text)
    
    def filter_zongsou_invalid(self, text: str) -> Tuple[str, List[str]]:
        """综搜过滤功能的公共接口"""
        result, deleted_matches = self.apply_patterns(text, self._zongsou_patterns)
        # 删除中文内部空格
        result = self._chinese_space_pattern.sub('', result)
        return result, deleted_matches

# ============= 初始过滤，在标准化引文之后 =============
def filter_invalid_str(s: str) -> Tuple[str, List[str]]:
    """过滤非法字符，返回过滤后的字符串和被删除的匹配项列表
    
    当前过滤策略：
    - [^2-^32]、[^2~^32]: 上标引用格式
    - (结果2][23)、(结果2)、(参考结果2、3): 结果引用格式
    - (注:以下)、(图片示例：此为示例图片): 注释和示例说明
    - [^2]: 简单上标格式
    - 空括号: ()、[]、【】等
    - [原博]、[^原博]: 原博标记
    
    Args:
        s: 待过滤的字符串
        
    Returns:
        tuple: (过滤后的字符串, 被删除的匹配项去重列表)
    """
    if not isinstance(s, str) or not s.strip():
        return s, []
    
    result, deleted_matches = _global_processor.filter_basic_invalid(s)
    
    return result, list(set(deleted_matches))


# ============= 括号里面包含结果x格式 =============
def filter_jieguo_str(s: str) -> str:
    """过滤括号里面包含结果x格式的部分数据
    
    过滤模式：
    - （例：结果1、结果2）
    - （结果1、结果12）
    - 【参考结果1至结果3】
    等各种括号内的结果引用格式
    
    Args:
        s: 待过滤的字符串
        
    Returns:
        过滤后的字符串
    """
    if not isinstance(s, str) or not s.strip():
        return s
    
    return _global_processor.filter_jieguo_format(s)

def clean_jieguo(text):
    l_bracket = r"[\(（\[【]"
    r_bracket = r"[\)）\]】]"

    mid = r"[^\n\(（\[【\)）\]】]*"
    jieguo = r"(?:\d+号?结果|结果\d+)"
    pattern = re.compile(rf"{l_bracket}{mid}{jieguo}{mid}{r_bracket}")
    text = pattern.sub("", text)
    return text

# ============= 预览版过滤策略 =============
def zongsou_filter_invalid_str(s: str) -> Tuple[str, List[str]]:
    """综搜版本的过滤策略，更加严格的过滤规则
    
    当前过滤策略：
    - 特殊字符: *、#、引号、换行符
    - HTML标签: <think>、</think>
    - 上标引用: [^2-^32]、[^2~^32]
    - 结果引用: (结果2][23)、(参考结果2、3)
    - 括号内容: 所有括号内的内容
    - 特殊格式: [^1^]、[^result=1^]
    - 未闭合括号: 行末的未闭合括号
    - 中文内部空格: 删除中文字符间的多余空格
    
    Args:
        s: 待过滤的字符串
        
    Returns:
        tuple: (过滤后的字符串, 被删除的匹配项去重列表)
    """
    if not isinstance(s, str) or not s.strip():
        return s, []
    
    result, deleted_matches = _global_processor.filter_zongsou_invalid(s)
    
    return result, list(set(deleted_matches))


# ============= 向后兼容的全局实例 =============
_global_processor = TextFilterProcessor()


def get_filter_processor() -> TextFilterProcessor:
    """获取全局过滤器实例
    
    Returns:
        TextFilterProcessor实例
    """
    return _global_processor
