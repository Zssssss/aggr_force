"""插入图片及排序"""
# -*- coding:utf-8 -*-
import json
import time
import re
import aiohttp
import numpy as np
from plugins.post_process.card_process import remove_wb_custom_block, remove_media_block

def log_info(msg, log_func=None):
    """打印日志"""
    if log_func:
        log_func(msg)

async def get_text_embedding(texts: list, log_func=None, retry=2):
    """获取文本的embeddings"""
    url = "http://mproxy.search.weibo.com/embedding/vectors"
    timeout = aiohttp.ClientTimeout(total=5)
    post_data = {
        "texts": texts,
        "sid": "smart_ algorithm_sstj",
        "model": "vector",
        "seqid": f"jingxuan_{int(time.time())}",
    }
    headers = {"content-Type": "application/json"}
    for i in range(retry):
        try:
            start = time.time()
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, headers=headers, json=post_data) as response:
                    res_data = await response.json()
                    status = res_data["status"]
                    if status == 1000:
                        log_info(f"get_text_embedding retry: {i} cost: {time.time() - start}, success", log_func)
                        return res_data["data"]
        except Exception as e:
            log_info(f"get_text_embedding retry: {i} cost: {time.time() - start}, error: " + str(e), log_func)
    log_info(f"get_text_embedding final error, texts: {json.dumps(texts, ensure_ascii=False)}")
    return None

def check_need_emb(data: list):
    """检测是否需要embedding"""
    if not data:
        return False
    text = data[0].get("content", "")
    if not text:
        return False
    return True

async def get_selected_data_embedding(selected_data: dict, log_func=None):
    """更新selected_data"""
    if not selected_data:
        return {}
    texts = []
    for _, data in selected_data.items():
        if not check_need_emb(data):
            continue
        text = data[0].get("content", "")
        texts.append(text)
    embeddings = await get_text_embedding(texts, log_func=log_func)
    result = {}
    if embeddings is None:
        return result
    index = 0
    for mid, data in selected_data.items():
        if not check_need_emb(data):
            continue
        result[mid] = embeddings[index]
        index += 1
    return result

def remove_quote(text: str):
    """去除引用"""
    re_quote = re.compile(r"<a>\[\d+\]</a>")
    re_multi = re.compile(r"\[\^多模态_.*?\]")
    text = re_quote.sub("", text)
    text = re_multi.sub("", text)
    return text

def is_table_end_line(lines: list, current_index: int) -> bool:
    """
    判断当前行是否为表格的最后一行
    
    Args:
        lines: 所有行的列表
        current_index: 当前行的索引
    
    Returns:
        bool: 如果是表格最后一行返回 True，否则返回 False
    """
    # 如果已经是最后一行，则认为当前行是表格最后一行
    if current_index + 1 >= len(lines):
        return True
    
    # 检查下一行是否为表格行
    next_line = lines[current_index + 1].strip()
    # 对下一行进行清理，确保判断准确
    next_line = remove_wb_custom_block(next_line)
    next_line = remove_media_block(next_line)
    next_line = remove_quote(next_line)
    
    # 如果下一行不是表格行（|字符少于2个），则当前行是表格最后一行
    return next_line.count('|') < 2

def format_result(content: str):
    """获取格式化后的结果"""
    lines = content.split("\n")
    result = []
    flag = True
    texts = []
    for index, line in enumerate(lines):
        cur_line = {"ori_text": line}
        line = line.strip()
        line = remove_wb_custom_block(line)
        line = remove_media_block(line)
        line = remove_quote(line)
        # 检查是否是标题行（以1-6个#开头）
        is_title = re.match(r'^#{1,6}\s', line.strip()) is not None
        # 检查是否包含中文字符
        has_chinese = re.search(r'[\u4e00-\u9fff]', line) is not None
        is_maohao = line.endswith(":") or line.endswith("：")
        
        # 判断表格行：包含至少2个|字符的行视为表格行
        # is_table 和 is_table_end 用于在添加多模态标记时对表格行进行特殊处理
        is_table = line.count('|') >= 2
        # 判断当前行是否为表格的最后一行
        is_table_end = is_table_end_line(lines, index) if is_table else False
        
        if (flag and is_maohao) or is_title or not has_chinese or is_table:
            if is_table:
                # 标记表格行
                cur_line["is_table"] = True
                # 标记表格最后一行
                if is_table_end:
                    cur_line["is_table_end"] = True
            result.append(cur_line)
            flag = False
            continue
        texts.append(line)
        cur_line["new_text"] = line
        result.append(cur_line)
        flag = False
    return result, texts

async def get_alll_text_embdings_dict(content: str, selected_data: dict, log_func=None):
    """获取所有文本的embeddings"""
    _, texts = format_result(content)
    embeddings = await get_text_embedding(texts, log_func=log_func)
    # 接口的多模态的emb
    select_embeddings = await get_selected_data_embedding(selected_data, log_func=log_func)
    texts_embeddings = {}
    if embeddings:
        min_num = min(len(embeddings), len(texts))
        for i in range(min_num):
            texts_embeddings[texts[i]] = embeddings[i]
    return {"texts": texts_embeddings, "selected": select_embeddings}

async def update_texts_embeddings(texts:list, embdings_dict:dict, log_func=None):
    """更新文本的embeddings"""
    new_texts = []
    texts_embeddings = embdings_dict.setdefault("texts", {})
    for text in texts:
        if text not in texts_embeddings:
            new_texts.append(text)
    if new_texts:
        new_embeddings = await get_text_embedding(new_texts, log_func=log_func)
        if new_embeddings:
            min_num = min(len(new_embeddings), len(new_texts))
            for i in range(min_num):
                texts_embeddings[new_texts[i]] = new_embeddings[i]

def get_texts_embeddings(result, embdings_dict):
    """获取文本的embeddings"""
    texts_embeddings = embdings_dict.setdefault("texts", {})
    embdings = []
    for cur_line in result:
        if "new_text" not in cur_line:
            continue
        new_text = cur_line["new_text"]
        if new_text not in texts_embeddings:
            continue
        embdings.append(texts_embeddings[new_text])
        cur_line["text_i"] = len(embdings) - 1
    return embdings

async def get_new_result(content: str, embdings_dict:dict, log_func=None):
    """获取新的结果"""
    result, texts = format_result(content)
    # await update_texts_embeddings(texts, embdings_dict, log_func=log_func)
    embeddings = get_texts_embeddings(result, embdings_dict)
    select_embdings = embdings_dict.get("selected", {})
    selected_mid = {}
    content_array = np.array(embeddings)
    if not select_embdings:
        return result
    try:
        for mid, emb in select_embdings.items():
            emb_array = np.array(emb)
            # 计算分子：点积
            cos_sim = np.dot(content_array, emb_array)
            max_index = int(np.argmax(cos_sim))
            max_value = float(cos_sim[max_index])
            if max_value > 0.4:
                selected_mid.setdefault(max_index, []).append(mid)
            else:
                log_info(f"mid:{mid}, value:{max_value}, not selected", log_func)
        for cur_line in result:
            if "text_i" not in cur_line:
                continue
            if cur_line["text_i"] in selected_mid:
                cur_line["mid_list"] = selected_mid[cur_line["text_i"]]
    except Exception as e:
            log_info(f"get_new_result error:{e}", log_func)
    return result


def get_lcs_len(s1: str, s2: str) -> int:
    """最长公共子序列长度"""
    n, m = len(s1), len(s2)
    dp = [0] * (m + 1)

    for i in range(n):
        prev = 0
        c1 = s1[i]
        for j in range(m):
            temp = dp[j + 1]
            if c1 == s2[j]:
                dp[j + 1] = prev + 1
            else:
                dp[j + 1] = dp[j] if dp[j] > dp[j + 1] else dp[j + 1]
            prev = temp
    return dp[m]

async def add_quote_result(result: str, embdings_dict:dict) -> str:
    """给结果加上引文"""
    ori_list = result.strip().split("\n")
    final_result = [{"content": text} for text in ori_list]

    texts_embeddings = embdings_dict.setdefault("texts", {})
    new_content = "\n".join(list(texts_embeddings.keys()))
    new_list = await get_new_result(new_content, embdings_dict)
    for cur_line in new_list:
        mid_list = cur_line.get("mid_list", [])
        text = cur_line.get("new_text", "")
        text_len = len(text)
        if not mid_list or not text:
            continue
        max_len = 0
        max_index = -1
        for index, ori_dict in enumerate(final_result):
            ori_text = ori_dict.get("content", "")
            lcs_len = get_lcs_len(ori_text, text)
            if lcs_len == text_len:
                max_len = lcs_len
                max_index = index
                break
            if lcs_len > max_len:
                max_len = lcs_len
                max_index = index
        if max_index == -1:
            continue
        final_result[max_index]["mid_list"] = mid_list
    return final_result
    