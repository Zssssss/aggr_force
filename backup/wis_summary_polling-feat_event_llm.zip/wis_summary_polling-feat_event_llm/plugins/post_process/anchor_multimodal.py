import json
import re
from typing import List, Optional, Dict, Union


# =====================================================================
#                         基础 AST Block 结构
# =====================================================================

class Block:
    """AST Block 基类"""

    def render(self) -> str:
        raise NotImplementedError


class PlainTextBlock(Block):
    def __init__(self, text: str):
        self.text = text

    def render(self) -> str:
        return self.text


class QuotedBlock(Block):
    """代表一个完整的 quoted 块（不拆内部结构）"""

    def __init__(self, full_text: str):
        self.full_text = full_text  # 保留原始 JSON/格式化内容

    def render(self) -> str:
        return self.full_text


class MediaDiv:
    """媒体 div 节点"""

    def __init__(
        self,
        full_html: str,
        data_type: str,
        data_scheme: str,
        paragraph: Optional[int],
        count: Optional[int],
        is_visible: bool,
        visible_index: int
    ):
        self.full_html = full_html
        self.data_type = data_type
        self.data_scheme = data_scheme
        self.paragraph = paragraph
        self.count = count
        self.is_visible = is_visible
        self.visible_index = visible_index

    def add_anchor(self, strategy: str):
        if not self.is_visible:
            return

        auto_play = "1" if strategy == "anchor_auto_play" else "0"
        anchor_tag = f' id="emphasis-tag-{self.visible_index}" data-auto-play="{auto_play}" class=\"emphasis-tag-hidden\"'

        pos = self.full_html.find(">")
        if pos != -1:
            self.full_html = (
                self.full_html[:pos] +
                anchor_tag +
                self.full_html[pos:]
            )

    def add_anchor_new(self):
        anchor_tag = f' id="emphasis-tag-{self.visible_index}" class=\"emphasis-tag-hidden\"'

        pos = self.full_html.find(">")
        if pos != -1:
            self.full_html = (
                self.full_html[:pos] +
                anchor_tag +
                self.full_html[pos:]
            )

    def render(self):
        return self.full_html


class MediaBlock(Block):
    """完整 media-block"""

    def __init__(self, divs: List[MediaDiv]):
        self.divs = divs

    def render(self) -> str:
        return "<media-block>" + "".join([d.render() for d in self.divs]) + "</media-block>"


# =====================================================================
#                         文本 Parser
# =====================================================================

class DocumentParser:

    # 三类块的识别 regex
    media_block_pattern = re.compile(r"<media-block>.*?</media-block>", re.DOTALL)
    quoted_block_pattern = re.compile(r'```wbCustomBlock\{"type": "quoted".*?```', re.DOTALL)

    div_pattern = re.compile(
        r'<div\s+data-type="([^"]+)"\s+data-scheme="([^"]+)"[^>]*>.*?</div>',
        re.DOTALL
    )

    def __init__(self, visible_map: Dict[str, int]):
        self.visible_map = visible_map

    def parse(self, content: str) -> List[Block]:
        """解析 document → AST Blocks"""

        blocks: List[Block] = []
        pos = 0

        # 找所有结构化块
        matches = []
        for m in self.media_block_pattern.finditer(content):
            matches.append(("media", m.start(), m.end(), m.group()))

        for m in self.quoted_block_pattern.finditer(content):
            matches.append(("quoted", m.start(), m.end(), m.group()))

        # 按位置排序
        matches.sort(key=lambda x: x[1])

        for m_type, start, end, text in matches:

            # 先加入文本块
            if pos < start:
                blocks.append(PlainTextBlock(content[pos:start]))

            if m_type == "media":
                blocks.append(self._parse_media_block(text))
            else:
                blocks.append(QuotedBlock(text))

            pos = end

        # 剩下的文本
        if pos < len(content):
            blocks.append(PlainTextBlock(content[pos:]))

        return blocks

    def _parse_media_block(self, text: str) -> MediaBlock:
        """解析 media-block 内部 div"""

        divs = []

        for div_match in self.div_pattern.finditer(text):
            full_html = div_match.group(0)
            data_type = div_match.group(1)
            data_scheme = div_match.group(2)

            # 提取 multi_xxx
            paragraph = None
            count = None

            pm = re.search(r"multi_paragraph=(\d+)", data_scheme)
            cm = re.search(r"multi_count=(\d+)", data_scheme)

            if pm:
                paragraph = int(pm.group(1))
            if cm:
                count = int(cm.group(1))

            is_visible = data_scheme in self.visible_map
            visible_index = self.visible_map.get(data_scheme, -1)

            divs.append(MediaDiv(
                full_html, data_type, data_scheme,
                paragraph, count,
                is_visible, visible_index
            ))

        return MediaBlock(divs)


# =====================================================================
#                         锚点策略处理器
# =====================================================================

class AnchorStrategyProcessor:

    def apply_anchor(self, blocks: List[Block], strategy: str):
        """段内排序 + 外显前置"""

        # Group media divs by paragraph and sort visible divs first
        for media_block in blocks:
            if not isinstance(media_block, MediaBlock):
                continue

            # 按 paragraph 分组
            paragraph_groups: Dict[int, List[MediaDiv]] = {}
            for div_node in media_block.divs:
                if div_node.paragraph is not None:
                    paragraph_groups.setdefault(div_node.paragraph, []).append(div_node)

            new_divs = []
            for para in sorted(paragraph_groups.keys()):
                paragraph_divs = paragraph_groups[para]
                visible_divs = [d for d in paragraph_divs if d.is_visible]
                non_visible_divs = [d for d in paragraph_divs if not d.is_visible]

                visible_divs.sort(key=lambda d: d.visible_index)
                non_visible_divs.sort(key=lambda d: d.count or 999)

                for div_node in visible_divs:
                    div_node.add_anchor(strategy)

                new_divs.extend(visible_divs + non_visible_divs)

            media_block.divs = new_divs

    def apply_anchor_new(self, blocks: List[Block]):
        """段内排序 + 外显前置 + 全部添加锚点"""
        non_num = 3
        # Group media divs by paragraph and sort visible divs first
        for media_block in blocks:
            if not isinstance(media_block, MediaBlock):
                continue

            # 按 paragraph 分组
            paragraph_groups: Dict[int, List[MediaDiv]] = {}
            for div_node in media_block.divs:
                if div_node.paragraph is not None:
                    paragraph_groups.setdefault(div_node.paragraph, []).append(div_node)

            new_divs = []
            for para in sorted(paragraph_groups.keys()):
                paragraph_divs = paragraph_groups[para]
                visible_divs = [d for d in paragraph_divs if d.is_visible]
                non_visible_divs = [d for d in paragraph_divs if not d.is_visible]

                visible_divs.sort(key=lambda d: d.visible_index)
                non_visible_divs.sort(key=lambda d: d.count or 999)

                for div_node in visible_divs:
                    div_node.add_anchor_new()
                
                for div_node in non_visible_divs:
                    div_node.visible_index = non_num
                    non_num += 1
                    div_node.add_anchor_new()

                new_divs.extend(visible_divs + non_visible_divs)

            media_block.divs = new_divs

    def apply_anchor_to_first(self, blocks: List[Block], strategy: str):
        """抽离全部外显 → 插入到第一个 quoted 后 / media-block 内部最前面"""

        # 1. 收集所有外显
        visible_divs = []
        for media_block_node in blocks:
            if isinstance(media_block_node, MediaBlock):
                for div_node in media_block_node.divs:
                    if div_node.is_visible:
                        visible_divs.append(div_node)

        if not visible_divs:
            return

        # 2. 给外显加 anchor
        for div_node in visible_divs:
            div_node.add_anchor(strategy)
        visible_divs.sort(key=lambda d: d.visible_index)
        # 3. 从原 media-block 中删除外显
        for media_block_node in blocks:
            if isinstance(media_block_node, MediaBlock):
                media_block_node.divs = [d for d in media_block_node.divs if not d.is_visible]

        # 4. 找第一个 quoted 与第一个 media 的位置
        first_quoted_index = next((i for i, b in enumerate(blocks) if isinstance(b, QuotedBlock)), None)
        first_media_index = next((i for i, b in enumerate(blocks) if isinstance(b, MediaBlock)), None)

        # Determine whether the first quoted block or the first media block appears earlier in the document
        if first_quoted_index is not None and first_media_index is not None:
            target_block_index = first_quoted_index if first_quoted_index < first_media_index else first_media_index
        else:
            target_block_index = first_quoted_index if first_quoted_index is not None else first_media_index

        target_block = blocks[target_block_index]

        # ★ 情况 A：目标是 quoted-block → 插到 quoted-block 后面（作为新 block）
        if isinstance(target_block, QuotedBlock):
            blocks.insert(target_block_index + 1, MediaBlock(visible_divs))

        # ★ 情况 B：目标是 media-block → 插到 media-block.divs 的最前边
        else:
            target_block.divs = visible_divs + target_block.divs

    def apply_anchor_to_all_divs(self, blocks: List[Block]):
        """
        为文中所有 media-block 中的每个 div 添加 emphasis-tag-{index}
        不考虑外显，仅按照出现顺序递增生成 id。
        """
        tag_index = 0
        for media_block in blocks:
            if isinstance(media_block, MediaBlock):
                for div_node in media_block.divs:
                    # 强制添加，可见不可见都加
                    div_node.visible_index = tag_index
                    div_node.is_visible = True
                    div_node.add_anchor("anchor")
                    tag_index += 1
        new_content = "".join(b.render() for b in blocks)
        return new_content

    def extract_pid_to_emphasis_map(self, blocks: List[Block]) -> Dict[str, str]:
        """
        从 media-block 的 div 中提取：
          - 图片 PID
          - HTML 中的 emphasis-tag-{index}

        返回:
          { pid: "emphasis-tag-{index}" }
        """

        pid_map: Dict[str, str] = {}

        # 编译正则：匹配 <img ...> 标签
        img_tag_pattern = re.compile(r'<img\b[^>]*?>')

        # 提取 PID
        pid_pattern = re.compile(r'/([A-Za-z0-9]+)\.(?:jpg|jpeg|png|gif)')

        # 提取 emphasis-tag index
        emphasis_pattern = re.compile(r'id="emphasis-tag-(\d+)"')

        for block in blocks:
            if not isinstance(block, MediaBlock):
                continue

            for div_node in block.divs:
                html = div_node.full_html

                # 1. 提取 emphasis-tag index
                emphasis_match = emphasis_pattern.search(html)
                if not emphasis_match:
                    continue
                emphasis_index = emphasis_match.group(1)
                emphasis_tag = f"emphasis-tag-{emphasis_index}"

                # 2. 查找 <img> 标签
                img_match = img_tag_pattern.search(html)
                if not img_match:
                    continue

                img_tag = img_match.group(0)

                # 3. 从 img src 中提取 pid
                pid_match = pid_pattern.search(img_tag)
                if not pid_match:
                    continue

                pid = pid_match.group(1)

                # 4. 建立 pid -> emphasis-tag 映射
                pid_map[pid] = emphasis_tag

        return pid_map


# =====================================================================
#                         主处理器 MultimodalAnchorProcessor
# =====================================================================

class MultimodalAnchorProcessor:

    def parse_visible_schemes(self, card_multimodal: str) -> Dict[str, int]:
        try:
            data = json.loads(card_multimodal)
            card_list = data.get("data", [])
        except Exception:
            return {}

        visible_map = {}
        for idx, item in enumerate(card_list[:3]):
            scheme = item.get("scheme")
            if scheme:
                visible_map[scheme] = idx

        return visible_map

    def run(self, strategy: str, card_multimodal: str, content: str):
        # 解析 visible map
        visible_map = self.parse_visible_schemes(card_multimodal)
        # 更新 card_multimodal
        try:
            data = json.loads(card_multimodal)
            card_list = data["data"]
            for idx, item in enumerate(card_list[:3]):
                item["id"] = f"emphasis-tag-{idx}"
            updated_card_multimodal = json.dumps(data, ensure_ascii=False)
        except:
            updated_card_multimodal = card_multimodal

        # AST 解析
        parser = DocumentParser(visible_map)
        blocks = parser.parse(content)
        # 策略执行
        strategy_processor = AnchorStrategyProcessor()

        if strategy in ("anchor", "anchor_auto_play"):
            strategy_processor.apply_anchor(blocks, strategy)
        elif strategy == "anchor_to_first":
            strategy_processor.apply_anchor_to_first(blocks, strategy)
        elif strategy == "anchor_new":
            strategy_processor.apply_anchor_new(blocks)

        # 渲染返回
        new_content = "".join(b.render() for b in blocks)
        new_content = new_content.replace("<media-block></media-block>","")
        new_content = new_content.replace("</media-block><media-block>","")
        return new_content, updated_card_multimodal

    def add_tag(self, content: str):
        # 解析 visible map
        visible_map = {}
        # AST 解析
        parser = DocumentParser(visible_map)
        blocks = parser.parse(content)

        # 策略执行
        strategy_processor = AnchorStrategyProcessor()

        res = strategy_processor.apply_anchor_to_all_divs( blocks)
        return res

    def parse_tag(self, content: str):
        # 解析 visible map
        visible_map = {}
        # AST 解析
        parser = DocumentParser(visible_map)
        blocks = parser.parse(content)

        # 策略执行
        strategy_processor = AnchorStrategyProcessor()

        res = strategy_processor.extract_pid_to_emphasis_map(blocks)
        return res
