# -*- coding:utf-8 -*-
import datetime
import json
import random
import re
import time
import re
import traceback
import aiohttp
import asyncio

from aiomcache import Client

from conf.config import TASK_CONCURRENCY
from lib.aiomcq import mcq_cli
from lib.base import Base
from plugins.post_process.anchor_multimodal import MultimodalAnchorProcessor
from lib.redis_utils import async_redis_client
from plugins.common.intervene_common import RECALCULATE_SOURCE, REDIS_INTERVENE_KNOWLEDGE_PREFIX
from plugins.post_process.quote_process import delete_quote
from plugins.post_process.card_process import (get_card_content_v1,get_left_percent)
from plugins.post_process.update_click import get_card_multimodal_lab_h2
from plugins.post_process.cache_multimodal import CacheMultimodal

class Output(Base):
    jingxuan_queue = mcq_cli(domain="queue.search.weibo.com", port=11233)

    def __init__(self, pid):
        super().__init__(pid)
        self.session = None
        self._lock = asyncio.Lock()

    async def get_session(self):
        async with self._lock:
            if self.session is None or self.session.closed:
                timeout = aiohttp.ClientTimeout(total=5)
                connector = aiohttp.TCPConnector(limit=TASK_CONCURRENCY)
                self.session = aiohttp.ClientSession(timeout=timeout, connector=connector)
        return self.session

    @staticmethod
    def deepseek_sort_mid(weibo, content):
        link_list = weibo.get("link_list", [])
        # pattern = r'<think>.*?</think>'
        # # 替换匹配到的内容为空字符串
        # cleaned_text = re.sub(pattern, '', content, flags=re.DOTALL)
        # num_list = re.findall(r'\[(\d+)\]', cleaned_text)
        # mid_tmp = []
        # for num in num_list:
        #     try:
        #         num = int(num)
        #         mid = link_list[num - 1]
        #         if "detail?mblogid=" not in mid:
        #             continue
        #         mid_tmp.append(mid)
        #     except:
        #         continue
        # mention_counts = {}
        # for item in mid_tmp:
        #     if item in mention_counts:
        #         mention_counts[item] += 1
        #     else:
        #         mention_counts[item] = 1
        # sorted_list = sorted(link_list, key=lambda x: (-mention_counts.get(x, 0), link_list.index(x)))

        res_mid = []
        mid_set = set()
        for mid in link_list:
            if "detail?mblogid=" in mid:
                mid = mid.split("mblogid=")[1]
                if mid in mid_set:
                    continue
                res_mid.append(mid)
                mid_set.add(mid)

        return res_mid

    @staticmethod
    def sort_all_list(sorted_data,sorted_material_list):
        order_dict = {item['mid']: int(item['rank']) for item in sorted_data}

        # 分割列表二为需要排序和保持原顺序的部分
        sorted_part = []
        unsorted_part = []
        for item in sorted_material_list:
            if item['mid'] in order_dict:
                sorted_part.append(item)
            else:
                unsorted_part.append(item)

    #     print(sorted_part)
        # 对需要排序的部分按照列表一的rank顺序排序
        sorted_part.sort(key=lambda x: order_dict[x['mid']])
    #     print(sorted_part)

        # 合并两部分，未提到的元素保持原顺序
        sorted_list2 = sorted_part + unsorted_part
        return sorted_list2

    @staticmethod
    def get_sorted_material_list(weibo):
        """获取输入博文的排序列表，返回排序后的博文以及序号
        """
        link_list = weibo.get("link_list", [])
        mid_rank_dict = []
        mid_set = set()
        for num,mid in enumerate(link_list):
            if "detail?mblogid=" in mid:
                mid = mid.split("mblogid=")[1]
                if mid in mid_set:
                    continue
                mid_set.add(mid)
                mid_rank_dict.append({"mid":mid,"rank":num+1,"type":"weibo"})
        return mid_rank_dict


    @staticmethod
    def qwen72b_sort_mid(weibo):
        content_mid_len = weibo.get('use_content_mid_len', 0)
        use_kol_mid_len = weibo.get('use_account_mid_len', 0)
        mid_list = []
        if weibo.get("sort_content_mid", []) == []:
            if content_mid_len != 0:
                content_mid_list = weibo.get("mid_list", [])
                mid_list += content_mid_list[:content_mid_len]
                if weibo.get("query_type", "") == "stock":
                    mid_list = mid_list[1:]

            if use_kol_mid_len :
                kol_mid_list = weibo.get("account_mid_list", [])
                tmp_mid_list = kol_mid_list[:use_kol_mid_len]
                mid_list += tmp_mid_list
        else:
            mid_list = weibo.get("sort_content_mid", [])

        zhisou_mid_list = weibo.get("zhisou_mids", [])

        all_mid_list = mid_list
        for mid in zhisou_mid_list:
            if mid not in all_mid_list:
                all_mid_list.append(mid)

        return all_mid_list

    @staticmethod
    def weibo_personal_homepage_invalid_str(s: str, num: int):
        pattern = "<a>[" + str(num) + "]</a>"
        result = s.replace(pattern, "")
        return result

    def replace_weibo_personal_homepage_str_and_log(self, s: str, query: str, trace_id: str, num: int):
        """过滤引用微博个人主页信息的编号，并记录日志"""
        result = self.weibo_personal_homepage_invalid_str(s, num)
        if len(result) != len(s):
            self.logger.info("traceid:{}\tquery:{}\tweibo_personal_homepage_invalid_str:{}\tbefore_result:{}".format(
                trace_id, query, str(num), json.dumps(s, ensure_ascii=False)))
        return result
    
    def make_from_zhisou_quote_list(self, quote_dict: dict, query_citation_mid: list[dict[str, str]]) -> list[dict[str, str]]:
        """智搜微博引用采纳通知"""
        result = []
        if not quote_dict:
            return result
        remaining_quotes = quote_dict.copy()
        try:
            for item in query_citation_mid:
                mid  = item.get('mid', '')
                if mid in remaining_quotes:
                    remaining_quotes[mid]["is_quote"] = True

            for key, value in remaining_quotes.items():
                result.append({
                    "mid": key,
                    **value
                })
            self.logger.info(self.pre_log_msg + f"from_zhisou_quote_list:{json.dumps(result, ensure_ascii=False)}")
        except Exception:
            self.logger.error(self.pre_log_msg + f"from_zhisou_quote_list: error: {traceback.format_exc()}")
        return result
    
    def fill_mid_business_quote_list(self, mid_ref_list: list[str], mid_business_list: list[str]) -> list[str]:
        """填充business_quote_mid_list"""
        result = []
        try:
            mid_ref_set = set(mid_ref_list)
            mid_business_set = set(mid_business_list)
            mid_quote_mid_set = (mid_ref_set & mid_business_set)
            result = list(mid_quote_mid_set)
            return result
        except Exception:
            self.logger.error(self.pre_log_msg + f"fill_mid_business_quote_list: error: {traceback.format_exc()}")
        return result


    def fill_reference_mid4deepseek(self, link_list: list[str], content: str) -> list[dict[str, str]]:
        """
        填充deepseek的reference_mid和对应的引用数量、引用排序
        [{"mid": "5137664437388978", "citation_num": "1","rank":"1"}, {"mid": "5137648970895030", "citation_num": "1","rank":"2"}]
        """
        def _get_reference_number(text):
            # 使用正则表达式匹配<think>标签及其内容</think>
            pattern = r'<think>.*?</think>'
            # 替换匹配到的内容为空字符串
            try:
                cleaned_text = re.sub(pattern, '', text, flags=re.DOTALL)
                # a_number = re.findall(r'<a>\[\d+\]</a>', cleaned_text, flags=re.DOTALL)
                # numbers = [int(re.search(r'\d+', item).group(0)) for item in a_number]
                # numbers_str = re.findall(r'\[\^(\d+)\]', cleaned_text, flags=re.DOTALL)
                # numbers = [int(item) for item in numbers_str]
                tq_pattern = r'```wbCustomBlock(\{.*?})```'
                matches = re.findall(tq_pattern, cleaned_text, re.DOTALL)
                numbers = []
                for match in matches:
                    try:
                        dict1 = eval(match)
                        if dict1["type"] != "quoted":
                            continue
                        for num in dict1["data"]["num"]:
                            numbers.append(num)
                    except:
                        continue
            except:
                self.logger.warning("get_reference_number error, text:{}".format(text))
                numbers = []

            return numbers

        # mid_list = [item.split("mblogid=")[1] for item in link_list if "detail?mblogid=" in item]
        reference_nums = _get_reference_number(content)
        res = [{
            "mid": "",
            "citation_num": "0",
            "rank": "-1"
        } for _ in range(len(link_list))]
        rank_id = 0
        try:
            for idx, reference_num in enumerate(reference_nums):
                if reference_num > len(res):
                    self.logger.warning("reference_num:{} out of range, mid_list_len:{}".format(reference_num, len(res)))
                    continue
                mid_obj = res[reference_num - 1]
                link_item = link_list[reference_num - 1]
                if "detail?mblogid=" in link_item:
                    if not mid_obj["mid"]:
                        mid_obj["mid"] = link_item.split("mblogid=")[1]
                    mid_obj['citation_num'] = str(int(mid_obj['citation_num']) + 1)
                    rank_id += 1
                    if mid_obj["rank"] == "-1":
                        mid_obj['rank'] = str(rank_id)
        except Exception as e:
            self.logger.warning("get_reference_mid error in for, e:{}".format(traceback.format_exc()))


        return [item for item in res if item['mid']]

    def get_reference_mid(self, weibo, content):
        trace_id = weibo.get("trace_id", "")
        llm_name = weibo.get("llm_name", "")
        try:
            if 'deepseek' in llm_name:
                return self.deepseek_sort_mid(weibo, content)
        except Exception as e:
            self.logger.error("error:{},traceid:{} get_reference_mid error".format(e, trace_id))
        return self.qwen72b_sort_mid(weibo)
    

    def _calculate_material_type_ratios(self, weibo, sorted_material_list):
        """
        计算物料类型比例，包括金橙标、媒体用户、认证用户和普通用户
        
        Args:
            weibo (dict): 包含mid_feature_dict等信息的字典
            sorted_material_list (list): 排序后的物料列表
            
        Returns:
            dict: 包含各类型mid列表和比例的字典
        """
        # 初始化各类型mid列表
        gold_orange_v_mids = []
        media_mids = []
        verified_user_mids = []
        normal_user_mids = []
        ref_mid_rank = {}
        
        # 获取mid特征字典
        mid_feature_dict = weibo.get("mid_feature_dict", {})
        
        # 遍历排序后的物料列表，分类mid
        for mid_item in sorted_material_list:
            cur_mid = mid_item["mid"]
            mid_rank = mid_item["rank"]
            ref_mid_rank[cur_mid] = {"rank":mid_rank}
            mid_features = mid_feature_dict.get(cur_mid, {})
            
            # 获取特征
            verified_type_ext = mid_features.get("verified_type_ext", -999)
            # is_media = mid_features.get("is_crediable_media", False)
            verified_type = mid_features.get("verified_type", -999)
            is_gold_orange = (int(verified_type) == 0 and int(verified_type_ext) in [1, 2])
            is_verified_user = (int(verified_type) >= 0 and int(verified_type) <= 7)
            is_media = (int(verified_type) == 3 and int(verified_type_ext) == 53)
            
            # 根据特征分类
            if is_gold_orange:
                gold_orange_v_mids.append(cur_mid)
            elif is_media:
                media_mids.append(cur_mid)
            elif is_verified_user:
                verified_user_mids.append(cur_mid)
            else:
                normal_user_mids.append(cur_mid)
        
        # 计算总数
        total_count = len(sorted_material_list)
        
        # 计算各类型比例，确保总和为100%
        if total_count > 0:
            # 计算精确比例
            gold_orange_v_ratio_exact = len(gold_orange_v_mids) / total_count * 100
            media_ratio_exact = len(media_mids) / total_count * 100
            verified_user_ratio_exact = len(verified_user_mids) / total_count * 100
            normal_user_ratio_exact = len(normal_user_mids) / total_count * 100
            
            # 使用最大余数法分配百分比，确保总和为100%
            ratios = [
                (gold_orange_v_ratio_exact, "gold_orange_v"),
                (media_ratio_exact, "media"),
                (verified_user_ratio_exact, "verified_user"),
                (normal_user_ratio_exact, "normal_user")
            ]
            
            # 初始化整数部分和余数
            integer_parts = [int(ratio[0]) for ratio in ratios]
            remainders = [ratio[0] - int(ratio[0]) for ratio in ratios]
            
            # 分配余数，使总和为100
            total_integer = sum(integer_parts)
            remaining = 100 - total_integer
            
            # 将余数从大到小排序，分配剩余的百分比点
            sorted_remainders = sorted(enumerate(remainders), key=lambda x: x[1], reverse=True)
            for i in range(min(remaining, len(sorted_remainders))):
                idx = sorted_remainders[i][0]
                integer_parts[idx] += 1
            
            # 格式化为字符串
            gold_orange_v_ratio = f"{integer_parts[0]}%"
            media_ratio = f"{integer_parts[1]}%"
            verified_user_ratio = f"{integer_parts[2]}%"
            normal_user_ratio = f"{integer_parts[3]}%"
        else:
            gold_orange_v_ratio = "0%"
            media_ratio = "0%"
            verified_user_ratio = "0%"
            normal_user_ratio = "0%"
        
        return {
            "gold_orange_v_mids": gold_orange_v_mids,
            "gold_orange_v_ratio": gold_orange_v_ratio,
            "media_mids": media_mids,
            "media_ratio": media_ratio,
            "verified_mids": verified_user_mids,
            "verified_ratio": verified_user_ratio,
            "normal_mids": normal_user_mids,
            "normal_ratio": normal_user_ratio,
            "ref_mid_rank": ref_mid_rank
        }

    def _reliable_tips(self, weibo, sorted_material_list):
        trace_id = weibo.get("trace_id", "")
        is_reliable = weibo.get('is_reliable', 0)
        reliable_summary = weibo.get("reliable_summary", "")
        reliable_score = weibo.get("reliable_score")
        try:
            material_type_ratios = self._calculate_material_type_ratios(weibo, sorted_material_list)
            if is_reliable and reliable_summary:
                material_type_ratios['reliable_summary'] = reliable_summary
            if is_reliable and reliable_score is not None:
                material_type_ratios['reliable_score'] = reliable_score
            return material_type_ratios
        except Exception as e:
            self.logger.error(f"traceid:{trace_id} reliable_tips error:{e}")
        return {}

    async def send_message_to_jingxuan(self, ready: str, prompt_scene: str, weibo: dict):
        """给'微博精选'发送智搜结果生成完成消息通知"""
        
        if prompt_scene not in ["deepseek", "deepseek_stream"]:
            return
        
        # stream模式下仅生成完成时发送一次消息通知
        if ready != "yes":
            return
        
        message = {
            "query": weibo.get("query", ""),
            "version": weibo.get("version", ""),
            "trace_id": weibo.get("trace_id", ""),
        }
        
        abtest = weibo.get("abtest", "")
        if abtest:
            message["abtest"] = abtest
        
        message_str = json.dumps(message, ensure_ascii=False)
        
        set_flag = await self.jingxuan_queue.set("wis_summary_jingxuan_queue", message_str)
        self.logger.info(self.pre_log_msg + f"send msg to wis_summary_jingxuan_queue:\t {message_str}\tset_flag: {set_flag}")

    async def save_intervene_knowledge(self, ready: str, prompt_scene: str, response_data: dict, weibo: dict):
        if prompt_scene not in ['deepseek', 'deepseek_stream']:
            return False
        
        if ready != "yes":
            return False
        query = weibo.get("query", "")
        if not query:
            return False
        tag_infos = response_data.get("tag_infos", [])
        if not tag_infos:
            return False
        
        keyword_set = set()
        for tag_info in tag_infos:
            if tag_info.get("keyword", ""):
                keyword_set.add(tag_info.get("keyword", ""))
        
        if not keyword_set:
            return False
        
        intervene_knowledge = f"不要提及{'、'.join(sorted(keyword_set))}相关的任何内容"   
        try:            
            # 写入Redis存储干预知识
            write_success = await self._write_intervene_knowledge_to_redis(query, intervene_knowledge)
            
            if not write_success:
                self.logger.info(self.pre_log_msg + "write intervene knowledge failed")
                return False
            
            # 再触发重新计算队列
            if not weibo.get("is_auto_intervene_knowledge", False):
                await self._trigger_recalculate_queue(weibo)
            self.logger.info(self.pre_log_msg + "update intervene knowledge success")
            return True
            
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"_update_intervene_knowledge error: {e}")
            return False
    
    async def _trigger_recalculate_queue(self, weibo):
        """
        触发重新计算队列
        
        Args:
            weibo: 微博数据字典
        """
        try:
            await self._trigger_recalculation(weibo)
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"_trigger_recalculate_queue error: {e}")
    
    async def _write_intervene_knowledge_to_redis(self, query, intervene_knowledge):
        """
        将干预知识写入Redis
        
        Args:
            intervene_knowledge: 干预知识内容
            
        Returns:
            bool: 写入是否成功
        """
        try:
            if not query:
                self.logger.warning(self.pre_log_msg + "query is empty, skip update")
                return False
                
            key = f"{REDIS_INTERVENE_KNOWLEDGE_PREFIX}{query}"
            client = async_redis_client.get_redis_server(key)

            value = intervene_knowledge            
            expire_seconds = 15 * 24 * 60 * 60
            # 设置带过期时间的键
            result = await client.set(key, value, ex=expire_seconds)
            self.logger.info(self.pre_log_msg + f"write intervene knowledge with expire_seconds={expire_seconds}")
            
            return bool(result)
            
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"write intervene knowledge to redis error: {e}")
            return False
    
    async def _trigger_recalculation(self, weibo):
        """
        触发重新计算队列
        
        Args:
            weibo: 微博数据字典
        """
        start_time = time.time()
        query = weibo.get("query", "")
        prompt_scene = weibo.get("prompt_scene", "")
        source = RECALCULATE_SOURCE 
        # 构建请求URL
        url = (
            f"http://admin.ai.s.weibo.com/api/llm/analysis_once_queue.json"
            f"?query={query}&models=deepseek&source={source}"
        )
        
        try:
            # 使用短超时触发重新计算
            timeout = aiohttp.ClientTimeout(total=1)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        result = await response.json()
                        self.logger.info(self.pre_log_msg + f"analysis_once_queue success: {result}")
                    else:
                        self.logger.warning(self.pre_log_msg + f"analysis_once_queue failed with status: {response.status}")
                        
        except asyncio.TimeoutError:
            self.logger.warning(self.pre_log_msg + "analysis_once_queue timeout")
        except aiohttp.ClientError as e:
            self.logger.error(self.pre_log_msg + f"analysis_once_queue client error: {e}")
        except Exception as e:
            self.logger.error(self.pre_log_msg + f"analysis_once_queue unexpected error: {e}")
        finally:
            cost_time = time.time() - start_time
            self.logger.info(self.pre_log_msg + f"recalculate with knowledge cost: {cost_time:.3f}s")

    async def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        ready = kwargs.get('ready', "")
        content = kwargs.get('content', "")
        status_stage = kwargs.get('status_stage', "")
        special_tips = kwargs.get('special_tips', "")
        trace_id = weibo.get("trace_id", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        sid = weibo.get("sid", "")

        start1 = time.time()
        url = "http://admin.ai.s.weibo.com/api/wis/update_summary.json"
        # num = random.randint(1, 100)
        # if num <= 50:
        #     url = "http://ai.s.weibo.com/api/wis/update_summary.json"
        #     if ready == 'yes':
        #         self.logger.info("use new url traceid:{}\tquery:{}".format(trace_id, query))

        llm_name = weibo.get("llm_name", "")
        hot_overview_override = weibo.get("hot_overview_override", "")
        robot_override = weibo.get("robot_override", "")
        verification_comment = weibo.get("verification_comment", "")
        prompt_scene = weibo.get('prompt_scene', "")
        ori_prompt_scene = weibo.get('ori_prompt_scene', "")
        cur_llm_name = llm_name
        if hot_overview_override:
            cur_llm_name = hot_overview_override
        if robot_override:
            cur_llm_name = robot_override
            self.logger.info(self.pre_log_msg + f"use robot_override:{robot_override}")
        if verification_comment:
            cur_llm_name = verification_comment
        if prompt_scene == 'direct_comment':
            cur_llm_name = 'direct_comment'
        if ori_prompt_scene:
            prompt_scene = ori_prompt_scene
            cur_llm_name = ori_prompt_scene
        if ready == "begin" and cur_llm_name not in ["deepseek", "deepseek_stream", "deepseek_verification"]:
            return
        query_category = weibo.get("ori_query_category", "")
        content_json = weibo.get("json_result", {})
        source = weibo.get("source", "")
        q_attr = weibo.get("q_attr", "{}")
        high_level = weibo.get("high_level", "")
        stream_output = weibo.get("stream_output", 0)
        query_citation_mid = weibo.get('query_citation_mid', [])
        sorted_material_list = self.get_sorted_material_list(weibo)
        debug = weibo.get('debug', {})
        level2_uid = weibo.get("level2_uid", "")
        self_account = weibo.get("self_account", 0)
        raw_time_grade = weibo.get("raw_time_grade", "")
        mid_category_v2 = weibo.get("mid_category_v2","")
        hot_social_category = weibo.get("hot_social_category", 0)
        if mid_category_v2 != "":
            query_field = mid_category_v2
        else:
            query_field = weibo.get("query_field",-1)
        
        link_list = weibo.get("link_list", [])
        label = weibo.get("label", "")
        version = weibo.get("version", "")
        risk_tip_tag = weibo.get("risk_tip_tag", 0)
        card_multimodal = weibo.get("card_multimodal", {})
        share_card_multimodal = weibo.get("share_card_multimodal", {})
        celebrity_news = weibo.get("celebrity_news", [])
        all_ready_list = weibo.get("ready_pid_dict", {}).get("all_ready_list", [])
        all_multi_list = weibo.get("all_multi_list",[])

        reference_mid_list = self.get_reference_mid(weibo, content)
        raw_material_list = weibo.get("raw_material_list", [])
        title_result = weibo.get("title_result","")
        is_risk_control = weibo.get("is_risk_control", 0)
        limit_degree = weibo.get("limit_degree", "")
        finish_reason = weibo.get("finish_reason", "") if not content or special_tips else ""
        query_filter_reason = weibo.get("query_filter_reason", "")
        basemodel = weibo.get("basemodel", "")
        from_zhisou_quote_dict = weibo.get("from_zhisou_quote_dict", {})
        emphasis_tag = weibo.get("emphasis_tag", [])
        from_zhisou_quote_list = []
        citation_mid_len = 0
        top_quote_list = []
        headers = {'Content-Type': 'application/json'}
        chat_status_stage = weibo.get("chat_status_stage", 1)
        abtest = weibo.get("abtest", "")
        is_reliable = weibo.get("is_reliable", 0)
        abtests = weibo.get("abtests", "")
        is_llm_called = weibo.get("is_llm_called", True)
        use_model = weibo.get("use_model", "")
        guide_text = weibo.get("guide_text", "")
        one_sentence = weibo.get("one_sentence", "")
        is_lab_filter = weibo.get("is_lab_filter", False)
        mid_business_list = weibo.get("mid_business_list", [])
        query_ori = weibo.get("query_ori", "")

        # if link_list and 'userinfo' in link_list[-1]:
        #     content = self.replace_weibo_personal_homepage_str_and_log(content, query, trace_id, len(link_list))
        if hot_overview_override and (len(content) > 60 or len(content) < 40):
            self.logger.info("[content length is invalid] traceid:{}\tquery:{}\thot_overview_override:{}\t content_length: {}".format(trace_id, query, hot_overview_override, len(content)))
            return
        if robot_override:
            if len(content) > 300:
                self.logger.info("[content length is too long] traceid:{}\tquery:{}\trobot_override:{}\t content_length: {}".format(trace_id, query, robot_override, len(content)))
                content = "无法回答"
    
            q_attr_dict = json.loads(q_attr)
            if q_attr_dict:
                query_mid = q_attr_dict.get("mid", "")
                q_attr_dict["query"] = query
                query = query_mid
                self.logger.info(self.pre_log_msg + f"[robot] set query with mid:{query_mid}")
            q_attr = json.dumps(q_attr_dict, ensure_ascii=False)
            if content == "无法回答":
                ready = "nodata"
            
        if "deepseek" in llm_name:
            query_citation_mid = self.fill_reference_mid4deepseek(link_list, content)
            mid_business_quote_list = self.fill_mid_business_quote_list([item["mid"] for item in query_citation_mid], mid_business_list)
            weibo['mid_business_quote_list'] = mid_business_quote_list
            from_zhisou_quote_list = self.make_from_zhisou_quote_list(from_zhisou_quote_dict, query_citation_mid)
            sorted_data = sorted(query_citation_mid,key=lambda x :int(x["rank"]),reverse=False)
            sorted_material_list = self.sort_all_list(sorted_data,sorted_material_list)
            top_quote_list =[item['mid'] for item in sorted_data[:10]]
            content = delete_quote(content)
            weibo["output_forward_zj_link"] = query_citation_mid
            # 添加额外属性
            uid_attrs_mapping = weibo.get("uid_attrs_mapping", {})
            query_citation_mid = [{**item, **uid_attrs_mapping.get(item.get("mid", ""), {})} for item in query_citation_mid]
            citation_mid_len = len(query_citation_mid)                

        post_data = {'zj_link': query_citation_mid,
                     'raw_time_grade': raw_time_grade}
        data = {"query": query, "model": cur_llm_name, "ready": ready, "content": content, "version": version,
                "first_version": version, "content_json": json.dumps(content_json), "query_category": query_category,
                "post_data": json.dumps(post_data), "source": source,
                "q_attr": q_attr, "high_level": high_level, "stream_output": stream_output, "level2_uid": level2_uid,
                "self_account": self_account, "time_grade": raw_time_grade, "label": label, 'modify_query': modify_query,
                'debug': json.dumps(debug, ensure_ascii=False), 'link_list': json.dumps(link_list),"top_quote_list": json.dumps(top_quote_list),
                "summarize_text":title_result,
                'risk_tip_tag': risk_tip_tag, "card_multimodal": json.dumps(card_multimodal, ensure_ascii=False),
                "share_card_multimodal": json.dumps(share_card_multimodal, ensure_ascii=False),
                'is_risk_control': is_risk_control, 'model_filter': finish_reason, 'query_filter_reason': query_filter_reason, 'prompt_scene': prompt_scene,
                "basemodel": basemodel, 'citation_mid_len': citation_mid_len, 'emphasis_tag': json.dumps(emphasis_tag, ensure_ascii=False),
                "chat_status_stage": chat_status_stage, 'abtests': abtests, 'is_llm_called': is_llm_called, 'use_model': use_model, 'sid': sid, 'guide_text': guide_text,
                "celebrity_news": json.dumps(celebrity_news, ensure_ascii=False), "query_ori": query_ori}

        if ready == "yes" and prompt_scene == 'deepseek' and hot_social_category:
            new_card_multimodal = await get_card_multimodal_lab_h2(weibo, self.pid, query, all_ready_list)
            if new_card_multimodal:
                data.update({"card_multimodal": json.dumps({"type": "mediablock", "data": new_card_multimodal},
                                                           ensure_ascii=False)})

        if ready == "yes":
            data.update({"content_style": get_card_content_v1(content)})
            data.update({"left_percent": get_left_percent(content, data["content_style"])})

        if ready == "yes" and prompt_scene == 'deepseek':
            content = data.get("content","")
            card_multimodal = data.get("card_multimodal","")
            strategy = "anchor_new"
            try:
                new_content, new_card_multimodal = MultimodalAnchorProcessor().run(strategy, card_multimodal, content)
                if new_content:
                    data.update({"content": new_content, "card_multimodal": new_card_multimodal})
            except Exception as e:
                self.logger.error(traceback.format_exc())
            await CacheMultimodal(weibo, self.pid).cache_multi_modal("online", all_ready_list)

        if abtest:
            data.update({"abtest": abtest})

        if from_zhisou_quote_list:
            data.update({'from_zhisou_quote_list': json.dumps(from_zhisou_quote_list)})
        
        if query_field != None:
             data.update({'query_field': query_field})

        if sid == "sina_news_verification":
            news_analyze = {
                "is_verification" : weibo.get("news_analyze_flag", False),
                "category": weibo.get("news_analyze_category", ""),
                "news_title" : weibo.get("news_title", "")
            }
            data.update({"news_analyze": json.dumps(news_analyze, ensure_ascii=False)})

        if special_tips and ready == "special_tips":
            data.update({'special_tips': special_tips})
        weibo['front_content'] = content
        cove_query = weibo.get('cove_query', False)
        if cove_query:
            data['content_json'] = ""

        if status_stage:
            data.update({'status_stage': status_stage})

        if limit_degree:
            data['limit_degree'] = limit_degree

        if prompt_scene in ['deepseek', 'deepseek_stream']:
            reliable_tips = self._reliable_tips(weibo, sorted_material_list)
            if reliable_tips:
                data.update({"reliable_tips": json.dumps(reliable_tips, ensure_ascii=False)})

        if status_stage in [1, 2, 3]:
            fields = ['query', 'model', 'ready', 'content', 'version', 'first_version', 'query_category', 'stream_output', 'status_stage', 'q_attr', 'query_ori']
            data = {key: val for key, val in data.items() if key in fields}

        # 评论回传
        if prompt_scene in ['verification_comment', 'direct_comment']:
            result_type = '其他' if not content else weibo.get('type', '其他')
            zs_not_reply = weibo.get("zs_not_reply", 0)
            is_chat = weibo.get('is_chat', 1)
            try:
                if q_attr:
                    json_data = json.loads(q_attr)
                    json_data['type'] = result_type
                    json_data['zs_not_reply'] = zs_not_reply
                    json_data['is_chat'] = is_chat
                    q_attr = json.dumps(json_data, ensure_ascii=False)
            except Exception as e:
                self.logger.error("{} {} de-serialize q_attr error:{}".format(trace_id, q_attr, e))

            data.update({
                'query': weibo.get('cid', ""),
                "q_attr": q_attr
            })
            if prompt_scene == 'direct_comment':
                data['query'] = weibo.get('query', '')

        end1 = time.time()
        start = time.time()
        timeout = aiohttp.ClientTimeout(total=2)
        retry = 2

        for i in range(retry):
            try:
                session = await self.get_session()
                async with session.post(url=url, json=data, headers=headers, timeout=timeout) as response:
                    response.raise_for_status()
                    response_json = await response.json()
                    response_data = {'status': response_json.get("status", ""),
                                'msg': response_json.get("msg", ""),
                                'sens_reason': response_json.get("data", {}).get("sens_reason", ""),
                                'sens_words': response_json.get("data", {}).get("sens_words", ""),
                                'tag_infos': response_json.get("data", {}).get("tag_infos", [])
                                }
                    if ready != 'no':
                        self.logger.info("traceid:{}\tquery:{}\tresponse:{}\tdata:{}\tcost:{}".format(
                            trace_id, query, response_data, json.dumps(data, ensure_ascii=False), time.time() - start))
                
                tasks = [
                    self.send_message_to_jingxuan(ready, prompt_scene, weibo),
                    self.save_intervene_knowledge(ready, prompt_scene, response_data, weibo)
                ]
                await asyncio.gather(*tasks, return_exceptions=True)
                break
            except Exception as e:
                self.logger.error("query:{},error:{},traceid:{} write to fronted error data:{}, cost:{}, retry: {}".format(query, str(e), trace_id, json.dumps(data, ensure_ascii=False), time.time() - start, i))

        self.logger.info("traceid:{}\tready:{}\tcost1:{}\tcost2:{}\tretry:{}".format(
            trace_id, ready, end1 - start1, time.time() - start, i))


    async def close(self):
        async with self._lock:
            if self.session and not self.session.closed:
                await self.session.close()

class ChatVerificationOutput(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.session = None
        self._lock = asyncio.Lock()

    async def get_session(self):
        async with self._lock:
            if self.session is None or self.session.closed:
                timeout = aiohttp.ClientTimeout(total=5)
                connector = aiohttp.TCPConnector(limit=TASK_CONCURRENCY)
                self.session = aiohttp.ClientSession(timeout=timeout, connector=connector)
        return self.session

    async def close(self):
        async with self._lock:
            if self.session and not self.session.closed:
                await self.session.close()


    def fill_reference_mid4deepseek(self, link_list: list[str], content: str) -> list[dict[str, str]]:
        """
        填充deepseek的reference_mid和对应的引用数量、引用排序
        [{"mid": "5137664437388978", "citation_num": "1","rank":"1"}, {"mid": "5137648970895030", "citation_num": "1","rank":"2"}]
        """
        def _get_reference_number(text):
            # 使用正则表达式匹配<think>标签及其内容</think>
            pattern = r'<think>.*?</think>'
            # 替换匹配到的内容为空字符串
            try:
                cleaned_text = re.sub(pattern, '', text, flags=re.DOTALL)
                # a_number = re.findall(r'<a>\[\d+\]</a>', cleaned_text, flags=re.DOTALL)
                # numbers = [int(re.search(r'\d+', item).group(0)) for item in a_number]
                # numbers_str = re.findall(r'\[\^(\d+)\]', cleaned_text, flags=re.DOTALL)
                # numbers = [int(item) for item in numbers_str]
                tq_pattern = r'```wbCustomBlock(\{.*?})```'
                matches = re.findall(tq_pattern, cleaned_text, re.DOTALL)
                numbers = []
                for match in matches:
                    try:
                        dict1 = eval(match)
                        if dict1["type"] != "quoted":
                            continue
                        for num in dict1["data"]["num"]:
                            numbers.append(num)
                    except:
                        continue
            except:
                self.logger.warning("get_reference_number error, text:{}".format(text))
                numbers = []

            return numbers

        # mid_list = [item.split("mblogid=")[1] for item in link_list if "detail?mblogid=" in item]
        reference_nums = _get_reference_number(content)
        res = [{
            "mid": "",
            "citation_num": "0",
            "rank": "-1"
        } for _ in range(len(link_list))]
        rank_id = 0
        try:
            for idx, reference_num in enumerate(reference_nums):
                if reference_num > len(res):
                    self.logger.warning("reference_num:{} out of range, mid_list_len:{}".format(reference_num, len(res)))
                    continue
                mid_obj = res[reference_num - 1]
                link_item = link_list[reference_num - 1]
                if "detail?mblogid=" in link_item:
                    if not mid_obj["mid"]:
                        mid_obj["mid"] = link_item.split("mblogid=")[1]
                    mid_obj['citation_num'] = str(int(mid_obj['citation_num']) + 1)
                    rank_id += 1
                    if mid_obj["rank"] == "-1":
                        mid_obj['rank'] = str(rank_id)
        except Exception as e:
            self.logger.warning("get_reference_mid error in for, e:{}".format(traceback.format_exc()))


        return [item for item in res if item['mid']]

    def sort_all_list(self, sorted_data, sorted_material_list):
        order_dict = {item['mid']: int(item['rank']) for item in sorted_data}

        # 分割列表二为需要排序和保持原顺序的部分
        sorted_part = []
        unsorted_part = []
        for item in sorted_material_list:
            if item['mid'] in order_dict:
                sorted_part.append(item)
            else:
                unsorted_part.append(item)

    #     print(sorted_part)
        # 对需要排序的部分按照列表一的rank顺序排序
        sorted_part.sort(key=lambda x: order_dict[x['mid']])
    #     print(sorted_part)

        # 合并两部分，未提到的元素保持原顺序
        sorted_list2 = sorted_part + unsorted_part
        return sorted_list2

    def get_sorted_material_list(self, link_list):
        """获取输入博文的排序列表，返回排序后的博文以及序号
        """
        mid_rank_dict = []
        mid_set = set()
        for num,mid in enumerate(link_list):
            if "detail?mblogid=" in mid:
                mid = mid.split("mblogid=")[1]
                if mid in mid_set:
                    continue
                mid_set.add(mid)
                mid_rank_dict.append({"mid":mid,"rank":num+1,"type":"weibo"})
        return mid_rank_dict

    def gen_sorted_material_list(self, link_list, content):
        sorted_material_list = self.get_sorted_material_list(link_list)
        query_citation_mid = self.fill_reference_mid4deepseek(link_list, content)
        sorted_data = sorted(query_citation_mid, key=lambda x : int(x["rank"]), reverse=False)
        sorted_material_list = self.sort_all_list(sorted_data, sorted_material_list)
        return sorted_material_list


    def update_status(self, ready):

        dic = {
            "begin": 2,
            "no": 3,
            "yes": 4
        }
        return dic.get(ready, 4)

    async def run(self, **kwargs):
        start = time.time()
        weibo = kwargs.get("weibo", {})
        content = kwargs.get('content', "")
        ready = kwargs.get('ready', "")

        trace_id = weibo.get('trace_id', "")
        question = weibo.get('ori_question', "")
        model = weibo.get('model', "deepseek")
        version = weibo.get('version', "")
        session_id = weibo.get('session_id', "")
        conversation_id = weibo.get('ori_conversation_id', "")
        uid = weibo.get('user_id', "")
        q_attr = weibo.get('q_attr', "")
        prompt_scene = weibo.get('prompt_scene', "")
        link_list = weibo.get("link_list",[])
        share_card_multimodal = weibo.get("share_card_multimodal", {})
        sorted_material_list = self.gen_sorted_material_list(link_list, content)
        mid_category_v2 = weibo.get("mid_category_v2", "")
        chat_type = 1
        if mid_category_v2 != "":
            query_field = mid_category_v2
        else:
            query_field = weibo.get("query_field", -1)
        debug = weibo.get('debug', {})
        chat_status_stage = weibo.get("chat_status_stage", 1)
        # status_stage = self.update_status(ready)
        status_stage = chat_status_stage
        content = delete_quote(content)
        data = {'content': content, 'ready': ready, "question": question,
                "model": model, "version": version, "session_id": session_id,
                "conversation_id": conversation_id, "user_id": uid, "q_attr": q_attr, "prompt_scene": prompt_scene,
                "sorted_material_list": json.dumps(sorted_material_list),
                "share_card_multimodal": json.dumps(share_card_multimodal, ensure_ascii=False),
                "debug": json.dumps(debug, ensure_ascii=False),
                "query_field": query_field,  "chat_type" : chat_type, "status_stage": status_stage}
        if ready == 'begin':
            data["first_chat_tag"] = 1
        try:
            timeout = aiohttp.ClientTimeout(total=2)
            headers = {'Content-Type': 'application/json'}
            session = await self.get_session()
            async with session.post(url="http://admin.ai.s.weibo.com/api/chat/update_answer.json", json=data, headers=headers, timeout=timeout) as response:
                response.raise_for_status()
                response_json = await response.json()

                self.logger.info("traceid:{}\tquery:{}\tresponse:{}\tdata:{}\tcost:{}".format(
                    trace_id, question, response_json, json.dumps(data, ensure_ascii=False), time.time() - start))
        except Exception as e:
            self.logger.error(
                "query:{},error:{},traceid:{} write to fronted error data:{}, cost:{}".format(
                    question, str(e), trace_id, json.dumps(data, ensure_ascii=False), time.time() - start))


class ShortSummaryOutput(Output):

    def __init__(self, pid):
        super().__init__(pid)

    async def run(self, **kwargs):
        if not kwargs.get('short_is_end', False):
            return
        weibo = kwargs.get('weibo', {})

        url = "http://admin.ai.s.weibo.com/intfs/llm/analysisbackup"
        query = weibo["query"]
        res_version = weibo.get("res_version", "")
        material_starttime = weibo.get("material_starttime", time.time())
        material_endtime = weibo.get("material_endtime", time.time())
        traceid = weibo["traceid"]
        if weibo == {}:
            calc_fail = 1
        else:
            calc_fail = 0

        category_type = "tiny_summary"
        llm_res = weibo.get("llm_result_summary", "")
        data = [{"type": category_type, "desc": llm_res, "material_starttime": material_starttime,
                 "material_endtime": material_endtime, "calc_fail": calc_fail, "analysis_time": time.time(),
                 "mids": ""}]

        if weibo.get("need_hot_summary", "0") == "1":
            data.append({"type": "hot_summary", "desc": weibo.get("llm_result_hot", ""),
                         "material_starttime": material_starttime, "material_endtime": material_endtime,
                         "calc_fail": calc_fail, "analysis_time": time.time(), "mids": ""})

        post_data = {"query": query, "version": res_version, "data": json.dumps(data, ensure_ascii=False)}
        headers = {'Content-Type': 'application/json'}
        res = None
        try:
            session = await self.get_session()
            async with session.post(url=url, headers=headers, data=json.dumps(post_data), timeout=10) as response:
                response.raise_for_status()
                res = await response.json()
            self.logger.info("llm_process\tquery:{}\ttraceid:{}\tres:{}\tpost_data:{}".format(
                query, traceid, res, json.dumps(post_data, ensure_ascii=False)))
        except Exception as e:
            self.logger.error("[{}] query:{}, res:{}, xiaojie_write fronted error:{} ".format(traceid, query, res, e))


class BriefSummaryOutput(Output):

    def __init__(self, pid):
        super().__init__(pid)

    async def run(self, **kwargs):

        weibo = kwargs.get('weibo', {})
        url = "http://admin.ai.s.weibo.com/intfs/llm/analysisbackup"
        query = weibo["query"]
        res_version = weibo.get("res_version", "")
        material_starttime = weibo.get("material_starttime", time.time())
        material_endtime = weibo.get("material_endtime", time.time())
        traceid = weibo["traceid"]
        if weibo == {}:
            calc_fail = 1
        else:
            calc_fail = 0

        json_result = weibo.get("json_result", {})
        llm_res = json.dumps(json_result, ensure_ascii=False)
        category_type = "briefing"
        data = [{"type": category_type, "desc": llm_res, "material_starttime": material_starttime,
                 "material_endtime": material_endtime, "calc_fail": calc_fail, "analysis_time": time.time(),
                 "mids": ""}]
        post_data = {"query": query, "version": res_version, "data": json.dumps(data, ensure_ascii=False)}
        headers = {'Content-Type': 'application/json'}
        res = None
        try:
            session = await self.get_session()
            async with session.post(url=url, headers=headers, data=json.dumps(post_data), timeout=10) as response:
                response.raise_for_status()
                res = await response.json()
            self.logger.info("llm_process\tquery:{}\ttraceid:{}\tres:{}\tpost_data:{}".format(
                query, traceid, res, json.dumps(post_data, ensure_ascii=False)))
        except Exception as e:
            self.logger.error("[{}] query:{}, res:{}, jianbao_write fronted error:{} ".format(traceid, query, res, e))


class ShortCommentOutput(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.key = "zs_zhijie_reply_task".encode('utf8')
        self.queue = Client("fe.queue.search.weibo.com", 11233, pool_minsize=1, pool_size=2)

    async def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        content = kwargs.get('content', "")
        ready = kwargs.get('ready', "")
        trace_id = weibo.get("trace_id", "")
        version = weibo.get("version", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        origin_input = weibo.get("origin_input", {})
        debug = weibo.get('debug', {})
        result_type = '其他' if not content else weibo.get('type', '其他')
        zs_not_reply = weibo.get("zs_not_reply", 0)
        is_chat = weibo.get('is_chat', 1)
        data = {
            'content': content,
            'type': result_type,
            'version': version,
            'input': origin_input,
            'debug': debug,
            'ready': ready,
            "zs_not_reply": zs_not_reply,
            "is_chat": is_chat
        }
        self.logger.info(
            "query:{},traceid:{} write:{}".format(query, trace_id, json.dumps(data, ensure_ascii=False)))



class AnnotationOutput(Base):

    async def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        content = kwargs.get('content', "")
        ready = kwargs.get('ready', "")
        trace_id = weibo.get("trace_id", "")
        version = weibo.get("version", "")
        modify_query = weibo.get("query", "")
        query = weibo.get("ori_query", modify_query)
        origin_input = weibo.get("origin_input", {})
        debug = weibo.get('debug', {})
        data = {
            'content': content,
            'version': version,
            'input': origin_input,
            'debug': debug,
            'ready': ready
        }
        self.logger.info(
            "query:{},traceid:{} write:{}".format(query, trace_id, json.dumps(data, ensure_ascii=False)))


class AwardOutput(Base):

    def __init__(self, pid):
        super().__init__(pid)
        self.session = None
        self._lock = asyncio.Lock()

    async def get_session(self):
        async with self._lock:
            if self.session is None or self.session.closed:
                timeout = aiohttp.ClientTimeout(total=5)
                connector = aiohttp.TCPConnector(limit=TASK_CONCURRENCY)
                self.session = aiohttp.ClientSession(timeout=timeout, connector=connector)
        return self.session

    async def run(self, **kwargs):
        start = time.time()
        url = "http://admin.ai.s.weibo.com/api/wis/subcontent/update.json"
        headers = {'Content-Type': 'application/json'}

        weibo = kwargs.get('weibo', {})
        ready = kwargs.get('ready', "")
        content = kwargs.get('content', "")
        status_stage = kwargs.get('status_stage', "")
        special_tips = kwargs.get('special_tips', "")
        trace_id = weibo.get("trace_id", "")
        version = weibo.get("version", "")
        query = weibo.get("query", "")
        q_attr = weibo.get("q_attr", "{}")
        debug = weibo.get('debug', {})
        datas = {"query": query, "ready": ready, "annual_message": content, "version": version,
                'debug': json.dumps(debug, ensure_ascii=False), 'q_attr': q_attr}

        data = {"query": query,  "datas": json.dumps(datas, ensure_ascii=False)}
        timeout = aiohttp.ClientTimeout(total=2)
        retry = 2
        for i in range(retry):
            try:
                session = await self.get_session()
                async with session.post(url=url, json=data, headers=headers, timeout=timeout) as response:
                    response.raise_for_status()
                    response_json = await response.json()
                    response_data = {'status': response_json.get("status", ""),
                                     'msg': response_json.get("msg", ""),
                                     'data': response_json.get("data", "")
                                     }
                    if ready != 'no':
                        self.logger.info("traceid:{}\tquery:{}\tresponse:{}\tdata:{}\tcost:{}".format(
                            trace_id, query, response_data, json.dumps(data, ensure_ascii=False), time.time() - start))
                break
            except Exception as e:
                self.logger.error(
                    "query:{},error:{},traceid:{} write to fronted error data:{}, cost:{}, retry: {}".format(
                        query, str(e), trace_id, json.dumps(data, ensure_ascii=False), time.time() - start, i))
            self.logger.info("traceid:{}\tready:{}\tcost:{}\tretry:{}".format(
                trace_id, ready, time.time() - start, i))

    async def close(self):
        async with self._lock:
            if self.session and not self.session.closed:
                await self.session.close()



class TestOutput(Base):
    async def run(self, **kwargs):
        weibo = kwargs.get('weibo', {})
        content = kwargs.get('content', {})
        status_stage = kwargs.get("status_stage")
        print(status_stage, content)
