# -*- coding:utf-8 -*-
import asyncio
import multiprocessing
import os.path
import signal
import random
import time
import sys
from bin.run_summary import signal_handler
from plugins.llm.llm import LLM
from plugins.llm.deepseek import DeepSeekLLM
from plugins.llm.stream_llm import StreamLLM
from plugins.output.output import TestOutput
from lib.safe_logger import get_logger
import datetime

log_filename = "log/run_unittest" + ".log"
logger = get_logger(log_filename, "run_unittest")


def load_query_file(file):
    querys = {}
    if os.path.exists(file):
        with open(file, "r") as f:
            lines = f.readlines()
            for line in lines:
                query = line.strip()
                label = 'Education_Gaokao'
                querys[query] = label
    logger.info("\tload_query_file:{}\tfile:{}".format(len(querys), file))
    return querys

semaphore = asyncio.Semaphore(5)
async def task(weibo, output, pid, pnum):
    async with semaphore:
        llm = DeepSeekLLM(weibo, output, pid)
        weibo = await llm.run()
        logger.info("\tweibo:{}".format(weibo))
        return weibo


async def main(query_dict, llm_name="qwen72b", stream_output=0, pid='test', pnum=5):
    version = int(time.time())
    output = TestOutput(pid)
    data_list = []
    for query, label in query_dict.items():
        trace_id = str(datetime.datetime.now()) + "-" + str(random.randrange(1000, 9999, 1))
        data = {'version': version, 'source': '99', 'llm_name': llm_name, 'query_category': label,
                'query': query, 'query_question': '',
                'stream_output': stream_output, 'trace_id': trace_id, 'traceid': trace_id, 'query_type': label}
        data_list.append(data)

    tasks = [task(data, output, pid, pnum) for data in data_list]
    await asyncio.gather(*tasks)


if __name__ == '__main__':
    file = "./tests/test_querys.txt"
    llm_name = "deepseek"
    stream_output = 0
    pid = 'master'
    process_num = 5
    if len(sys.argv) >= 2:
        file = sys.argv[1]
    if len(sys.argv) >= 3:
        llm_name = sys.argv[2]
    if len(sys.argv) >= 4:
        stream_output = int(sys.argv[3])
    if len(sys.argv) >= 5:
        pid = sys.argv[4]
    if len(sys.argv) >= 6:
        process_num = int(sys.argv[5])
    query_dict = load_query_file(file)

    shutdown_flag = multiprocessing.Manager().Event()
    signal.signal(signal.SIGINT, lambda sig, frame: signal_handler(sig, frame, shutdown_flag))
    signal.signal(signal.SIGTERM, lambda sig, frame: signal_handler(sig, frame, shutdown_flag))

    asyncio.run(main(query_dict, llm_name, stream_output, pid, process_num))
