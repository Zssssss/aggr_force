cd ../
# 需要在项目根目录下执行以下命令
nohup /data1/jilin5/envs/piccolo-base/bin/python -m tests.run_unittest &
# 解析日志
cd tests
nohup /data1/jilin5/envs/piccolo-base/bin/python parse_log.py &
