#!/bin/bash
set -x
# dynamic generate tag
APP_NAME=registry.api.weibo.com/wbsearch/wis_summary:v1.8


#docker rmi -f $(docker images -qa )
docker build --no-cache -t $APP_NAME .

docker push ${APP_NAME}
echo "IMAGE_NAME: $APP_NAME"