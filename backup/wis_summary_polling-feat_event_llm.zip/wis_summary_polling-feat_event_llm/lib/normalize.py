# -*- coding: utf-8 -*-
import sys
import ctypes
import hashlib
import os

g_curdir = os.path.dirname(os.path.realpath(__file__))
g_libtopicid = ctypes.cdll.LoadLibrary(f"{g_curdir}/libtopicid.so")


def topic_normalize(topic):
  """
  对话题进行全半角、大小写、繁简进行转换
  """
  topic = topic.encode('utf-8') # python2 不需要这句
  length = len(topic)
  out_topic =(ctypes.c_char * (length * 2))()
  g_libtopicid.topic_normalize(topic, out_topic)
  return out_topic.value.decode('utf-8') # python2 decode

#
# def md5(data):
#   return hashlib.md5(data.encode('utf-8')).hexdigest()
#
#
# def topic2tid(topic):
#   return md5(topic_normalize(topic))
#
# if __name__ == '__main__':
#   print(topic_normalize("Abc中國《"))
#   print(topic_normalize("男子68页PPT曝妻子出轨华南理工博士"))