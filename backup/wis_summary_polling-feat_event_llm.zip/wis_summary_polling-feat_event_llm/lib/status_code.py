class StatusCode:
    # 通用错误码
    OK = 0  # OK
    ERROR = -1  # 未知错误


class MaterialStatusCode(StatusCode):
    # 物料错误
    MATERIAL_ERR = 1001  # '物料不足'


class LLMStatusCode(MaterialStatusCode):
    # 大模型错误
    LLM_ERR = 2001  # '模型调用异常'
    MAPPER_ERR = 2002  # 'mapper阶段异常'
    REDUCER_ERR = 2003  # 'reducer阶段异常'


class ErrorCode:

    def __init__(self, status_code, status_msg=""):
        self.status_code = status_code
        self.status_msg = status_msg

    @property
    def code(self):
        return self.status_code

    @property
    def msg(self):
        return self.status_msg
