import hashlib
import os
from ctypes import cdll

import redis
import time
from loguru import logger


class RedisClient(object):
    def __init__(self, hosts, ports, db=0, key_map_fun='md5', pipeline=False):
        """
        一组redis连接
        :param hosts:
        :param ports:
        :param key_map_fun: md5 or crc
        :param pipeline:
        """
        self.m_hosts = hosts.split(",")
        self.m_ports = ports.split(",")
        self.db = db
        self.m_conn_list = []
        self.m_pipeline = pipeline
        self.key_map_fun = key_map_fun
        if key_map_fun == 'crc':
            base_dir = os.path.dirname(os.path.abspath(__file__))
            crc_file = os.path.join(base_dir, "libcrc.so")
            self.lib_crc = cdll.LoadLibrary(crc_file)

        self.connect()

        self.m_curr_conn = False

        self.clear()

    @staticmethod
    def get_key_md5(key: str):
        m2 = hashlib.md5()
        m2.update(key)
        md5 = m2.hexdigest()
        return md5

    def get_hash(self, key):
        key = key.encode("utf-8")
        if self.key_map_fun == 'md5':
            return int(self.get_key_md5(key), 16) % len(self.m_ports)
        else:
            return self.lib_crc.RunCRC64(key, len(key), 0) % len(self.m_ports)

    def connect(self):
        for i in range(len(self.m_ports)):
            pool = redis.ConnectionPool(host=self.m_hosts[i], port=int(self.m_ports[i]), db=self.db,
                                        decode_responses=True, socket_timeout=60, retry_on_timeout=True)
            r = redis.Redis(connection_pool=pool)

            """ pipeline flag """
            if self.m_pipeline:
                pipe = r.pipeline(transaction=False)
                self.m_conn_list.append(pipe)
            else:
                self.m_conn_list.append(r)
        return True

    def get_share(self, key):
        share = self.get_hash(key)
        if self.m_pipeline:
            self.m_set_share.add(share)
            # self.m_dict_share[key] = share
            self.m_dict_share[share].append(key)

        return share

    def execute(self):
        if self.m_pipeline:
            result = []
            for i in self.m_set_share:
                """
                result.append((self.m_dict_share[i], self.m_conn_list[i].execute()))
                """
                ret = self.m_conn_list[i].execute()

                for j, v in enumerate(ret):
                    key = self.m_dict_share[i][j]
                    result.append((key, v))
            self.clear()

            return result
        else:
            return None

    def execute_log(self, mid, execute_type):
        if self.m_pipeline:
            result = []
            for i in self.m_set_share:
                """
                result.append((self.m_dict_share[i], self.m_conn_list[i].execute()))
                """
                t1 = time.time()
                ret = self.m_conn_list[i].execute()
                t2 = time.time()
                logger.info("执行mid:{0},keys:{1},耗时:{2},RedRock:{3},端口:{4},类型:{5},标记:{6}".format(mid, "#".join(
                    self.m_dict_share[i]), (t2 - t1) * 1000, self.m_hosts[i], self.m_ports[i], execute_type, 1))

                for j, v in enumerate(ret):
                    key = self.m_dict_share[i][j]
                    result.append((key, v))
            self.clear()

            return result
        else:
            return None

    def clear(self):
        """
        self.m_set_share.clear()
        self.m_dict_share.clear()
        """
        self.m_set_share = set()
        self.m_dict_share = dict()

        for i in range(len(self.m_ports)):
            self.m_dict_share[i] = list()

    def instance(self, key):
        return self.m_conn_list[self.get_share(key)]

    def expire(self, key, expire):
        return self.instance(key).expire(key, expire)

    def exists(self, key):
        return self.instance(key).exists(key)

    def ttl(self, key):
        return self.instance(key).ttl(key)

    """ string """

    def get(self, key):
        return self.instance(key).get(key)

    def set(self, key, value):
        return self.instance(key).set(key, value)

    def set_lock(self, key, value, ex=24 * 60 * 60, nx=False):
        return self.instance(key).set(key, value, ex=ex, nx=nx)

    def setex(self, key, expire_seconds, value):
        return self.instance(key).setex(key, expire_seconds, value)

    def delete(self, key):
        return self.instance(key).delete(key)

    """ zset """

    def zadd(self, key, mapping):
        return self.instance(key).zadd(key, mapping)

    def zcard(self, key):
        return self.instance(key).zcard(key)

    def zrank(self, key, member):
        return self.instance(key).zrank(key, member)

    def zcount(self, key, min_idx, max_idx):
        return self.instance(key).zcount(key, min_idx, max_idx)

    def zrange(self, key, begin=0, end=-1, with_scores=False):
        return self.instance(key).zrange(key, begin, end, withscores=with_scores)

    def zrevrange(self, key, begin=0, end=-1, with_scores=True):
        return self.instance(key).zrevrange(key, begin, end, withscores=with_scores)

    def zrevrangebyscore(self, key, max=-1, min=0, start=0, num=None, with_scores=True):
        return self.instance(key).zrevrangebyscore(key, max, min, start=start, num=num, withscores=with_scores)

    def zrem(self, key, *argv):
        return self.instance(key).zrem(key, *argv)

    def zremrangebyscore(self, key, min_idx, max_idx):
        return self.instance(key).zremrangebyscore(key, min_idx, max_idx)

    def zremrangebyrank(self, key, start, stop):
        return self.instance(key).zremrangebyrank(key, start, stop)

    """ set """

    def sadd(self, key, *members):
        return self.instance(key).sadd(key, *members)

    def smembers(self, key):
        return self.instance(key).smembers(key)

    def scard(self, key):
        return self.instance(key).scard(key)

    def srem(self, key, *members):
        return self.instance(key).srem(key, *members)

    def sismember(self, key, members):
        return self.instance(key).sismember(key, members)

    """
    can't suppord
    def sdiff(self, *members):
    """

    """ hash """

    def hmset(self, key, mapping):
        return self.instance(key).hmset(key, mapping)

    def hset(self, key, field, value):
        return self.instance(key).hset(key, field, value)

    def hget(self, key, field):
        return self.instance(key).hget(key, field)

    def hdel(self, key, *argv):
        return self.instance(key).hdel(key, *argv)

    def hgetall(self, key):
        return self.instance(key).hgetall(key)

    def hlen(self, key):
        return self.instance(key).hlen(key)

    def hexists(self, key, field):
        return self.instance(key).hexists(key, field)

    def type(self, key):
        return self.instance(key).type(key)

    """list"""

    def lrange(self, key, start, end):
        return self.instance(key).lrange(key, start, end)

    def lpush(self, key, val):
        return self.instance(key).lpush(key, val)

    def llen(self, key):
        return self.instance(key).llen(key)

    def rpop(self, key):
        return self.instance(key).rpop(key)

    def ltrim(self, key, start, end):
        return self.instance(key).ltrim(key, start, end)

    def pipe_get(self, keys):
        dict_keys = dict()
        dict_pipe = dict()
        dict_result = dict()
        for key in keys:
            i = self.get_hash(key)
            pipe = self.m_conn_list[i]
            dict_pipe[i] = pipe

            if i not in dict_keys:
                dict_keys[i] = list()
            dict_keys[i].append(key)

            pipe.get(key)

        # print(dict_keys)
        # print(dict_pipe)
        for shard, pipe in dict_pipe.items():
            # print(pipe)
            res = pipe.execute()
            # print(res)
            for i, val in enumerate(res):
                key = dict_keys[shard][i]
                value = res[i]

                dict_result[key] = value
        return dict_result

    def pipe_getbykey(self, key):
        self.get(key)
        res = self.execute()
        for k, v in res:
            return v

    def pipe_command(self, command, keys):
        dict_keys = dict()
        dict_pipe = dict()
        dict_result = dict()
        for key in keys:
            i = self.get_hash(key)
            pipe = self.m_conn_list[i]
            dict_pipe[i] = pipe

            if i not in dict_keys:
                dict_keys[i] = list()
            dict_keys[i].append(key)

            fun = getattr(pipe, command, None)

            fun(key)

        # print(dict_keys)
        # print(dict_pipe)
        for shard, pipe in dict_pipe.items():
            # print(pipe)
            res = pipe.execute()
            # print(res)
            for i, val in enumerate(res):
                key = dict_keys[shard][i]
                value = res[i]

                dict_result[key] = value
        return dict_result
