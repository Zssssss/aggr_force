import aiomysql
import json
from datetime import datetime
from aiomysql.cursors import DictCursor
from contextlib import asynccontextmanager
import asyncio

class MySQLOperator:
    """MySQL数据库操作类（连接池版）"""

    def __init__(self, host, user, password, database, port=4473, pool_size=5):
        self.pool = None
        self.pool_config = {
            'host': host,
            'port': port,
            'user': user,
            'password': password,
            'db': database,
            'charset': 'utf8',
            'minsize': 2,  # 最小连接数
            'maxsize': 20,  # 最大连接数
            'pool_recycle': -1,  # 连接回收时间，-1表示不回收
            'autocommit': True,
        }
        # 添加同步锁防止协程多次进行连接池初始化
        self._pool_lock = asyncio.Lock()

    async def init_pool(self):
        async with self._pool_lock:
            if not self.pool:
                self.pool = await aiomysql.create_pool(**self.pool_config)
        return self.pool

    async def get_connection(self):
        if not self.pool:
            await self.init_pool()
        return await self.pool.acquire()

    @asynccontextmanager
    async def get_cursor(self):
        conn = await self.get_connection()
        try:
            async with conn.cursor(DictCursor) as cursor:
                yield cursor
        finally:
            await self.pool.release(conn)

    async def execute(self, query, params=None, batch=False):
        """执行SQL语句"""
        async with self.get_cursor() as cursor:
            try:
                if batch:
                    await cursor.executemany(query, params)
                else:
                    await cursor.execute(query, params or ())
                await cursor.connection.commit()
                if not batch:  # 只有在非批量模式下读取结果
                    return await cursor.fetchall()
            except aiomysql.Error as e:
                await cursor.connection.rollback()
                raise Exception(f"数据库操作错误: {e}") from e
    
    # 生产禁用MYSQL写入
    # async def batch_insert(self, table, data, flag_list, batch_size=1000):
    #     if not data:
    #         return

    #     # 转义所有列名（防止保留字冲突）
    #     columns = ', '.join([f'`{col}`' for col in data[0].keys()])
    #     placeholders = ', '.join(['%s'] * len(data[0]))

    #     # 明确只更新指定字段
    #     on_duplicate_list = []
    #     for i in flag_list:
    #         if i == "hot":
    #             str1 = "`hot` = GREATEST(`hot`, VALUES(`hot`))"
    #         else:
    #             str1 = f"`{i}` =  VALUES(`{i}`)"
    #         on_duplicate_list.append(str1)
    #     on_duplicate_query = ",".join(on_duplicate_list)

    #     # 构建完整 SQL 语句
    #     query = f"""
    #         INSERT INTO `{table}` ({columns}) 
    #         VALUES ({placeholders}) 
    #         ON DUPLICATE KEY UPDATE {on_duplicate_query}
    #     """.strip()

    #     try:
    #         for i in range(0, len(data), batch_size):
    #             batch = data[i:i + batch_size]
    #             for item in batch:
    #                 # 强制转换 hot 为整数（处理异常值）
    #                 if "hot" in flag_list:
    #                     hot = item.get('hot', '')
    #                     try:
    #                         item['hot'] = int(hot) if hot not in ['', None] else ''
    #                     except (ValueError, TypeError):
    #                         item['hot'] = ''

    #             params = [tuple(item.values()) for item in batch]

    #             # 调试输出（实际生产环境建议移除）
    #             # print("Executing query:", query)
    #             # print("Sample params:", params[:5])  # 避免日志过长

    #             await self.execute(query, params, batch=True)
    #     except Exception as e:
    #         raise Exception(f"批量插入数据时出错: {e}")

    async def close(self):
        """关闭连接池"""
        if self.pool:
            self.pool.close()
            await self.pool.wait_closed()

if __name__ == "__main__":
    async def main():
        # 初始化实例
        db = MySQLOperator('m4473i.eos.grid.sina.com.cn', 'wis_data', 'orhLCcm3N9Ttxl7f', 'wis_data', port=4473)
        db.init_pool()
        all_queries = [{'query': 'test2', 'date': '2025-09-02', 'source': 'main123', 'overview': '2025-09-11', 'brief': '2025-09-04'}]
        flag_list = ["overview", "brief"]
        await db.batch_insert("hot_search_results", all_queries, flag_list)
        await db.close()

    asyncio.run(main())
