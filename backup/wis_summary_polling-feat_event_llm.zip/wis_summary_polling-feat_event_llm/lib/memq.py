import re
import time
import socket

from lib.memcache import Client, _ConnectionDeadError, _Error

__file__ = "memq.py"
__author__ = "jiren(jiren@staff.weibo.com)"
__version__ = "1.0.1"
__copyright__ = "Copyright (C) 2019 WEIBO"

import six
if six.PY3:
    from operator import ne as cmp


class Queue(object):
    _DNS_INTERVAL = 60

    def __init__(self, queuestr):
        try:
            arr = re.split('@|:', queuestr)
            self.__key, self.__host, self.__port = arr
        except ValueError:
            raise Exception("Invalid queue string. Need 3 values to unpack but there is %d"%(len(arr)))

        self.__is_domain = False
        self.__dns_time = int(time.time())

        self.__ip_list = []
        self.__queue_list = []

        if not self.__parse():
            raise Exception("Parse queue failed.")

    def __str__(self):
        return ' | '.join([str(item) for item in self.__dict__.values()])

    def __is_ipv4(self, address):
        ipv4_regex = re.compile(
            r'(?:25[0-5]|2[0-4]\d|[0-1]?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3}',
            re.IGNORECASE)
        return True if ipv4_regex.match(address) else False

    def __domain_parse(self):
        ip_list = []
        try:
            ip_list = [item[4][0] for item in socket.getaddrinfo(self.__host, None, 0, socket.SOCK_STREAM)]
            ip_list.sort()
        except:
            pass

        return ip_list

    def __format(self, host, port):
        return '{0}:{1}'.format(host, port)

    def __gen_queue(self):
        return [self.__format(host, self.__port) for host in self.__ip_list]

    def __parse(self):
        if self.__is_ipv4(self.__host):
            self.__queue_list.append(self.__format(self.__host, self.__port))
            return True

        self.__ip_list = self.__domain_parse()
        if not len(self.__ip_list):
            return False

        self.__queue_list = self.__gen_queue()
        self.__is_domain = True

        return True

    def check(self):
        now = int(time.time())
        if self.__is_domain and now - self.__dns_time > Queue._DNS_INTERVAL:
            self.__dns_time = now
            ip_list = self.__domain_parse()
            if ip_list and cmp(ip_list, self.__ip_list):
                self.__ip_list = ip_list
                self.__queue_list = self.__gen_queue()
                return True
        return False

    def get_queue(self):
        return len(self.__queue_list), self.__queue_list

    def get_key(self):
        return self.__key


class Memcache(Client):

    def set_by_key(self, key, idx, val, time=0, min_compress_len=0, noreply=False):
        server = self.servers[idx]
        if not server or not server.connect():
            return False

        cmd = 'set'
        key = self._encode_key(key)

        def _unsafe_set():
            self._statlog(cmd)

            store_info = self._val_to_store_info(val, min_compress_len)
            if not store_info:
                return False
            flags, len_val, encoded_val = store_info
            headers = "%d %d %d" % (flags, time, len_val)
            fullcmd = self._encode_cmd(cmd, key, headers, noreply, b'\r\n', encoded_val)

            try:
                server.send_cmd(fullcmd)
                if noreply:
                    return True
                return server.expect(b"STORED", raise_exception=True) == b"STORED"
            except socket.error as msg:
                if isinstance(msg, tuple):
                    msg = msg[1]
                server.mark_dead(msg)
            return False

        try:
            return _unsafe_set()
        except _ConnectionDeadError:
            # retry once
            try:
                if server.connect():
                    return _unsafe_set()
            except (_ConnectionDeadError, socket.error) as msg:
                server.mark_dead(msg)
            return False

    def get_by_key(self, key, idx):
        server = self.servers[idx]
        if not server or not server.connect():
            return None

        cmd = 'get'
        key = self._encode_key(key)

        def _unsafe_get():
            self._statlog(cmd)

            try:
                fullcmd = self._encode_cmd(cmd, key, 0, 0)

                server.send_cmd(fullcmd)
                rkey = flags = rlen = cas_id = None

                rkey, flags, rlen, = self._expectvalue(
                    server, raise_exception=True
                )

                if not rkey:
                    return None
                try:
                    value = self._recv_value(server, flags, rlen)
                    #if six.PY3:

                    #    value = value.decode('utf-8')
                finally:
                    server.expect(b"END", raise_exception=True)
            except (_Error, socket.error) as msg:
                if isinstance(msg, tuple):
                    msg = msg[1]
                server.mark_dead(msg)
                return None

            return value

        try:
            return _unsafe_get()
        except _ConnectionDeadError:
            # retry once
            try:
                if server.connect():
                    return _unsafe_get()
                return None
            except (_ConnectionDeadError, socket.error) as msg:
                server.mark_dead(msg)
            return None


class MEMQ(object):
    _MISS_TIME = 3

    def __init__(self, queuestr):
        self.__queue = Queue(queuestr)
        self.__key = self.__queue.get_key()
        self.__num, self.__queue_list = self.__queue.get_queue()
        self.__memq = Memcache(self.__queue_list, debug=0)
        self.__last_id = -1
        self.__miss_time = 0

    def __del__(self):
        self.__close()

    def __close(self):
        self.__memq.disconnect_all()

    def __reconnect(self):
        if self.__queue.check():
            self.__num, self.__queue_list = self.__queue.get_queue()
            self.__close()
            self.__memq.set_servers(self.__queue_list)

    def get(self):
        self.__reconnect()
        for i in range(self.__num):
            self.__last_id = (self.__last_id + 1) % self.__num
            value = self.__memq.get_by_key(self.__key, self.__last_id)
            if value is None:
                continue

            self.__miss_time = 0
            return value

        self.__miss_time += 1
        if self.__miss_time > MEMQ._MISS_TIME:
            #self.__miss_time = 0
            time.sleep(1)

        return None

    def set(self, value):
        self.__reconnect()
        for i in range(self.__num):
            self.__last_id = (self.__last_id + 1) % self.__num
            ret = self.__memq.set_by_key(self.__key, self.__last_id, value)
            if not ret:
                continue

            self.__miss_time = 0
            return True

        self.__miss_time += 1
        if self.__miss_time > MEMQ._MISS_TIME:
            self.__miss_time = 0
            time.sleep(1)

        return False


if __name__ == '__main__':
    q = memq.MEMQ("jiren@127.0.0.1:11233")
    q.set('1111')
    q.get()
    pass


