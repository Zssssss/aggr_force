import asyncio
from collections import defaultdict
from typing import List, Dict, Any

import redis
import hashlib

import zlib
# import aioredis
from redis import asyncio as aioredis


class redis_connect:
    def __init__(self):
        self.servers = []
        self.hosts = [
            "pkm26770.eos.grid.sina.com.cn",
            "pkm26771.eos.grid.sina.com.cn",
            "pkm26772.eos.grid.sina.com.cn",
            "pkm26773.eos.grid.sina.com.cn",
            "pkm26774.eos.grid.sina.com.cn",
            "pkm26775.eos.grid.sina.com.cn",
            "pkm26776.eos.grid.sina.com.cn",
            "pkm26777.eos.grid.sina.com.cn"
        ]
        self.ports = [26770, 26771, 26772, 26773, 26774, 26775, 26776, 26777]
        self.load_conn_pools()

    def load_conn_pools(self):
        try:
            for i in range(8):
                redis_client = redis.StrictRedis(host=self.hosts[i], port=self.ports[i], db=0)
                self.servers.append(redis_client)
        except Exception as e:
            print(e)

    def get_hash_index(self, query):
        md5 = hashlib.md5()
        md5.update(query.encode(encoding='utf-8'))
        m = md5.hexdigest()
        map_key = str(m)[-2:]
        return int(map_key, 16) % 8

    def get_redis_server(self, query):
        return self.servers[self.get_hash_index(query)]


TIME_OUT = 3
HEALTH_CHECK_INTERVAL = 1


class AsyncRedisConnect:

    def __init__(self):
        self.servers = []
        self.hosts = [
            "pkm26770.eos.grid.sina.com.cn",
            "pkm26771.eos.grid.sina.com.cn",
            "pkm26772.eos.grid.sina.com.cn",
            "pkm26773.eos.grid.sina.com.cn",
            "pkm26774.eos.grid.sina.com.cn",
            "pkm26775.eos.grid.sina.com.cn",
            "pkm26776.eos.grid.sina.com.cn",
            "pkm26777.eos.grid.sina.com.cn"
        ]
        self.ports = [26770, 26771, 26772, 26773, 26774, 26775, 26776, 26777]
        self.load_conn_pools()

    def load_conn_pools(self):
        for i in range(len(self.hosts)):
            redis_client = aioredis.Redis(host=self.hosts[i], port=self.ports[i], socket_timeout=TIME_OUT,
                                          health_check_interval=HEALTH_CHECK_INTERVAL, 
                                          retry_on_timeout=True)
            self.servers.append(redis_client)

    def get_hash_index(self, query):
        md5 = hashlib.md5()
        md5.update(query.encode(encoding='utf-8'))
        m = md5.hexdigest()
        map_key = str(m)[-2:]
        return int(map_key, 16) % 8

    def get_redis_server(self, query):
        index = self.get_hash_index(query)
        return self.servers[index]
    
    async def batch_get_hash_all_kv(self, hash_keys: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        批量获取多个hash key的所有键值对
        
        Args:
            hash_keys: 要查询的hash key列表
            
        Returns:
            嵌套字典，hash_key -> {field: value} 的映射，如果hash key不存在则不包含在结果中
        """
        async def _batch_get_hash_from_server(redis_server: aioredis.Redis, hash_keys: List[str]) -> Dict[str, Dict[str, Any]]:
            """
            从单个Redis服务器批量获取hash数据
            使用pipeline优化性能
            """
            try:
                result = {}
                
                # 使用pipeline批量执行命令，减少网络往返
                pipe = redis_server.pipeline(transaction=False)
                for hash_key in hash_keys:
                    pipe.hgetall(hash_key)
                
                # 执行pipeline
                hash_results = await pipe.execute()
                
                # 处理结果
                for hash_key, hash_result in zip(hash_keys, hash_results):
                    # 如果hash存在且不为空
                    if hash_result:
                        decoded_hash = {}
                        for field, value in hash_result.items():
                            # 处理字节解码
                            if isinstance(field, bytes):
                                field = field.decode('utf-8')
                            if isinstance(value, bytes):
                                value = value.decode('utf-8')
                            decoded_hash[field] = value
                        
                        if decoded_hash:  # 只有非空的hash才加入结果
                            result[hash_key] = decoded_hash
                
                return result
                
            except Exception as e:
                print(f"Error querying server {redis_server}: {e}")
                return {}

        if not hash_keys:
            return {}
        
        # 按服务器分组hash keys
        server_keys_map = defaultdict(list)
        for hash_key in hash_keys:
            server_index = self.get_hash_index(hash_key)
            server_keys_map[server_index].append(hash_key)
        
        # 并行查询所有服务器
        tasks = []
        for server_index, server_hash_keys in server_keys_map.items():
            task = _batch_get_hash_from_server(self.servers[server_index], server_hash_keys)
            tasks.append(task)
        
        # 等待所有查询完成
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 合并结果
        final_result = {}
        for result in results:
            if isinstance(result, Exception):
                # 处理异常情况，可以根据需要记录日志
                print(f"Error in batch hash query: {result}")
                continue
            final_result.update(result)
        
        return final_result
    
    async def batch_get_hash_specific_fields(self, hash_keys: List[str], fields: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        批量获取多个hash key的指定字段
        
        Args:
            hash_keys: 要查询的hash key列表
            fields: 要获取的字段列表
            
        Returns:
            嵌套字典，hash_key -> {field: value} 的映射
        """
        async def _batch_get_hash_fields_from_server(redis_server: aioredis.Redis, hash_keys: List[str]) -> Dict[str, Dict[str, Any]]:
            """
            从单个Redis服务器批量获取hash指定字段数据
            使用pipeline优化性能
            """
            try:
                result = {}
                
                # 使用pipeline批量执行命令
                pipe = redis_server.pipeline(transaction=False)
                for hash_key in hash_keys:
                    pipe.hmget(hash_key, *fields)
                
                # 执行pipeline
                hash_results = await pipe.execute()
                
                # 处理结果
                for hash_key, hash_result in zip(hash_keys, hash_results):
                    # 构建字段值映射
                    if hash_result:
                        field_values = {}
                        for field, value in zip(fields, hash_result):
                            if value is not None:
                                # 处理字节解码
                                if isinstance(value, bytes):
                                    value = value.decode('utf-8')
                                field_values[field] = value
                        
                        if field_values:  # 只有存在值的hash才加入结果
                            result[hash_key] = field_values
                
                return result
                
            except Exception as e:
                print(f"Error querying server {redis_server}: {e}")
                return {}

        if not hash_keys or not fields:
            return {}
        
        # 按服务器分组hash keys
        server_keys_map = defaultdict(list)
        for hash_key in hash_keys:
            server_index = self.get_hash_index(hash_key)
            server_keys_map[server_index].append(hash_key)
        
        # 并行查询所有服务器
        tasks = []
        for server_index, server_hash_keys in server_keys_map.items():
            task = _batch_get_hash_fields_from_server(self.servers[server_index], server_hash_keys)
            tasks.append(task)
        
        # 等待所有查询完成
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 合并结果
        final_result = {}
        for result in results:
            if isinstance(result, Exception):
                print(f"Error in batch hash field query: {result}")
                continue
            final_result.update(result)
        
        return final_result
    
    async def batch_get(
    self,
    keys: List[str],
    include_missing: bool = False
) -> Dict[str, Any]:
        """
        批量获取多个key的value, 默认未命中的key不返回

        Args:
            keys: 要查询的key列表
            include_missing: 是否将未命中的 key 也加入返回结果中，value=None

        Returns:
            字典: key -> value
        """

        async def _batch_get_from_server(redis_server: aioredis.Redis, keys: List[str]) -> Dict[str, Any]:
            """
            从单个Redis服务器批量获取数据（只返回命中的 key）
            """
            try:
                # 使用mget进行批量查询
                values = await redis_server.mget(keys)

                result = {}
                for key, value in zip(keys, values):
                    if value is not None:
                        # 如果存储的是字节，需要解码
                        if isinstance(value, bytes):
                            result[key] = value.decode('utf-8')
                        else:
                            result[key] = value
                
                return result
            except Exception as e:
                print(f"Error querying server {redis_server}: {e}")
                return {}

        if not keys:
            return {}
        
        # 按服务器分组keys
        server_keys_map = defaultdict(list)
        for key in keys:
            server_index = self.get_hash_index(key)
            server_keys_map[server_index].append(key)
        
        # 并行查询所有服务器
        tasks = []
        for server_index, server_keys in server_keys_map.items():
            tasks.append(_batch_get_from_server(self.servers[server_index], server_keys))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # 合并命中的 key
        merged = {}
        for result in results:
            if isinstance(result, Exception):
                continue
            merged.update(result)

        # 如果不需要补全，则直接返回
        if not include_missing:
            return merged

        # 需要补齐未命中的 key
        final_result = {k: merged.get(k, None) for k in keys}

        return final_result


class RealTimeAsyncRedisConnect(AsyncRedisConnect):
    def __init__(self):
        super().__init__()
        self.servers = []
        self.hosts = [
             "pkm27034.eos.grid.sina.com.cn",
             "pkm27035.eos.grid.sina.com.cn",
             "pkm27036.eos.grid.sina.com.cn",
             "pkm27037.eos.grid.sina.com.cn",
             "pkm27038.eos.grid.sina.com.cn",
             "pkm27039.eos.grid.sina.com.cn",
             "pkm27040.eos.grid.sina.com.cn",
             "pkm27041.eos.grid.sina.com.cn",
             "pkm27042.eos.grid.sina.com.cn",
             "pkm27043.eos.grid.sina.com.cn",
             "pkm27044.eos.grid.sina.com.cn",
             "pkm27045.eos.grid.sina.com.cn",
             "pkm27046.eos.grid.sina.com.cn",
             "pkm27047.eos.grid.sina.com.cn",
             "pkm27048.eos.grid.sina.com.cn",
             "pkm27049.eos.grid.sina.com.cn",
             "pkm27050.eos.grid.sina.com.cn",
             "pkm27051.eos.grid.sina.com.cn",
             "pkm27052.eos.grid.sina.com.cn",
             "pkm27053.eos.grid.sina.com.cn",
             "pkm27054.eos.grid.sina.com.cn",
             "pkm27055.eos.grid.sina.com.cn",
             "pkm27056.eos.grid.sina.com.cn",
             "pkm27057.eos.grid.sina.com.cn",
             "pkm27058.eos.grid.sina.com.cn",
             "pkm27059.eos.grid.sina.com.cn",
             "pkm27060.eos.grid.sina.com.cn",
             "pkm27061.eos.grid.sina.com.cn",
             "pkm27062.eos.grid.sina.com.cn",
             "pkm27063.eos.grid.sina.com.cn",
             "pkm27064.eos.grid.sina.com.cn",
             "pkm27065.eos.grid.sina.com.cn"
        ]
        self.ports = [27034, 27035, 27036, 27037, 27038, 27039, 27040, 27041, 27042, 27043,
                     27044, 27045, 27046, 27047, 27048, 27049, 27050, 27051, 27052, 27053,
                     27054, 27055, 27056, 27057, 27058, 27059, 27060, 27061, 27062, 27063,
                     27064, 27065]
        self.load_conn_pools()

    def get_hash_index(self, query):
        md5 = hashlib.md5()
        md5.update(query.encode(encoding='utf-8'))
        m = md5.hexdigest()
        map_key = str(m)[-2:]
        return int(map_key, 16) % len(self.hosts)



class JingXuanAsyncRedisConnect(AsyncRedisConnect):
    def __init__(self):
        super().__init__()
        self.servers = []
        self.hosts = [
                'pkm26754.eos.grid.sina.com.cn',
                'pkm26755.eos.grid.sina.com.cn',
                'pkm26756.eos.grid.sina.com.cn',
                'pkm26757.eos.grid.sina.com.cn',
                'pkm26758.eos.grid.sina.com.cn',
                'pkm26759.eos.grid.sina.com.cn',
                'pkm26760.eos.grid.sina.com.cn',
                'pkm26761.eos.grid.sina.com.cn'
        ]
        self.ports = [26754, 26755,26756,26757,26758,26759,26760,26761]
        self.load_conn_pools()

    def get_hash_index(self, query):
        return zlib.crc32(query.encode('utf-8')) % 8


# redis_client = redis_connect()
async_redis_client = AsyncRedisConnect()
real_time_async_redis_client = RealTimeAsyncRedisConnect()
jing_xuan_async_redis_client = JingXuanAsyncRedisConnect()
# old_redis_client = redis.StrictRedis(host='pkm25152.eos.grid.sina.com.cn', port=25152, db=0)
async_old_redis_client = aioredis.Redis(host='pkm25152.eos.grid.sina.com.cn', port=25152, socket_timeout=TIME_OUT,
                                          health_check_interval=HEALTH_CHECK_INTERVAL)
