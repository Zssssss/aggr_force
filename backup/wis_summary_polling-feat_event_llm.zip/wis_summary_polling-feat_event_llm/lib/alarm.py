# -*- coding: utf-8 -*-
import urllib
import urllib.parse
import urllib.request
import socket
from base import Base


class Alarm(Base):

    def alarm(self, content, group='wis_analysis', title='智搜分析异常报警'):
        hostname = socket.gethostname()
        re_param = {'content': "[{}] ".format(hostname) + content, 'group': group, 'title': title}
        re_param = urllib.parse.urlencode(re_param)
        alarm_api = "http://falcon.search.weibo.com/falcon/alarm?%s" % re_param
        req = urllib.request.Request(url=alarm_api)
        try:
            res = urllib.request.urlopen(req, timeout=3)
            res = res.read().strip()
            self.logger.info("alarm send alarm content: {}, res: {}".format(content, res))
        except Exception as e:
            self.logger.error("alarm exception:{}, content: {}".format(e, content))
