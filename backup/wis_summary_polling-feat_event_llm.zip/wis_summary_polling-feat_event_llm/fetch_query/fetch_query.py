import hashlib
import asyncio
import time
from redis.asyncio import Redis
import aiohttp
from datetime import datetime

# 超时和健康检查配置
TIME_OUT = 3
HEALTH_CHECK_INTERVAL = 1

# 热搜接口URL
url_hot_main_band = 'http://was.search.weibo.com/was/was.php/innerApi/api?key=rank_net_list'
url_fun_band = 'http://was.search.weibo.com/was/was.php/innerApi/api?key=fun_out_inside_list'


class AsyncRedisConnect:
    def __init__(self):
        self.servers = []
        self.hosts = [
            "pkm26770.eos.grid.sina.com.cn",
            "pkm26771.eos.grid.sina.com.cn",
            "pkm26772.eos.grid.sina.com.cn",
            "pkm26773.eos.grid.sina.com.cn",
            "pkm26774.eos.grid.sina.com.cn",
            "pkm26775.eos.grid.sina.com.cn",
            "pkm26776.eos.grid.sina.com.cn",
            "pkm26777.eos.grid.sina.com.cn"
        ]
        self.ports = [26770, 26771, 26772, 26773, 26774, 26775, 26776, 26777]

    async def load_conn_pools(self):
        for i in range(len(self.hosts)):
            redis_client = Redis(
                host=self.hosts[i],
                port=self.ports[i],
                socket_timeout=TIME_OUT,
                health_check_interval=HEALTH_CHECK_INTERVAL,
                retry_on_timeout=True,
                decode_responses=True
            )
            self.servers.append(redis_client)

    def get_hash_index(self, query):
        md5 = hashlib.md5()
        md5.update(query.encode(encoding='utf-8'))
        m = md5.hexdigest()
        map_key = str(m)[-2:]
        return int(map_key, 16) % 8

    def get_redis_server(self, query):
        index = self.get_hash_index(query)
        return self.servers[index]


# 全局 redis 连接实例
async_redis_client = AsyncRedisConnect()


async def store_to_redis(query, prefix="wis_summary_polling_gaokao"):
    """存储查询到Redis"""
    if not query:
        return False

    try:
        redis_server = async_redis_client.get_redis_server(query)
        current_time = int(time.time())
        key = f"{prefix}{query}"
        await redis_server.set(key, current_time, ex=86400 * 192)
        return True
    except Exception as e:
        print(f"❌ 存储到Redis时出错: {e}")
        return False


async def fetch_hot_data(url):
    """获取热搜榜数据"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=5) as response:
                if response.status == 200:
                    data = await response.json()
                    if url == url_fun_band and isinstance(data, dict) and "realtimehot" in data:
                        return data.get("realtimehot", [])
                    return data
                print(f"❌ 获取 {url} 失败，状态码: {response.status}")
    except Exception as e:
        print(f"❌ 请求 {url} 时出错: {e}")
    return None


async def store_hot_data(hot_data, prefix):
    """存储热搜数据到Redis，并返回成功条数"""
    if not hot_data or not isinstance(hot_data, list):
        return 0

    tasks = [store_to_redis(item.get('word'), prefix=prefix) for item in hot_data if item.get('word')]
    if tasks:
        results = await asyncio.gather(*tasks, return_exceptions=True)
        success_count = sum(1 for r in results if r is True)
        return success_count
    return 0


async def process_hot_bands():
    """处理两个热搜榜数据"""
    main_band_data = await fetch_hot_data(url_hot_main_band)
    fun_band_data = await fetch_hot_data(url_fun_band)

    total_count = 0

    if main_band_data:
        print(f"获取到主要热搜榜数据，共 {len(main_band_data)} 条")
        count = await store_hot_data(main_band_data, prefix="wis_summary_polling_gaokao")
        print(f"已存储主要热搜榜条数: {count}")
        total_count += count

    if fun_band_data:
        print(f"获取到娱乐热搜榜数据，共 {len(fun_band_data)} 条")
        count = await store_hot_data(fun_band_data, prefix="wis_summary_polling_gaokao")
        print(f"已存储娱乐热搜榜条数: {count}")
        total_count += count

    print(f"🕒 当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 本轮共存储: {total_count} 条\n",flush=True)

    return total_count


async def main():
    """主函数"""
    await async_redis_client.load_conn_pools()

    try:
        while True:
            await process_hot_bands()
            await asyncio.sleep(60)
    except KeyboardInterrupt:
        print("🛑 程序被用户中断")
    except Exception as e:
        print(f"❌ 程序运行出错: {e}")


if __name__ == "__main__":
    asyncio.run(main())