#!/bin/bash

MODULE_PATH="fetch_query"
LOG_FILE="rank.log"
PID_FILE="rank.pid"

# 启动模块
nohup python3 -m $MODULE_PATH > $LOG_FILE 2>&1 &
echo $! > $PID_FILE
echo "✅ $MODULE_PATH started with PID $(cat $PID_FILE)"