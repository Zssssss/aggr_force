# -*- coding:utf-8 -*-
from sse_starlette.sse import EventSourceResponse
import json
import uvicorn
import asyncio
import traceback
import time
from fastapi import FastAPI, Body
from fastapi.responses import JSONResponse
from lib.safe_logger import get_logger
from lib.base import Base
from refector_web_server.override_stream import OverrideStreamSummaryInput, OverrideStreamLLM
from refector_web_server.web_setting import host, port, proc_name, workers


app = FastAPI()
pid = str(port)
log_filename = "log/" + "refector-web-server" + "-" + str(pid) + ".log"
logger = get_logger(log_filename, "refector-web-server")

class OverrideOutput(Base):
    async def run(self, **kwargs):
        pass


class OverrideStreamSummary(Base):

    async def single_query(self, query, base_length, trace_id):
        try:
            weibo = await OverrideStreamSummaryInput(pid, query).run()
            weibo["trace_id"] = trace_id
            weibo["traceid"] = trace_id
            llm = OverrideStreamLLM(weibo, OverrideOutput(pid), pid, base_length)
            await llm.run()
            return weibo
        except Exception as e:
            self.logger.exception("summary exception: {}, msg: {}".format(e, traceback.format_exc()))
        return None

@app.post("/v1/wis_summary")
async def wis_response(payload: dict = Body(...)):
    try:
        start_time = time.time()
        search_querys = payload.get('search_querys', [])
        materials_length = payload.get('materials_length', 30000)
        trace_id = payload.get('trace_id', '')

        logger.info(f"trace_id: {trace_id}\tsearch_querys:{json.dumps(search_querys, ensure_ascii=False)}\t"
                    f"materials_length:{materials_length}")
        if search_querys:
            materials_length /= len(search_querys)

        # 并发处理所有查询
        tasks = []
        for search_query in search_querys:
            tasks.append(OverrideStreamSummary(pid).single_query(search_query, materials_length, trace_id))
        
        weibos = await asyncio.gather(*tasks)

        # 整合材料
        materials = ""
        for weibo in weibos:
            if not weibo:
                continue
            content_str = weibo.get("content", "")
            account_content_str = weibo.get("account_content", "")
            opinion_str = weibo.get("opinion", "")
            knowledge_str = weibo.get("knowledge", "")
            
            # 过滤空内容并拼接
            valid_contents = [content for content in [content_str, account_content_str, opinion_str, knowledge_str] if content.strip()]
            if valid_contents:
                materials += "\n".join(valid_contents) + "\n"
        logger.info(f"trace_id: {trace_id} search_querys: {search_querys} materials_len: {len(materials)} cost: {time.time() - start_time}")
        return JSONResponse({
            "status": 200,
            "msg": "",
            "data": {
                "materials" : materials,
                "materials_length" : len(materials)
            }
        })
        
    except Exception as e:
        logger.exception(f"wis_response error: {e}")
        error_response = {
            "status": 400,
            "error": str(e)
        }
        return error_response


if __name__ == '__main__':
    uvicorn.run(app=f'{proc_name}:app', host=host, port=port, workers=workers)