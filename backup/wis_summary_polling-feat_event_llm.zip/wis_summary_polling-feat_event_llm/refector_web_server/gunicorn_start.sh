#!/bin/bash

# Kill existing gunicorn processes running the refector_web_server
ps -ef | grep "refector_chat_server" | grep "gunicorn" | awk '{print $2}' |grep -v PID | xargs kill -9

# Print a message
echo "refector_web_server starting..."

# Start the server with nohup and redirect output to refector_web_server.log
nohup /data1/zsss/miniforge3/envs/zsss/bin/python -m gunicorn -k uvicorn.workers.UvicornWorker -c refector_web_server/web_setting.py refector_web_server.refector_chat_server:app > refector_chat_server.log 2>&1 &

# We added 2>&1 to redirect stderr to stdout so that both are in the log file.

# Print a message
echo "refector_web_server started"