#!/bin/bash

# 目标日志目录
MOUNTPOINT="/data1/"
LOGDIR="/data1/minisearch/upload/LLM_TASK/wis_summary_ds/log/"

# 设定磁盘使用率阈值（百分比）
THRESHOLD=95

# 获取当前磁盘使用率（%）
get_usage() {
    df -h "$MOUNTPOINT" | awk 'NR==2 {print $5}' | sed 's/%//'
}

# 获取最早的日期文件夹
get_oldest_folder() {
    find "$LOGDIR" -maxdepth 1 -type d | grep -E "/[0-9]{4}-[0-9]{2}-[0-9]{2}$" | sort | head -n 1
}

# 获取当前磁盘占用率
USED_PERCENT=$(get_usage)
echo "当前磁盘占用率: $USED_PERCENT%，阈值: $THRESHOLD%"

# 如果磁盘占用率超过阈值，则按日期顺序删除最早的日志文件夹
if [[ $USED_PERCENT -ge $THRESHOLD ]]; then
    OLDEST_FOLDER=$(get_oldest_folder)

    if [[ -z "$OLDEST_FOLDER" ]]; then
        echo "未找到符合格式的日志文件夹，无法继续删除。"
        break
    fi

    echo "正在删除文件夹: $OLDEST_FOLDER"
    rm -rf "$OLDEST_FOLDER"

    # 更新磁盘使用率
    USED_PERCENT=$(get_usage)
    echo "更新后的磁盘占用率: $USED_PERCENT%"
else
    echo "磁盘占用率未超过阈值，无需删除。"
fi

echo "清理完成"